/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once
#ifndef COUPONPROCESSMANAGERDERIVED_H
#define COUPONPROCESSMANAGERDERIVED_H
#include "GamesCore/CouponProcessManager.h"
#include "GamesCore/CouponUtilitiesDerived.h"
#include "PlaySlipDataDerived.h"
#include <QDBusError>
/**
 * @file CouponProcessManagerDerived.h
 * @class CouponProcessManagerDerived
 * @brief Override CouponProcessManager
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */

#define NUMBER_OF_CAMERA_MARKS 1000
// That's how data come from MiniLot's Camera
typedef struct {
	int32_t unused1;
	int32_t unused2;
	int32_t iPrimaRiga;
	uint16_t iNoOfMarks;
	uint16_t camMarks[NUMBER_OF_CAMERA_MARKS];
	struct timeval mTime;
}__attribute__((packed)) SMiniLotCouponDatMarks;

class CouponProcessManagerDerived : public CouponProcessManager
{
	Q_OBJECT

public:
	explicit CouponProcessManagerDerived ( QObject* parent = 0 );

	enum class BoxType {
		Invalid,
		AdditionalGame,
		AdditionalGamePerArea,
		QP,
		Void,
		Mark,
		Multiplier,
		Multidraw
	};

	enum PrognosticsFlag
	{
		Invalid    = 0,
		HomeWin    = 1,
		Draw       = 1 << 1,
		VisitorWin = 1 << 2,

		// aliases
		HomeDraw        = HomeWin  | Draw,
		HomeVisitor     = HomeWin  | VisitorWin,
		DrawVisitor     = Draw     | VisitorWin,
		HomeDrawVisitor = HomeDraw | VisitorWin
	};
	Q_DECLARE_FLAGS (PrognosticsFlags, PrognosticsFlag)



private:

	void processCameraCoupon ( const QByteArray& qbaCouponData ) Q_DECL_OVERRIDE;
	void processGuiFlexBetData ( const QByteArray& ) Q_DECL_OVERRIDE;
	void updateCouponCost ( GamesConfig&, const Coupon& ) Q_DECL_OVERRIDE;
	void promptForGeneralError ( const QString& qsDisplayText, const QString& qsBtn1Text, const QString& qsMsgBoxTitle, int iTimeOut = 10000) Q_DECL_OVERRIDE;
	void procceedOnDuplicateDataSlot ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData ) Q_DECL_OVERRIDE;
	void createCouponDataFromGameTxData ( const QByteArray&, Coupon&, GamesConfig *const ) Q_DECL_OVERRIDE;
	void finalizeQpPlay ( GamesConfig&, Coupon&, ExternalPlay& ) Q_DECL_OVERRIDE;

	CouponError checkForCouponErrors ();
	QString initializeCouponDataFromMarks (const quint16* pCamMarks, quint16 iSize, qint32 iRiga);
	QString initializePollaGolFromMarks(const quint16* pCamMarks, quint16 iSize, qint32 iRiga);
	void promptForCouponErrors ( const QString& qsDisplayText );
	void makePollaGolQP(QVariantMap& mMatches);
	void promptForCost ();

	QScopedPointer<CouponUtilitiesDerived> m_pcCouponUtilitiesDerived;

	GamesConfig m_cGamesConfig;
	Coupon m_cCouponData;
	QMetaObject::Connection  m_msgBoxConnection;
	QScopedPointer<PDIPlayslipProject> m_pcPlaySlipProject;

	//Fixed characters length for each area game
	static const int iNoOfDigitsInEachAreaLotto       = 33;
	static const int iNoOfDigitsInEachAreaSuperLotto  = 49;
	static const int iNoOfDigitsInEachAreaMark        = 25;
	static const int iNoOfDigitsInEachAreaKeno        = 26;

	QMap<qint32,QVariantMap> m_mSlips;
	QVariantMap m_mLotoSlip;
	QVariantMap m_mLoto3Slip;
	QVariantMap m_mLoto4Slip;
	QVariantMap m_mRachaSlip;
	QVariantMap m_mPollaGolSlip;

	bool m_bIsTraining = false;
};
Q_DECLARE_OPERATORS_FOR_FLAGS(CouponProcessManagerDerived::PrognosticsFlags)

#endif // COUPONPROCESSMANAGERDERIVED_H
