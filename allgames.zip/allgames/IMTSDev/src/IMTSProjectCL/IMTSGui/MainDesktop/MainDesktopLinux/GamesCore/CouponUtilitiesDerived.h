/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once
#ifndef COUPONUTILITIESDERIVED_H
#define COUPONUTILITIESDERIVED_H
#include "CheckCoupon/CouponUtilities.h"
/**
  * @file CouponUtilitiesDerived.h
  * @class CouponUtilitiesDerived
  * @brief Override default stuff.
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
class CouponUtilitiesDerived : public CouponUtilities
{
public:
	explicit CouponUtilitiesDerived ( QObject* parent = 0 );

	QString promptForCost (const int& iGameCode, const double& dCouponCost );
	QString promptForCombinations (const int& iGameCode, const Coupon& couponData );
	static QString getCouponStringErrorsInArea ( GamesConfig*const );
	void checkAdditionalGamePerArea (const int& iArea, GamesConfig*const gameConfig, const Coupon& couponData, const bool& bHasAnAreaMarked, CouponError& couponError );
	void customCheckPickGameCoupon ( GamesConfig*const , const Coupon&, const bool&, CouponError& );

	qint32 pickXGetNumbersSet ( GamesConfig*const gameConfig, const Coupon &couponData, const qint32 &iArea );

	qint32 getMultiplier (GamesConfig*const, const Coupon&, const qint32 iArea);

	QString potentialWinnings( GamesConfig*const pcGameConfig, const Coupon& couponData );

	double getAdditionalGameCostPerArea ( GamesConfig*const gameConfig, const Coupon &couponData, const int& iArea );

	quint16 countSystemPickBoxCombos ( GamesConfig*const gameConfig, const Coupon& couponData, const int& iArea);

	static bool isPollaGolValid (const qint32& iDoubles, const qint32& iTriples);
	static qint32 getPollaGolColumns (const qint32& iDoubles, const qint32& iTriples);


private:
};

#endif // COUPONUTILITIESDERIVED_H
