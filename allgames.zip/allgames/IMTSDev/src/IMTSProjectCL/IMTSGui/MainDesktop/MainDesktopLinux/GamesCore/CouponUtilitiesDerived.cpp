/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file CouponUtilitiesDerived.h
  * @class CouponUtilitiesDerived
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include "CouponUtilitiesDerived.h"
#include "../ProjectGameCodes.h"
#include "ImtsGamesEnums.h"
#include "FormatAmount/FormatAmount.h"
#include <QSettings>
#include <QStringBuilder>
#include <QDebug>


// map<Pair<doubles,triples>, columns>>
static const QMap<QPair<qint32,qint32>,qint32> mPOLLAGOL_DOUBLE_TRIPLES =
{

	{qMakePair(1,0),2},
	{qMakePair(0,1),3},
	{qMakePair(2,0),4},
	{qMakePair(1,1),6},
	{qMakePair(3,0),8},
	{qMakePair(0,2),9},
	{qMakePair(2,1),12},
	{qMakePair(4,0),16},
	{qMakePair(1,2),18},
	{qMakePair(3,1),24},
	{qMakePair(0,3),27},
	{qMakePair(5,0),32},
	{qMakePair(2,2),36},
	{qMakePair(4,1),48},
	{qMakePair(1,3),54},
	{qMakePair(6,0),64},
	{qMakePair(3,2),72},
	{qMakePair(0,4),81},
	{qMakePair(5,1),96},
	{qMakePair(2,3),108},
	{qMakePair(7,0),128},
	{qMakePair(4,2),144},
	{qMakePair(1,4),162},
	{qMakePair(6,1),192},
	{qMakePair(3,3),216}
};

CouponUtilitiesDerived::CouponUtilitiesDerived ( QObject* parent )
	: CouponUtilities ( parent )
{
}



/**
 * @sa getMultiplier
 * @param gameConfig
 * @param couponData
 * @param iArea
 * @return
 */
qint32 CouponUtilitiesDerived::getMultiplier (GamesConfig*const gameConfig, const Coupon& couponData, const qint32 iArea)
{
	auto iMultiplier = 0;

	if (IS_PICK(gameConfig->readGameCode ()) ) {

		QVariantMap mMultipliers = couponData.getArea (iArea)->getCustomData ();

		for (const auto pair : mMultipliers.toStdMap ()) {
			iMultiplier += pair.second.toInt ();
		}

	} else {
		iMultiplier = CouponUtilities::getMultiplier (gameConfig,couponData,iArea);
	}

	// This method could return a 0 multiplier. In general this is wrong, because multiplier's default value should be 1.
	// However, the way Loto3 game works where multiplier is bind with pickPlayType we got to return a 0 multiplier.

	return iMultiplier;

}

/**
 * @sa pickXGetNumbersSet
 * @param gameConfig
 * @param couponData
 * @param iArea
 * @return columns for Chile combo play type
 * @brief pickXGetNumbersSet method calculates the number or columns for Combo play type. Combos just consist
 * of permutations where each one is played as straight, and that adds additional cost. For Chile we've defined TrioPar to be a Combo play type.
 * I don't know whether this is right or wrong. Nevertheless, their TrioPar should not produce 3 columns, as a Combo
 * play type would do, but just one column. Override method and produce 1 column!!!
 */
qint32 CouponUtilitiesDerived::pickXGetNumbersSet ( GamesConfig*const gameConfig, const Coupon &couponData, const qint32 &iArea )
{
	quint16 iColumns = CouponUtilities::countCombos (gameConfig, couponData, iArea);
	return qint32(iColumns);
}

/**
 * @sa countSystemPickBoxCombos
 * @param iArea
 * @return 0 fhor Chile Loto3 game
 */
quint16 CouponUtilitiesDerived::countSystemPickBoxCombos( GamesConfig*const, const Coupon&, const int&)
{
	return 0;
}


/**
 * @sa promptForCost
 * @param iGameCode
 * @param dCouponCost
 * @return the cost warning messages based on costWarning values set in config
 */
QString CouponUtilitiesDerived::promptForCost ( const int& iGameCode, const double& dCouponCost )
{

	QSettings settings( QStringLiteral ("Intralot"), QStringLiteral ("ImtsProjectDependentConfig") );
	bool bShowWarning = false;
	QString qsWarning = QString ();
	qsWarning.reserve (512);
#pragma message ("TODO: NONDAS add cost warnings here")
//    if ( (iGameCode == LOTTO          && dCouponCost >= settings.value( QStringLiteral("CostWarning/Lotto"),        QVariant(10.)).toDouble ()) ||
//         (iGameCode == EURO_MILLIONS  && dCouponCost >= settings.value( QStringLiteral("CostWarning/EuroMillions"), QVariant(10.)).toDouble ()) ||
//         (iGameCode == DAILY_MILLION  && dCouponCost >= settings.value( QStringLiteral("CostWarning/DailyMillion"), QVariant(10.)).toDouble ()) ||
//         (iGameCode == LOTTO_54321    && dCouponCost >= settings.value( QStringLiteral("CostWarning/Lotto54321"),   QVariant(10.)).toDouble ()) ) {

//	bShowWarning = true;
//	}

	if ( bShowWarning ) {
		qsWarning = QString(tr("Cost for current play is %1").arg (FormatAmount::getFormatedAmount( dCouponCost )));
		qsWarning += QString(tr("\nWould you like to proceed?"));
	}

	return qsWarning;
}

/**
 * @sa promptForCombinations --- CH_Polla Chilena
 * @param iGameCode
 * @param couponData
 * @return returns the information (text) to be added to the 'cost warning' text regarding the Area's Combinations
 */
QString CouponUtilitiesDerived::promptForCombinations (const int& iGameCode, const Coupon& couponData )
{
	QString qsWarning = QString ();
	qsWarning.reserve (512);

	qsWarning = QString(tr("The number of combinations is %1 \n").arg (couponData.getCouponColumns()));

	return qsWarning;
}

/**
 * @sa potentialWinnings
 * @param the multiplier's index regarding the corresponding play type (i.e., 1, 2, ..., 5)
 * @param the multiplier
 * @brief This function calculates and returns the potential winning amount for the given multiplier selection.
 */
QString CouponUtilitiesDerived::potentialWinnings ( GamesConfig*const pcGameConfig, const Coupon& couponData )
{
	// Look up table that comes in handy to resolve a PickXTypeString to actual type
	static QMap<QString,ImtsGamesEnums::PickXPlayTypeFlags> typeStringToType = {
		{QStringLiteral("Straight")     , ImtsGamesEnums::Straight},
		{QStringLiteral("Combo")        , ImtsGamesEnums::Combo },
		{QStringLiteral("Box")          , ImtsGamesEnums::Box},
		{QStringLiteral("Pairs")        , ImtsGamesEnums::FrontBackPairs},
		{QStringLiteral("LastDigit")    , ImtsGamesEnums::LastDigit}
	};

	auto dPotWinnings = 0.0;
	auto iMultiplier = 1;

	for (auto iArea = 0; iArea < pcGameConfig->readNumberOfAreas (); ++iArea ) {

		QVariantMap mMultipliers = couponData.getArea (iArea)->getCustomData ();

		for (const auto pair : mMultipliers.toStdMap ()) {

			iMultiplier = pair.second.toInt ();

			switch (typeStringToType.value (pair.first)) { // These values are specified by Polla Chilena.
			case ImtsGamesEnums::Straight:
				dPotWinnings += 400.*iMultiplier;
				break;
			case ImtsGamesEnums::Combo:
				dPotWinnings += 130.*iMultiplier;
				break;
			case ImtsGamesEnums::Box:
				dPotWinnings += 65.*iMultiplier;
				break;
			case ImtsGamesEnums::FrontBackPairs:
				dPotWinnings += 20.*iMultiplier;
				break;
			case ImtsGamesEnums::LastDigit:
				dPotWinnings += 4.*iMultiplier;
				break;
			default:
				break;
			}
		}
	}
	return FormatAmount::getFormatedAmount(dPotWinnings);

}

/**
 * @sa getCouponStringErrorsInArea
 */
QString CouponUtilitiesDerived::getCouponStringErrorsInArea ( GamesConfig*const pGamesConfig )
{
	QString qsErrorString = QString();

	CouponError cLastCouponErrors = CouponUtilities::getLastCouponErrors ();

	if ( !cLastCouponErrors.isEmpty () ) {

		qsErrorString += cLastCouponErrors.getCouponErrorsInArea( 100 );

		QList<CouponErrorDefinitions::eeCouponParsingError> lAreaErrorsIds;
		lAreaErrorsIds.clear ();
		for ( int iArea = 0; iArea < pGamesConfig->readNumberOfAreas (); ++iArea ) {

			lAreaErrorsIds = cLastCouponErrors.getCouponErrorIdsInArea( iArea );

			for ( int iError = 0; iError < lAreaErrorsIds.size (); ++iError ) {

				qsErrorString = qsErrorString %	tr("Panel %1 ").arg(QChar('A'+iArea)) %	ErrorHandling::getCouponErrors (lAreaErrorsIds.at (iError) ) %	QStringLiteral("\n");
			}

		}
	}

	return qsErrorString;
}


/**
 * @brief CouponUtilitiesDerived::checkAdditionalGamePerArea
 * @param iArea
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief checks errors on the additional game. Project specific
 */
void CouponUtilitiesDerived::checkAdditionalGamePerArea (const int& iArea, GamesConfig*const cGamesConfig, const Coupon& couponData, const bool&, CouponError& couponErrors )
{

	if ( cGamesConfig->readGameCode() == LOTO_CL ) {

		QVariantMap mAdditionalGamesPerArea  = couponData.getArea (iArea)->getAdditionalGamePerArea();

		auto bWrongAddOnCombination = false;
		for (int i=0; i < mAdditionalGamesPerArea.size(); i++) {

			if ( mAdditionalGamesPerArea.contains("Jubilazo") && !mAdditionalGamesPerArea.contains("Ahora si que si!") && mAdditionalGamesPerArea.size() < 4 ) {
				bWrongAddOnCombination = true;
			}
			if ( mAdditionalGamesPerArea.contains("Ahora si que si!") && !mAdditionalGamesPerArea.contains("Desquite") && mAdditionalGamesPerArea.size() < 3 ) {
				bWrongAddOnCombination = true;
			}
			if ( mAdditionalGamesPerArea.contains("Multiplicador") && mAdditionalGamesPerArea.size() < 3 ) {
				bWrongAddOnCombination = true;
			}
			if ( mAdditionalGamesPerArea.contains("Desquite") && !mAdditionalGamesPerArea.contains("Revancha") && mAdditionalGamesPerArea.size() < 2 ) {
				bWrongAddOnCombination = true;
			}

		}
		if (bWrongAddOnCombination) {
			couponErrors.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_ADDITIONAL_GAME_SELECTIONS);
		}
	}
}

/**
 * @sa customCheckPickGameCoupon
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief The minimum number of participations the player will need to select in order for the ticket
 * to be accepted by the Central System will be 2; this means there need to be 2 playtypes selected
 * for the same 3digit number or select at least $200 in order for a ticket to be valid
 */
void CouponUtilitiesDerived::customCheckPickGameCoupon ( GamesConfig*const gameConfig, const Coupon& couponData, const bool&, CouponError& couponError)
{
	if (getMultiplier(gameConfig,couponData,0)<200) {
		couponError.setCouponError (100,CouponErrorDefinitions::LOWER_LIMIT_COST);
	}
}

/**
 * @sa getAdditionalGameCostPerArea
 * @param gameConfig
 * @param couponData
 * @return additional games cost per area. Applies only in case the additional games is in per area basis.
 */
double CouponUtilitiesDerived::getAdditionalGameCostPerArea ( GamesConfig*const gameConfig, const Coupon &couponData, const int& iArea )
{
	double dAdditionalGameCost = 0.;
	QVariantList lAdditionalGameList = gameConfig->readAdditionalGamePerArea();
	QVariantMap selectedAddOns = couponData.getArea (iArea)->getAdditionalGamePerArea ();

	if ( gameConfig->readGameCode() == RACHA_CL ) {

		bool bAllAdditionalGamesSelected = true;

		for ( int addOn = 0; addOn < lAdditionalGameList.length(); addOn++ ) {
			if ( !selectedAddOns.contains( lAdditionalGameList.at(addOn).toMap().value( QStringLiteral("Name") ).toString() ) ) {
				bAllAdditionalGamesSelected = false;
			}
		}

		if ( bAllAdditionalGamesSelected || selectedAddOns.isEmpty() ) {
			dAdditionalGameCost = 200;
		}

	}


	return dAdditionalGameCost;
}

/**
 * @sa isPollaGolValid
 * @param iDoubles
 * @param iTriples
 * @return
 */
bool CouponUtilitiesDerived::isPollaGolValid (const qint32& iDoubles, const qint32& iTriples)
{
	return mPOLLAGOL_DOUBLE_TRIPLES.value (qMakePair(iDoubles,iTriples))>0;
}

/**
 * @sa getPollaGolColumns
 * @param iDoubles
 * @param iTriples
 * @return
 */
qint32 CouponUtilitiesDerived::getPollaGolColumns (const qint32& iDoubles, const qint32& iTriples)
{
	return mPOLLAGOL_DOUBLE_TRIPLES.value (qMakePair(iDoubles,iTriples));
}
