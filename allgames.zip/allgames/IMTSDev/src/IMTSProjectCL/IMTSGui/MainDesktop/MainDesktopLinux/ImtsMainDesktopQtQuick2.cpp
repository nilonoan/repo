/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file ImtsMainDesktopQtQuick2.cpp
  * @class ImtsMainDesktopQtQuick2
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include <QtCore/QtDebug>
#include <QtWidgets/QApplication>
#include "ImtsMainDesktopQtQuick2.h"
#include "PClubSessionManager/PClubSessionManager.h"
#include "LocalEventLoggerEvents.h"
#include "Muse/IMTSMuse.h"
#include "GetConfigValue.h"
#include <QtQml/QQmlExtensionPlugin>
#include <QtCore/QPluginLoader>
#include "DbusWrapper.h"
#include "IMTSDbusArmInterfaces/DbusWrapperArm.h"
#include "JsonOperations.h"
#include "ImtsEnumerations.h"
#include "GetConfigValue.h"
#include "Dialogs/QmlMessageBox.h"
#include "Nvram/Nvram.h"
#include "GameChip.h"
#include "GamesCore/PollaGol.h"
#include <QtQml/QQmlEngine>

/**
  * @sa ImtsMainDesktopQtQuick2
  * @param parent
  * @brief ImtsMainDesktopQtQuick2 constructor
  */
ImtsMainDesktopQtQuick2::ImtsMainDesktopQtQuick2 ( QWindow* parent )
	: ImtsViewerQtQuick2 ( parent )
	, m_pid ( 0 )
	, m_bScreenSaverEnabled ( false )
	, m_qsLocale ( "es-cl")
{

	setUpDBusInterface (); // so that we expose our desktop to d-Bus-

	m_pcProjectDependentConfig = new ProjectDependentConfig ( true/*DBusSupport*/, this);

	setObjectName (QStringLiteral("ImtsMainDesktop"));

	engine ()->addImportPath ("/IMTSResources/IMTSUiMaterial");

	IMTSMuse muse;
	muse.playSoundEffectSlot ( IMTSMuse::SND_STARTUP );

	setResizeMode ( QQuickView::SizeRootObjectToView);

	m_pcPleaseWaitNew = new PleaseWaitNew (this);
	m_pcProgressDialog = new ProgressDialog (this);

	m_pcQDeclarativeContext = rootContext (); // Setup context
	m_pcQDeclarativeContext->setContextProperty ("PleaseWaitBackEnd",     m_pcPleaseWaitNew); // expose this object to QML
	m_pcQDeclarativeContext->setContextProperty ("ProgressDialogBackEnd", m_pcProgressDialog); // expose this object to QML
	m_pcQDeclarativeContext->setContextProperty ("ImtsMainWindowBackEnd", this);
	m_pcQDeclarativeContext->setContextProperty ("ProjectDependentConfigBackEnd", m_pcProjectDependentConfig );


	// Update SCM as well as block access to coupons and playslips
	DbusWrapper::getConfigManagerInterface ()->setSignOn   (false);
	DbusWrapper::getConfigManagerInterface ()->setTraining (false);
	DbusWrapper::getConfigManagerInterface ()->setUserAndPass (QString(),QString());
	DbusWrapper::getConfigManagerInterface ()->setLoginIdentity (UserLoginType::InvalidIdentity);

#if defined IMTS_ARM
	DbusWrapperArm::setEnabled (false);
#else
	DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (false);
#endif

	DbusWrapper::getConfigManagerInterface ()->setCouponProcessingBlocked ( true );
	DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked ( true );

	m_pid = QCoreApplication::applicationPid();
	QString qsMsg = QString(QStringLiteral("Application: %1 with pid: %2 started")).arg (qAppName ()).arg(m_pid);
	LOG ( qsMsg );
	qDebug () << qsMsg;


	QObject::connect ( this, &ImtsMainDesktopQtQuick2::changeLanguage, this, &ImtsMainDesktopQtQuick2::changeLanguageSlot );


	QMap<QString,QString> mPluginMap; // key: uri, value: plugin path&name
#if defined(IMTS_LINUX) // MAC or LINUX
#if defined(IMTS_MACOSX_PORT) // MAC
	mPluginMap.insert (QStringLiteral("ImtsQmlUtilities"),       QStringLiteral("/usr/local/lib/libIMTS_LINUX_qmlutilitiesplugin.dylib" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlUtilitiesDerived"),QStringLiteral("/usr/local/lib/libIMTS_LINUX_clqmlplugin.dylib" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModels"),          QStringLiteral("/usr/local/lib/libIMTS_LINUX_qmlmodelsplugin.dylib" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModelsDerived"),   QStringLiteral("/usr/local/lib/libIMTS_LINUX_clqmlmodelsplugin.dylib" ) );

	loadPlugins (mPluginMap);
	addPluginPath (QStringLiteral("/usr/local/lib"));
	addLibraryPath (QStringLiteral("/usr/local/lib"));
#else // LINUX

	mPluginMap.insert (QStringLiteral("ImtsQmlUtilities"),       QStringLiteral("/usr/local/lib/IMTSQmlPlugins/libIMTS_LINUX_qmlutilitiesplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlUtilitiesDerived"),QStringLiteral("/usr/local/lib/IMTSQmlPlugins/libIMTS_LINUX_clqmlplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModels"),          QStringLiteral("/usr/local/lib/IMTSQmlPlugins/libIMTS_LINUX_qmlmodelsplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModelsDerived"),   QStringLiteral("/usr/local/lib/IMTSQmlPlugins/libIMTS_LINUX_clqmlmodelsplugin.so" ) );

	loadPlugins (mPluginMap);
	addPluginPath (QStringLiteral("/usr/local/lib/IMTSQmlPlugins"));
	addLibraryPath (QStringLiteral("/usr/local/lib/IMTSQmlPlugins"));
#endif


#else // ARM
	mPluginMap.insert (QStringLiteral("ImtsQmlUtilities"),       QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm/libIMTS_ARM_qmlutilitiesplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlUtilitiesDerived"),QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm/libIMTS_ARM_clqmlplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModels"),          QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm/libIMTS_ARM_qmlmodelsplugin.so" ) );
	mPluginMap.insert (QStringLiteral("ImtsQmlModelsDerived"),   QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm/libIMTS_ARM_clqmlmodelsplugin.so" ) );

	loadPlugins (mPluginMap);
	addPluginPath (QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm"));
	addLibraryPath (QStringLiteral("/usr/local/lib/IMTSQmlPlugins/arm"));
#endif


	qmlRegisterUncreatableType<GameChip>("com.intralot.imts.games", 1, 0, "GameChip", "Used in delegates to access GameChip properties");
	qmlRegisterUncreatableType<ImtsGamesEnums>("com.intralot.imts.games", 1, 0, "ImtsGamesEnums","Used only to expose enum values in QML");
	qmlRegisterUncreatableType<PollaGol>("com.intralot.imts.pollgol", 1, 0, "PollaGolEnum","Used only to expose enum values in QML");


	m_pcGamesCenter = new GamesCenter (this);


	//	QString qsMainQmlFile = GetConfigValue::getResourcePathInstance()->getDesktopQmlPath () + QStringLiteral("../testQtQuick2.qml"/*"Desktop/DesktopUi.qml"*/);
	QString qsMainQmlFile = GetConfigValue::getDesktopQmlPath() + QStringLiteral("Desktop/DesktopUi.qml");
	setMainQmlFile (qsMainQmlFile);

	QSettings settings ( QStringLiteral ("Intralot"), QStringLiteral ("ImtsGlobalConfig") );
	QString qsTrPath = settings.value (QStringLiteral ("Global/CompletePath")).toString ().append (QStringLiteral("Translations/"));

	QLocale::setDefault ( QLocale(m_qsLocale) );

	QString qsLanguage = DbusWrapper::getImtsGlobalConfigInterface ()->locale ();

	QStringList l = qsLanguage.split (QChar('-'));
	qsLanguage = l.size () == 1 ? l.at (0):l.at (1);

	auto bLoaded = m_Translator.load ( QString("IMTS_%1.qm").arg ( qsLanguage ), qsTrPath );
	qDebug () << "Translator loaded: " << bLoaded;
	QApplication::installTranslator ( &m_Translator );
	emit languageChanged (); // signal so all qml text is updated.

	emit imtsServiceUp ( qAppName (), m_pid );

	LOG(QString("Func[%1] camera full disabled: %2 ").arg (Q_FUNC_INFO).arg (true));

#if defined IMTS_ARM
	DbusWrapperArm::setEnabled (false);
#else
	DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (true);
#endif

	DbusWrapper::getPrintingServiceInterface ()->forcePrinterStatusCheck ( int(PrinterTypes::Chief ) );


	// Chile is up and running
//    QTimer* timer = new QTimer();
//    timer->setSingleShot(true);
//    connect(timer, &QTimer::timeout, [timer,this] {
//        QDBusMessage dBusMessage = QDBusMessage::createMethodCall(QString::fromLatin1("com.intralot.IMTSSplashScreen"),QString::fromLatin1("/SplashScreenOperations"), QString::fromLatin1(""), QString::fromLatin1("exitService"));
//        dBusMessage.setArguments(QVariantList() << QVariant(QString("IMTS Main Desktop")));
//        QDBusConnection::sessionBus().call(dBusMessage);
//        timer->deleteLater();
//#if defined (IMTS_APPLICATION_RELEASE_MODE)
//        setOpacity (1);
//#endif
//    });
//    timer->start(3000);
}

ImtsMainDesktopQtQuick2::~ImtsMainDesktopQtQuick2 ()
{
}

/**
  * @sa setUpDBusInterface
  * @return register to DBus
  * @brief registers desktop to DBus
  */
void ImtsMainDesktopQtQuick2::setUpDBusInterface ()
{
	LOG("Setting Up MainDesktop Operations");
	new DesktopOperationsAdaptor(this); // D-Bus stuff. Create the D-Bus adaptor for desktop

	QDBusConnection connection = QDBusConnection::sessionBus ();

	if ( !connection.registerService ("com.intralot.IMTSMainDesktop") ) {
		LOG ( QStringLiteral("!!! ERROR !!! com.intralot.IMTSMainDesktop could not register to D-Bus") );
		LOG ( QStringLiteral("com.intralot.IMTSMainDesktop already registered"));
		qWarning () << QStringLiteral("!!! ERROR !!! com.intralot.IMTSMainDesktop could not register to D-Bus");
		qWarning () << QStringLiteral("com.intralot.IMTSMainDesktop already registered");
		exit ( 0 );// goodbye cruel world
	}
	connection.registerObject("/DesktopOperations", this);
}

/**
 * @sa changeLanguageSlot
 * @brief installs the translator
 */
void ImtsMainDesktopQtQuick2::changeLanguageSlot ()
{

	if ( GetConfigValue::getLocale ().contains ("en") ) { // change from english to other

		QApplication::removeTranslator ( &m_Translator );

		QSettings settings ( QStringLiteral ("Intralot"), QStringLiteral ("ImtsGlobalConfig") );
		QString qsTrPath = settings.value (QStringLiteral ("Global/CompletePath")).toString ().append (QStringLiteral("Translations/"));

		QLocale::setDefault ( QLocale(m_qsLocale) );

		QString qsLanguage = QString ();

		QStringList l = m_qsLocale.split (QChar('-'));
		qsLanguage = l.size () == 1 ? l.at (0):l.at (1);

		m_Translator.load ( QString("IMTS_%1.qm").arg ( qsLanguage ), qsTrPath );
		QApplication::installTranslator ( &m_Translator );

		// It's up to you how you want to handle language change. language change is more dynamic
		// and causes no qml reload whereas emitting reload will reload the qml and bring you back
		// to signoff state.
		emit languageChanged (); // signal so all qml text is updated.
		// emit reload ();

		DbusWrapper::getImtsGlobalConfigInterface ()->setLocale (m_qsLocale);


	} else { // change from other to english


		QLocale::setDefault ( QLocale("en-us") );
		qDebug () << "Foreign Translator was removed successfully: " << qApp->removeTranslator ( &m_Translator );

		// It's up to you how you want to handle language change. language change is more dynamic
		// and causes no qml reload whereas emitting reload will reload the qml and bring you back
		// to signoff state.
		emit languageChanged (); // signal so all qml text is updated.
		// emit reload ();
		DbusWrapper::getImtsGlobalConfigInterface ()->setLocale ( "en-us");
	}

}

/**
 * @sa screenSaverEnabled
 * @return
 */
bool ImtsMainDesktopQtQuick2::screenSaverEnabled () const
{
	return m_bScreenSaverEnabled;
}

/**
 * @sa showBet
 * @brief asks to show bet
 */
void ImtsMainDesktopQtQuick2::showBet ()
{
	static QScopedPointer<QDBusInterface> flexBetDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSFlexBet"), QLatin1String("/FlexBetOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
	// set timeout to 0, that is no waiting to get an answer because we don't want one.
	flexBetDbusInterface.data ()->setTimeout (0);
	flexBetDbusInterface.data ()->call ("Play", 0,0 );
}

/**
 * @sa isScreenSaverAllowed
 * @return allow screen saver for Retailer and Training.
 */
bool ImtsMainDesktopQtQuick2::isScreenSaverAllowed ()
{
	UserLoginType::LoginIdentityFlags loginIdentityFlag( DbusWrapper::getConfigManagerInterface ()->loginIdentity ());

	if ( loginIdentityFlag.testFlag (UserLoginType::MaintenanceLogin) ||
		 loginIdentityFlag.testFlag (UserLoginType::FieldTechnician) ) {
		 return false;
	}

	return true;
}


/**
 * @sa setScreenSaverEnabled
 * @param newVal
 * @brief screen saver is available only for normal retailer. When login identity is not Retailer
 * there is not gonna be a screen saver.
 */
void ImtsMainDesktopQtQuick2::setScreenSaverEnabled (const bool& newVal )
{

	if ( m_bScreenSaverEnabled == newVal ) return;

	m_bScreenSaverEnabled = newVal;
	emit screenSaverEnabledChanged ();

	LOG(QString("Screensaver is active: %1").arg (m_bScreenSaverEnabled));

	if ( m_bScreenSaverEnabled ) {

		DbusWrapper::getWindowManagerInterface ()->hideAllWindows (); // hide all windows but MainDesktop.
		DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked (true);
		DbusWrapper::getConfigManagerInterface ()->setCouponProcessingBlocked (true);
		LOG(QString("Func[%1] camera enabled: %2 ").arg (Q_FUNC_INFO).arg (false));

#if defined IMTS_ARM
		DbusWrapperArm::setEnabled (false);
#else
		DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (false);
		DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (true);
#endif




	} else {


		// Before attempting to enable camera etc, we need to check whether business is on.
		// The scenario is screensaver starts while business is ON, and business goes off after
		// midnight. The input will be blocked again by houseKeeping. The retailer presses the sceen
		// and exits screen saver. In that case we don't want to enable terminal input. We'll do so
		// iff business is OFF. Hence, the check below. Good luck with your testing SWQA, because I won't
		// test....

		bool bBusinessOn = DbusWrapper::getConfigManagerInterface ()->businessOn ();

		if ( bBusinessOn ) {

			quint32 iTerminalMode = DbusWrapper::getNvramOperItInterface ()->mode ();

			switch (iTerminalMode) {
				case OperIt::NormalTerminal:
				case OperIt::CashierTerminal: {

					DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked (false);
					DbusWrapper::getConfigManagerInterface ()->setCouponProcessingBlocked (false);
					LOG(QString("1. Func[%1] camera enabled: %2 ").arg (Q_FUNC_INFO).arg (true));

#if defined IMTS_ARM
					DbusWrapperArm::setEnabled (true);
#else
					DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (true);
					DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (false);
#endif


				}
				break;
				case OperIt::OrganizationTerminal: {

					DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked (false);
					DbusWrapper::getConfigManagerInterface ()->setCouponProcessingBlocked (true);
					LOG(QString("2. Func[%1] camera enabled: %2 ").arg (Q_FUNC_INFO).arg (true));

#if defined IMTS_ARM
					DbusWrapperArm::setEnabled (true);
#else
					DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (true);
					DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (false);
#endif

				}
				break;
				default:
				break;
			}

		} else {
			DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked (true);
			DbusWrapper::getConfigManagerInterface ()->setCouponProcessingBlocked (true);
			LOG(QString("3. Func[%1] camera enabled: %2 ").arg (Q_FUNC_INFO).arg (false));


#if defined IMTS_ARM
			DbusWrapperArm::setEnabled (false);
#else
			DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (false);
			DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (true);
#endif


		}
	}

}


/**
 * @sa windowActive
 * @return
 */
bool ImtsMainDesktopQtQuick2::windowActive () const
{
	return m_bWindowActive;
}

/**
 * @sa setWindowActive
 */
void ImtsMainDesktopQtQuick2::setWindowActive (const bool& bActive)
{
	m_bWindowActive = bActive;
	emit windowActiveChanged ();
}

/**
  * @sa processBarcode
  * @param the list of barcodes
  * @return true to let cameraManager know that we received the barcodes it sent us.
  * @brief This routine receives a list of barcodes for further processing. Basically,
  * we have set desktop to be the default receiver.
  */
bool ImtsMainDesktopQtQuick2::processBarcode(const QVariantList qvlBarcodes )
{
	return DbusWrapper::getValidationOperationsInterface ()->processBarcode ( qvlBarcodes );
}


/**
 * @sa isGuiApplicationVisible
 * @brief returns if main desktop window is active or not.
 */
bool ImtsMainDesktopQtQuick2::isGuiApplicationVisible ()
{
	return this->isVisible ();
}


/**
 * @sa displayMessageBox
 * @param display text
 * @param OK button text
 * @param title text
 * @param cancel button text or 2nd button
 * @param 3rd button text
 * @param 4th button text
 * @return user selection
 * @brief pop up a message box onto display based on the the parameteres passed
 */
int ImtsMainDesktopQtQuick2::displayMessageBox ( const QString qsDisplayText,
												 const QString qsOkButtonText,
												 const QString qsTitle,
												 const QString qsCancelButtonText,
												 const QString qsCustomButton1Text,
												 const QString qsCustomButton2Text,
												 const int iTimeOut )
{

	QmlMessageBox::eeQmlMessageBoxResult eUsersChoice = QmlMessageBox::eTIMEOUT;

	QmlMessageBox msgBox ( qsDisplayText, qsOkButtonText, qsTitle, qsCancelButtonText, qsCustomButton1Text, qsCustomButton2Text );
	msgBox.setButtonFontSize (12);
	msgBox.setDisplayTextFontSize (12);
	quint8 iNewLnes = qsDisplayText.count (QLatin1Char('\n'));

	if ( iNewLnes ) {
		quint16 iHeight = 320 + iNewLnes*10;

		if (iHeight>700) {
			iHeight=700;
		}
		msgBox.setDialogWidthAndHeight(560,iHeight);
	}

	if ( iTimeOut ) {
		msgBox.setBusyIndicator (true);
		msgBox.setTimeOutValue (iTimeOut);
	}

	eUsersChoice = msgBox.exec ();

	return (int)eUsersChoice;
}

/**
 * @sa showPleaseWait
 * @param display text
 * @param step to increase progress bar
 * @param show progress bar
 * @param maximum for progress bar
 * @param show cancel button
 * @param application name that requested to show dialog
 * @brief shows pleaseWait
 */
void ImtsMainDesktopQtQuick2::showPleaseWait (const QString qsPleaseWaitText,
											  const int iStep,
											  const bool bShowProgressBar,
											  const int iMaximum,
											  const bool bShowCancelButton,
											  const QString qsSourceObject)
{
	if ( m_pcPleaseWaitNew->readState ().contains ( QStringLiteral("show") ) ) { // if already on screen just update step if requested

		if ( iStep > -1 ) {
			m_pcPleaseWaitNew->setStep (iStep);
		}

		if ( bShowProgressBar ) {
			if ( !m_pcPleaseWaitNew->readProgressBarEnabled () ) {
				m_pcPleaseWaitNew->initWithBarProgress ();
			}
			m_pcPleaseWaitNew->setMaximum (iMaximum);

		} else {
			m_pcPleaseWaitNew->setProgressBarEnabled (false);
		}

		m_pcPleaseWaitNew->setDisplayText (qsPleaseWaitText); // update display text while in view

	} else { // dialog not on screen

		if ( bShowProgressBar ) { // if we want progress bar init dialog appropriately

			m_pcPleaseWaitNew->initWithBarProgress ();

			if ( iStep > -1 ) {
				m_pcPleaseWaitNew->setStep (iStep);
			}

			m_pcPleaseWaitNew->setMaximum (iMaximum);

		} else {

			m_pcPleaseWaitNew->initForGeneralUse ();
		}

		m_pcPleaseWaitNew->setDisplayText (qsPleaseWaitText);
		m_pcPleaseWaitNew->setState (QStringLiteral("show"));
	}


	if ( bShowCancelButton ) {

		if ( qsSourceObject.contains ( QStringLiteral("CouponCollectorManager" ) ) ) { // that's not dynamic but needed work for being so....Let it pass.

			DbusWrapper::CouponCollectorManagerInterface * interface = DbusWrapper::getCouponCollectorManagerInterface ();
			QObject::connect ( m_pcPleaseWaitNew, &PleaseWaitNew::cancelOperation, interface, &DbusWrapper::CouponCollectorManagerInterface::endBatchTransmissionSlot);
			m_pcPleaseWaitNew->setCancelButtonEnabled (true);

		} else {
			// where else do you want to connect cancel click?
		}

	} else {

		m_pcPleaseWaitNew->setCancelButtonEnabled (false);

	}

}

/**
 * @sa hidePleaseWait
 * @param application name that requests to hide dialog
 * @brief hides please wait
 */
void ImtsMainDesktopQtQuick2::hidePleaseWait ()
{
	// it will disconnect any connections we have made previously
	m_pcPleaseWaitNew->resetAndHide();
}


/**
 * @sa showProgressDialog
 * @param display text
 * @param maximum for progress bar
 * @param step to increase progress bar
 * @brief shows pleaseWait
 */
void ImtsMainDesktopQtQuick2::showProgressDialog (const QString qsProgressDialogText,
												  const int iMaximum,
												  const int iStep)
{

	if ( !m_pcProgressDialog->readRunning () ) {

		m_pcProgressDialog->setMaximum (iMaximum);
		m_pcProgressDialog->setStep (iStep);
		m_pcProgressDialog->setDisplayText (qsProgressDialogText); // update display text while in view
		m_pcProgressDialog->setRunning (true);

	} else {
		qWarning () << "Progress dialog already running";
	}

}

/**
 * @sa updateProgressDialog
 * @param step to increase progress bar
 * @param update the text
 * @brief updates progerss bar
 */
void ImtsMainDesktopQtQuick2::updateProgressDialog ( const int iStep, QString qsProgressDialogText )
{
	if ( iStep > -1 ) {
		m_pcProgressDialog->setStep (iStep);
	}

	m_pcProgressDialog->setDisplayText (qsProgressDialogText); // update display text while in view

}


/**
 * @sa hideProgressDialog
 * @param application name that requests to hide dialog
 * @brief hides please wait
 */
void ImtsMainDesktopQtQuick2::hideProgressDialog ()
{
	m_pcProgressDialog->resetAndHide();
}

/**
 * @sa reload
 * @brief triggers F5 to reload QML files
 */
Q_NOREPLY void ImtsMainDesktopQtQuick2::reload ()
{
	DbusWrapper::getConfigManagerInterface ()->setSignOn (false);
	m_pcProjectDependentConfig->reloadGamesConfigSlot ();
	emit ImtsViewerQtQuick2::reloadRequest ();
}

/**
 * @sa resetScreenSaver
 * @brief signals to reset the screen saver.
 * ImtsMainDesktopQtQuick2 is not registered in QML's context.
 * But the object we are inheriting from it is. Hence emit the signal
 * found in ImtsViewerQtQuick2
 */
Q_NOREPLY void ImtsMainDesktopQtQuick2::resetScreenSaver ()
{
	emit resetScreenSaverExpirationTime ();
	emit resetTrainingExpirationTime ();
}


/**
 * @sa blockCameraInputSlot
 * @param true / false
 * @brief blocks/unblocks camera on demand based on passed in parameter
 */
Q_NOREPLY void ImtsMainDesktopQtQuick2::blockCameraInputSlot ( const bool& bBlock )
{

	bool bBusinessOn = DbusWrapper::getConfigManagerInterface ()->businessOn ();

	if ( bBusinessOn && !m_bScreenSaverEnabled ) {

		LOG(QString("Func[%1] camera enabled: %2 ").arg (Q_FUNC_INFO).arg (!bBlock));

#if defined IMTS_ARM

		DbusWrapperArm::setEnabled (!bBlock);
#else
		DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (!bBlock);
		DbusWrapper::getReadingDeviceOperationsInterface ()->setFullDisabled (bBlock);
#endif
	}
}

/**
 * @sa wakeUpService
 */
void ImtsMainDesktopQtQuick2::wakeUpService ( const QString serviceNameThatsWakesMeUp)
{
	LOG ( QString("%1 wakes up by %2").arg (qAppName ()).arg (serviceNameThatsWakesMeUp));
}

/**
 * @sa exitService
 */
void ImtsMainDesktopQtQuick2::exitService ( const QString serviceNameThatKillsMe )
{
	LOG (QString("%1 was killed by %2").arg (qAppName ()).arg (serviceNameThatKillsMe));
	QCoreApplication::quit ();
}
