/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file GamesLogicDerived.cpp
  * @class GamesLogicDerived
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include "GamesLogicDerived.h"
#include "QpGeneration/QpGeneration.h"
#include <QtDebug>
#include "JsonOperations.h"
#include "parser.h"
#include "DbusWrapper.h"
#include "ProjectGameCodes.h"
#include "FormatAmount/FormatAmount.h"
#include "GamesCore/CouponUtilitiesDerived.h"

GamesLogicDerived::GamesLogicDerived( QObject* parent )
	: GamesLogic ( parent )
	, m_pcCouponUtilitiesDerived ( new CouponUtilitiesDerived )
{

	QObject::connect (this,&GamesLogic::currentAreaChanged,this,&GamesLogicDerived::setUpMultipliersForPick);
}

/**
 * @sa ~GamesLogicDerived
 * @brief destructor. got to delete lamba connection, otherwise u'll leak.
 */
GamesLogicDerived::~GamesLogicDerived ()
{
}


bool GamesLogicDerived::combo ()
{
	return m_bCombo;
}

bool GamesLogicDerived::box ()
{
	return m_bBox;
}

void GamesLogicDerived::setCombo (const bool& bEnabled)
{
	if (m_bCombo==bEnabled) return;
	m_bCombo = bEnabled;
	emit comboChanged ();
}

void GamesLogicDerived::setBox (const bool& bEnabled)
{
	if (m_bBox==bEnabled) return;
	m_bBox= bEnabled;
	emit boxChanged ();
}

/**
 * @sa customGameInitialization
 * @brief For Ireland we initialize data with additional game set by default.
 */
void GamesLogicDerived::customGameInitialization ( const int& iGameCode )
{

	Coupon cCouponData = getCouponData();
	m_pcGameConfig = getGameConfig ();

	if ( iGameCode == RACHA_CL ) {

		QVariantMap mAdditionalGameMap;

		mAdditionalGameMap.insert( "0", 1 );
		mAdditionalGameMap.insert( "10", 1 );

		cCouponData.getArea( 0 )->setAdditionalGamePerArea(mAdditionalGameMap);

	}

	if ( iGameCode == LOTO_CL ) {

		QVariantMap mAdditionalGameMap;

		mAdditionalGameMap.insert( "Revancha", 1 );
		mAdditionalGameMap.insert( "Desquite", 1 );
		mAdditionalGameMap.insert( "Multiplicador", 1 );
		mAdditionalGameMap.insert( "Ahora si que si!", 1 );
		mAdditionalGameMap.insert( "Jubilazo", 1 );

		cCouponData.getArea( 0 )->setAdditionalGamePerArea(mAdditionalGameMap);

	}

	setCouponData(cCouponData);

}

/**
 * @sa selectAreaNumber
 * @param iNewArea
 * @brief selects the area
 */
void GamesLogicDerived::selectAreaNumber ( const int& iNewArea )
{
	Coupon cCouponData = getCouponData ();
	m_pcGameConfig = getGameConfig ();

	if ( iNewArea != cCouponData.getLastSelectedArea() && isCurrentAreaErrorFree () ) { // only do stuff if selection is different than current and area is error free

		setCurrentArea (iNewArea);
		cCouponData.setLastSelectedArea (iNewArea);

		if ( cCouponData.getArea( iNewArea )->isAreaEmpty() ) {
			if ( m_pcGameConfig->readGameCode() == RACHA_CL ) {

				QVariantMap mAdditionalGameMap;

				mAdditionalGameMap.insert( "0", 1 );
				mAdditionalGameMap.insert( "10", 1 );

				cCouponData.getArea( iNewArea )->setAdditionalGamePerArea(mAdditionalGameMap);

			}

			if ( m_pcGameConfig->readGameCode() == LOTO_CL ) {

				QVariantMap mAdditionalGameMap;

				mAdditionalGameMap.insert( "Revancha", 1 );
				mAdditionalGameMap.insert( "Desquite", 1 );
				mAdditionalGameMap.insert( "Multiplicador", 1 );
				mAdditionalGameMap.insert( "Ahora si que si!", 1 );
				mAdditionalGameMap.insert( "Jubilazo", 1 );

				cCouponData.getArea( iNewArea )->setAdditionalGamePerArea(mAdditionalGameMap);

			}
		}

		setCouponData (cCouponData);

		ImtsGamesEnums::ViewUpdateOptionsFlags updateAreas = ImtsGamesEnums::UpdateAllAreaContents;
		setMaxSelectedMarksInPanels( m_pcCouponUtilitiesDerived->getMinMaxMarksInPanels ( m_pcGameConfig, cCouponData, iNewArea ) );

		updateCouponView ( updateAreas | ImtsGamesEnums::UpdateAreaCost | ImtsGamesEnums::UpdateCouponCost | ImtsGamesEnums::CheckCoupon );
	}
}

/**
 * @sa selectMultiplierNumber
 * @param iNewMultiplierIndex
 * @param pickPlayType
 * @brief when you pass in -1 it will reset multiplier value for passed-in playType
 */
void GamesLogicDerived::selectMultiplierNumber ( const int& iNewMultiplierIndex, int iPickXPlayType)
{


	static QMap<ImtsGamesEnums::PickXPlayTypeFlags,QString> typeToTypeString = {
		{ImtsGamesEnums::Straight       , QStringLiteral("Straight")},
		{ImtsGamesEnums::Combo          , QStringLiteral("Combo")},
		{ImtsGamesEnums::Box            , QStringLiteral("Box")},
		{ImtsGamesEnums::FrontBackPairs , QStringLiteral("Pairs")},
		{ImtsGamesEnums::LastDigit      , QStringLiteral("LastDigit")}
	};

	if ( iPickXPlayType != ImtsGamesEnums::NoPlayType )	{

		Coupon cCouponData = getCouponData();
		m_pcGameConfig = getGameConfig ();

		ImtsGamesEnums::PickXPlayTypeFlags ePlayTypeFlag = ImtsGamesEnums::PickXPlayTypeFlags(iPickXPlayType);
		ImtsGamesEnums::PickXPlayTypeFlags eCurrentPlayTypeFlag = ImtsGamesEnums::PickXPlayTypeFlags (cCouponData.getArea ( currentArea ())->getPickXPlayType ());

		QString qsPlaytype = typeToTypeString.value (ePlayTypeFlag);

		QVariantMap mMultipliers  = cCouponData.getArea (currentArea ())->getCustomData ();

		if ( iNewMultiplierIndex>=0) {

			auto iNewValueMultiplier = m_pcGameConfig->readMultiplierCfgMap().value(QStringLiteral("MultiplierList")).toList().at(iNewMultiplierIndex ).toInt();

			if ( mMultipliers.value (qsPlaytype).toInt () == iNewValueMultiplier ) { // exists remove it

				mMultipliers.remove (qsPlaytype);
				eCurrentPlayTypeFlag.operator &= (~ePlayTypeFlag); // remove previous playType.


			} else {

				mMultipliers.insert (qsPlaytype,iNewValueMultiplier);
			}

			eCurrentPlayTypeFlag.operator |= (ePlayTypeFlag);
			eCurrentPlayTypeFlag.operator &= (~ImtsGamesEnums::NoPlayType); // remove NoPlayType.

		} else {

			mMultipliers.remove (qsPlaytype);
			eCurrentPlayTypeFlag.operator &= (~ePlayTypeFlag);
		}

		if ( mMultipliers.isEmpty() ) {
			eCurrentPlayTypeFlag.operator = (ImtsGamesEnums::NoPlayType);
		}

		cCouponData.getArea (currentArea ())->setCustomData (mMultipliers);
		setCouponData (cCouponData);

		updateCouponView ( ImtsGamesEnums::UpdateMultipliers | ImtsGamesEnums::CheckCoupon | ImtsGamesEnums::UpdateCouponCost );

		selectPickXPlayType (eCurrentPlayTypeFlag,QString ());

	} else {
		qDebug () << "No pick play type selected";
	}
}

/**
  * @sa currentAreaCustomClear
  * @brief does what function name says
  * For Loto3 multiplier data are kept in copons misc data map.
  * So we got clear it too.
  */
void GamesLogicDerived::currentAreaCustomClear ()
{
	Coupon cCouponData = getCouponData ();
	cCouponData.getArea ( currentArea ())->clearArea ();
	setCouponData (cCouponData);

	m_pcGameConfig = getGameConfig ();

	qDebug () << "CustomData: " << getCouponData ().getArea (currentArea ())->getCustomData ();

	if (IS_PICK(m_pcGameConfig->readGameCode ())) {
		setCombo (false);
		setBox (false);
	}
}


/**
 * @brief GamesLogic::proceedWithMarkSelection
 * @param iArea
 * @param iPanel
 * @return it tells whether we should go on with mark selection or not. Used prior to Mark and QP selection
 * For bettype lotto and pick games we will not procceed if a PT is not selected.
 * We need to override original method due to the fact that in Pick3 customQp the user can make a single only
 * selection on second panel. All Taiwan games support system play but Pick3 with playType being 2nd digit.
 */
bool GamesLogicDerived::proceedWithMarkSelection ( const int& iArea, const int& iPanel )
{
	Coupon cCouponData = getCouponData ();
	m_pcGameConfig = getGameConfig ();
	bool bUpdateMark = true;

	ImtsGamesEnums::GameTypeFlags gameTypeFlag ( getMaxSelectedMarksInPanels ().value (iPanel).value ("GameType"));

	// For bettype games a bettype selection should be in place in order to update the mark. Otherwise we skip it.
	if ( gameTypeFlag.testFlag (ImtsGamesEnums::BetTypeSupport) && !cCouponData.getArea (iArea)->getBetTypeValue () ) {
		bUpdateMark = false;
	}

	// RACHA is a bettype game, which does not follow the above rule.
	if ( m_pcGameConfig->readGameCode() == RACHA_CL ) {
		bUpdateMark = true;
	}

	if (  (IS_PICK(m_pcGameConfig->readGameCode ())) ) {
		bUpdateMark = true;
	}

	return bUpdateMark;

}


/**
  * @sa displayTotalCostWarning
  * @return the warning to be display onto the screen
  * @brief per return
  */
QString GamesLogicDerived::displayTotalCostWarning ()
{
	// Note: This function is "connected" with 'CouponUtilitiesDerived.cpp'.

	m_pcGameConfig = getGameConfig ();
	Coupon cCouponData = getCouponData ();
	double dCouponCost = cCouponData.getCouponCost ()*cCouponData.getNumberOfTickets ();
	QString qsWarning = QString ();

	// CH_Polla Chilena: Loto & Loto 4 require information about the number of combinations.
	if ( m_pcGameConfig->readGameCode() == LOTO_CL || m_pcGameConfig->readGameCode() == LOTO4_CL ) {
		qsWarning = m_pcCouponUtilitiesDerived->promptForCombinations( m_pcGameConfig->readGameCode (), cCouponData );
	}
	qsWarning += m_pcCouponUtilitiesDerived->promptForCost ( m_pcGameConfig->readGameCode (), dCouponCost );

	return qsWarning;
}

/**
  * @sa selectAdditionalGame
  * @param data from additional game
  * @brief does additional game logic for Taiwan High/Low and Bull's Eye additional games
  * for Keno
  */
void GamesLogicDerived::selectAdditionalGame ( const int& iData )
{
	Coupon cCouponData = getCouponData ();
	m_pcGameConfig = getGameConfig ();

	QVariantMap mAdditionalGameMap = cCouponData.getAdditionalGameMap ();

	if ( iData == -1 ) { // if 'NO' remove
		mAdditionalGameMap.clear ();
	} else { // if 'YES' add

		double dAdditionalGameCost = m_pcGameConfig->readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();

		mAdditionalGameMap.insert (QStringLiteral("UserSelection"), iData);
		mAdditionalGameMap.insert (QStringLiteral("Price"), dAdditionalGameCost );
		mAdditionalGameMap.insert (QStringLiteral("GameName"), m_pcGameConfig->readAdditionalGame ().value(QStringLiteral("Name")).toString () );
	}

	cCouponData.setAdditionalGameMap (mAdditionalGameMap);

	setCouponData (cCouponData);

	updateCouponView ( ImtsGamesEnums::UpdateAdditionalGame | ImtsGamesEnums::CheckCoupon | ImtsGamesEnums::UpdateCouponCost );
}

/**
  * @sa selectAdditionalGameInArea
  * @param index of additional game
  * @brief does additional game logic for additional games
  */
void GamesLogicDerived::selectAdditionalGameInArea ( const int& iData )
{
	Coupon cCouponData = getCouponData ();
	m_pcGameConfig = getGameConfig ();

	QMap<int,QString> mIntToNameString = QMap<int,QString> ();

	if (mIntToNameString.isEmpty()) {

		QVariantList lAdditionalGamesList = m_pcGameConfig->readAdditionalGamePerArea();
		int numberOfAdditionalGamesInArea = lAdditionalGamesList.length();

		/*
		 * < 0, additionalGame_name_1>
		 * < 1, additionalGame_name_2>
		 * < 2, additionalGame_name_3>
		 * ...
		 */
		for ( int i=0; i<numberOfAdditionalGamesInArea; i++ ) {
			mIntToNameString.insert( i, lAdditionalGamesList.at(i).toMap().value( QStringLiteral("Name") ).toString() );
		}
	}

	QVariantMap mAdditionalGameMap = cCouponData.getArea( cCouponData.getLastSelectedArea() )->getAdditionalGamePerArea();

	if ( mAdditionalGameMap.contains( mIntToNameString.value(iData) ) ) {

		mAdditionalGameMap.remove( mIntToNameString.value(iData) );

		if ( m_pcGameConfig->readGameCode() == LOTO_CL ) {
			// CH_Polla Chilena: Loto requires specific treatement of the additional games' selection.
			switch ( iData ) {
				case 0:
					// Revancha
					if ( mAdditionalGameMap.contains( "Desquite" ) ) { mAdditionalGameMap.remove( "Desquite" ); }
					if ( mAdditionalGameMap.contains( "Multiplicador" ) ) { mAdditionalGameMap.remove( "Multiplicador" ); }
					if ( mAdditionalGameMap.contains( "Ahora si que si!" ) ) { mAdditionalGameMap.remove( "Ahora si que si!" ); }
					if ( mAdditionalGameMap.contains( "Jubilazo" ) ) { mAdditionalGameMap.remove( "Jubilazo" ); }
					break;
			case 1:
				// Desquite
				if ( mAdditionalGameMap.contains( "Multiplicador" ) ) { mAdditionalGameMap.remove( "Multiplicador" ); }
				if ( mAdditionalGameMap.contains( "Ahora si que si!" ) ) { mAdditionalGameMap.remove( "Ahora si que si!" ); }
				if ( mAdditionalGameMap.contains( "Jubilazo" ) ) { mAdditionalGameMap.remove( "Jubilazo" ); }
				break;
			case 3:
				// Ahora si que si!
				if ( mAdditionalGameMap.contains( "Jubilazo" ) ) { mAdditionalGameMap.remove( "Jubilazo" ); }
				break;
			}
		}


	} else {
		mAdditionalGameMap.insert( mIntToNameString.value(iData), 1 );
	}

	cCouponData.getArea( cCouponData.getLastSelectedArea() )->setAdditionalGamePerArea(mAdditionalGameMap);

	setCouponData (cCouponData);

	updateCouponView ( ImtsGamesEnums::UpdateAdditionalGamePerArea | ImtsGamesEnums::CheckCoupon | ImtsGamesEnums::UpdateCouponCost );
}


/**
 * @sa updateCouponCost
 */
void GamesLogicDerived::updateCouponCost ()
{
	Coupon cCouponData = getCouponData ();
	m_pcCouponUtilitiesDerived->updateCouponCost ( getGameConfig (), cCouponData );
	setCouponData (cCouponData);
}


/**
 * @sa selectBetTypeNumber
 * @param int iNewBetTypeIndex. iNewBetTypeIndex indicates which betType Number object we want to set/reset.
 * @brief This routine will update the data model for bettype selection. Once the data model
 * is sorted out, the routine will emit a signal to update the view. NOTE: For bettype games, d->m_mMaxSelectedMarksInPanels
 * list is a dynamic parameter which is directly depended on the bettype selection, and this routine also takes care of it.
 */
void GamesLogicDerived::selectBetTypeNumber ( const int& iNewBetTypeIndex )
{

	ImtsGamesEnums::ViewUpdateOptionsFlags flags = ImtsGamesEnums::UpdateBetTypes | ImtsGamesEnums::CheckCoupon | ImtsGamesEnums::UpdateCouponCost;

	Coupon cCouponData = getCouponData ();
	m_pcGameConfig = getGameConfig ();

	int iNewValue = m_pcGameConfig->readBetTypeCfgMap ().value (QStringLiteral("BetTypeSelectionsList")).toList ().at(iNewBetTypeIndex).toInt();

	if ( (IS_LOTTO (m_pcGameConfig->readGameCode ())) ) {

			if ( iNewValue != cCouponData.getArea ( currentArea () )->getBetTypeValue () ) { // if new is the same as old ignore

				cCouponData.getArea ( currentArea () )->setBetTypeSingle ( iNewValue ); // set new
				setCouponData (cCouponData);

//                QMap<int, QMap<QString,int> > m = m_pcCouponUtilities->getMinMaxMarksInPanels ( m_pcGameConfig, cCouponData, currentArea () );
//				setMaxSelectedMarksInPanels (m);

			}

	}

	updateCouponView ( flags );

}

/**
  * @sa getCouponErrors
  * @brief check for errors. Calling getLastErrors you can get the last one occured.
  */
void GamesLogicDerived::getCouponErrors ()
{
	m_pcCouponUtilitiesDerived->getCouponErrors ( getGameConfig (), getCouponData () );
}

/**
 * @sa setUpMultipliersForPick
 */
void GamesLogicDerived::setUpMultipliersForPick ()
{
	m_pcGameConfig = getGameConfig ();

	if (IS_PICK(m_pcGameConfig->readGameCode ())) {

		Coupon cCouponData = getCouponData();

		QList<int> lBetLine = cCouponData.getArea (currentArea ())->getPickGameBetline ();
		auto iRepetations = 0;

		for ( auto i = 0; i < 10; ++i ) { // Find out how many times each digit exist in our betLine.

			if (lBetLine.count (i)>1) {
				iRepetations = lBetLine.count (i);
			}
		}

		if (lBetLine.size ()==3) { // do only when all 3-digits exist

			if (iRepetations == 0) { //Enable Box(TrioAzar) 123

				setBox (true);
				setCombo (false);

			} else if (iRepetations==2) { // Enable Combo (TrioPar) 122

				setCombo (true);
				setBox (false);

			} else if (iRepetations==3) {// disaable Combo(TrioPar) and Box(TrioAzar) 111

				setCombo (false);
				setBox (false);
			}

		} else {

			setCombo (false);
			setBox (false);
		}

		if (!combo ()) {
			selectMultiplierNumber (-1,ImtsGamesEnums::Combo); // reset multiplier values
		}

		if (!box ()) {
			selectMultiplierNumber (-1,ImtsGamesEnums::Box); // reset multiplier values
		}
	}
}



/**
 * @sa postQpSelection
 */
void GamesLogicDerived::postQpSelection ()
{
	setUpMultipliersForPick ();
}

/**
 * @sa postSelectMarkPanelX
 */
void GamesLogicDerived::postSelectMarkPanelX (const int&, const int&)
{
	setUpMultipliersForPick ();
}

