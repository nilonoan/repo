#ifndef COMMONDEFINITIONS_H
#define COMMONDEFINITIONS_H

class QChar;
class QString;
class QPalette;
class QFont;

#define APP_SCREEN_WIDTH 1024
#define APP_SCREEN_HEIGHT 768
#define APP_BTN_WIDTH_SMALL 100 // aste: was 129 in BG
#define APP_BTN_HEIGHT_SMALL 55 // aste: was 60 in BG

/**
 * @enum ModuleAction
 * @brief Requests to the module.
 */
enum ModuleAction
{
    MOD_ACTION_NEW_CPN=0, /**< Create a new coupon. */
    MOD_ACTION_EDIT_CPN, /**< Edit an existing coupon. */
    MOD_ACTION_CHECK_CPN, /**< Check an existing coupon. */
    MOD_ACTION_APPRVD_CPN, /**< Prepare a coupon after approval (betting). */
    MOD_ACTION_PREVIEW_PLAYED_CPN, /**< Prepare a preview of coupon */
    MOD_ACTION_CREATE_RECORD, /**< Prepare the record. */
    MOD_ACTION_SET_TEAM_CPN, /**< Set the team coupon flag in the recorrd. */
    MOD_ACTION_UNSET_TEAM_CPN, /**< Uset the team coupon flag. */
    MOD_ACTION_CANCELLED_CPN, /**< Prepare a cancellation receipt. */
    MOD_ACTION_REBUILD_CPN, /**< Recreate record from the marks. */
    MOD_ACTION_PARTIAL_CPN, /**< Play partial scanned coupon. */
    MOD_ACTION_UPDATE_CPN, /**< Use the verify reply to update. */
    MOD_ACTION_QP_BARCODE_CPN, /**< QP barcode play. */
    MOD_ACTION_ADVANCEPLAY_CPN, /**< Mark the advance play flag. */
    MOD_ACTION_QP_DIALOG, /**< Show the QP dialog. */
    MOD_ACTION_QP_ONE_PLAY, /**< Play 1 QP no dialog. */
    MOD_ACTION_QP_FIVE_PLAYS, /**< Play 5 QP no dialog. */
    MOD_ACTION_QP_ONE_PLAY_4PACK, /**< Play a 4 pack QP no dialog. */
    MOD_ACTION_QP_ONE_PLAY_5PACK /**< Play a 5 pack QP no dialog. */
};

enum ModuleStage
{
    MOD_STAGE_RECORD=0,
    MOD_STAGE_REPLY,
    MOD_STAGE_PRINT,
    MOD_STAGE_TEAM_COUPON,
    MOD_STAGE_REGENERATE,
    MOD_STAGE_RECORD_AS_SECONDARY,
    MOD_STAGE_EXCHANGE,
    MOD_STAGE_PROMOTION,
    MOD_STAGE_FAVOURITE_COUPON,
    MOD_STAGE_PRINT_CARD_COUPON
};

#endif // COMMONDEFINITIONS_H
