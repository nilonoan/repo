#ifndef FLEXBET_STRUCTS_H
#define FLEXBET_STRUCTS_H

#include "SystemWideConstValues.h"
extern int deviceType;

typedef struct
{
    int	choice;
    bool standard;
    bool random;
    int	group; //1000=A, 100=B, 10=C, 1=D
    int	betType;
}
EventStruct;

#define IFLEX_GAMECODE		iFlex_CL
#define MAX_EVENT_CODE  	5000

//Number of choices to the player for each screen
#define NUM_O_BETS          45 // aste: was 38 in BG
#define NUM_O_PERMS 		32 // aste: CH has no 0-system or ALL-system options, so only systems 1-30 are actually supported, but it is easier to keep this at 32 and just write at the proper points of the marks array, rather than changing it to 30 and doing all sorts of code rewrites...
#define NUM_O_STAKES 		18 // aste: was 12 in BG
#define NUM_O_MULTS 		0 // aste: CH has no multipliers, was 4 in BG
#define NUM_O_STAKES_MULTS (NUM_O_STAKES + NUM_O_MULTS)
#define NUM_O_GROUPS 		0 // aste: CH has no groups, was 4 in BG
#define NUM_O_RGROUP        0 // aste: CH has no groups, was 1 in BG
#define NUM_O_SYSTEMMULTS	0 // aste: CH has no system multipliers, was 4 in BG
#define NUM_O_SJP	        0 // aste: CH has no SJP, was 6 in BG

#define NUM_O_SPECIALCOLUMN1 5
#define NUM_O_SPECIALCOLUMN2 6
#define NUM_O_SPECIALCOLUMN3 6


#define EMPTY_AREA -999
#define TOT_CPN_AREAS 30
//Each area's total marks
#define AREA_MARKS		79  // For Polla Chilena
#define TOTAL_ECPN_MARKS  AREA_MARKS*TOT_CPN_AREAS+NUM_O_PERMS+(NUM_O_PERMS-1)*NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS+NUM_O_SJP

#define SCAN_TOT_AREAS		15


#define OFFSET_OF_BET	 	34
#define OFFSET_OF_GROUPS 	79 // aste: Was 72 in BG (not that it matters much for Chile, as there is no group support there)
#define OFFSET_OF_STAKE  	TOT_CPN_AREAS*AREA_MARKS
#define OFFSET_OF_MULT      (OFFSET_OF_STAKE + NUM_O_STAKES)
#define OFFSET_OF_SYS  		TOT_CPN_AREAS*AREA_MARKS+NUM_O_STAKES_MULTS
#define OFFSET_OF_SYS_ALL  	AREA_MARKS*TOT_CPN_AREAS+NUM_O_STAKES_MULTS+(NUM_O_PERMS-1)+(NUM_O_PERMS-1)*NUM_O_SYSTEMMULTS
#define OFFSET_OF_SJP       (OFFSET_OF_SYS_ALL+1)

#define NUM_O_SPECIALROW1 5
#define NUM_O_SPECIALROW2 6
#define NUM_O_SPECIALROW3 6

#define FINAL_1		400
#define FINAL_X		401
#define FINAL_2		402
#define FINAL_1X	800
#define FINAL_12	801
#define FINAL_X2	802
#define FINAL_1X2	803
#define FstHALF_1X      810
#define FstHALF_12      811
#define FstHALF_X2      812
#define FstHALF_1X2     813
#define SndHALF_1X      820
#define SndHALF_12      821
#define SndHALF_X2      822
#define SndHALF_1X2     823
#define FINALHC_1X      830
#define FINALHC_12      831
#define FINALHC_X2      832
#define FINALHC_1X2     833

#define UNDER_OVER_STARTING_CODE 467
#define UNDER_OVER_ENDING_CODE 548

#define WHO_WILL_WIN_THE_REST_OF_THE_GAME_STARTING_CODE 724
#define WHO_WILL_WIN_THE_REST_OF_THE_GAME_ENDING_CODE   729

#define SPECIALBETTYPE_CODE_OFFSET 100 /// The special bet type 100 in verbal (calculator)
/// corresponds to special bet type 0 in CS

#define getbit(c,i) ((c)&(0x01<<(i)))
#define FlgPILOTPROG 0x01
#define FlgINCLUDELIVE 0x02
const int MAX_PRESSED_BTNS_ALLOWED = 6;
const int MAX_PRINT_LENGTH = 48;

//// ===================================== DEFINITIONS FOR PLAYSLIP =====================
//const int NUM_O_PLAYSLIP_PERMS = 16;
//const int NUM_0_PLAYSLIP_MULTS = 16;
//const int NUM_O_PLAYSLIP_AREAS = 15;
//const int NUM_O_PLAYSLIP_EVENT_MULT = 3;
//const int NUM_O_PLAYSLIP_EVENT_MARKS = 30;

//// ===================================== DEFINITIONS FOR PLAYSLIP =====================
const int NUM_O_PLAYSLIP_PERMS = 10; // aste : was 14 in BG (12 systems, plus 0-system, plus ALL-system)
//const int NUM_O_PLAYSLIP_PERMS2 = 8;
const int NUM_0_PLAYSLIP_MULTS = NUM_O_STAKES_MULTS; // aste: was 12 in BG
const int NUM_O_PLAYSLIP_AREAS = 10; // aste: was 12 in BG
//const int NUM_O_PLAYSLIP_AREAS2 = 6;
const int NUM_O_PLAYSLIP_AREA_MARKS = 79; // aste: was (76-4) in BG //-4 group marks
const int NUM_O_PLAYSLIP_EVENT_MULT = 4;
const int NUM_O_PLAYSLIP_EVENT_MARKS = 30;

const int NO_MARK = -1;

const int A1 = AREA_MARKS*0;
const int A1_BET_OFFSET = A1+OFFSET_OF_BET;

const int A2 = AREA_MARKS*1;
const int A2_BET_OFFSET = A2+OFFSET_OF_BET;

const int A3 = AREA_MARKS*2;
const int A3_BET_OFFSET = A3+OFFSET_OF_BET;

const int A4 = AREA_MARKS*3;
const int A4_BET_OFFSET = A4+OFFSET_OF_BET;

const int A5 = AREA_MARKS*4;
const int A5_BET_OFFSET = A5+OFFSET_OF_BET;

const int A6 = AREA_MARKS*5;
const int A6_BET_OFFSET = A6+OFFSET_OF_BET;


const int A7 = AREA_MARKS*6;
const int A7_BET_OFFSET = A7+OFFSET_OF_BET;

const int A8 = AREA_MARKS*7;
const int A8_BET_OFFSET = A8+OFFSET_OF_BET;

const int A9 = AREA_MARKS*8;
const int A9_BET_OFFSET = A9+OFFSET_OF_BET;

const int A10 = AREA_MARKS*9;
const int A10_BET_OFFSET = A10+OFFSET_OF_BET;

const int A1_VOID = TOTAL_ECPN_MARKS+0;
const int A2_VOID = TOTAL_ECPN_MARKS+1;
const int A3_VOID = TOTAL_ECPN_MARKS+2;
const int A4_VOID = TOTAL_ECPN_MARKS+3;
const int A5_VOID = TOTAL_ECPN_MARKS+4;
const int A6_VOID = TOTAL_ECPN_MARKS+5;
const int A7_VOID = TOTAL_ECPN_MARKS+6;
const int A8_VOID = TOTAL_ECPN_MARKS+7;
const int A9_VOID = TOTAL_ECPN_MARKS+8;
const int A10_VOID = TOTAL_ECPN_MARKS+9;

const int A01_GPROFF = NO_MARK;
const int A02_GPROFF = NO_MARK;
const int A03_GPROFF = NO_MARK;
const int A04_GPROFF = NO_MARK;
const int A05_GPROFF = NO_MARK;
const int A06_GPROFF = NO_MARK;
const int A07_GPROFF = NO_MARK;
const int A08_GPROFF = NO_MARK;
const int A09_GPROFF = NO_MARK;
const int A10_GPROFF = NO_MARK;

const int GRP_R = 72;
const int GRP_A = 73;
const int GRP_B = 74;
const int GRP_C = 75;
const int GRP_D = 76;

const int SWITCH = 37;

const int NUM_OF_GROUP_MARKS = (4*NUM_O_PLAYSLIP_AREAS); //4: R,A,B,C

const uint TotalScanCouponMarks_c = //0x1FB //original
    NUM_0_PLAYSLIP_MULTS +
    NUM_O_PLAYSLIP_PERMS +
    ( NUM_O_PLAYSLIP_AREA_MARKS * NUM_O_PLAYSLIP_AREAS );


//const uint TotalScanCouponMarks_c2 = //0x231 //iFlex half
//    NUM_0_PLAYSLIP_MULTS +
//    NUM_O_PLAYSLIP_PERMS2 +
//    ( NUM_O_PLAYSLIP_AREA_MARKS * NUM_O_PLAYSLIP_AREAS2 );


/// Representation of how the playslip is read by the camera
const int CouponToMarks_c[TotalScanCouponMarks_c]=
{

    /// FOLLOWING ALL SQUARE/CIRCULAR MARKS

    // For Playslip Systems
//    OFFSET_OF_SYS, // System 0 (not supported in CH)
    OFFSET_OF_SYS+1, // System 1
    OFFSET_OF_SYS+2, // System 2
    OFFSET_OF_SYS+3, // System 3
    OFFSET_OF_SYS+4, // System 4
    OFFSET_OF_SYS+5, // System 5
    OFFSET_OF_SYS+6, // System 6
    OFFSET_OF_SYS+7, // System 7
    OFFSET_OF_SYS+8, // System 8
    OFFSET_OF_SYS+9, // System 9
    OFFSET_OF_SYS+10, // System 10
//    OFFSET_OF_SYS+55, // System 11 (not supported in CH)
//    OFFSET_OF_SYS+60, // System 12 (not supported in CH)

    // aste :  CH has 18 stakes (BG had 12)
    // Stake
    OFFSET_OF_STAKE,     // 500
    OFFSET_OF_STAKE+1,   // 1000
    OFFSET_OF_STAKE+2,   // 2000
    OFFSET_OF_STAKE+3,   // 3000
    OFFSET_OF_STAKE+4,   // 4000
    OFFSET_OF_STAKE+5,   // 5000
    OFFSET_OF_STAKE+6,   // 6000
    OFFSET_OF_STAKE+7,   // 7000
    OFFSET_OF_STAKE+8,   // 10000
    OFFSET_OF_STAKE+9,   // 15000
    OFFSET_OF_STAKE+10,  // 20000
    OFFSET_OF_STAKE+11,  // 25000
    OFFSET_OF_STAKE+12,  // 30000
    OFFSET_OF_STAKE+13,  // 40000
    OFFSET_OF_STAKE+14,  // 50000
    OFFSET_OF_STAKE+15,  // 100000
    OFFSET_OF_STAKE+16,  // 200000
    OFFSET_OF_STAKE+17,  // 500000

    // 1st Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A1_BET_OFFSET+0 /*#P*/, A1+0 /*1K*/, A1+4,  A1+5,  A1+6,  A1+7,  A1+8,  A1+9,  A1+10, A1+11, A1+12, A1+13, A1_BET_OFFSET+3  /*L*/, A1_BET_OFFSET+6  /*HG*/, A1_BET_OFFSET+9 /*LL*/, A1_BET_OFFSET+12 /*EL*/, A1_BET_OFFSET+15 /*VL*/, A1_BET_OFFSET+18 /*0-1*/, A1_BET_OFFSET+21 /*-G*/, A1_BET_OFFSET+24 /*+G*/, A1_BET_OFFSET+27 /*0.5*/, A1_BET_OFFSET+30  /*1*/, A1_BET_OFFSET+33 /*0*/, A1_BET_OFFSET+36  /*1*/, A1_BET_OFFSET+39 /*0*/, A1_BET_OFFSET+42  /*1*/,
             A1_BET_OFFSET+1 /*#R*/, A1+1 /*2K*/, A1+14, A1+15, A1+16, A1+17, A1+18, A1+19, A1+20, A1+21, A1+22, A1+23, A1_BET_OFFSET+4 /*E*/, A1_BET_OFFSET+7 /*1er*/, A1_BET_OFFSET+10 /*LE*/, A1_BET_OFFSET+13 /*EE*/, A1_BET_OFFSET+16 /*VE*/, A1_BET_OFFSET+19 /*2-3*/, A1_BET_OFFSET+22 /*NG*/, A1_BET_OFFSET+25  /*G*/, A1_BET_OFFSET+28    /*2*/, A1_BET_OFFSET+31  /*3*/, A1_BET_OFFSET+34 /*2*/, A1_BET_OFFSET+37  /*3*/, A1_BET_OFFSET+40 /*2*/, A1_BET_OFFSET+43  /*3*/,
    A1_VOID, A1_BET_OFFSET+2   /*F*/, A1+2 /*3K*/, A1+24, A1+25, A1+26, A1+27, A1+28, A1+29, A1+30, A1+31, A1+32, A1+33, A1_BET_OFFSET+5 /*V*/, A1_BET_OFFSET+8 /*2do*/, A1_BET_OFFSET+11 /*LV*/, A1_BET_OFFSET+14 /*EV*/, A1_BET_OFFSET+17 /*VV*/, A1_BET_OFFSET+20  /*4+*/, A1_BET_OFFSET+23 /*P*/, A1_BET_OFFSET+26  /*I*/, A1_BET_OFFSET+29    /*4*/, A1_BET_OFFSET+32 /*5*/, A1_BET_OFFSET+35 /*4*/, A1_BET_OFFSET+38 /*5+*/, A1_BET_OFFSET+41 /*4*/, A1_BET_OFFSET+44 /*5+*/,

    // 2nd Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A2_BET_OFFSET+0 /*#P*/, A2+0 /*1K*/, A2+4,  A2+5,  A2+6,  A2+7,  A2+8,  A2+9,  A2+10, A2+11, A2+12, A2+13, A2_BET_OFFSET+3  /*L*/, A2_BET_OFFSET+6  /*HG*/, A2_BET_OFFSET+9 /*LL*/, A2_BET_OFFSET+12 /*EL*/, A2_BET_OFFSET+15 /*VL*/, A2_BET_OFFSET+18 /*0-1*/, A2_BET_OFFSET+21 /*-G*/, A2_BET_OFFSET+24 /*+G*/, A2_BET_OFFSET+27 /*0.5*/, A2_BET_OFFSET+30  /*1*/, A2_BET_OFFSET+33 /*0*/, A2_BET_OFFSET+36  /*1*/, A2_BET_OFFSET+39 /*0*/, A2_BET_OFFSET+42  /*1*/,
             A2_BET_OFFSET+1 /*#R*/, A2+1 /*2K*/, A2+14, A2+15, A2+16, A2+17, A2+18, A2+19, A2+20, A2+21, A2+22, A2+23, A2_BET_OFFSET+4 /*E*/, A2_BET_OFFSET+7 /*1er*/, A2_BET_OFFSET+10 /*LE*/, A2_BET_OFFSET+13 /*EE*/, A2_BET_OFFSET+16 /*VE*/, A2_BET_OFFSET+19 /*2-3*/, A2_BET_OFFSET+22 /*NG*/, A2_BET_OFFSET+25  /*G*/, A2_BET_OFFSET+28    /*2*/, A2_BET_OFFSET+31  /*3*/, A2_BET_OFFSET+34 /*2*/, A2_BET_OFFSET+37  /*3*/, A2_BET_OFFSET+40 /*2*/, A2_BET_OFFSET+43  /*3*/,
    A2_VOID, A2_BET_OFFSET+2   /*F*/, A2+2 /*3K*/, A2+24, A2+25, A2+26, A2+27, A2+28, A2+29, A2+30, A2+31, A2+32, A2+33, A2_BET_OFFSET+5 /*V*/, A2_BET_OFFSET+8 /*2do*/, A2_BET_OFFSET+11 /*LV*/, A2_BET_OFFSET+14 /*EV*/, A2_BET_OFFSET+17 /*VV*/, A2_BET_OFFSET+20  /*4+*/, A2_BET_OFFSET+23  /*P*/, A2_BET_OFFSET+26  /*I*/, A2_BET_OFFSET+29    /*4*/, A2_BET_OFFSET+32 /*5*/, A2_BET_OFFSET+35 /*4*/, A2_BET_OFFSET+38 /*5+*/, A2_BET_OFFSET+41 /*4*/, A2_BET_OFFSET+44 /*5+*/,

    // 3rd Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A3_BET_OFFSET+0 /*#P*/, A3+0 /*1K*/, A3+4,  A3+5,  A3+6,  A3+7,  A3+8,  A3+9,  A3+10, A3+11, A3+12, A3+13, A3_BET_OFFSET+3  /*L*/, A3_BET_OFFSET+6  /*HG*/, A3_BET_OFFSET+9 /*LL*/, A3_BET_OFFSET+12 /*EL*/, A3_BET_OFFSET+15 /*VL*/, A3_BET_OFFSET+18 /*0-1*/, A3_BET_OFFSET+21 /*-G*/, A3_BET_OFFSET+24 /*+G*/, A3_BET_OFFSET+27 /*0.5*/, A3_BET_OFFSET+30  /*1*/, A3_BET_OFFSET+33 /*0*/, A3_BET_OFFSET+36  /*1*/, A3_BET_OFFSET+39 /*0*/, A3_BET_OFFSET+42  /*1*/,
             A3_BET_OFFSET+1 /*#R*/, A3+1 /*2K*/, A3+14, A3+15, A3+16, A3+17, A3+18, A3+19, A3+20, A3+21, A3+22, A3+23, A3_BET_OFFSET+4 /*E*/, A3_BET_OFFSET+7 /*1er*/, A3_BET_OFFSET+10 /*LE*/, A3_BET_OFFSET+13 /*EE*/, A3_BET_OFFSET+16 /*VE*/, A3_BET_OFFSET+19 /*2-3*/, A3_BET_OFFSET+22 /*NG*/, A3_BET_OFFSET+25  /*G*/, A3_BET_OFFSET+28    /*2*/, A3_BET_OFFSET+31  /*3*/, A3_BET_OFFSET+34 /*2*/, A3_BET_OFFSET+37  /*3*/, A3_BET_OFFSET+40 /*2*/, A3_BET_OFFSET+43  /*3*/,
    A3_VOID, A3_BET_OFFSET+2   /*F*/, A3+2 /*3K*/, A3+24, A3+25, A3+26, A3+27, A3+28, A3+29, A3+30, A3+31, A3+32, A3+33, A3_BET_OFFSET+5 /*V*/, A3_BET_OFFSET+8 /*2do*/, A3_BET_OFFSET+11 /*LV*/, A3_BET_OFFSET+14 /*EV*/, A3_BET_OFFSET+17 /*VV*/, A3_BET_OFFSET+20  /*4+*/, A3_BET_OFFSET+23  /*P*/, A3_BET_OFFSET+26  /*I*/, A3_BET_OFFSET+29    /*4*/, A3_BET_OFFSET+32 /*5*/, A3_BET_OFFSET+35 /*4*/, A3_BET_OFFSET+38 /*5+*/, A3_BET_OFFSET+41 /*4*/, A3_BET_OFFSET+44 /*5+*/,

    // 4th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A4_BET_OFFSET+0 /*#P*/, A4+0 /*1K*/, A4+4,  A4+5,  A4+6,  A4+7,  A4+8,  A4+9,  A4+10, A4+11, A4+12, A4+13, A4_BET_OFFSET+3  /*L*/, A4_BET_OFFSET+6  /*HG*/, A4_BET_OFFSET+9 /*LL*/, A4_BET_OFFSET+12 /*EL*/, A4_BET_OFFSET+15 /*VL*/, A4_BET_OFFSET+18 /*0-1*/, A4_BET_OFFSET+21 /*-G*/, A4_BET_OFFSET+24 /*+G*/, A4_BET_OFFSET+27 /*0.5*/, A4_BET_OFFSET+30  /*1*/, A4_BET_OFFSET+33 /*0*/, A4_BET_OFFSET+36  /*1*/, A4_BET_OFFSET+39 /*0*/, A4_BET_OFFSET+42  /*1*/,
             A4_BET_OFFSET+1 /*#R*/, A4+1 /*2K*/, A4+14, A4+15, A4+16, A4+17, A4+18, A4+19, A4+20, A4+21, A4+22, A4+23, A4_BET_OFFSET+4 /*E*/, A4_BET_OFFSET+7 /*1er*/, A4_BET_OFFSET+10 /*LE*/, A4_BET_OFFSET+13 /*EE*/, A4_BET_OFFSET+16 /*VE*/, A4_BET_OFFSET+19 /*2-3*/, A4_BET_OFFSET+22 /*NG*/, A4_BET_OFFSET+25  /*G*/, A4_BET_OFFSET+28    /*2*/, A4_BET_OFFSET+31  /*3*/, A4_BET_OFFSET+34 /*2*/, A4_BET_OFFSET+37  /*3*/, A4_BET_OFFSET+40 /*2*/, A4_BET_OFFSET+43  /*3*/,
    A4_VOID, A4_BET_OFFSET+2   /*F*/, A4+2 /*3K*/, A4+24, A4+25, A4+26, A4+27, A4+28, A4+29, A4+30, A4+31, A4+32, A4+33, A4_BET_OFFSET+5 /*V*/, A4_BET_OFFSET+8 /*2do*/, A4_BET_OFFSET+11 /*LV*/, A4_BET_OFFSET+14 /*EV*/, A4_BET_OFFSET+17 /*VV*/, A4_BET_OFFSET+20  /*4+*/, A4_BET_OFFSET+23  /*P*/, A4_BET_OFFSET+26  /*I*/, A4_BET_OFFSET+29    /*4*/, A4_BET_OFFSET+32 /*5*/, A4_BET_OFFSET+35 /*4*/, A4_BET_OFFSET+38 /*5+*/, A4_BET_OFFSET+41 /*4*/, A4_BET_OFFSET+44 /*5+*/,

    // 5th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A5_BET_OFFSET+0 /*#P*/, A5+0 /*1K*/, A5+4,  A5+5,  A5+6,  A5+7,  A5+8,  A5+9,  A5+10, A5+11, A5+12, A5+13, A5_BET_OFFSET+3  /*L*/, A5_BET_OFFSET+6  /*HG*/, A5_BET_OFFSET+9 /*LL*/, A5_BET_OFFSET+12 /*EL*/, A5_BET_OFFSET+15 /*VL*/, A5_BET_OFFSET+18 /*0-1*/, A5_BET_OFFSET+21 /*-G*/, A5_BET_OFFSET+24 /*+G*/, A5_BET_OFFSET+27 /*0.5*/, A5_BET_OFFSET+30  /*1*/, A5_BET_OFFSET+33 /*0*/, A5_BET_OFFSET+36  /*1*/, A5_BET_OFFSET+39 /*0*/, A5_BET_OFFSET+42  /*1*/,
             A5_BET_OFFSET+1 /*#R*/, A5+1 /*2K*/, A5+14, A5+15, A5+16, A5+17, A5+18, A5+19, A5+20, A5+21, A5+22, A5+23, A5_BET_OFFSET+4 /*E*/, A5_BET_OFFSET+7 /*1er*/, A5_BET_OFFSET+10 /*LE*/, A5_BET_OFFSET+13 /*EE*/, A5_BET_OFFSET+16 /*VE*/, A5_BET_OFFSET+19 /*2-3*/, A5_BET_OFFSET+22 /*NG*/, A5_BET_OFFSET+25  /*G*/, A5_BET_OFFSET+28    /*2*/, A5_BET_OFFSET+31  /*3*/, A5_BET_OFFSET+34 /*2*/, A5_BET_OFFSET+37  /*3*/, A5_BET_OFFSET+40 /*2*/, A5_BET_OFFSET+43  /*3*/,
    A5_VOID, A5_BET_OFFSET+2   /*F*/, A5+2 /*3K*/, A5+24, A5+25, A5+26, A5+27, A5+28, A5+29, A5+30, A5+31, A5+32, A5+33, A5_BET_OFFSET+5 /*V*/, A5_BET_OFFSET+8 /*2do*/, A5_BET_OFFSET+11 /*LV*/, A5_BET_OFFSET+14 /*EV*/, A5_BET_OFFSET+17 /*VV*/, A5_BET_OFFSET+20  /*4+*/, A5_BET_OFFSET+23  /*P*/, A5_BET_OFFSET+26  /*I*/, A5_BET_OFFSET+29    /*4*/, A5_BET_OFFSET+32 /*5*/, A5_BET_OFFSET+35 /*4*/, A5_BET_OFFSET+38 /*5+*/, A5_BET_OFFSET+41 /*4*/, A5_BET_OFFSET+44 /*5+*/,

    // 6th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A6_BET_OFFSET+0 /*#P*/, A6+0 /*1K*/, A6+4,  A6+5,  A6+6,  A6+7,  A6+8,  A6+9,  A6+10, A6+11, A6+12, A6+13, A6_BET_OFFSET+3  /*L*/, A6_BET_OFFSET+6  /*HG*/, A6_BET_OFFSET+9 /*LL*/, A6_BET_OFFSET+12 /*EL*/, A6_BET_OFFSET+15 /*VL*/, A6_BET_OFFSET+18 /*0-1*/, A6_BET_OFFSET+21 /*-G*/, A6_BET_OFFSET+24 /*+G*/, A6_BET_OFFSET+27 /*0.5*/, A6_BET_OFFSET+30  /*1*/, A6_BET_OFFSET+33 /*0*/, A6_BET_OFFSET+36  /*1*/, A6_BET_OFFSET+39 /*0*/, A6_BET_OFFSET+42  /*1*/,
             A6_BET_OFFSET+1 /*#R*/, A6+1 /*2K*/, A6+14, A6+15, A6+16, A6+17, A6+18, A6+19, A6+20, A6+21, A6+22, A6+23, A6_BET_OFFSET+4 /*E*/, A6_BET_OFFSET+7 /*1er*/, A6_BET_OFFSET+10 /*LE*/, A6_BET_OFFSET+13 /*EE*/, A6_BET_OFFSET+16 /*VE*/, A6_BET_OFFSET+19 /*2-3*/, A6_BET_OFFSET+22 /*NG*/, A6_BET_OFFSET+25  /*G*/, A6_BET_OFFSET+28    /*2*/, A6_BET_OFFSET+31  /*3*/, A6_BET_OFFSET+34 /*2*/, A6_BET_OFFSET+37  /*3*/, A6_BET_OFFSET+40 /*2*/, A6_BET_OFFSET+43  /*3*/,
    A6_VOID, A6_BET_OFFSET+2   /*F*/, A6+2 /*3K*/, A6+24, A6+25, A6+26, A6+27, A6+28, A6+29, A6+30, A6+31, A6+32, A6+33, A6_BET_OFFSET+5 /*V*/, A6_BET_OFFSET+8 /*2do*/, A6_BET_OFFSET+11 /*LV*/, A6_BET_OFFSET+14 /*EV*/, A6_BET_OFFSET+17 /*VV*/, A6_BET_OFFSET+20  /*4+*/, A6_BET_OFFSET+23  /*P*/, A6_BET_OFFSET+26  /*I*/, A6_BET_OFFSET+29    /*4*/, A6_BET_OFFSET+32 /*5*/, A6_BET_OFFSET+35 /*4*/, A6_BET_OFFSET+38 /*5+*/, A6_BET_OFFSET+41 /*4*/, A6_BET_OFFSET+44 /*5+*/,

    // 7th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A7_BET_OFFSET+0 /*#P*/, A7+0 /*1K*/, A7+4,  A7+5,  A7+6,  A7+7,  A7+8,  A7+9,  A7+10, A7+11, A7+12, A7+13, A7_BET_OFFSET+3  /*L*/, A7_BET_OFFSET+6  /*HG*/, A7_BET_OFFSET+9 /*LL*/, A7_BET_OFFSET+12 /*EL*/, A7_BET_OFFSET+15 /*VL*/, A7_BET_OFFSET+18 /*0-1*/, A7_BET_OFFSET+21 /*-G*/, A7_BET_OFFSET+24 /*+G*/, A7_BET_OFFSET+27 /*0.5*/, A7_BET_OFFSET+30  /*1*/, A7_BET_OFFSET+33 /*0*/, A7_BET_OFFSET+36  /*1*/, A7_BET_OFFSET+39 /*0*/, A7_BET_OFFSET+42  /*1*/,
             A7_BET_OFFSET+1 /*#R*/, A7+1 /*2K*/, A7+14, A7+15, A7+16, A7+17, A7+18, A7+19, A7+20, A7+21, A7+22, A7+23, A7_BET_OFFSET+4 /*E*/, A7_BET_OFFSET+7 /*1er*/, A7_BET_OFFSET+10 /*LE*/, A7_BET_OFFSET+13 /*EE*/, A7_BET_OFFSET+16 /*VE*/, A7_BET_OFFSET+19 /*2-3*/, A7_BET_OFFSET+22 /*NG*/, A7_BET_OFFSET+25  /*G*/, A7_BET_OFFSET+28    /*2*/, A7_BET_OFFSET+31  /*3*/, A7_BET_OFFSET+34 /*2*/, A7_BET_OFFSET+37  /*3*/, A7_BET_OFFSET+40 /*2*/, A7_BET_OFFSET+43  /*3*/,
    A7_VOID, A7_BET_OFFSET+2   /*F*/, A7+2 /*3K*/, A7+24, A7+25, A7+26, A7+27, A7+28, A7+29, A7+30, A7+31, A7+32, A7+33, A7_BET_OFFSET+5 /*V*/, A7_BET_OFFSET+8 /*2do*/, A7_BET_OFFSET+11 /*LV*/, A7_BET_OFFSET+14 /*EV*/, A7_BET_OFFSET+17 /*VV*/, A7_BET_OFFSET+20  /*4+*/, A7_BET_OFFSET+23  /*P*/, A7_BET_OFFSET+26  /*I*/, A7_BET_OFFSET+29    /*4*/, A7_BET_OFFSET+32 /*5*/, A7_BET_OFFSET+35 /*4*/, A7_BET_OFFSET+38 /*5+*/, A7_BET_OFFSET+41 /*4*/, A7_BET_OFFSET+44 /*5+*/,

    // 8th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A8_BET_OFFSET+0 /*#P*/, A8+0 /*1K*/, A8+4,  A8+5,  A8+6,  A8+7,  A8+8,  A8+9,  A8+10, A8+11, A8+12, A8+13, A8_BET_OFFSET+3  /*L*/, A8_BET_OFFSET+6  /*HG*/, A8_BET_OFFSET+9 /*LL*/, A8_BET_OFFSET+12 /*EL*/, A8_BET_OFFSET+15 /*VL*/, A8_BET_OFFSET+18 /*0-1*/, A8_BET_OFFSET+21 /*-G*/, A8_BET_OFFSET+24 /*+G*/, A8_BET_OFFSET+27 /*0.5*/, A8_BET_OFFSET+30  /*1*/, A8_BET_OFFSET+33 /*0*/, A8_BET_OFFSET+36  /*1*/, A8_BET_OFFSET+39 /*0*/, A8_BET_OFFSET+42  /*1*/,
             A8_BET_OFFSET+1 /*#R*/, A8+1 /*2K*/, A8+14, A8+15, A8+16, A8+17, A8+18, A8+19, A8+20, A8+21, A8+22, A8+23, A8_BET_OFFSET+4 /*E*/, A8_BET_OFFSET+7 /*1er*/, A8_BET_OFFSET+10 /*LE*/, A8_BET_OFFSET+13 /*EE*/, A8_BET_OFFSET+16 /*VE*/, A8_BET_OFFSET+19 /*2-3*/, A8_BET_OFFSET+22 /*NG*/, A8_BET_OFFSET+25  /*G*/, A8_BET_OFFSET+28    /*2*/, A8_BET_OFFSET+31  /*3*/, A8_BET_OFFSET+34 /*2*/, A8_BET_OFFSET+37  /*3*/, A8_BET_OFFSET+40 /*2*/, A8_BET_OFFSET+43  /*3*/,
    A8_VOID, A8_BET_OFFSET+2   /*F*/, A8+2 /*3K*/, A8+24, A8+25, A8+26, A8+27, A8+28, A8+29, A8+30, A8+31, A8+32, A8+33, A8_BET_OFFSET+5 /*V*/, A8_BET_OFFSET+8 /*2do*/, A8_BET_OFFSET+11 /*LV*/, A8_BET_OFFSET+14 /*EV*/, A8_BET_OFFSET+17 /*VV*/, A8_BET_OFFSET+20  /*4+*/, A8_BET_OFFSET+23  /*P*/, A8_BET_OFFSET+26  /*I*/, A8_BET_OFFSET+29    /*4*/, A8_BET_OFFSET+32 /*5*/, A8_BET_OFFSET+35 /*4*/, A8_BET_OFFSET+38 /*5+*/, A8_BET_OFFSET+41 /*4*/, A8_BET_OFFSET+44 /*5+*/,

    // 9th Playslip Area
    //                                             0      1      2      3      4      5      6      7      8      9                                                                                                                                                                                                                                                                Goles Locales                                    Goles Visita
             A9_BET_OFFSET+0 /*#P*/, A9+0 /*1K*/, A9+4,  A9+5,  A9+6,  A9+7,  A9+8,  A9+9,  A9+10, A9+11, A9+12, A9+13, A9_BET_OFFSET+3  /*L*/, A9_BET_OFFSET+6  /*HG*/, A9_BET_OFFSET+9 /*LL*/, A9_BET_OFFSET+12 /*EL*/, A9_BET_OFFSET+15 /*VL*/, A9_BET_OFFSET+18 /*0-1*/, A9_BET_OFFSET+21 /*-G*/, A9_BET_OFFSET+24 /*+G*/, A9_BET_OFFSET+27 /*0.5*/, A9_BET_OFFSET+30  /*1*/, A9_BET_OFFSET+33 /*0*/, A9_BET_OFFSET+36  /*1*/, A9_BET_OFFSET+39 /*0*/, A9_BET_OFFSET+42  /*1*/,
             A9_BET_OFFSET+1 /*#R*/, A9+1 /*2K*/, A9+14, A9+15, A9+16, A9+17, A9+18, A9+19, A9+20, A9+21, A9+22, A9+23, A9_BET_OFFSET+4 /*E*/, A9_BET_OFFSET+7 /*1er*/, A9_BET_OFFSET+10 /*LE*/, A9_BET_OFFSET+13 /*EE*/, A9_BET_OFFSET+16 /*VE*/, A9_BET_OFFSET+19 /*2-3*/, A9_BET_OFFSET+22 /*NG*/, A9_BET_OFFSET+25  /*G*/, A9_BET_OFFSET+28    /*2*/, A9_BET_OFFSET+31  /*3*/, A9_BET_OFFSET+34 /*2*/, A9_BET_OFFSET+37  /*3*/, A9_BET_OFFSET+40 /*2*/, A9_BET_OFFSET+43  /*3*/,
    A9_VOID, A9_BET_OFFSET+2   /*F*/, A9+2 /*3K*/, A9+24, A9+25, A9+26, A9+27, A9+28, A9+29, A9+30, A9+31, A9+32, A9+33, A9_BET_OFFSET+5 /*V*/, A9_BET_OFFSET+8 /*2do*/, A9_BET_OFFSET+11 /*LV*/, A9_BET_OFFSET+14 /*EV*/, A9_BET_OFFSET+17 /*VV*/, A9_BET_OFFSET+20  /*4+*/, A9_BET_OFFSET+23  /*P*/, A9_BET_OFFSET+26  /*I*/, A9_BET_OFFSET+29    /*4*/, A9_BET_OFFSET+32 /*5*/, A9_BET_OFFSET+35 /*4*/, A9_BET_OFFSET+38 /*5+*/, A9_BET_OFFSET+41 /*4*/, A9_BET_OFFSET+44 /*5+*/,

    // 10th Playslip Area
    //                                                0       1       2       3       4       5       6       7       8       9                                                                                                                                                                                                                                                                           Goles Locales                                      Goles Visita
              A10_BET_OFFSET+0 /*#P*/, A10+0 /*1K*/, A10+4,  A10+5,  A10+6,  A10+7,  A10+8,  A10+9,  A10+10, A10+11, A10+12, A10+13, A10_BET_OFFSET+3  /*L*/, A10_BET_OFFSET+6  /*HG*/, A10_BET_OFFSET+9 /*LL*/, A10_BET_OFFSET+12 /*EL*/, A10_BET_OFFSET+15 /*VL*/, A10_BET_OFFSET+18 /*0-1*/, A10_BET_OFFSET+21 /*-G*/, A10_BET_OFFSET+24 /*+G*/, A10_BET_OFFSET+27 /*0.5*/, A10_BET_OFFSET+30  /*1*/, A10_BET_OFFSET+33 /*0*/, A10_BET_OFFSET+36  /*1*/, A10_BET_OFFSET+39 /*0*/, A10_BET_OFFSET+42  /*1*/,
              A10_BET_OFFSET+1 /*#R*/, A10+1 /*2K*/, A10+14, A10+15, A10+16, A10+17, A10+18, A10+19, A10+20, A10+21, A10+22, A10+23, A10_BET_OFFSET+4 /*E*/, A10_BET_OFFSET+7 /*1er*/, A10_BET_OFFSET+10 /*LE*/, A10_BET_OFFSET+13 /*EE*/, A10_BET_OFFSET+16 /*VE*/, A10_BET_OFFSET+19 /*2-3*/, A10_BET_OFFSET+22 /*NG*/, A10_BET_OFFSET+25  /*G*/, A10_BET_OFFSET+28    /*2*/, A10_BET_OFFSET+31  /*3*/, A10_BET_OFFSET+34 /*2*/, A10_BET_OFFSET+37  /*3*/, A10_BET_OFFSET+40 /*2*/, A10_BET_OFFSET+43  /*3*/,
    A10_VOID, A10_BET_OFFSET+2   /*F*/, A10+2 /*3K*/, A10+24, A10+25, A10+26, A10+27, A10+28, A10+29, A10+30, A10+31, A10+32, A10+33, A10_BET_OFFSET+5 /*V*/, A10_BET_OFFSET+8 /*2do*/, A10_BET_OFFSET+11 /*LV*/, A10_BET_OFFSET+14 /*EV*/, A10_BET_OFFSET+17 /*VV*/, A10_BET_OFFSET+20  /*4+*/, A10_BET_OFFSET+23  /*P*/, A10_BET_OFFSET+26  /*I*/, A10_BET_OFFSET+29    /*4*/, A10_BET_OFFSET+32 /*5*/, A10_BET_OFFSET+35 /*4*/, A10_BET_OFFSET+38 /*5+*/, A10_BET_OFFSET+41 /*4*/, A10_BET_OFFSET+44 /*5+*/,

//    // 11th Playslip Area
//    A11+0,                  A11+4,         A11+5,            A11+6,            A11+7,             A11+8,            A11+9,            A11+10,           A11+11,           A11+12,           A11+13,            /*A11_BET_OFFSET+5,*/  A11_BET_OFFSET+18, A11_BET_OFFSET+21, A11_BET_OFFSET+24, A11_BET_OFFSET+27, A11_BET_OFFSET+30, A11_VOID            ,
//    A11+1,                  A11+14,        A11+15,           A11+16,           A11+17,            A11+18,           A11+19,           A11+20,           A11+21,           A11+22,           A11+23,            /*A11_BET_OFFSET+15,*/ A11_BET_OFFSET+19, A11_BET_OFFSET+22, A11_BET_OFFSET+25, A11_BET_OFFSET+28, A11_BET_OFFSET+31, A11_BET_OFFSET+34   ,
//    A11+2,                  A11+24,        A11+25,           A11+26,           A11+27,            A11+28,           A11+29,           A11+30,           A11+31,           A11+32,           A11+33,            /*A11_BET_OFFSET+16,*/ A11_BET_OFFSET+20, A11_BET_OFFSET+23, A11_BET_OFFSET+26, A11_BET_OFFSET+29, A11_BET_OFFSET+32, A11_BET_OFFSET+35   ,
//    A11_BET_OFFSET+SWITCH,  A11_BET_OFFSET, A11_BET_OFFSET+1, A11_BET_OFFSET+2, A11_BET_OFFSET+33, A11_BET_OFFSET+3, A11_BET_OFFSET+4, A11_BET_OFFSET+6, A11_BET_OFFSET+7, A11_BET_OFFSET+9, A11_BET_OFFSET+10, /*A11_BET_OFFSET+17,*/ A11_BET_OFFSET+8,  A11_BET_OFFSET+11, A11_BET_OFFSET+12, A11_BET_OFFSET+13, A11_BET_OFFSET+14, A11_BET_OFFSET+36   ,

//    // 12th Playslip Area
//    A12+0,                  A12+4,         A12+5,            A12+6,            A12+7,             A12+8,            A12+9,            A12+10,           A12+11,           A12+12,           A12+13,            /*A12_BET_OFFSET+5,*/  A12_BET_OFFSET+18, A12_BET_OFFSET+21, A12_BET_OFFSET+24, A12_BET_OFFSET+27, A12_BET_OFFSET+30, A12_VOID            ,
//    A12+1,                  A12+14,        A12+15,           A12+16,           A12+17,            A12+18,           A12+19,           A12+20,           A12+21,           A12+22,           A12+23,            /*A12_BET_OFFSET+15,*/ A12_BET_OFFSET+19, A12_BET_OFFSET+22, A12_BET_OFFSET+25, A12_BET_OFFSET+28, A12_BET_OFFSET+31, A12_BET_OFFSET+34   ,
//    A12+2,                  A12+24,        A12+25,           A12+26,           A12+27,            A12+28,           A12+29,           A12+30,           A12+31,           A12+32,           A12+33,            /*A12_BET_OFFSET+16,*/ A12_BET_OFFSET+20, A12_BET_OFFSET+23, A12_BET_OFFSET+26, A12_BET_OFFSET+29, A12_BET_OFFSET+32, A12_BET_OFFSET+35   ,
//    A12_BET_OFFSET+SWITCH,  A12_BET_OFFSET, A12_BET_OFFSET+1, A12_BET_OFFSET+2, A12_BET_OFFSET+33, A12_BET_OFFSET+3, A12_BET_OFFSET+4, A12_BET_OFFSET+6, A12_BET_OFFSET+7, A12_BET_OFFSET+9, A12_BET_OFFSET+10, /*A12_BET_OFFSET+17,*/ A12_BET_OFFSET+8,  A12_BET_OFFSET+11, A12_BET_OFFSET+12, A12_BET_OFFSET+13, A12_BET_OFFSET+14, A12_BET_OFFSET+36   ,


    /// FOLLOWING ALL RECTANGLE MARKS
    // None in CH (all are squares/circles)


//    //Area 2
//    A2_BET_OFFSET+34 /*0-1*/, A2_BET_OFFSET+23 /*0.5*/, A2_BET_OFFSET+6  /*1*/,
//    A2_BET_OFFSET+35 /*2-3*/, A2_BET_OFFSET+7    /*2*/, A2_BET_OFFSET+8  /*3*/,
//    A2_BET_OFFSET+36  /*4+*/, A2_BET_OFFSET+9    /*4*/, A2_BET_OFFSET+33 /*5*/,

//    //Area 11
//    A11_BET_OFFSET+5, //[0.5]
//    A11_BET_OFFSET+15,//[0-1]
//    A11_BET_OFFSET+16,//[2-3]
//    A11_BET_OFFSET+17,//[4+ ]

//    //Area 12
//    A12_BET_OFFSET+5, //[0.5]
//    A12_BET_OFFSET+15,//[0-1]
//    A12_BET_OFFSET+16,//[2-3]
//    A12_BET_OFFSET+17,//[4+ ]

    // aste : ALL-system not supported in CH
//    // PRMUTATION ALL
//    OFFSET_OF_SYS_ALL,

    // aste : No multipliers in CH
//    // Multiplier
//    OFFSET_OF_MULT,   //2
//    OFFSET_OF_MULT+1, //3
//    OFFSET_OF_MULT+2, //4
//    OFFSET_OF_MULT+3  //5
};


//playslip 2
/////////////////////////////////////////////////////////////////////////////////
/// Representation of how the playslip is read by the camera
//const int CouponToMarks_c2[TotalScanCouponMarks_c2]=
//{
//    /// FOLLOWING ALL SQUARE MARKS [1k][0][1]

//    // For Playslip Systems
//    OFFSET_OF_SYS,
//    OFFSET_OF_SYS+5,
//    OFFSET_OF_SYS+10,
//    OFFSET_OF_SYS+15,
//    OFFSET_OF_SYS+20,
//    OFFSET_OF_SYS+25,
//    OFFSET_OF_SYS+30,

//    //1k                   0              1                2                3                 4                5                6                7                8                9                 0.5
//    // 1st Playslip Area
//    A1+0,/*1_2K 2_3K 3_4K*/A1+4,          A1+5,            A1+6,            A1+7,             A1+8,            A1+9,            A1+10,           A1+11,           A1+12,           A1+13,            /*A1_BET_OFFSET+5,*/  A1_BET_OFFSET+18, A1_BET_OFFSET+21, A1_BET_OFFSET+24, A1_BET_OFFSET+27, A1_BET_OFFSET+30, A1_VOID         ,
//    A1+1,                  A1+14,         A1+15,           A1+16,           A1+17,            A1+18,           A1+19,           A1+20,           A1+21,           A1+22,           A1+23,            /*A1_BET_OFFSET+15,*/ A1_BET_OFFSET+19, A1_BET_OFFSET+22, A1_BET_OFFSET+25, A1_BET_OFFSET+28, A1_BET_OFFSET+31, A1_BET_OFFSET+34,
//    A1+2,                  A1+24,         A1+25,           A1+26,           A1+27,            A1+28,           A1+29,           A1+30,           A1+31,           A1+32,           A1+33,            /*A1_BET_OFFSET+16,*/ A1_BET_OFFSET+20, A1_BET_OFFSET+23, A1_BET_OFFSET+26, A1_BET_OFFSET+29, A1_BET_OFFSET+32, A1_BET_OFFSET+35,
//    A1_BET_OFFSET+SWITCH,  A1_BET_OFFSET, A1_BET_OFFSET+1, A1_BET_OFFSET+2, A1_BET_OFFSET+33, A1_BET_OFFSET+3, A1_BET_OFFSET+4, A1_BET_OFFSET+6, A1_BET_OFFSET+7, A1_BET_OFFSET+9, A1_BET_OFFSET+10, /*A1_BET_OFFSET+17,*/ A1_BET_OFFSET+8,  A1_BET_OFFSET+11, A1_BET_OFFSET+12, A1_BET_OFFSET+13, A1_BET_OFFSET+14, A1_BET_OFFSET+36,

//    // 2nd Playslip Area
//    A2+0,                  A2+4,          A2+5,            A2+6,            A2+7,             A2+8,            A2+9,            A2+10,           A2+11,           A2+12,           A2+13,            /*A2_BET_OFFSET+5,*/  A2_BET_OFFSET+18, A2_BET_OFFSET+21, A2_BET_OFFSET+24, A2_BET_OFFSET+27, A2_BET_OFFSET+30, A2_VOID         ,
//    A2+1,                  A2+14,         A2+15,           A2+16,           A2+17,            A2+18,           A2+19,           A2+20,           A2+21,           A2+22,           A2+23,            /*A2_BET_OFFSET+15,*/ A2_BET_OFFSET+19, A2_BET_OFFSET+22, A2_BET_OFFSET+25, A2_BET_OFFSET+28, A2_BET_OFFSET+31, A2_BET_OFFSET+34,
//    A2+2,                  A2+24,         A2+25,           A2+26,           A2+27,            A2+28,           A2+29,           A2+30,           A2+31,           A2+32,           A2+33,            /*A2_BET_OFFSET+16,*/ A2_BET_OFFSET+20, A2_BET_OFFSET+23, A2_BET_OFFSET+26, A2_BET_OFFSET+29, A2_BET_OFFSET+32, A2_BET_OFFSET+35,
//    A2_BET_OFFSET+SWITCH,  A2_BET_OFFSET, A2_BET_OFFSET+1, A2_BET_OFFSET+2, A2_BET_OFFSET+33, A2_BET_OFFSET+3, A2_BET_OFFSET+4, A2_BET_OFFSET+6, A2_BET_OFFSET+7, A2_BET_OFFSET+9, A2_BET_OFFSET+10, /*A2_BET_OFFSET+17,*/ A2_BET_OFFSET+8,  A2_BET_OFFSET+11, A2_BET_OFFSET+12, A2_BET_OFFSET+13, A2_BET_OFFSET+14, A2_BET_OFFSET+36,

//    // 3rd Playslip Area
//    A3+0,                  A3+4,          A3+5,            A3+6,            A3+7,             A3+8,            A3+9,            A3+10,           A3+11,           A3+12,           A3+13,            /*A3_BET_OFFSET+5,*/  A3_BET_OFFSET+18, A3_BET_OFFSET+21, A3_BET_OFFSET+24, A3_BET_OFFSET+27, A3_BET_OFFSET+30, A3_VOID         ,
//    A3+1,                  A3+14,         A3+15,           A3+16,           A3+17,            A3+18,           A3+19,           A3+20,           A3+21,           A3+22,           A3+23,            /*A3_BET_OFFSET+15,*/ A3_BET_OFFSET+19, A3_BET_OFFSET+22, A3_BET_OFFSET+25, A3_BET_OFFSET+28, A3_BET_OFFSET+31, A3_BET_OFFSET+34,
//    A3+2,                  A3+24,         A3+25,           A3+26,           A3+27,            A3+28,           A3+29,           A3+30,           A3+31,           A3+32,           A3+33,            /*A3_BET_OFFSET+16,*/ A3_BET_OFFSET+20, A3_BET_OFFSET+23, A3_BET_OFFSET+26, A3_BET_OFFSET+29, A3_BET_OFFSET+32, A3_BET_OFFSET+35,
//    A3_BET_OFFSET+SWITCH,  A3_BET_OFFSET, A3_BET_OFFSET+1, A3_BET_OFFSET+2, A3_BET_OFFSET+33, A3_BET_OFFSET+3, A3_BET_OFFSET+4, A3_BET_OFFSET+6, A3_BET_OFFSET+7, A3_BET_OFFSET+9, A3_BET_OFFSET+10, /*A3_BET_OFFSET+17,*/ A3_BET_OFFSET+8,  A3_BET_OFFSET+11, A3_BET_OFFSET+12, A3_BET_OFFSET+13, A3_BET_OFFSET+14, A3_BET_OFFSET+36,

//    // 4th Playslip Area
//    A4+0,                  A4+4,          A4+5,            A4+6,            A4+7,             A4+8,            A4+9,            A4+10,           A4+11,           A4+12,           A4+13,            /*A4_BET_OFFSET+5,*/  A4_BET_OFFSET+18, A4_BET_OFFSET+21, A4_BET_OFFSET+24, A4_BET_OFFSET+27, A4_BET_OFFSET+30, A4_VOID         ,
//    A4+1,                  A4+14,         A4+15,           A4+16,           A4+17,            A4+18,           A4+19,           A4+20,           A4+21,           A4+22,           A4+23,            /*A4_BET_OFFSET+15,*/ A4_BET_OFFSET+19, A4_BET_OFFSET+22, A4_BET_OFFSET+25, A4_BET_OFFSET+28, A4_BET_OFFSET+31, A4_BET_OFFSET+34,
//    A4+2,                  A4+24,         A4+25,           A4+26,           A4+27,            A4+28,           A4+29,           A4+30,           A4+31,           A4+32,           A4+33,            /*A4_BET_OFFSET+16,*/ A4_BET_OFFSET+20, A4_BET_OFFSET+23, A4_BET_OFFSET+26, A4_BET_OFFSET+29, A4_BET_OFFSET+32, A4_BET_OFFSET+35,
//    A4_BET_OFFSET+SWITCH,  A4_BET_OFFSET, A4_BET_OFFSET+1, A4_BET_OFFSET+2, A4_BET_OFFSET+33, A4_BET_OFFSET+3, A4_BET_OFFSET+4, A4_BET_OFFSET+6, A4_BET_OFFSET+7, A4_BET_OFFSET+9, A4_BET_OFFSET+10, /*A4_BET_OFFSET+17,*/ A4_BET_OFFSET+8,  A4_BET_OFFSET+11, A4_BET_OFFSET+12, A4_BET_OFFSET+13, A4_BET_OFFSET+14, A4_BET_OFFSET+36,

//    // 5th Playslip Area
//    A5+0,                  A5+4,          A5+5,            A5+6,            A5+7,             A5+8,            A5+9,            A5+10,           A5+11,           A5+12,           A5+13,            /*A5_BET_OFFSET+5,*/  A5_BET_OFFSET+18, A5_BET_OFFSET+21, A5_BET_OFFSET+24, A5_BET_OFFSET+27, A5_BET_OFFSET+30, A5_VOID         ,
//    A5+1,                  A5+14,         A5+15,           A5+16,           A5+17,            A5+18,           A5+19,           A5+20,           A5+21,           A5+22,           A5+23,            /*A5_BET_OFFSET+15,*/ A5_BET_OFFSET+19, A5_BET_OFFSET+22, A5_BET_OFFSET+25, A5_BET_OFFSET+28, A5_BET_OFFSET+31, A5_BET_OFFSET+34,
//    A5+2,                  A5+24,         A5+25,           A5+26,           A5+27,            A5+28,           A5+29,           A5+30,           A5+31,           A5+32,           A5+33,            /*A5_BET_OFFSET+16,*/ A5_BET_OFFSET+20, A5_BET_OFFSET+23, A5_BET_OFFSET+26, A5_BET_OFFSET+29, A5_BET_OFFSET+32, A5_BET_OFFSET+35,
//    A5_BET_OFFSET+SWITCH,  A5_BET_OFFSET, A5_BET_OFFSET+1, A5_BET_OFFSET+2, A5_BET_OFFSET+33, A5_BET_OFFSET+3, A5_BET_OFFSET+4, A5_BET_OFFSET+6, A5_BET_OFFSET+7, A5_BET_OFFSET+9, A5_BET_OFFSET+10, /*A5_BET_OFFSET+17,*/ A5_BET_OFFSET+8,  A5_BET_OFFSET+11, A5_BET_OFFSET+12, A5_BET_OFFSET+13, A5_BET_OFFSET+14, A5_BET_OFFSET+36,

//    // 6th Playslip Area
//    A6+0,                  A6+4,          A6+5,            A6+6,            A6+7,             A6+8,            A6+9,            A6+10,           A6+11,           A6+12,           A6+13,            /*A6_BET_OFFSET+5,*/  A6_BET_OFFSET+18, A6_BET_OFFSET+21, A6_BET_OFFSET+24, A6_BET_OFFSET+27, A6_BET_OFFSET+30, A6_VOID         ,
//    A6+1,                  A6+14,         A6+15,           A6+16,           A6+17,            A6+18,           A6+19,           A6+20,           A6+21,           A6+22,           A6+23,            /*A6_BET_OFFSET+15,*/ A6_BET_OFFSET+19, A6_BET_OFFSET+22, A6_BET_OFFSET+25, A6_BET_OFFSET+28, A6_BET_OFFSET+31, A6_BET_OFFSET+34,
//    A6+2,                  A6+24,         A6+25,           A6+26,           A6+27,            A6+28,           A6+29,           A6+30,           A6+31,           A6+32,           A6+33,            /*A6_BET_OFFSET+16,*/ A6_BET_OFFSET+20, A6_BET_OFFSET+23, A6_BET_OFFSET+26, A6_BET_OFFSET+29, A6_BET_OFFSET+32, A6_BET_OFFSET+35,
//    A6_BET_OFFSET+SWITCH,  A6_BET_OFFSET, A6_BET_OFFSET+1, A6_BET_OFFSET+2, A6_BET_OFFSET+33, A6_BET_OFFSET+3, A6_BET_OFFSET+4, A6_BET_OFFSET+6, A6_BET_OFFSET+7, A6_BET_OFFSET+9, A6_BET_OFFSET+10, /*A6_BET_OFFSET+17,*/ A6_BET_OFFSET+8,  A6_BET_OFFSET+11, A6_BET_OFFSET+12, A6_BET_OFFSET+13, A6_BET_OFFSET+14, A6_BET_OFFSET+36,

//    /// FOLLOWING ALL RECTANGLE MARKS: score [ 0.5 ] [ 0-1 ] [ 2-3 ] [ 4+ ] ,sysall [ ALL ], multipliers [ 100 ] [  50 ]...
//    //Area 1
//    A1_BET_OFFSET+5, //[0.5]
//    A1_BET_OFFSET+15,//[0-1]
//    A1_BET_OFFSET+16,//[2-3]
//    A1_BET_OFFSET+17,//[4+ ]
//    //Area 2
//    A2_BET_OFFSET+5, //[0.5]
//    A2_BET_OFFSET+15,//[0-1]
//    A2_BET_OFFSET+16,//[2-3]
//    A2_BET_OFFSET+17,//[4+ ]
//    //Area 3
//    A3_BET_OFFSET+5, //[0.5]
//    A3_BET_OFFSET+15,//[0-1]
//    A3_BET_OFFSET+16,//[2-3]
//    A3_BET_OFFSET+17,//[4+ ]
//    //Area 4
//    A4_BET_OFFSET+5, //[0.5]
//    A4_BET_OFFSET+15,//[0-1]
//    A4_BET_OFFSET+16,//[2-3]
//    A4_BET_OFFSET+17,//[4+ ]
//    //Area 5
//    A5_BET_OFFSET+5, //[0.5]
//    A5_BET_OFFSET+15,//[0-1]
//    A5_BET_OFFSET+16,//[2-3]
//    A5_BET_OFFSET+17,//[4+ ]
//    //Area 6
//    A6_BET_OFFSET+5, //[0.5]
//    A6_BET_OFFSET+15,//[0-1]
//    A6_BET_OFFSET+16,//[2-3]
//    A6_BET_OFFSET+17,//[4+ ]

//    // PRMUTATION ALL
//    OFFSET_OF_SYS_ALL,

//    // Stake
//    OFFSET_OF_STAKE,     //0.1
//    OFFSET_OF_STAKE+1,   //0.2
//    OFFSET_OF_STAKE+2,   //0.5
//    OFFSET_OF_STAKE+3,   //1
//    OFFSET_OF_STAKE+4,   //2
//    OFFSET_OF_STAKE+5,   //5
//    OFFSET_OF_STAKE+6,   //10
//    OFFSET_OF_STAKE+7,   //20
//    OFFSET_OF_STAKE+8,   //50
//    OFFSET_OF_STAKE+9,   //100
//    OFFSET_OF_STAKE+10,  //250
//    OFFSET_OF_STAKE+11,  //500

//    // Multiplier
//    OFFSET_OF_MULT,   //2
//    OFFSET_OF_MULT+1, //3
//    OFFSET_OF_MULT+2, //4
//    OFFSET_OF_MULT+3  //5
//};



const int BIT_0_POS = 7;
const int BIT_1_POS = 6;
const int BIT_2_POS = 5;
const int BIT_3_POS = 4;
const int BIT_4_POS = 3;
const int BIT_5_POS = 2;
const int BIT_6_POS = 1;
const int BIT_7_POS = 0;






#endif
