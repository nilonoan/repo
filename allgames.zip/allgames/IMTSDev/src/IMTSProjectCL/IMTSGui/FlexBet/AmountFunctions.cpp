#include "AmountFunctions.h"
#include "GetConfigValue.h"
#include <qstring.h>
#include <qfile.h>
#include <qdom.h>
#include <qtextstream.h>

#define FRACTIONAL_SIZE		6

/******************************GetFileColumnCost()*********************************
* Returns the column price found in the 'column price file'. If it does not
* exist it returns the default game column price the game is either build with
* or set at runtime.
***********************************************************************************/
void AmountFunctions::GetFileColumnCost ( unsigned long ulGameCode )
{
    double dColumnCost=0;

    dColumnCost = getColumnCost(); //IGC_COLUMN_PRICE;

    QString strFile = QString ( "%1%2.col" ).arg ( GetColumnCostsFolder() ).arg ( ulGameCode );
    QFile AmountFunctionsFile ( strFile );

    if ( !AmountFunctionsFile.exists() )
        return;

    if ( AmountFunctionsFile.open ( IO_ReadOnly ) )
    {
        QTextStream stream ( &AmountFunctionsFile );
        stream >> dColumnCost;
        AmountFunctionsFile.close();
        setColumnCost( dColumnCost ); //update with the new value
    }
}

/******************************SetFileColumnCost()*********************************
* This functions updates the 'column price' file if other than the active column
* price is calculated over the CS rellied data.
***********************************************************************************/
void AmountFunctions::SetFileColumnCost ( unsigned long ulGameCode,  double dColumnCost )
{
    QFile AmountFunctionsFile ( QString ( "%1%2.col" ).arg ( GetColumnCostsFolder() ).arg ( ulGameCode ) );

    if ( !AmountFunctionsFile.exists() )
    {
        if ( !AmountFunctionsFile.open ( IO_ReadWrite ) )
            return;
    }
    else
    {
        if ( !AmountFunctionsFile.open ( IO_WriteOnly ) )
            return;
    }

    QTextStream stream ( &AmountFunctionsFile );
    stream << dColumnCost;
    AmountFunctionsFile.close();
}

/******************************UpdateFileColumnCost()******************************
* This function is called when we retreive a new column price for the game
***********************************************************************************/
bool AmountFunctions::UpdateFileColumnCost ( CSS_IT_1 *css_it_1, REPLY_100_1 *reply_100_1 )
{
    if( css_it_1==NULL || reply_100_1==NULL )
        return false;

    double dTotalCost=0;
    double dColumnCost=0;
    bool bResult = false;

    //normal & win promotion
    if ( IsReplyPromotion(css_it_1->flags) ) /*&& (!reply_100_1->data[8]):not a team coupon*/
        return bResult;

    unsigned int uiDraws = reply_100_1->data[5] - reply_100_1->data[3] + 1;
    unsigned long uiColumns = reply_100_1->data[1];

    dTotalCost = getAmount ( ( AMOUNT_STRC * ) &reply_100_1->amount );
    dColumnCost  = dTotalCost / ( uiDraws * uiColumns );

    if ( dColumnCost!=getColumnCost() && dColumnCost )
    {
        SetFileColumnCost ( reply_100_1->game,dColumnCost );
        setColumnCost ( dColumnCost );

//        printf ( "Game(%d)::Updating column price=%0.2f\n",reply_100_1->game,dColumnCost );
//        pLogger->LogE ( eeLoggerInfo,true, ( char* ) "Game(%d)::Updating column price=%0.2f",reply_100_1->game,dColumnCost );
        bResult = true;
    }
    return bResult;
}


double AmountFunctions::getAmount(AMOUNT_STRC *amount)
{
//    double d,di,df;
//    di=(double)labs(amount->i);
//    df=(double)labs(amount->f);
//    d=di+df/(pow(10.0,FRACTIONAL_SIZE));
//    if (amount->i<0 || amount->f<0)
//        d=d*((double)(-1.0));

//    return d;
    static bool bFourBillionSupport = GetConfigValue::fourBillionSupport ();

    if ( bFourBillionSupport ) {

        long long d = 0;
        long long di = 0;
        long long df = 0;

        di=amount->i;
        df=amount->f;
        d=(di<<32)|(df&0x00000000FFFFFFFFLL);

        return (double)d;

    } else {

        double d = 0.;
        double di = 0.;
        double df = 0.;

        di = (double)labs(amount->i);
        df = (double)labs(amount->f);

        d = di+df/(pow(10.0,FRACTIONAL_SIZE));

        if (amount->i<0 || amount->f<0) {
            d = d*((double)(-1.0));
        }

        return d;
    }
}

QString AmountFunctions::getAmountStr(AMOUNT_STRC *amount)
{
    return getAmountStr(getAmount(amount));
}

QString AmountFunctions::getAmountStr(double amount, bool bUseLocale)
{
    QString strAmount="";

    if (bUseLocale)
    {
        strAmount = QString("$%L1").arg(amount,0,'f',0);
//        strAmount.replace(",","@");
        strAmount.replace(".",",");
//        strAmount.replace("@",".");
    }
    else
        strAmount = QString("$%1").arg(amount,0,'f',0);

    return strAmount;
}
