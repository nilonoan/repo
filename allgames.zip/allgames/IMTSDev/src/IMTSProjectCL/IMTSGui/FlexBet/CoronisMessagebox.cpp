/***************************************************************************
 Brazil 2008
 ***************************************************************************/

#include "CoronisMessagebox.h"
#include <qpixmap.h>
#include <qlabel.h>
#include <qpainter.h>
#include <qfile.h>
#include "CommonDefinitions.h"
#include "ProjectApp.h"

CoronisMessageBox::CoronisMessageBox (QWidget * parent, const char *name,int timeout):
QDialog (parent, name, true),
  lblTitle(NULL),
  lblContents(NULL),
  timer(NULL),
  bmpBtnMask(NULL),
  btnOk(NULL),
  btnCancel(NULL),
  btnOther(NULL)
{

//    bmpBtnMask=NULL;
    bContFontChanged = bTitleFontChanged = bPositionSet = false;
    iWidth = 320;
    iHeight = 250;
    strTitle = "";
    strContents = "";
    bOkOn = true;
    bCancelOn = bOtherOn = false;
    iBackIconImage=QString::null;
    strOk = ("OK");
    strCancel = ("CANCEL");
    strOther = ("PRINT");
    fntTitle.setFamily(QString("Arial"));

    fntTitle.setPixelSize (14);
    fntContents.setFamily(QString("Arial"));
    fntContents.setPixelSize (12);
    //      fntContents.setCharSet(QFont::ISO_8859_7);
    iRetValue = OKPRESSED;
    QTimer *timer=new QTimer(this);
    connect (timer, SIGNAL (timeout ()), SLOT (OkPressed()));
    if (timeout)
        timer->start(timeout*1000);
}

CoronisMessageBox::~CoronisMessageBox () {
    if (bmpBtnMask) {
        delete bmpBtnMask;
    }
}


//void CoronisMessageBox::SetPixmap (char *s) {
//    pixText.load (s);
//}

void CoronisMessageBox::SetTitle (QString s) {
    strTitle = (s);
}

void CoronisMessageBox::SetContents (QString s) {
    strContents = (s);
}

void CoronisMessageBox::SetContentsNoTRNS (QString s) {
    strContents = s;
}

void CoronisMessageBox::SetButtons(bool bOkValue, bool bCancelValue, bool bOtherValue) {
    bOkOn = bOkValue;
    bCancelOn = bCancelValue;
    bOtherOn = bOtherValue;
}

void CoronisMessageBox::SetOkText (QString s) {
    strOk = s;
}

void CoronisMessageBox::SetCancelText (QString s) {
    strCancel = s;
}

void CoronisMessageBox::SetOtherText (QString s) {
    strOther = s;
}

void CoronisMessageBox::SetTitleFont (QFont f) {
    bTitleFontChanged = true;
    fntTitle = f;
}

void CoronisMessageBox::SetContentsFont (QFont f) {
    bContFontChanged = true;
    fntContents = f;
}

void CoronisMessageBox::SetSize (int w, int h) {
    resize (w, h);
    move ( (APP_SCREEN_WIDTH-w)/2, (APP_SCREEN_HEIGHT-h)/2);
}

void CoronisMessageBox::SetPos (int x, int y) {
    this->move (x,y);
    iPosX=x;
    iPosY=y;
    bPositionSet=true;
}


void CoronisMessageBox::SetRetValue (int ret) {
    iRetValue = ret;
}

int CoronisMessageBox::GetResult () {
    return iRetValue;
}

void
CoronisMessageBox::SetBackIconimage (int Icon) {
    iBackIconImage=Icon;
}

void CoronisMessageBox::Exec (bool Execute) {
    QString fname;

    bmpBtnMask = new QBitmap (m_pApp->getGamesBitmapsPath()+ QString("buttons/msk100x55.bmp"));

    QString bckGroundStr;
    if (iBackIconImage != QString::null)
       bckGroundStr = m_pApp->getGamesBitmapsPath()+ iBackIconImage;
    else
        bckGroundStr = m_pApp->getGamesBitmapsPath()+ QString("panel390X345Ekrou.png");

    setBackgroundPixmap (bckGroundStr);
    QPixmap p (bckGroundStr);
    resize (p.width(), p.height());
    setGeometry((APP_SCREEN_WIDTH/2)-(width()/2),(APP_SCREEN_HEIGHT/2)-(height()/2),width(),height());


    lblTitle = new QLabel (this, "NoName");
    lblTitle->setGeometry (0, 0, width(), 45);
    if (!bTitleFontChanged)
        lblTitle->setFont (QFont ("Arial", 18, 50));
    else
        lblTitle->setFont (fntTitle);

    lblTitle->setAlignment (Qt::AlignHCenter | Qt::AlignVCenter);
    lblTitle->setBackgroundPixmap (p);
    lblTitle->setBackgroundOrigin (QLabel::ParentOrigin);
    QPalette TitlePal;
    TitlePal.setColor (QColorGroup::Foreground, QColor (0, 0, 0));
    lblTitle->setPalette (TitlePal);
    lblTitle->setText (strTitle);

    lblContents = new QLabel (this, "NoName");
    lblContents->setGeometry (0, 45, width(), height()-150);
    if (!bContFontChanged)
        lblContents->setFont (QFont("Arial", 18, 50));
    else
        lblContents->setFont (fntContents);
//    lblContents->setAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::TextWordWrap);
    lblContents->setAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
    lblContents->setBackgroundPixmap (p);
    lblContents->setBackgroundOrigin (ParentOrigin);
    lblContents->setText (strContents);

    int YPos = 105;
    int Pos1 [3][2] ={{(width()-APP_BTN_WIDTH_SMALL)/2,height()-YPos},{0,0},{0,0}};
    int Pos2 [3][2] ={{58,height()-YPos},{width()-58-APP_BTN_WIDTH_SMALL,height()-YPos},{0,0}};
    int Pos3 [3][2] ={{width()/2-3*APP_BTN_WIDTH_SMALL/2-45,height()-YPos},{width()/2-APP_BTN_WIDTH_SMALL/2,height()-YPos},{width()/2-APP_BTN_WIDTH_SMALL+45,height()-YPos}};

    if (bOkOn) {
        btnOk = new TouchButton (this, "btnOk");
//        btnOk->setFocusPolicy(QWidget::NoFocus);
        btnOk->setFocusPolicy(Qt::NoFocus);
        btnOk->setAutoDefault(FALSE);
        if (strOk.contains("EDIT"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnEdit");
        else if (strOk.contains("OK"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnOk");
        else if (strOk.contains("CASH"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnCash");
        else {
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnOther");
            btnOk->setText(strOk);
        }
        btnOk->SetPixmapText (fname);
        btnOk->setMask (*bmpBtnMask);

        connect (btnOk, SIGNAL (sgnPressed ()), SLOT (OkPressed()));
        if (!bCancelOn && !bOtherOn){
            btnOk->setGeometry (Pos1[0][0], Pos1[0][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        }else if (bCancelOn && bOtherOn){
            btnOk->setGeometry (Pos3[0][0], Pos2[0][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        }else{
            btnOk->setGeometry (Pos2[0][0], Pos3[0][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        }
    }
    if (bCancelOn) {
        btnCancel = new TouchButton (this, "btnCancel");
//        btnCancel->setFocusPolicy(QWidget::NoFocus);
        btnCancel->setFocusPolicy(Qt::NoFocus);
        btnCancel->setAutoDefault(FALSE);
        if (bOtherOn)
            btnCancel->setGeometry (Pos3[1][0], Pos3[1][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        else
            btnCancel->setGeometry (Pos2[1][0], Pos2[1][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        if (strCancel.contains("DROP"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnDiscard");
        else if (strCancel.contains("CANCEL"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnCancel");
        else if (strCancel.contains("CHEQUE"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnCheque");
        else {
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnOther");
            btnOk->setText(strCancel);
        }
        btnCancel->SetPixmapText (fname);
        btnCancel->setMask (*bmpBtnMask);
        connect (btnCancel, SIGNAL (sgnPressed ()), SLOT (CancelPressed()));
    }
    if (bOtherOn) {
        btnOther = new TouchButton (this, "btnOther");
//        btnOther->setFocusPolicy(QWidget::NoFocus);
        btnOther->setFocusPolicy(Qt::NoFocus);
        btnOther->setAutoDefault(FALSE);
        if (bCancelOn)
            btnOther->setGeometry (Pos3[2][0], Pos3[2][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        else
            btnOther->setGeometry (Pos2[2][0], Pos2[2][1], APP_BTN_WIDTH_SMALL, APP_BTN_HEIGHT_SMALL);
        if (strOther.contains("PRINT"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnPrint");
        else if (strOther.contains("CANCEL"))
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnCancel");
        else {
            fname = m_pApp->getGamesBitmapsPath()+ QString("buttons/buttonsB/btnOther");
            btnOther->setText(strOther);
        }
        btnOther->SetPixmapText (fname);
        btnOther->setMask (*bmpBtnMask);
        connect (btnOther, SIGNAL (sgnPressed ()), SLOT (OtherPressed()));
    }
    if(Execute == true)
        exec ();
    else if(Execute == false)
        show();
}

void CoronisMessageBox::OkPressed () {
    move(APP_SCREEN_WIDTH,0);
    iRetValue = OKPRESSED;
    close ();
}

void CoronisMessageBox::CancelPressed () {
    move(APP_SCREEN_WIDTH,0);
    iRetValue = CANCELPRESSED;
    close ();
}

void CoronisMessageBox::OtherPressed () {
    iRetValue = OTHERPRESSED;
    close ();
}

//MHNYMA SE AYTON POY TO EGRAPSE : PAPSE NA MAS VASANIZEIS !
/*int DisplayMsg (const char * ptitle, const char * pmsg) {*/
int DisplayMsg (QString ptitle, QString pmsg,QWidget * parent) {

    CoronisMessageBox msb(parent);
    msb.SetTitle(ptitle);
    msb.SetContents( pmsg );
    msb.SetButtons(true, false, false);
    //   if(2==btncount) msb.SetButtons(true, true, false);
    //   if(3==btncount) msb.SetButtons(true, true, true);
    msb.Exec();
    return 1;
}

void CoronisMessageBox::setBackgroundPixmap (QString s){
    m_backGroundPixmap = s;
}

void CoronisMessageBox::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    painter.setPen(Qt::black);
    if (QFile::exists(m_backGroundPixmap))
        painter.drawPixmap(0,0,QPixmap(m_backGroundPixmap));
}

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************
void CoronisMessageBox::SetOk (bool on)
{
    bOkOn = on;
}
void CoronisMessageBox::SetCancel (bool on)
{
    bCancelOn = on;
}
void CoronisMessageBox::SetOther (bool on)
{
    bOtherOn = on;
}
