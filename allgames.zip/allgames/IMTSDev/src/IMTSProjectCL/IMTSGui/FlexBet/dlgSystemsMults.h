#ifndef SYSTEMSMULTIPLIERS_H
#define SYSTEMSMULTIPLIERS_H

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <qpixmap.h>
#include <qbitmap.h>
#include <q3canvas.h>
#include <qdialog.h>
#include <CoronisMessagebox.h>
#include <TouchButton.h>
#include "screenView.h"
#include "coupondefs.h"
#include "FlexBetDefs.h"
#include "FlexBet.h"

#define DISABLE_SYSMULTS

class SystemsMultipliers : public Screen
{

    Q_OBJECT

public:
    SystemsMultipliers(bool draw=false, QWidget *parent=0, const char *name=0);
    ~SystemsMultipliers();

    // aste : Added for CH to show the same statistics on this screen as on the main one
    QLabel *SysLabel;
    QLabel *SysText;
    QLabel *MultLabel;
    QLabel *MultText;
    QLabel *TotalCpnsCostLabel;
    QLabel *TotalCpnsCostText;
    QLabel *DateTimeText;

protected:
    void initDialog();
    void initGraph();
    void initTouchAreas();
    void initMark();

    FlexBet *m_FlexBet;
//    void ShowValues();

    void emptyMulti(int index);

    CouponRecord betCoupon;
//    TouchButton *SMButton[NUM_O_PERMS-1];	//the multiplier button for each system. Remember to set each
    //button's caption to i. All has no touchbutton
    Q3CanvasText *sysText;
    Q3CanvasSprite *sysMultsTick[NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS];	//change the number of choices
    GraphMarkRecord PicArray[NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS];
    TouchButton *ReturnBtn;
    TouchButton *CancelBtn;
    QPixmap bitmap;
    QPixmap screenSys;
    Q3Canvas *mpCanvas;
    screenView *mpView;
    Q3CanvasPixmapArray *pixMarkSysMults;
    Q3CanvasPixmapArray *pixMarkStakes; // aste: Added for CH, as Stake buttons have a different size (and therefore pixmap) than system buttons
    QLabel *m_HideSysMults;

    bool Draw;
    int indexP;
    int sysMultiplier[NUM_O_PERMS-1];	//the systems' multipliers
    int cpnStake;			//the overall stake for the coupon
    int cpnMultiplier;			//the overall multiplier for the coupon
    int sysNumAllowed;			//can be used to set max nbr of systems allowed from outside
public slots:
    void ExitSgn();
    void CancelSgn();
    void MultiSgn();
    void InformMousePressEvent(QMouseEvent *e);
public:
    bool OkPressed;						//use this as an outside switch to copy betCoupon to Couponrec
    //and get the results
    void calculateIt();
    void setSysAllowed(int howMany);
    void setCouponMarks(CouponRecord &rec, int length);
    void getCouponMarks(CouponRecord &rec, int length);
    void getResults(int *sys, int *arrayOfMults, int &multi);
    void UpdateArea();
    void CheckGUI();
    void setFlexBet(FlexBet *FlexBet) { m_FlexBet=FlexBet; }
private slots:
    void showDateTime();
};
#endif
