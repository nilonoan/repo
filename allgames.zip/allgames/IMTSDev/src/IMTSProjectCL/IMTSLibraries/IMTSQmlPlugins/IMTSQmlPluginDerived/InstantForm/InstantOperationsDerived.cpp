﻿/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
 * @file InstantOperationsDerived.cpp
 * @brief Handles InstantOperationsDerived
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */

#include <QtCore/QtDebug>
#include "SystemWideConstValues.h"
#include "InstantOperationsDerived.h"
#include "ImtsLotos5Enumerations.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "LocalEventLoggerEvents.h"
#include "../IMTSQmlModelsDerived/InstantOperationsList/InstantOperationsListDerived.h"
#include "DbusWrapper.h"
#include "JsonOperations.h"
#include "Crypt/SimpleCrypt.h"
#include "RequestDataFromCs.h"
#include "InstantCheckDigits.h"
#include "BarcodeUtilities/BarcodeUtilities.h"
#include "GetConfigValue.h"


const int ORDER_NUMBER_LENGTH_NUMERIC = 10;
const int MANUAL_ACTIVATION_LENGTH = 9;


/*
 * Game-Pack-Ticket-suplier-virn-check digits
 * GGG-PPPPPP-TTT-SS-VVVVVVVVV-CC
 *
 * Game-Pack-Ticket-check digits (CC are not printed in the barcode number)
 * GGG-PPPPPP-TTT-CC
 */


#define DEBUG_FORM
/** @note @developer for debugging
 * To test the forms you can use barcode "264900034552091" which will pass isBarcodeValid algorithm.
 * Of course you could do #define DEBUG_FORM above. But remember to undo it when code is released.
 * Eventhough, in release mode code will always undef DEBUG_FORM
 */

#if defined DEBUG_FORM && IMTS_GUI_TX_RELEASE
#undef DEBUG_FORM
#endif

InstantOperationsDerived::InstantOperationsDerived ( QObject* parent )
	: InstantOperations                   ( parent )
	, m_qsOrderNumber                     ( QString () )
	, m_bScratchActivationScanned         ( true )
	, m_bScratchReturnScanned             ( true )
	, m_bScratchOrderReceiveByPackScanned ( true )
{
	m_pcPackReturnList = new InstantOperationsListDerived (this);
	m_pcPackReturnList->setMaxPacks (15);

	QObject::connect ( m_pcPackReturnList, &InstantOperationsListDerived::showMessage,
					   this,               &InstantOperationsDerived::showMessageSlot, Qt::QueuedConnection );

	QObject::connect ( this, &InstantOperations::clearInstantOperationsForm,
					   this, &InstantOperationsDerived::clearInstantOperationsFormSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcPackReturnList, &InstantOperationsListDerived::packAdded, [this] {
		readBarcodeInputForm ()->readLineInput_1 ()->setLineInputText ( "" );
	});

}

InstantOperationsDerived::~InstantOperationsDerived ()
{

}


/**
 * @sa readPackReturnList
 * @return
 */
InstantOperationsListDerived* InstantOperationsDerived::readPackReturnList () const
{
	return m_pcPackReturnList;
}

/**
 * @sa setPackReturnList
 * @param obj
 */
void InstantOperationsDerived::setPackReturnList ( InstantOperationsListDerived* obj )
{
	if ( obj ) {
		if ( m_pcPackReturnList == obj ) return;
		m_pcPackReturnList = obj;
		emit packReturnListChanged ();
	}
}


bool InstantOperationsDerived::readScratchActivationScanned () const
{
	return m_bScratchActivationScanned;
}

bool InstantOperationsDerived::readScratchReturnScanned () const
{
	return m_bScratchReturnScanned;
}

bool InstantOperationsDerived::readScratchOrderReceiveByPackScanned () const
{
	return m_bScratchOrderReceiveByPackScanned;
}

void InstantOperationsDerived::setScratchActivationScanned ( const bool& bScanned )
{
	if ( m_bScratchActivationScanned == bScanned ) return;
	m_bScratchActivationScanned = bScanned;
	emit scratchActivationScannedChanged ();
}

void InstantOperationsDerived::setScratchReturnScanned ( const bool& bScanned )
{
	if ( m_bScratchReturnScanned == bScanned ) return;
	m_bScratchReturnScanned = bScanned;
	emit scratchReturnScannedChanged ();
}

void InstantOperationsDerived::setScratchOrderReceiveByPackScanned ( const bool& bScanned )
{
	if ( m_bScratchOrderReceiveByPackScanned == bScanned ) return;
	m_bScratchOrderReceiveByPackScanned = bScanned;
	emit scratchOrderReceiveByPackScannedChanged ();
}

/**
 * @sa clearInstantOperationsFormSlot
 * @param clearFormFlag
 */
void InstantOperationsDerived::clearInstantOperationsFormSlot ( const int& clearFormFlag )
{
	Q_UNUSED ( clearFormFlag ) // cause I want to clear values based on the operation.

	int packOper = readPackOperations ();

	if ( packOper == InstantOperationsEnums::Activation ) {

		emit clearActivationForm (int(BarcodeInputForm::ClearAndFocusLineInput_1));

	} else if ( packOper == InstantOperationsEnums::OrderReceivedByPack || packOper == InstantOperationsEnums::OrderReceivedByOrder ) {

		emit clearOrderForm ( int(BarcodeInputForm::ClearAndFocusLineInput_1) );

	} else if ( packOper == InstantOperationsEnums::Returned ) {

		emit clearBookReturnForm (int(BarcodeInputForm::ClearAndFocusLineInput_1) );

	} else {

		qDebug () << "Unknown operation";
	}
}


/**
 * @sa showMessageSlot
 * @param qsMessage
 * @brief If during an operation on the list there is an error it emits a signal with the error.
 * We dont' directly show the message there but we emit a signal and execute its execution here
 * because when a message box is on screen we want to disable barcode reception. Something that
 * InstantOperations::showMessage () method does for us.
 */
void InstantOperationsDerived::showMessageSlot (const QString& qsMessage )
{
	emit showMessage ( qsMessage, int(BarcodeInputForm::ClearForm) );
}

/**
 * @sa isBarcodeValid
 * @param barcode
 * @return true if all OK, false otherwise
 * @brief method should check the given barcode's validitity.
 */
bool InstantOperationsDerived::isBarcodeValid ( const QString& qsBarcode )
{
	bool bOK = false;

	int packOper = readPackOperations ();

	if ( packOper == InstantOperationsEnums::OrderReceivedByOrder && qsBarcode.size () == ORDER_NUMBER_LENGTH_NUMERIC ) {

		bOK = InstantCheckDigits::validateManifestNumberCheckDigit(qsBarcode);

	} else {

		BarcodeTypes::BarcodeType eBarcodeType = getBarcodeUtilitiesObj ()->getTypeFromLength ( qsBarcode.length () );


		if ( eBarcodeType == BarcodeTypes::InstantItfBarcode ) {
#pragma message "//TODO: NONDAS For Polla Chilena: commented until algorithms will be provided. --- Kostas did this"
			//bOK = InstantCheckDigits::validateCheckDigits ( qsBarcode, eBarcodeType );
			bOK = true;

		} else {

			if ( (packOper == InstantOperationsEnums::OrderReceivedByPack ||
				  packOper == InstantOperationsEnums::Activation ||
				  packOper == InstantOperationsEnums::Returned )
				 && ( qsBarcode.size () == MANUAL_ACTIVATION_LENGTH ||
					  qsBarcode.size () == ORDER_NUMBER_LENGTH_NUMERIC ) ) { // Manually entering barcode game-book, hence 12. Order barcode length: 9.

				bOK = true;

			}
		}
	}

	return bOK;
}

///**
// * @sa identifyAndTrimBarcode
// * @param qsBarcode
// * @return given the barcode it finds out its type. This is very much project depended and you will
// * have to override it. Basically, you might have two barcodes with the same length. There got to be
// * a way to distinguish between the two. You know how to do it, because it will be project depended.
// *
// * In addition you might want to alter the barcode trim/chop etc. You could do it if you wish.
// */
//BarcodeType InstantOperationsDerived::identifyAndTrimBarcode ( QString& qsBarcode )
//{
//	if ( qsBarcode.size () == ORDER_NUMBER_LENGTH_ALPHANUMERIC ) {

//		int packOper = readPackOperations ();

//		if ( packOper == InstantOperationsEnums::OrderReceivedByOrder ) {

//			// Keep the whole number along with the text. We'll need it when we print a receipt.
//			m_qsOrderNumber = qsBarcode;
//			qsBarcode.remove (QRegExp("\\D"));// get rid of non numbers

//			if ( qsBarcode.size () == ORDER_NUMBER_LENGTH_NUMERIC ) {
//				return BarcodeType::InstantOrderNumber;
//			} else {
//				return BarcodeType::InvalidBarcode;
//			}

//		} else if ( packOper == InstantOperationsEnums::OrderReceivedByPack ) {

//			qsBarcode.remove (QRegExp("\\D"));// get rid of non numbers
//			return BarcodeType::InstantOrderByPack;

//		} else {

//			return BarcodeType::InvalidBarcode;
//		}

//	} else {

//		qsBarcode.remove (QRegExp("\\D"));// get rid of non numbers
//		return getBarcodeUtilitiesObj ()->getTypeFromLength ( qsBarcode.length () );
//	}
//}



/**
 * @sa validateUserInputAndProceed
 * @brief let's check user input before proceeding.
 */
bool InstantOperationsDerived::validateUserInputAndProceed ( QString& qsBarcode )
{
	bool bProceed = true;
	int packOper = readPackOperations ();

	// Dynamically set operation based on barcode length so that buttons in ReceiveOrder form, are auto selected
	if ( packOper == InstantOperationsEnums::OrderReceivedByOrder && qsBarcode.length () != ORDER_NUMBER_LENGTH_NUMERIC) {

		setPackOperations (InstantOperationsEnums::OrderReceivedByPack);
		emit clearOrderForm ( int(BarcodeInputForm::ClearAndFocusLineInput_1) );

	} else if ( packOper == InstantOperationsEnums::OrderReceivedByPack && qsBarcode.length () == ORDER_NUMBER_LENGTH_NUMERIC) {

		setPackOperations (InstantOperationsEnums::OrderReceivedByOrder);
		emit clearOrderForm ( int(BarcodeInputForm::ClearAndFocusLineInput_1) );
	}

	// re-read pack oper cause might have changed
	packOper = readPackOperations ();

	auto checkBarcode = [ this, packOper, qsBarcode, &bProceed](){

		bProceed = isBarcodeValid ( qsBarcode );

		if ( !bProceed ) {
			emit showMessage ( tr("Invalid Barcode"), int(BarcodeInputForm::ClearNothing) );
			clearInstantOperationsFormSlot ( int(BarcodeInputForm::ClearForm) ) ; // passed in value is unused in slot.
		}
	};

	if ( packOper == InstantOperationsEnums::OrderReceivedByOrder ) {

		if ( BarcodeTypes::BarcodeType(readBarcodeInputForm ()->readBarcodeType () ) == BarcodeTypes::InstantOrderNumber ) {

			checkBarcode ();

			if ( bProceed ) {

				readBarcodeInputForm ()->readLineInput_1 ()->setLineInputMask ( "" );
				readBarcodeInputForm ()->readLineInput_1 ()->setLineInputLength ( qsBarcode.length () );
				readBarcodeInputForm ()->readLineInput_1 ()->setLineInputText ( qsBarcode ); // update form with the given barcode

				emit dataReady (); // enables the send button
			}

		} else {

			bProceed = false;
            emit showMessage ( tr("Invalid Barcode"), int(BarcodeInputForm::ClearNothing) );
			emit clearOrderForm ( int(BarcodeInputForm::ClearForm) );
		}

	} else if ( packOper == InstantOperationsEnums::Activation ||
				packOper == InstantOperationsEnums::OrderReceivedByPack ) {

		checkBarcode ();

		if ( bProceed ) {

			readBarcodeInputForm ()->setInputMethod (BarcodeInputForm::Scanned);
			qsBarcode.truncate (9);
			readBarcodeInputForm ()->readLineInput_1 ()->setLineInputText ( qsBarcode );

			setScratchActivationScanned (true);
			setScratchOrderReceiveByPackScanned ( true);
			emit dataReady (); // enables the send button

		}

	} else if ( packOper == InstantOperationsEnums::Returned ) {

		checkBarcode ();
		if ( bProceed ) {
			setScratchReturnScanned (true);
			readBarcodeInputForm ()->setInputMethod (BarcodeInputForm::Scanned);
			m_pcPackReturnList->addSinglePack ( qsBarcode, int(BarcodeType::InstantItfBarcode) ); // Return and Activation share the same type, since they are essentially the same barcodes.
		}

	} else {

		bProceed = false;
		QString qsErrMsg = QString(QStringLiteral("Not supported Operation: %1")).arg (readPackOperations ());
		LOG(qsErrMsg);
		qWarning () << qsErrMsg;
	}


	enableBarcodeReception ();
	return bProceed;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// RECEIVE ORDER ////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @sa initializeReceiveOrderTrnsData
 */
void InstantOperationsDerived::initializeReceiveOrderTrnsData ()
{
	QString qsBarcode = readBarcodeInputForm ()->readLineInput_1 ()->readLineInputText ();

	QVariantMap mTrnsSpecificDataMap = QVariantMap ();
	Lotos5DataRequestJsonObj* lotos5DataRequestJsonObj = getLotos5DataRequestJsonObj ();

	// First of all create a map that would contain all necessary information collected by Gui
	// so that a we construct the Tx packet and in continue use the same information when we process
	// the reply from C/S.
	lotos5DataRequestJsonObj->setMsg (61);
	lotos5DataRequestJsonObj->setSMsg (InstantOperationsEnums::Type_61_1_PackOperations);

	// Identify Oper, that is how you want to receive your order is it by:
	PackOperations oper = (PackOperations)readPackOperations ();

	lotos5DataRequestJsonObj->setD0 (oper);
	lotos5DataRequestJsonObj->setD3 (0);
	lotos5DataRequestJsonObj->setD4 (0);

	if ( oper ==  InstantOperationsEnums::OrderReceivedByOrder ) {

		lotos5DataRequestJsonObj->setD1 (qsBarcode.length ()); // order id length. The data would follow the struct as a char array.
		lotos5DataRequestJsonObj->setD2 (0);

		mTrnsSpecificDataMap.insert (QStringLiteral("OrderId"), qsBarcode);

	} else if ( oper == InstantOperationsEnums::OrderReceivedByPack ) {

		lotos5DataRequestJsonObj->setD1 (QString(qsBarcode.mid( 0,3)).toUInt());
		lotos5DataRequestJsonObj->setD2 (QString(qsBarcode.mid( 3,6)).toUInt());
		mTrnsSpecificDataMap.insert (QStringLiteral("OrderId"), qsBarcode);
	}

	mTrnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"), readBarcodeInputForm ()->readHtmlTemplate ());
	mTrnsSpecificDataMap.insert (QStringLiteral("ReportHeader"), readBarcodeInputForm ()->readReportHeader ());
	lotos5DataRequestJsonObj->setTrnsSpecificDataMap (mTrnsSpecificDataMap);

}

/**
 * @brief processReceiveOrder
 * @param qvmCsReply
 */
void InstantOperationsDerived::processReceiveOrder (const QVariantMap & qvmCsReply )
{

	QString qsMsgBoxMessage = qvmCsReply.value(CS_ERROR_MSG).toString();

	if (qsMsgBoxMessage.isEmpty ()) {

		readBarcodeInputForm ()->setHtml ( QString::fromUtf8(qvmCsReply.value(PREVIEW_DATA).toByteArray().data()) );
		emit clearOrderForm (BarcodeInputForm::ClearAllLineInputs);
	} else {
		emit showMessage ( qsMsgBoxMessage, int(BarcodeInputForm::ClearAllLineInputs) );
	}

	m_qsOrderNumber.clear ();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// PACK ACTIVATION //////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa initializeActivatePackTrnsData
 */
void InstantOperationsDerived::initializeActivatePackTrnsData ()
{

	Lotos5DataRequestJsonObj* lotos5DataRequestJsonObj = getLotos5DataRequestJsonObj ();

	QVariantMap mTrnsSpecificDataMap = QVariantMap ();
	mTrnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"),      readBarcodeInputForm ()->readHtmlTemplate ());
	mTrnsSpecificDataMap.insert (QStringLiteral("ReportHeader"),      readBarcodeInputForm ()->readReportHeader ());
	mTrnsSpecificDataMap.insert (QStringLiteral("ActivationBarcode"), readBarcodeInputForm ()->readLineInput_1 ()->readLineInputText () );
	// First of all create a map that would contain all necessary information collected by Gui
	// so that a we construct the Tx packet and in continue use the same information when we process
	// the reply from C/S.
	lotos5DataRequestJsonObj->setMsg ( 61 );
	lotos5DataRequestJsonObj->setSMsg ( InstantOperationsEnums::Type_61_1_PackOperations );
	lotos5DataRequestJsonObj->setD0 ( InstantOperationsEnums::Activation );
	lotos5DataRequestJsonObj->setD1 ( uint(InstantOperationsEnums::UnitType::Pack) );
	lotos5DataRequestJsonObj->setD2 ( 0 );
	lotos5DataRequestJsonObj->setD3 ( 0 );
	lotos5DataRequestJsonObj->setD4 ( 1 ); // means how many packets are activated. the data of the packet, i.e., Game/Pack are stored inside the misc map. The transmit object is responsible to know what to expect so that tx buffer is correctly initialized.

	lotos5DataRequestJsonObj->setTrnsSpecificDataMap (mTrnsSpecificDataMap);
}

/**
 * @sa processActivatePack
 * @param qvmCsReply
 */
void InstantOperationsDerived::processActivatePack (const QVariantMap& qvmCsReply )
{

	QString qsMsgBoxMessage = qvmCsReply.value(CS_ERROR_MSG).toString();

	if (qsMsgBoxMessage.isEmpty ()) {

		readBarcodeInputForm ()->setHtml ( QString::fromUtf8(qvmCsReply.value(PREVIEW_DATA).toByteArray().data()) );

		emit clearActivationForm (BarcodeInputForm::ClearAndFocusBarcode);

	} else {
		emit showMessage ( qsMsgBoxMessage, int(BarcodeInputForm::ClearAllLineInputs) );

	}

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// PACK     RETURN //////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @sa initializeFullPackReturnTrnsData
 */
void InstantOperationsDerived::initializeFullPackReturnTrnsData ()
{

	Lotos5DataRequestJsonObj* lotos5DataRequestJsonObj = getLotos5DataRequestJsonObj ();

	// First of all create a map that would contain all necessary information collected by Gui
	// so that a we construct the Tx packet and in continue use the same information when we process
	// the reply from C/S.
	lotos5DataRequestJsonObj->setMsg (61 );
	lotos5DataRequestJsonObj->setSMsg (InstantOperationsEnums::Type_61_1_PackOperations );
	lotos5DataRequestJsonObj->setD0 ( InstantOperationsEnums::Returned );
	lotos5DataRequestJsonObj->setD1 ( uint(InstantOperationsEnums::UnitType::Pack) );
	lotos5DataRequestJsonObj->setD2 ( 0 );
	lotos5DataRequestJsonObj->setD3  (0 );
	QVariantMap mTrnsSpecificDataMap = QVariantMap ();
	mTrnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"), readBarcodeInputForm ()->readHtmlTemplate ());
	mTrnsSpecificDataMap.insert (QStringLiteral("ReportHeader"), readBarcodeInputForm ()->readReportHeader ());

	QVariantList qvlReturnPacks = QVariantList ();
	QVariantMap qvmPackDetails = QVariantMap ();

	// Create a list of maps where each map contains pack return details.
	for ( auto iPack = 0; iPack < m_pcPackReturnList->readInstantListModel ()->rowCount (); ++iPack ) {

		InstantPackItem* pPackItem = static_cast<InstantPackItem*>(m_pcPackReturnList->readInstantListModel ()->listItemFromRowIndex (iPack));

		if ( pPackItem ) {

			qvmPackDetails.insert (QStringLiteral("Game"), pPackItem->packGame ());
			qvmPackDetails.insert (QStringLiteral("Book"), pPackItem->packBook ());
			qvlReturnPacks.append (qvmPackDetails);
			qvmPackDetails.clear ();
		}
	}

	mTrnsSpecificDataMap.insert (QStringLiteral("ReturnPacks"), qvlReturnPacks );

	lotos5DataRequestJsonObj->setD4 ( qvlReturnPacks.size () ); // means how many packets are returned. the data of the packet, i.e., Game/Pack are stored inside the misc map. The transmit object is responsible to know what to expect so that tx buffer is correctly initialized.


	lotos5DataRequestJsonObj->setTrnsSpecificDataMap (mTrnsSpecificDataMap);
}

/**
 * @sa processFullPackReturn
 * @param qvmCsReply
 */
void InstantOperationsDerived::processFullPackReturn ( const QVariantMap& qvmCsReply )
{

	QString qsMsgBoxMessage = qvmCsReply.value(CS_ERROR_MSG).toString();

	if (!qsMsgBoxMessage.isEmpty ()) {

		emit showMessage ( qsMsgBoxMessage, int(BarcodeInputForm::ClearAllLineInputs) );

	} else {

		// but there might be also stuff we want to display on a message box
		qsMsgBoxMessage = qvmCsReply.value (MSGBOX_MSG).toString ();

		if ( !qsMsgBoxMessage.isEmpty () ) {

			emit showMessage ( qsMsgBoxMessage, int(BarcodeInputForm::ClearAllLineInputs) );
			emit performPrint (QString::fromUtf8(qvmCsReply.value(PREVIEW_DATA).toByteArray().data()));

		} else {

			readBarcodeInputForm ()->setHtml ( QString::fromUtf8(qvmCsReply.value(PREVIEW_DATA).toByteArray().data()) );
			m_pcPackReturnList->clearPackList ();
			emit showPreview ();
		}
	}
}
