/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file ClGamesCommonRx.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */
#include "ClGamesCommonRx.h"
#include "ImtsGamesEnums.h"
#include "Lotos5Helper/MiscReceiptInfo.h"
#include "DbusWrapper.h"
#include "JsonOperations.h"
#include "LocalEventLoggerEvents.h"
#include "FormatAmount/FormatAmount.h"
#include "GetConfigValue.h"
#include "BarcodeUtilities/BarcodeUtilities.h"
#include "SystemWideConstValues.h"
#include "PlaceServerManagerRequest.h"
#include "ClientServerDefinitions.h"
#include "FormatDate/FormatDate.h"
#include "EmailInfo/EmailInfo.h"
#include <QStringBuilder>
#include "CustomerSession/CustomerSessionTrnsData.h"


ClGamesCommonRx::ClGamesCommonRx ()
{
	m_mHtmlData.clear ();
	m_qsGameName.clear ();
}

/**
 * @sa initCouponHdrFlagsExchange
 * @param pReply_50_1
 */
void ClGamesCommonRx::initCouponHdrFlagsExchange ( const REPLY_50_1* pReply_50_1 )
{
	int iFlags = pReply_50_1->hdr.flags;
	Q_UNUSED ( iFlags )

}

/**
 * @sa initTypeFor5000Exchange
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
 */
void ClGamesCommonRx::initTypeFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode )
{

	if ( iGameCode == RACHA ) {
		QVariantMap qvmAdditionaGames = QVariantMap ();

		switch (pTrns_gm_5000->type) {
			case 1:
				qvmAdditionaGames.insert(QStringLiteral("10"), 1);
			break;
			case 2:
				qvmAdditionaGames.insert(QStringLiteral("0"), 1);
			break;
			case 3:
				qvmAdditionaGames.insert(QStringLiteral("0"), 1);
				qvmAdditionaGames.insert(QStringLiteral("10"), 1);
			break;
			default:
			break;
		}

		mAreaValues.insert ( QStringLiteral("AdditionalGamePerArea"), qvmAdditionaGames );

	} else if ( iGameCode == LOTTO_CL ) {
		QVariantMap qvmAdditionaGames = QVariantMap ();

		switch (pTrns_gm_5000->type) {
			case 3:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
			break;
			case 7:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
			break;
			case 15:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Ahora si que si!"), 1);
			break;
			case 31:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Ahora si que si!"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Jubilazo"), 1);
			break;
			case 39:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Multiplicador"), 1);
			break;
			case 47:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Multiplicador"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Ahora si que si!"), 1);
			break;
			case 63:
				qvmAdditionaGames.insert(QStringLiteral("Revancha"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Desquite"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Multiplicador"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Ahora si que si!"), 1);
				qvmAdditionaGames.insert(QStringLiteral("Jubilazo"), 1);
			break;
			default:
			break;
		}

		mAreaValues.insert ( QStringLiteral("AdditionalGamePerArea"), qvmAdditionaGames );
	} else {
		mAreaValues.insert ( QStringLiteral("DefaultMarks"), pTrns_gm_5000->type ); // Total number of min marks the user is allowed to select without system, i.e. lotto 6/49 6 is the number. For bettype games min is set to the betType user selected.
	}




}



/**
 * @sa initSysFor5000Exchange
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief  Watch out because sys[1] is initialized based on the game code. In some goes the multiplier and in some the
 * the number of marks for panelB for example. So we'll make it pure virtual so that you will have to implemented yourself.
 * The cost is that in case you don't have exchange or ticket replay as a requirement at your project you will have to implement
 * it as an empty method to allow you inherit this class.
 */
void ClGamesCommonRx::initSysFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode )
{
	Q_UNUSED ( pTrns_gm_5000 )
	Q_UNUSED ( iGameCode )

	mAreaValues.insert ( QStringLiteral("Multiplier"),  1 ); // multiplier

}


/**
 * @sa initGameFlagsFor5000Exchange
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief initializes the flags for exchange ticket.
 */
void ClGamesCommonRx::initGameFlagsFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode )
{

	quint8 iFlags = pTrns_gm_5000->flags;
	Q_UNUSED ( iFlags )
	Q_UNUSED ( iGameCode )
	//mAreaValues.insert (QStringLiteral("Gmx000Flags"), pTrns_gm_5000->flags );
	mAreaValues.insert (QStringLiteral("Gmx000Flags"), 0 ); // When we perform a Ticket Replay, there is no QP.

}

/**
 * @sa initFlagsFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the flags for exchange ticket. Very much project dependent. Default does TW.
 */
void ClGamesCommonRx::initFlagsFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 )
{
	Q_UNUSED (pTrns_gm_2000)
	mAreaValues.insert (QStringLiteral("Gmx000Flags"), 0 );  // When we perform a Ticket Replay, there is no QP.
}

/**
 * @sa initTypeFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
 */
void ClGamesCommonRx::initTypeFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode )
{
	if ( iGameCode != LOTTO_3_CL ) {
		ImtsGamesEnums::PickXPlayTypeFlags ePickXPlayTypeFlag;

		if ( pTrns_gm_2000->type == 1 ) {

			ePickXPlayTypeFlag = ImtsGamesEnums::Straight;

		} else if ( pTrns_gm_2000->type == 2 ) {

			ePickXPlayTypeFlag = ImtsGamesEnums::Box;

		} else if ( pTrns_gm_2000->type == 4 ) {

			ePickXPlayTypeFlag = ImtsGamesEnums::StraightBox ;

		} else if ( pTrns_gm_2000->type == 8 ) {

			ePickXPlayTypeFlag = ImtsGamesEnums::FrontBackPairs;

		} else  if ( pTrns_gm_2000->type == 16 ) {

			ePickXPlayTypeFlag = ImtsGamesEnums::SecondDigit ;
		}

		mAreaValues.insert ( QStringLiteral("PickXPlayType"), ePickXPlayTypeFlag.operator int () );

	} else {

		int iPlayType=0;

		for ( int iMultiplier = 0; iMultiplier < 5 ; iMultiplier++ ) {

			if ( pTrns_gm_2000->mult[iMultiplier] != 0 ) {

				/*
				 * m_pRtrns_gm_2000->data[0]    -> "Straight"
				 * m_pRtrns_gm_2000->data[1]    -> "Combo"
				 * m_pRtrns_gm_2000->data[2]    -> "Box"
				 * m_pRtrns_gm_2000->data[3]    -> "Pairs"
				 * m_pRtrns_gm_2000->data[4]    -> "LastDigit"
				 */

				// The below play types do not actualy match the required. The transformation is performed later.
				switch (iMultiplier) {
					case 0:
						iPlayType=2;
					break;
					case 1:
						iPlayType=8;
					break;
					case 2:
						iPlayType=4;
					break;
					case 3:
						iPlayType=16;
					break;
					case 4:
						iPlayType=18;
					break;
					default:
					break;
				}

			}

		}

		mAreaValues.insert ( QStringLiteral("PickXPlayType"), iPlayType );

	}

}


/**
 * @sa initValueFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the value for exchange ticket. Very much project dependent. Default does TW.
 */
void ClGamesCommonRx::initValueFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode )
{
	if ( iGameCode != LOTTO_3_CL ) {
		mAreaValues.insert ( QStringLiteral("Multiplier"), pTrns_gm_2000->value );
	} else {

		QVariantMap qvmMultipliers = QVariantMap ();
		double dMultiplier = 0;

		for ( int iMultiplier = 0; iMultiplier < 5 ; iMultiplier++ ) {

			dMultiplier = pTrns_gm_2000->mult[iMultiplier];

			if ( dMultiplier != 0 ) {

				/*
				 * m_pRtrns_gm_2000->data[0]    -> "Straight"
				 * m_pRtrns_gm_2000->data[1]    -> "Combo"
				 * m_pRtrns_gm_2000->data[2]    -> "Box"
				 * m_pRtrns_gm_2000->data[3]    -> "Pairs"
				 * m_pRtrns_gm_2000->data[4]    -> "LastDigit"
				 */

				switch (iMultiplier) {
					case 0:
						qvmMultipliers.insert( "Straight", dMultiplier*100 );
					break;
					case 1:
						qvmMultipliers.insert( "Combo", dMultiplier*100 );
					break;
					case 2:
						qvmMultipliers.insert( "Box", dMultiplier*100 );
					break;
					case 3:
						qvmMultipliers.insert( "Pairs", dMultiplier*100 );
					break;
					case 4:
						qvmMultipliers.insert( "LastDigit", dMultiplier*100 );
					break;
					default:
					break;
				}

			}
		}

		mAreaValues.insert ( QStringLiteral("CustomData"), qvmMultipliers );

		// For consistency during 'updateCouponCost'; that method uses the 'lMultiplier' list for cost calculation.
		mAreaValues.insert ( QStringLiteral("Multiplier"), 1 );
	}

}

/**
 * @sa populateTicketPreviewData
 * @param eReceiptFor
 */
void ClGamesCommonRx::populateTicketPreviewData ( const PlayPrintReceiptFlags& eReceiptFor )
{

	QScopedPointer<MiscReceiptInfo> pcMiscReceiptInfo ( new MiscReceiptInfo );
	qint32 iNumberOfDraws = getNumberOfValidDraws ();

	if ( iNumberOfDraws > 1 ) {

		m_mHtmlData.insert ( QStringLiteral("numberOfDrawsAndCost"), QString( QObject::tr("%1 DRAWS &nbsp;&nbsp;&nbsp;&nbsp;%2")).arg (iNumberOfDraws).arg ( getFormatedCouponCost () ) );
		m_mHtmlData.insertMulti (QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("cost") );

	} else {

		m_mHtmlData.insertMulti (QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("numberOfDrawsAndCostCell") );
		m_mHtmlData.insert ( QStringLiteral("cost"), getFormatedCouponCost () );
	}

	m_mHtmlData.insert (QStringLiteral("agent"),             pcMiscReceiptInfo->getAgencyString());
	m_mHtmlData.insert (QStringLiteral("terminal"),          pcMiscReceiptInfo->getTerminalString());
	m_mHtmlData.insert (QStringLiteral("TransanctionDate"),  getSalesDate ( QStringLiteral("dd/MM/yyyy")) );
	m_mHtmlData.insert (QStringLiteral("transactionNumber"), getTrnsNumber());


	if ( !eReceiptFor.testFlag ( Training ) ) {
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("TrainingNotForSale") );
	}

	if ( !eReceiptFor.testFlag ( Pilot ) ) {
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PilotOperNotForSale") );
	}
}


/**
 * @sa populateTicketPrintData
 * @param eReceiptFor
 */
void ClGamesCommonRx::populateTicketPrintData ( const PlayPrintReceiptFlags& eReceiptFor )
{

	QScopedPointer<MiscReceiptInfo> pcMiscReceiptInfo ( new MiscReceiptInfo );

	QString qsBarcode        = getBarcode();
	QString qsISecure        = getIsecurePrintable ().replace (QChar('-'),QChar(' '));
	QString qs30digitBarcode = qsBarcode.left(35);
	QString qsCrc            = qsBarcode.right(5);
	qsCrc.append(" ");

	m_mHtmlData.insert (QStringLiteral("barcodeText"),        qs30digitBarcode);
	m_mHtmlData.insert (QStringLiteral("iSecure"),            QString("%1%2").arg ( qsCrc ).arg ( qsISecure ) );

	// This is only valid for demostrating printer's read after print feature set in maintenance gui. Normally you want to print barcodes :)
	QSettings settings( QLatin1String("Intralot"), QLatin1String("ImtsProjectDependentConfig") );
	if ( !settings.value ( QStringLiteral("PrinterSettings/ReadAfterPrintDemo"), QVariant(false) ).toBool () ) { // If ain't such value default to false.
		QString qsGraphicalBarcode = qsBarcode%qsISecure;
		m_mHtmlData.insert (QStringLiteral("graphical_barcode"),  qsGraphicalBarcode.remove (QRegExp("\\D")));
	}

	m_mHtmlData.insertMulti (QStringLiteral("CLEAR_CONTENT_AFTER_PRINT"), QStringLiteral("barcodeText") );               // Print, Clear, Save
	m_mHtmlData.insertMulti (QStringLiteral("CLEAR_CONTENT_AFTER_PRINT"), QStringLiteral("iSecure") );                   // Print, Clear, Save
	m_mHtmlData.insertMulti (QStringLiteral("CLEAR_CONTENT_AFTER_PRINT"), QStringLiteral("graphical_barcode") );         // Print, Clear, Save

	qint32 iNumberOfDraws = getNumberOfValidDraws ();
	if ( iNumberOfDraws > 1 ) {

		m_mHtmlData.insert ( QStringLiteral("numberOfValidDraws"), QString( QObject::tr("Ticket valid for %1 DRAWS") ).arg (iNumberOfDraws) );   // CH_Polla Chilena: tr()
		m_mHtmlData.insert ( QStringLiteral("drawDates"),          QString(QStringLiteral("%1 - %2")).arg (getFirstDrawDate (QStringLiteral("ddd MMM dd yyyy"))).arg ( getLastDrawDate (QStringLiteral("ddd MMM dd yyyy"))) );
		m_mHtmlData.insert ( QStringLiteral("drawNumbers"),        QString(QObject::tr("Draw Numbers %1 - %2")).arg (getFirstDraw ()).arg (getLastDraw ()));


	} else {

		m_mHtmlData.insert ( QStringLiteral("numberOfValidDraws"), QString("Ticket valid for %1 DRAW").arg (iNumberOfDraws));
		m_mHtmlData.insert ( QStringLiteral("drawDates"),          QString(QStringLiteral("%1")).arg (getFirstDrawDate (QStringLiteral("ddd MMM dd yyyy"))));
		m_mHtmlData.insert ( QStringLiteral("drawNumbers"),        QString(QObject::tr("Draw Number %1")).arg (getFirstDraw ()));

	}


	m_mHtmlData.insert (QStringLiteral("couponCost"), getFormatedCouponCost ());


	m_mHtmlData.insert (QStringLiteral("agent"),             pcMiscReceiptInfo->getAgencyString());
	m_mHtmlData.insert (QStringLiteral("terminal"),          pcMiscReceiptInfo->getTerminalString());
	m_mHtmlData.insert (QStringLiteral("salesDate"),         getSalesDate ( QStringLiteral("dd/MM/yyyy")) );
	m_mHtmlData.insert (QStringLiteral("couponNo"),          getCouponNumber ().append (QChar('*')));
	m_mHtmlData.insert (QStringLiteral("transactionNumber"), getTrnsNumber());


	if ( !eReceiptFor.testFlag ( Training ) ) {
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("TrainingNotForSale") );
	}

	if ( !eReceiptFor.testFlag ( Pilot ) ) {
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PilotOperNotForSale") );
	}

	QString qsSaveReceivedFileName = QString("Game_%1_Play_%2").arg (getGameCode ()).arg (getTrnsNumber ());


	quint8 iIndex = 0;
	if ( eReceiptFor.testFlag ( Training ) ) {

		qsSaveReceivedFileName.append ("_Training");

		for (; iIndex<4; ++iIndex) {
			m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QString("MessageRow_%1").arg (iIndex+1) );
		}

	} else {

		QVariantList qvlOnTicketMessageList = getOnTicketMessages ();
		quint8 iListSize = qvlOnTicketMessageList.size ();
		if ( iListSize > 0 ) {
			if ( getGameCode() == LOTTO_CL ) {
				m_mHtmlData.insert (QStringLiteral("messages_label"), QStringLiteral("LOTO TICKET MSG") );
			} else if ( getGameCode() == LOTTO_3_CL ) {
				m_mHtmlData.insert (QStringLiteral("messages_label"), QStringLiteral("LOTO 3 TICKET MSG") );
			} else if ( getGameCode() == LOTTO_4_CL ) {
				m_mHtmlData.insert (QStringLiteral("messages_label"), QStringLiteral("LOTO 4 TICKET MSG") );
			} else if ( getGameCode() == RACHA ) {
				m_mHtmlData.insert (QStringLiteral("messages_label"), QStringLiteral("RACHA TICKET MSG") );
			}
		}
		for ( ; iIndex < iListSize; ++iIndex ) {
			m_mHtmlData.insert (QString("message_%1").arg (iIndex+1), qvlOnTicketMessageList.at (iIndex).toString () );
		}

		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("MessageRow_label") );
		for (; iIndex<4; ++iIndex) {
			m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QString("MessageRow_%1").arg (iIndex+1) );
		}

	}

	if ( eReceiptFor.testFlag ( Exchange ) ) {
		m_mHtmlData.insert ( QStringLiteral("exchange"), QStringLiteral("Exchange ticket") );
	}



	//--------------------- Update the receipt with promotion information ---------------------------------------------
	QByteArray qbaPromotionData = getGamePromotionData();
	PromotionData promotionData;
	QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);


	QStringList qslTitle = promotionData.readPrintoutTitle ();
	QStringList qslPromotionMessage = promotionData.readPrintoutMessage ();

	QString qsExtraUpperLogoImage = promotionData.readPrintoutExtraUpperLogoImage();
	QStringList qslExtraUpperLogoMessage = promotionData.readPrintoutExtraUpperLogoMessage();

	QString qsExtraMiddleLogoImage = promotionData.readPrintoutExtraMiddleLogoImage();
	QStringList qslExtraMiddleLogoMessage = promotionData.readPrintoutExtraMiddleLogoMessage();

	/// Do Promotion Title Message Text
	if ( !qslTitle.isEmpty () ) {

		for ( QString qsMsg : qslTitle ) {
			m_mHtmlData.insertMulti (QStringLiteral("PromotionTitle_Line"), QStringLiteral("CLONE_ONLY"));
			m_mHtmlData.insertMulti(QStringLiteral("PromotionTitle_Cell"), qsMsg );
		}
	} else {
		// remove title stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionTitle_Line") );
	}

	/// Do Promotion Main Body Message Text
	if ( !qslPromotionMessage.isEmpty () ) {
		for ( QString qsMsg : qslPromotionMessage ) {
			m_mHtmlData.insertMulti (QStringLiteral("PromotionMessage_Line"), QStringLiteral("CLONE_ONLY"));
			m_mHtmlData.insertMulti (QStringLiteral("PromotionMessage_Cell"), qsMsg );
		}
	} else {
		// remove promotion message stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionMessage_Line") );
	}

	/// Do Extra Promotion Upper Logo & Message Text.
	if ( !qsExtraUpperLogoImage.isEmpty () ) {
		m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraUpperLogo_Image"), qsExtraUpperLogoImage );
	} else {
		// remove promotion message stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionExtraUpperLogo_Line") );
	}

	if ( !qslExtraUpperLogoMessage.isEmpty () ) {

		for ( QString qsMsg : qslExtraUpperLogoMessage ) {
			m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraUpperMessage_Line"), QStringLiteral("CLONE_ONLY"));
			m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraUpperMessage_Cell"), qsMsg );
		}
	} else {
		// remove promotion message stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionExtraUpperMessage_Line") );
	}

	/// Do Extra Promotion Middle Logo & Message Text.
	if ( !qsExtraMiddleLogoImage.isEmpty () ) {
		m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraMiddleLogo_Image"), qsExtraMiddleLogoImage );
	} else {
		// remove promotion message stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionExtraMiddleLogo_Line") );
	}

	if ( !qslExtraMiddleLogoMessage.isEmpty () ) {
		for ( QString qsMsg : qslExtraMiddleLogoMessage ) {
			m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraMiddleMessage_Line"), QStringLiteral("CLONE_ONLY"));
			m_mHtmlData.insertMulti (QStringLiteral("PromotionExtraMiddleMessage_Cell"), qsMsg );
		}
	} else {
		// remove promotion message stuff
		m_mHtmlData.insertMulti ( QStringLiteral("REMOVE_LINES_BEFORE_PROCESSING"), QStringLiteral("PromotionExtraMiddleMessage_Line") );
	}

	// -----------------------------------------------------------------------------------------------------


	setSaveReceiptFileName (qsSaveReceivedFileName);
	m_mHtmlData.insert (QStringLiteral("SAVE_AS"), qsSaveReceivedFileName );

}


/**
 * @sa agenerateCommonReceiptContent
 * @param PlayPrintReceiptFlags
 */
void ClGamesCommonRx::generateCommonReceiptContent ( const PlayPrintReceiptFlags& eReceiptFor )
{

	if ( eReceiptFor.testFlag (TicketRepeat) ) {
		populateTicketPreviewData ( eReceiptFor );
	} else {
		populateTicketPrintData ( eReceiptFor );
	}
}


/**
 * @sa getGameName
 * @return
 */
QString ClGamesCommonRx::getGameName ()
{
	QString qsGameName = GamesCommonRx::getGameName ();

	if ( getGameCode () == Powerball_DC || getGameCode () == MegaMillions_DC ) {

		if ( isAdditionalGameSelected () ) {

			qsGameName.append (QStringLiteral(" + "));
			qsGameName.append (m_pcGameTxData->readAdditionalGame ().value (QStringLiteral("GameName")).toString () );
		}
	}

	return qsGameName;
}


/**
 * @sa getQuickPickLabel5000
 * @param iArea
 * @return the qp label
 */
QString ClGamesCommonRx::getQuickPickLabel5000 ( const int& iArea, const int& iPanel )
{
	quint8 iQp = getAreaFlags (iArea);

	if ( iPanel == 0 && iQp&Imts::Gm5000QpA)  {
		return QString(QObject::tr("QP"));
	}

	if ( iPanel == 1 && iQp&Imts::Gm5000QpB)  {
		return QString(QObject::tr("QP"));

	}

	if ( getGameCode() == RACHA || getGameCode() == LOTTO_CL ) {
		return QString ("-");
	} else {
		return QString ("");
	}
}

/**
 * @sa getQuickPickLabel5000
 * @param iArea
 * @return the qp label
 */
QString ClGamesCommonRx::getQuickPickLabel2000 ( const int& iArea )
{
	quint8 iQp = getAreaFlags (iArea);

	if ( iQp != Imts::Gm5000Normal)  {
		return QString(QObject::tr("QP"));
	} else {
		return QString ("");
	}
}


/**
 * @sa getCostLabel
 * @param iArea
 * @return cost label
 * @brief .
 */
QString ClGamesCommonRx::getCostLabel (const int& iArea )
{
	double dAreaCost = getAreaCost (iArea);
	return FormatAmount::getFormatedAmount (dAreaCost);
}

/**
 * @sa isAdditionalGameSelected
 * @return true false
 */
bool ClGamesCommonRx::isAdditionalGameSelected ()
{
	return bool(m_pcGameTxData->readAdditionalGame ().value (QStringLiteral("UserSelection")).toInt ());
}

/**
 * @sa getAdditionalGamesPerArea
 * @return a string containing the first letter of each Additional Game's name
 */
QString ClGamesCommonRx::getAdditionalGamesPerArea ( const int& iArea ){

	QVariantMap selectedAdditionalGames = m_pcGameTxData->readAreaList().at(iArea).toMap().value("AdditionalGamePerArea").toMap();
	QString selectedGamesString = QString ();

	if ( getGameCode() == RACHA ) {
		if ( selectedAdditionalGames.contains( "0" ) ) { selectedGamesString.append(" C"); } else { selectedGamesString.append(" -"); }
		if ( selectedAdditionalGames.contains( "10" ) ) { selectedGamesString.append("D"); } else { selectedGamesString.append("-"); }
		if ( selectedAdditionalGames.isEmpty() ) { selectedGamesString.clear(); selectedGamesString.append(" CD"); }
	} else if ( getGameCode() == LOTTO_CL ) {
		if ( selectedAdditionalGames.contains( "Revancha" ) ) { selectedGamesString.append(" R"); } else { selectedGamesString.append(" -"); }
		if ( selectedAdditionalGames.contains( "Desquite" ) ) { selectedGamesString.append("D"); } else { selectedGamesString.append("-"); }
		if ( selectedAdditionalGames.contains( "Multiplicador" ) ) { selectedGamesString.append("M"); } else { selectedGamesString.append("-"); }
		if ( selectedAdditionalGames.contains( "Ahora si que si!" ) ) { selectedGamesString.append("S"); } else { selectedGamesString.append("-"); }
		if ( selectedAdditionalGames.contains( "Jubilazo" ) ) { selectedGamesString.append("J"); } else { selectedGamesString.append("-"); }
	} else {
		selectedGamesString = " ";
	}

	return selectedGamesString;
}

void ClGamesCommonRx::insertAdditionalGamesCosts( const PlayPrintReceiptFlags& eReceiptFor ) {

	if ( getGameCode() == LOTTO_CL ) {

		if ( eReceiptFor.testFlag (Exchange) ) {
			REPLY_50_1* m_pReply_50_1 = (REPLY_50_1*) ( &m_pReceivedData [ sizeof(CSS_IT_1) ] );
			m_pRstrns_gm_5000 = (RSTRNS_GM_5000*) ( &m_pReceivedData [ sizeof(CSS_IT_1) + sizeof(REPLY_50_1) + m_pReply_50_1->hdr.grps *sizeof(TRNS_GM_5000) ] );
		} else {
			m_pRstrns_gm_5000 = (RSTRNS_GM_5000*) ( &m_pReceivedData [ sizeof(CSS_IT_1) + sizeof(REPLY_100_1)  ] );
		}

		m_mHtmlData.insert (QStringLiteral("LotoCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[0] ) );
		m_mHtmlData.insert (QStringLiteral("RevanchaCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[1] ) );
		m_mHtmlData.insert (QStringLiteral("DesquiteCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[2] ) );
		m_mHtmlData.insert (QStringLiteral("AhoraCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[3] ) );
		m_mHtmlData.insert (QStringLiteral("JubilazoCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[4] ) );
		m_mHtmlData.insert (QStringLiteral("MultiplicadorCost"), FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pRstrns_gm_5000->amount[5] ) );

	}
}


/**
 * @sa makeCommonReceipt - CH_Polla Chilena
 * @return ImtsRxErrors::eeRxStatus
 * @brief This routine constructs the data that will fill the html template.
 *
 */
ImtsRxErrors::eeRxStatus ClGamesCommonRx::makeCommonReceipt ( const PlayPrintReceiptFlags& eReceiptFor, QVariantMap& qvmDataForGui, const char* pReceivedData )
{
	m_pReceivedData = pReceivedData;
	ImtsRxErrors::eeRxStatus eReturnRxStatus = ImtsRxErrors::RX_SUCCESS;

	generateCommonReceiptContent ( eReceiptFor );

	if ( getGameCode() != LOTTO_3_CL ) {
		populatePrognosticsAreaContent();
		populateAdditionalContent( eReceiptFor );
	} else {
		populateLoto3Content( eReceiptFor );
	}

	if ( eReceiptFor.testFlag (TicketRepeat) ) {

		QByteArray qbaHtmlData = QByteArray ();

		eReturnRxStatus = DbusWrapper::makeGuiData ( getHtmlPreviewTemplateFile(), m_mHtmlData, qbaHtmlData );

		if ( eReturnRxStatus == ImtsRxErrors::RX_SUCCESS ) {
			qvmDataForGui.insert (PREVIEW_DATA, qbaHtmlData);
			qvmDataForGui.insert (REGENERATE_TICKET_DATA, QJson::JsonOperations::qObjectToJson (getGameTxData ()) ); // Send to gui GameTxData so that it can place a call for play.
		}

	} else {

		if ( !getEmail ().isEmpty () ) {

			EmailInfo emailInfo;
			QVariantMap m;
			m.insert (QStringLiteral("name"), "");
			m.insert (QStringLiteral("email"), getEmail () );
			QVariantList qvlEmailList;
			qvlEmailList<< m;
			emailInfo.setMailRecipients (qvlEmailList);
			emailInfo.setSendersName ("");
			emailInfo.setPassword (getEmailPassword ());

			eReturnRxStatus = DbusWrapper::makeGuiDataAndSendMail ( getHtmlTemplateFile(), m_mHtmlData, QJson::JsonOperations::qObjectToJson (&emailInfo), PrinterTypes::DeputyA );

		} else {

			eReturnRxStatus = DbusWrapper::makeGuiDataAndPrint( getHtmlTemplateFile(), m_mHtmlData, PrinterTypes::Chief );
		}
	}

	return eReturnRxStatus;

}

/**
 * @sa populatePrognosticsAreaContent - CH_Polla Chilena
 * @return ImtsRxErrors::eeRxStatus
 * @brief This routine constructs the data that will fill the html template.
 */
void ClGamesCommonRx::populatePrognosticsAreaContent ()
{
	const quint8 iNumberOfAreas = getNumberOfAreas();
	const quint8 iNumberOfPanels = getNumberOfPanels ();

	QString areaLabel = QString ();
	QVariantList qvlPanelMarks = QVariantList ();
	QString qsMarks = QString ();
	QString qsLbl = QString ();

	for ( int iArea = 0; iArea < iNumberOfAreas; iArea++ ) {

		if ( getArea(iArea).value(QStringLiteral("IsAreaEmpty")).toBool() ) { // get area map and check for value
			continue;
		}

		areaLabel.clear();
		qsMarks.clear ();
		qsLbl.clear ();

		m_mHtmlData.insertMulti (QStringLiteral("area"), QStringLiteral("CLONE_ONLY"));
		areaLabel.append(QChar(0x0041+ iArea));

		for ( int iPanel = 0; iPanel < iNumberOfPanels; ++iPanel ) {

			qvlPanelMarks = getPanel(iArea, iPanel);

			if ( iPanel == 0 ) {
				for ( int iMark = 0; iMark < qvlPanelMarks.size (); ++iMark) {
					qsMarks.append ( QString::number (qvlPanelMarks.at (iMark).toInt ()+1).rightJustified (2,'0'));
					if ( iMark < qvlPanelMarks.size ()-1 ) {
						qsMarks.append (QStringLiteral("&nbsp;"));
					}
				}

				if ( getGameCode() != RACHA )
					areaLabel.append( QString::number(qvlPanelMarks.size ()).rightJustified (2,'0') );

				qsMarks.append (QStringLiteral("&nbsp;"));

				qsLbl.append( getAdditionalGamesPerArea(iArea) );
				qsLbl.append( getQuickPickLabel5000 (iArea,iPanel) );
			}


		}

		m_mHtmlData.insertMulti (QStringLiteral("area_name"), QString("%1.").arg (areaLabel));
		m_mHtmlData.insertMulti (QStringLiteral("area_numbers"), qsMarks);
		m_mHtmlData.insertMulti (QStringLiteral("area_misc"), qsLbl);
	}

}

/**
 * @sa populateAdditionalContent - CH_Polla Chilena
 * @return ImtsRxErrors::eeRxStatus
 * @brief This routine constructs the data that will fill the html template with additional game-specific data.
 */
void ClGamesCommonRx::populateAdditionalContent ( const PlayPrintReceiptFlags& eReceiptFor )
{
	insertAdditionalGamesCosts( eReceiptFor );
}

/**
 * @sa populateLoto3Content - CH_Polla Chilena
 * @return ImtsRxErrors::eeRxStatus
 * @brief This routine constructs the data that will fill the html template.
 */
void ClGamesCommonRx::populateLoto3Content ( const PlayPrintReceiptFlags& eReceiptFor )
{
	int iArea = 0;
	const quint8 iNumberOfPanels = getNumberOfPanels ();

	QVariantList qvlPanelMarks = QVariantList ();
	QString qsMarks = QString ();
	QString qsLbl = QString ();
	QString qsQP = QString ();

	QVariantMap qvmMultipliers = QVariantMap ();
	qvmMultipliers = m_pcGameTxData->readAreaList().at(iArea).toMap().value("CustomData").toMap();

	QMap<int,QString> mIntToNameString = QMap<int,QString> ();
	if (mIntToNameString.isEmpty()) {
		mIntToNameString.insert( 0, "Straight" );
		mIntToNameString.insert( 1, "Combo" );
		mIntToNameString.insert( 2, "Box" );
		mIntToNameString.insert( 3, "Pairs" );
		mIntToNameString.insert( 4, "LastDigit" );
	}

	if ( eReceiptFor.testFlag (Exchange) ) {
		m_pTrns_gm_2000 = (TRNS_GM_2000*)&m_pReceivedData[sizeof(CSS_IT_1)+sizeof(REPLY_50_1)+iArea*sizeof(TRNS_GM_2000)];
	} else {
		m_pRtrns_gm_2000 = (RTRNS_GM_2000*) ( &m_pReceivedData [ sizeof(CSS_IT_1) + sizeof(REPLY_100_1)  ] );
	}

	for ( int iMultiplier = 0; iMultiplier < 5 ; iMultiplier++ ) {

		qsMarks.clear ();
		qsLbl.clear ();
		qsQP.clear();


		if ( qvmMultipliers.contains( mIntToNameString.value(iMultiplier) ) ) {

			m_mHtmlData.insertMulti (QStringLiteral("area"), QStringLiteral("CLONE_ONLY"));

			for ( int iPanel = 0; iPanel < iNumberOfPanels; ++iPanel ) {

				qvlPanelMarks = getPanel(iArea, iPanel);

				for ( int iMark = 0; iMark < qvlPanelMarks.size (); ++iMark) {

					// Creates the '--X' for 'Terminacion'.
					if ( iPanel < iNumberOfPanels-1 && iMultiplier == 4 ){
						qsMarks.append ( QStringLiteral("X") );
					} else {
						qsMarks.append ( QString::number (qvlPanelMarks.at (iMark).toInt () ));
					}

					if ( iMark < qvlPanelMarks.size ()-1 ) {
						qsMarks.append (QStringLiteral("&nbsp;"));
					}
				}

			}

			qsMarks.append (qsLbl);
			m_mHtmlData.insertMulti (QStringLiteral("numbers"), qsMarks);


			switch (iMultiplier) {
				case 0:
					m_mHtmlData.insertMulti (QStringLiteral("pickType"), QStringLiteral("Exacta") );
				break;
				case 1:
					m_mHtmlData.insertMulti (QStringLiteral("pickType"), QStringLiteral("Trio Par") );
				break;
				case 2:
					m_mHtmlData.insertMulti (QStringLiteral("pickType"), QStringLiteral("Trio Azar") );
				break;
				case 3:
					m_mHtmlData.insertMulti (QStringLiteral("pickType"), QStringLiteral("Par") );
				break;
				case 4:
					m_mHtmlData.insertMulti (QStringLiteral("pickType"), QStringLiteral("Terminacion") );
				break;
				default:
				break;
			}

			if ( eReceiptFor.testFlag (Exchange) ) {
				m_mHtmlData.insertMulti (QStringLiteral("amount"), FormatAmount::getFormatedAmount( double(m_pTrns_gm_2000->mult[iMultiplier] *100.) ) );
			} else {
				m_mHtmlData.insertMulti (QStringLiteral("amount"), FormatAmount::getFormatedAmount( double(m_pRtrns_gm_2000->data[iMultiplier] *100.) ) );
			}

			qsQP.append("&nbsp;");
			qsQP.append( getQuickPickLabel2000 (iArea) );
			m_mHtmlData.insertMulti (QStringLiteral("qp"), qsQP);
		}

	}

}


/**
 * @sa addPlayToLastPlayList
 * @brief Add exchange ticket to last play list.
 * Normally when we do addPlayTransactionToCustomerSession it will trigger the addition but it will also
 * update the customer session money which we don't want. So, this method will only do the last play addition.
 */
void ClGamesCommonRx::addPlayToLastPlayList ()
{

	int iSession = m_pcGameTxData->readSessionId ();
	QString qsTrnsDescription = getGameName ();
	QDateTime dateTime = QDateTime::currentDateTime ();

	CustomerSessionTrnsData customerSessionTrnsData;
	customerSessionTrnsData.setHandleId ( 0 ); // 0 because only one customer is currently supported. We could add more customers.
	customerSessionTrnsData.setSessionId ( iSession );
	customerSessionTrnsData.setTransactionDateTime ( dateTime.toTime_t () );
	customerSessionTrnsData.setTransactionDescription ( qsTrnsDescription );
	customerSessionTrnsData.setTransactionType (TransactionTypes::Play);
	customerSessionTrnsData.setTransactionNumber ( getTrnsNumber () );
	customerSessionTrnsData.setAmount ( getPlainCouponCost () );
	customerSessionTrnsData.setTimesPrinted (0);
	QString qsBarcode = getBarcode ()%QString("-")%getIsecurePrintable ();

	customerSessionTrnsData.setBarcode ( qsBarcode );
	customerSessionTrnsData.setLastPrintFileName ( m_qsSaveReceiptFileName );

	QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&customerSessionTrnsData);
	DbusWrapper::getLastTransactionsListInterface ()->appendLastTransactionSlot (qbaJsonData);// Append the data to the list model that maintains all last transactions, for priting purposes.
}

/**
 * @sa makeReply_100_1_From_Reply_50_1
 * @param pReceivedData
 */
void ClGamesCommonRx::makeReply_100_1_From_Reply_50_1 ( const char* pReceivedData )
{

	m_qbaFakedData.fill ('\0', 1024); // create the array that will be used to hold the fake data.

	REPLY_50_1  *pReply_50_1  = (REPLY_50_1*)&pReceivedData[sizeof(CSS_IT_1)];

	m_pCss_It_1     = (CSS_IT_1*)m_qbaFakedData.constData ();
	m_pReply_100_1  = (REPLY_100_1*)(&m_qbaFakedData.constData ()[sizeof(CSS_IT_1)]);

	memcpy( m_pCss_It_1, pReceivedData, sizeof(CSS_IT_1) );

	memcpy ( m_pReply_100_1->cpn_id,  pReply_50_1->cpn_id, 3*sizeof(long) );

	double dCost = pReply_50_1->hdr.data[Imts::Reply50_1_CouponAmountInt]/100.+0.00001; // in cents
	FormatAmount::convertDoubleToAMOUNTSTRC ( dCost, (AMOUNT_STRC *)&m_pReply_100_1->amount );

	m_pReply_100_1->game                                        = pReply_50_1->game;
	m_pReply_100_1->cpn                                         = pReply_50_1->cpn;
	m_pReply_100_1->data[Imts::Reply100_1_AcceptanceTime]       = m_pCss_It_1->sys_time;
	m_pReply_100_1->data[Imts::Reply100_1_Columns]              = 0;                                                             // Not used
	m_pReply_100_1->data[Imts::Reply100_1_StartingDraw]         = pReply_50_1->hdr.data[Imts::Reply50_1_NewStartingDraw];
	m_pReply_100_1->data[Imts::Reply100_1_StartingDrawDeadline] = pReply_50_1->hdr.data[Imts::Reply50_1_NewStartingDrawDeadline];
	m_pReply_100_1->data[Imts::Reply100_1_EndingDraw]           = pReply_50_1->hdr.data[Imts::Reply50_1_NewEndingDraw];
	m_pReply_100_1->data[Imts::Reply100_1_EndingDrawDeadline]   = pReply_50_1->hdr.data[Imts::Reply50_1_NewEndingDrawDeadline];
	m_pReply_100_1->data[7]                                     = pReply_50_1->hdr.data[Imts::Reply50_1_CouponAmountFraction];   // Use of the position of the 'CouponAmountFraction', for the remaining draws in case of Exchange.
	//    pCssIt_1->hdr.trns                                        = pCssIt_1->hdr.trns;                                        // Leave as is, EXCHANGE doesn't have a trnsnr
	//    pCssIt_1->hdr.crc                                         = pCssIt_1->data;                                            // This contains the CRC of the original coupon
	m_pReply_100_1->data[9]                                     = pReply_50_1->hdr.data[Imts::Reply50_1_TeamCoupons];            // This should contain the random in exchange
}
