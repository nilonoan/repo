/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once
#ifndef CLGAMESCOMMONRX_H
#define CLGAMESCOMMONRX_H

#define _RTRNS_GM_2000

#include "GamesCommonRx.h"

/**
 * @file ClGamesCommonRx.h
 * @class ClGamesCommonRx
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief overrides where needed provided virtual methods
 */
class ClGamesCommonRx : public GamesCommonRx
{
public:
	explicit ClGamesCommonRx ();

protected:
	void initCouponHdrFlagsExchange   ( const REPLY_50_1* pReply_50_1 ) Q_DECL_OVERRIDE;
	void initGameFlagsFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode ) Q_DECL_OVERRIDE;
	void initSysFor5000Exchange       ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode ) Q_DECL_OVERRIDE;
	void initTypeFor5000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode ) Q_DECL_OVERRIDE;
	void initFlagsFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 ) Q_DECL_OVERRIDE;
	void initTypeFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode ) Q_DECL_OVERRIDE;
	void initValueFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode  ) Q_DECL_OVERRIDE;
	QString getGameName               () Q_DECL_OVERRIDE;

	void generateCommonReceiptContent (const PlayPrintReceiptFlags&  );
	void populateTicketPrintData ( const PlayPrintReceiptFlags& eReceiptFor );
	void populateTicketPreviewData ( const PlayPrintReceiptFlags& eReceiptFor );

	QString getQuickPickLabel5000 ( const int& iArea, const int& iPanel );
	QString getQuickPickLabel2000 ( const int& iArea );
	QString getCostLabel          ( const int& iArea );
	bool isAdditionalGameSelected ();
	QString getAdditionalGamesPerArea ( const int& iArea );

	ImtsRxErrors::eeRxStatus makeCommonReceipt ( const PlayPrintReceiptFlags&, QVariantMap& qvmDataForGui, const char* pReceivedData );

	void populatePrognosticsAreaContent ();
    void populateAdditionalContent( const PlayPrintReceiptFlags& );
    void insertAdditionalGamesCosts( const PlayPrintReceiptFlags& );
    void populateLoto3Content( const PlayPrintReceiptFlags& );

	void addPlayToLastPlayList ();

    void makeReply_100_1_From_Reply_50_1 (const char* pReceivedData );

	QVariantMap m_mHtmlData;

private:
	QString m_qsGameName;

	RSTRNS_GM_5000* m_pRstrns_gm_5000;
	RTRNS_GM_2000* m_pRtrns_gm_2000;
    TRNS_GM_2000* m_pTrns_gm_2000;
    const char* m_pReceivedData;
};

#endif // CLGAMESCOMMONRX_H
