/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file CouponUtilities.h
  * @class CouponUtilities
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#define C_PLUS_PLUS
#if defined(C_PLUS_PLUS)
#include <algorithm>
#endif
#include "CouponUtilities.h"
#include "SystemWideConstValues.h"
#include "LocalEventLoggerEvents.h"
#include "JsonOperations.h"
#include "Transactions/100_149_DrawTransactions/GameTxData.h"
#include "ImtsGamesEnums.h"
#include "GetConfigValue.h"

#if defined(IMTS_LINUX) || defined(IMTS_ARM)
#include <QtDBus/QDBusReply>
#include "DbusWrapper.h"
#elif defined(IMTS_ANDROID)
#include "HostCallWrapper.h"
#endif

#include <QtCore/QTimer>
CouponError CouponUtilities::cLastCouponErrors;

/**
 * @sa CouponUtilities constructor
 */
CouponUtilities::CouponUtilities( QObject *parent )
	: QObject ( parent )
{
	cLastCouponErrors.clearCouponErrors ();
}

CouponUtilities::~CouponUtilities ()
{

}

/**
 * @sa getMinMaxMarksInPanels
 * @return a map containing marks max-min-default for selected game in per panel basis.
 *
 * @brief This method is widely use throughout the s/w. Basically it detects the type of game and sets a map with min-max-default marks values
 * as well as the type of the game in per panel basis..
 * min: means the minimum allowed marks to form a valid bet. For example, if game Lotto with default 7 marks supports system then you can have iMin = 3. Check LW.
 * max: means the maximum allowed marks to form a valid bet
 * default: means the default allowed marks to form a valid default bet (no system)
 *
 * I have written an extensive documentation on this and you should find it in IMTS documents. Don't complain, try to understand how it works.
 * If you think you could have done a better job, just form an argument and change stuff. The s/w at least gives this option.
 *
 * The method detects the type of the game and based upon that it sets
 *
 * BetType Games:
 *                  Min     : takes value from config and it's the first value of the bettype
 *                  Max     : takes value from config and it's the last value of the bettype
 *                  Default : dynamically evaluated to bettype selection
 *                  GameType: ImtsGamesEnums::BetTypeSupport
 *
 * BetType and System Games:
 *                  Min     : dynamically evaluated as: selected bettype + default value from config
 *                  Max     : takes value from config. If however, MaxOffset is greater than zero in BetTypeCfgMap{} then the max is dynamically evaluated as betType+MaxOffset (Keno Taiwan)
 *                  Default : dynamically evaluated to bettype selection
 *                  GameType: ImtsGamesEnums::BetTypeWithSystemSupport
 *
 *
 * System Games:
 *                  Min     : takes value from config
 *                  Max     : takes value from config
 *                  Default : takes value from config if system is not bound on user selection else dynamically based on the value user has selected. Just like with bettype.
 *                  GameType: ImtsGamesEnums::SystemSupport OR ImtsGamesEnums::DefaultGame
 *
 * NoSystem Games:
 *                  Min     : takes value from config
 *                  Max     : takes value from config
 *                  Default : takes value from config
 *                  GameType: ImtsGamesEnums::DefaultGame
 *
 * Example:
 * OzLotto       : [PanelA]-> Min: 4, Max: 18, Default: 7   [PanelB]-> not contained in the returned map because ain't any
 * TW 6/49       : [PanelA]-> Min: 5, Max: 16, Default: 6   [PanelB]-> not contained in the returned map because ain't any
 * PowerBall     : [PanelA]-> Min: 6, Max:  6, Default: 6   [PanelB]-> Min: 1, Max: 1, Default: 1
 * TW SuperLotto : [PanelA]-> Min: 5, Max: 16, Default: 6   [PanelB]-> Min: 1, Max: 8, Default: 1
 *
 * QMap<int, QMap<QString,int> >
 *      |           |      |
 *      |           |      |-> value of "Min","Max","Default","GameType"
 *      |           |
 *      |           |->"Min","Max","Default","GameType"
 *      |
 *      |->panel number as int 0,1,2 etc
 *
 * Example accessing the returned Map:
 * theMap.value(0).value("Min") will get you Min for panelA
 * theMap.value(1).value("Max") will get you Max for panelB
 *
 * Remember that each time you set a new BetType for betType supported games, Keno and Taiwan Mark games you have to call method
 * to recalculate the map. The "Default" value is dynamically calculated based on selected bettype. Do the same for LW games that use system.
 *
 * Note: If you break this routine the whole gameSuit will break apart. So please be really carefull....
 * Originally I made this method static, but after the last comment I decided to make it virtual. In that case you need an object to call it
 * and you loose on speed(?) but earn in modularity and reduce the risk of breaking things.
 */
QMap<int, QMap<QString,int> > CouponUtilities::getMinMaxMarksInPanels ( GamesConfig*const gameConfig, const Coupon& couponData, const int &iArea )
{
	QMap<int, QMap<QString,int> > mMinMax;

	ImtsGamesEnums::GameTypeFlags gameTypeFlag (ImtsGamesEnums::DefaultGame);

	if ( !gameConfig->readBetTypeCfgMap ().isEmpty ()) {

		gameTypeFlag |= ImtsGamesEnums::BetTypeSupport;
	}

	if ( !gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().isEmpty () ) {

		gameTypeFlag |= ImtsGamesEnums::SystemSupport;

		// Now check for variations
		if ( gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value("PerArea").toBool () ) {
			gameTypeFlag |= ImtsGamesEnums::SystemPerArea;
		}

		if ( gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value("NoOfMarkSelectionsBoundToSystem").toBool () ) {
			gameTypeFlag |= ImtsGamesEnums::SystemBoundToUserSelection;
		}

	}

	if ( !gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value ("FixedSystemCfgMap").toMap ().isEmpty() ) {
		gameTypeFlag  |= ImtsGamesEnums::FixedSystemSupport; // didn't test.
	}

	if ( gameConfig->readPartialQp () ) {
		gameTypeFlag  |= ImtsGamesEnums::PartialQp;
	}

	if ( gameConfig->readSystemQp () ) {
		gameTypeFlag  |= ImtsGamesEnums::SystemQp;
	}

	if ( gameConfig->readPickXGameUseCalculator () ) {
		gameTypeFlag  |= ImtsGamesEnums::CalculatorSupport;
	}

	if ( gameConfig->readQpPerPanel () ) {
		gameTypeFlag  |= ImtsGamesEnums::QpPerPanel;
	}


	if ( gameTypeFlag.testFlag (ImtsGamesEnums::BetTypeSupport) && !gameTypeFlag.testFlag (ImtsGamesEnums::SystemSupport) )  { // BetType only

		// I'm not aware of a game where you can have a bettype with more than one panel. Hence iPanel = 0
		quint8 iPanel = 0;
		QMap<QString,int> mTmp;
		mTmp.insert (QStringLiteral("Min"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Min")).toInt ());
		mTmp.insert (QStringLiteral("Max"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Max")).toInt ());
		mTmp.insert (QStringLiteral("Default"), couponData.getArea (iArea)->getBetTypeValue () );
		mTmp.insert (QStringLiteral("GameType"), gameTypeFlag.operator int () );

		mMinMax.insert (iPanel, mTmp );


	} else if ( gameTypeFlag.testFlag (ImtsGamesEnums::BetTypeWithSystemSupport) ) { // System and Bettype

		// I'm not aware of a game with multiple panels where bettype is supported, supporting system selections at the same time!!!. Hence iPanel = 0.
		quint8 iPanel = 0;
		quint8 iBetType = couponData.getArea (iArea)->getBetTypeValue ();

		QMap<QString,int> mTmp;

		mTmp.insert (QStringLiteral("Min"), iBetType+gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Default")).toInt ()); // Be very careful how you configure your config file. If default is -1 the min is one less than the bettype κοκ. If defautl is 0 then you only support as minimum the bettype and basically you have forward systems only.

		quint8 iMaxOffset = gameConfig->readBetTypeCfgMap ().value (QStringLiteral("MaxOffset")).toInt ();
		if (iMaxOffset) {
			mTmp.insert (QStringLiteral("Max"), iBetType+iMaxOffset);
		} else {
			mTmp.insert (QStringLiteral("Max"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Max")).toInt ());
		}

		mTmp.insert (QStringLiteral("Default"), iBetType );
		mTmp.insert (QStringLiteral("GameType"), gameTypeFlag.operator int () );

		mMinMax.insert (0, mTmp );

	} else if ( gameTypeFlag.testFlag (ImtsGamesEnums::SystemSupport) && !gameTypeFlag.testFlag (ImtsGamesEnums::BetTypeSupport) ) { // System only

		quint8 iPanel = 0;
		quint8 iMaxPanels = gameConfig->readNumberOfPanels ();

		QMap<QString,int> mTmp;

		bool bUserSystemSelectionBoundedToMarks = gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value("NoOfMarkSelectionsBoundToSystem").toBool (); // Tells whether the user needs to select a system from gui and then bound that selection to the number of marks to be made onto the panel. Works sort of like bettype. LW games are like this, afaik.

		// Store for each panel the min,max and default mark selections.
		for ( iPanel = 0; iPanel < iMaxPanels; ++iPanel ) {

			mTmp.insert (QStringLiteral("Min"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Min")).toInt ());
			mTmp.insert (QStringLiteral("Max"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Max")).toInt ());


			if ( iPanel == 0 ) {

				if ( bUserSystemSelectionBoundedToMarks ) { // "Default" is bound on user's system selection.

					if ( gameTypeFlag.testFlag (ImtsGamesEnums::SystemPerArea ) ) { // system bet selection per area. Not aware of such a game where in each area the user has the option to select the system first and then make the marks' selections.

						mTmp.insert (QStringLiteral("Default"), couponData.getArea (iArea)->getSystemBet () );

					} else { // per coupon ozLotto

						mTmp.insert (QStringLiteral("Default"), couponData.getSystemBet () );
					}

				} else { // System is based on the number of user's marks selections. So the default is not bound on Gui selection.

					mTmp.insert (QStringLiteral("Default"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Default")).toInt ());
				}

			} else {

				mTmp.insert (QStringLiteral("Default"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Default")).toInt ()); // get default value for second panel from config.
			}


			mTmp.insert (QStringLiteral("GameType"), gameTypeFlag.operator int () );

			mMinMax.insert (iPanel,  mTmp );
			mTmp.clear ();
		}

	} else { // Store min,max and default marks per panel as dictated in the config file.)

		quint8 iPanel = 0;
		quint8 iMaxPanels = gameConfig->readNumberOfPanels ();

		QMap<QString,int> mTmp;

		// Store for each panel the min,max and default mark selections. It's all taken from config.
		for ( iPanel = 0; iPanel < iMaxPanels; ++iPanel ) {

			mTmp.insert (QStringLiteral("Min"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Min")).toInt ());
			mTmp.insert (QStringLiteral("Max"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Max")).toInt ());
			mTmp.insert (QStringLiteral("Default"), gameConfig->readMarksCfgMap ().value (QStringLiteral("MinMax")).toList ().at (iPanel).toMap ().value (QStringLiteral("Default")).toInt ());
			mTmp.insert (QStringLiteral("GameType"), gameTypeFlag.operator int () );

			mMinMax.insert (iPanel,  mTmp );
			mTmp.clear ();
		}
	}

	return mMinMax;

}

/**
   * @sa getGameConfig
   * @param get config by riga or game code.
   * @param gameRiga you want the config data for.
   * @param a byteArray which will be initialized with the config data
   * @brief request from SCM the games' config contained in a QByteArray
 */
bool CouponUtilities::getGameConfig( const eeGetConfigBy& eGetConfigBy, const int& iGameCode, GamesConfig& cGameConfig )
{

	bool bOK = true;
	QByteArray qbaGameConfigJsonData = QByteArray ();
	cGameConfig.clearConfig ();

#if defined(IMTS_ANDROID)

	if ( eGetConfigBy == eByGameCode ) {

		HostCallWrapper hostCallWrapper;
		qbaGameConfigJsonData = hostCallWrapper.getGameConfigByGameCode ( iGameCode );

	} else {
		qDebug () << "Riga is not currently supported in Android application";
	}

#elif defined(IMTS_LINUX) || defined(IMTS_ARM)

	if ( eGetConfigBy == eByGameCode ) {
		DbusWrapper::getGameConfigByGameCode( iGameCode, qbaGameConfigJsonData );
	} else {
		DbusWrapper::getGameConfigByRiga( iGameCode, qbaGameConfigJsonData );
	}

#endif

	if ( qbaGameConfigJsonData.isEmpty() ) {

		QString errMsg = QString();
		eGetConfigBy == eByGameCode ? errMsg.append(QStringLiteral("getGameConfig returned an empty reply")) : errMsg.append(QStringLiteral("getGameConfig returned an empty reply"));
		LOG(errMsg);
		bOK = false;

	} else {

		QJson::JsonOperations::JsonToqObject(qbaGameConfigJsonData, &cGameConfig); //! Initialize gameConfig object with game's config data
	}

	return bOK;
}

/**
 * @sa comp
 * @param m: number of selected marks
 * @param n: number of minimum marks permitted
 * @brief get compinations
 */
quint32 CouponUtilities::comp( const quint8& m, const quint8& n )
{
	quint32 c = 0;

	if ( !n )
		return 1;
	if ( !m )
		return 0;
	if ( n==1 )
		return m;
	if ( m==n )
		return 1;

	if (m > n )
		c = comp (m-1,n) + comp(m-1,n-1);

	return c;
}

/**
 * @sa countCombos
 * @param iArea
 * @return the combinations for all panels.
 * @brief A{1,2,3} B{1,2,3} B{1,2,3} the returned value will be 3x3x3 = 27
 */
quint16 CouponUtilities::countCombos ( GamesConfig*const gameConfig, const Coupon& couponData, const int& iArea )
{
	quint16 iCombos = 1;
	quint8 iNumberOfPanels = gameConfig->readNumberOfPanels ();

	for ( int iPanel = 0; iPanel < iNumberOfPanels; ++iPanel ) {

		iCombos *=couponData.getArea (iArea)->getPanelXList (iPanel).size ();

	}

	return iCombos;
}

/**
 * @sa countSystemPickBoxCombos
 * @param iArea
 * @return combinations of all numbers in panels but the same digits.
 * @brief For Taiwan pick games where the user can select more than one digit per panel
 * we need to calculate the combinations for all panels when play type is a BOX. That is,
 * if panel A{1,2,3} panel B{4,5,6} C{7,8,9} combos will be 3x3x3 =27. Easy peasy.
 * However, we got to exclude the combination for the digit that exists in all panels
 * and forms a valid combination. For example, A{1,2,3} B{1,5,6} C{1,8,9} will give
 * us 3x3x3=27 minus the combination {1,1,1} resulting in 26 combinations.
 * The implementation has as follows. First we get in a list the betLine, that is all
 * numbers the user has selected. Then starting at 0 up to the end of the list we call
 * qCount which will count the digit at [i] subsequently. iCountOfNumber will tell us
 * how many times the digit at[i] exists in the list. If it equals the size of our
 * panels then it means that we have found what we were looking for and the number is
 * appended into a temp list and continue until we reach the end of betLine list.
 * At last we do multiplicate the sizes of each of our panels and substract the size
 * of our temp list, and we get the combos we're after.
 *
 */
quint16 CouponUtilities::countSystemPickBoxCombos( GamesConfig*const gameConfig, const Coupon& couponData, const int& iArea)
{
	quint16 iCombos = 1;
	QList<int> lBetline = couponData.getArea (iArea )->getPickGameBetline ();
	int iCountOfNumber = 0;
	QList<int> lTemp;
	quint8 iNumberOfPanels = gameConfig->readNumberOfPanels ();
	quint8 iSizeOfBetLine = lBetline.size ();


	// Find out how many times each digit exist in our betLine. If equals the size of our
	// panels append into a temp list.
	for ( int i = 0; i < iSizeOfBetLine; ++i ) {

		if ( !lTemp.contains (lBetline.at (i))) {

			qCount(lBetline.begin(), lBetline.end(), lBetline.at (i), iCountOfNumber);

			if ( iCountOfNumber == iNumberOfPanels ) {
				lTemp.append (lBetline.at (i));
			}
			iCountOfNumber = 0;
		}
	}

	// Calculate the combinations
	iCombos = countCombos (gameConfig, couponData, iArea);

	// Substract from last calculated combinations the number of times a digit exist in all panels.
	iCombos -= lTemp.size ();

	return iCombos;
}

/**
 * @sa getColumnsInAreaForPickGame
 * @param gameConfig
 * @param couponData
 * @param area interested in
 * @return the number of columns
 */
int CouponUtilities::getColumnsInAreaForPickGame ( GamesConfig*const gameConfig, const Coupon &couponData, const int& iArea )
{

	int iColumns = 0;

	if ( couponData.getArea (iArea)->getPickXPlayType ().testFlag (ImtsGamesEnums::Combo) ) { // each permutation is a column

		iColumns = pickXGetNumbersSet ( gameConfig, couponData, iArea );

	} else {

		if ( couponData.getArea (iArea)->getPickXPlayType () == ImtsGamesEnums::Box) {

			iColumns = CouponUtilities::countSystemPickBoxCombos ( gameConfig, couponData,  iArea);

		} else if ( couponData.getArea (iArea)->getPickXPlayType () == ImtsGamesEnums::StraightBox) {

			iColumns = CouponUtilities::countCombos (gameConfig, couponData, iArea)+countSystemPickBoxCombos (gameConfig, couponData, iArea);

		} else if ( couponData.getArea (iArea)->getPickXPlayType () == ImtsGamesEnums::SecondDigit) {

			// Before we return the number of columns we got to check that the 2nd digit is there. Otherwise we got to return 0.

			iColumns = couponData.getArea (iArea)->getPanelXList (1/*2nd digit's panel*/).size ()?10:0 ; //e.g., if 6 is the 2ndDigit then we got: { "060", "161", "262", "363", "464", "565", "666", "767", "868", "969" }

		} else {

			iColumns = CouponUtilities::countCombos (gameConfig, couponData, iArea);
		}
	}

	return iColumns;
}


/**
 * @sa getColumnsInAreaLotto
 * @param gameConfig
 * @param couponData
 * @param area interested in
 * @return the number of columns
 */
int CouponUtilities::getColumnsInAreaForLottoGame ( GamesConfig*const gameConfig, const Coupon &couponData, const int& iArea )
{
	int iColumns = 0;

	QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, iArea );

	int iNumberOfSelectedMarksPanelA = couponData.getArea ( iArea )->countMarksInPanelX (0);
	int iNumberOfSelectedMarksPanelB = couponData.getArea ( iArea )->countMarksInPanelX (1);

	int iNumberOfPanels = gameConfig->readNumberOfPanels();

	if ( !(mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("GameType")) & ImtsGamesEnums::SystemSupport) ) { // If system is not supported

		if ( iNumberOfSelectedMarksPanelA > 0 && iNumberOfSelectedMarksPanelA == mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) ) {

			iColumns += comp ( iNumberOfSelectedMarksPanelA, mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) );

		} else if ( iNumberOfSelectedMarksPanelA > 0 && iNumberOfSelectedMarksPanelA >= mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Min")) && iNumberOfSelectedMarksPanelA <= mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Max")) ) {

			iColumns += comp ( iNumberOfSelectedMarksPanelA, mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) );

		} else {

			iColumns = 0;
		}

		if ( iNumberOfPanels > 1 && iNumberOfSelectedMarksPanelB != mMaxSelectedMarksInPanels.value (1).value (QStringLiteral("Default")) ) {
			iColumns = 0;
		}


	} else { // system is supported.

		int iMarksInPanel = gameConfig->readMarksCfgMap ().value (QStringLiteral("MarksInPanelsList")).toList ().at (0).toInt (); // get the number of marks in panel0

		if ( iNumberOfSelectedMarksPanelA > 0  &&  iNumberOfSelectedMarksPanelA == mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Min")) ) {

			if ( mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Min")) == mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) ) { // if min and defautl are the same then use default calculate columns.
				iColumns += comp ( iNumberOfSelectedMarksPanelA, mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) );
			} else {
				iColumns += (iMarksInPanel - mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Min")));
			}


		} else if ( iNumberOfSelectedMarksPanelA > 0  &&  iNumberOfSelectedMarksPanelA >= mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) ) {

			iColumns += comp ( iNumberOfSelectedMarksPanelA, mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Default")) );

		} else {

			iColumns = 0;
		}

		if ( iNumberOfPanels > 1 ) {
			iColumns *= iNumberOfSelectedMarksPanelB;
		}
	}

	return iColumns;

}


/**
 * @sa getColumnsInArea
 * @param the area we want to calculate the columns for
 * @return number of columns for specific area
 * @brief The routine calculates the columns for a specific area. It is all in one method, that is, it advises
 * gameConfig and based on configuration it makes the calculations. Opap's games makes it a bit more complicated
 * but leaving that part out it is easy to follow.
 */
int CouponUtilities::getColumnsInArea ( GamesConfig*const gameConfig, const Coupon& couponData, const int& iArea )
{
	int iColumns = 0;

	if ( gameConfig && !couponData.isCouponEmpty() ) {

		if ( !couponData.getArea(iArea)->isVoidArea() && !couponData.getArea(iArea)->isAreaEmpty() ) {

			// First of all find out whether this game supports system bets. If it does check whether such selection was made
			// and if true, using the config file get the number of columns for that system. This is opap specific, unlikely to
			// see it in other games.
			if ( !gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().value (QStringLiteral("FixedSystemCfgMap")).toMap ().isEmpty() ) {

				int iFixedSystemBet = couponData.getArea ( iArea )->getSystemBet (); // get the FixedSystemBet selection for this area.

				iColumns = gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().value (QStringLiteral("FixedSystemCfgMap")).toMap ().value (QStringLiteral("SystemTypeMap")).toMap().value(QString::fromLatin1("%1").arg(iFixedSystemBet)).toList().at(1).toInt();
			}

			if ( iColumns == 0 ) {

				if ( IS_PICK(gameConfig->readGameCode () ) ) {

					iColumns = getColumnsInAreaForPickGame ( gameConfig, couponData, iArea );

				}
				else { // Keno and Lotto games

					iColumns = getColumnsInAreaForLottoGame (  gameConfig, couponData, iArea );
				}
			}
		}
	}

	return iColumns;
}

/**
 * @sa getColumnsInCoupon
 * @param gameConfig
 * @param couponData
 * @return total columns in coupon
 */
int CouponUtilities::getColumnsInCoupon ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	int iTotalColumns = 0;
	if ( gameConfig && !couponData.isCouponEmpty() ) {

		for ( int iArea = 0; gameConfig->readNumberOfAreas (); ++iArea ) {
			iTotalColumns += getColumnsInArea (gameConfig, couponData, iArea);
		}
	}

	return iTotalColumns;
}

/**
 * @brief getMultidrawsBasedOnDrawType
 * @param gameConfig
 * @param couponData
 * @return number of draws
 * @brief returns the number of draws for selected draw type. The number of draws for selected draw type
 * is reflected in game's configuration data. This is how the config data look:
 * We got a drawType list that contains lists each of which contains 3 items.
 * at 0 we got the string to display.
 * at 1 the enum value that would help us construct c/s data
 * at 2 the number of draws we need to multiply coupon cost with, to get the final cost.
 * For the case where Multiselect is false we read the value in our coupon data match it to the one in config
 * and finally get the number of draws we need.
 *
 * For the case where Multiselect is true we count the number of bits set which in that case it the number of
 * of draws.
 *
 */
int CouponUtilities::getMultidrawsBasedOnDrawType ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	int iNumberOfDraws = 1;
	QVariantMap mDrawTypeMap   = gameConfig->readDrawTypeMap (); // get the draw type values from config
	QVariantList lDrawTypeList = mDrawTypeMap.value (QStringLiteral("DrawTypeList")).toList ();
	int iDrawTypeListSize      = lDrawTypeList.size ();
	bool bMultiSelect          = mDrawTypeMap.value (QStringLiteral("MultiSelection"),false).toBool ();


	if ( bMultiSelect ) {

		quint32 iMask = 1;
		ImtsGamesEnums::DrawTypeFlags drawTypeFlag = couponData.getDrawType ();

		iNumberOfDraws = 0; // reset we'll count bits.

		for ( int iIndex = 0; iIndex < 32; ++iIndex ) {

			if ( drawTypeFlag.testFlag ( ImtsGamesEnums::DrawTypeFlag(iMask) ) ) {
				++iNumberOfDraws;
			}

			iMask<<=1;
		}

	} else {

		if ( iDrawTypeListSize ) {

			ImtsGamesEnums::DrawTypeFlags drawTypeFlag = couponData.getDrawType ();

			for ( int iIndex = 0; iIndex < iDrawTypeListSize; ++iIndex ) {
				if ( lDrawTypeList.at (iIndex).toList ().at (1) == drawTypeFlag.operator int () ) {
					iNumberOfDraws = lDrawTypeList.at (iIndex).toList ().at(2).toInt ();
				}
			}
		}
	}

	return iNumberOfDraws;
}


/**
 * @sa getAdditionalGameCost
 * @param gameConfig
 * @param couponData
 * @return additional game cost. Applies only in case the additional game is in per coupon basis.
 * @brief I think the default does Super66 for LotteryWest. Override to get your cost for your
 * additional game. Check Taiwan High/Low for Keno.
 */
double CouponUtilities::getAdditionalGameCost ( GamesConfig*const gameConfig, const Coupon &couponData )
{
	double dAdditionalGameCost = 0.;
	if ( !gameConfig->readAdditionalGame ().value (QStringLiteral("AddCostInPerAreaBasis")).toBool () &&
		 couponData.getAdditionalGameMap ().value (QStringLiteral("UserSelection")).toInt () ) {
		int iUserSelection = couponData.getAdditionalGameMap ().value (QStringLiteral("UserSelection")).toInt ();
		dAdditionalGameCost = iUserSelection*gameConfig->readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();
	}

	return dAdditionalGameCost;

}

/**
 * @sa getAdditionalGameCostPerArea
 * @param gameConfig
 * @param couponData
 * @return additional games cost per area. Applies only in case the additional games is in per area basis.
 */
double CouponUtilities::getAdditionalGameCostPerArea ( GamesConfig*const, const Coupon &, const int& )
{
	// Implemented inside CouponUtilitiesDerived
	return 0.0;
}



/**
 * @sa getMultiplier
 * @param couponData
 * @param iArea
 * @return multiplier for data.
 * Override to get your custom multiplier
 */
qint32 CouponUtilities::getMultiplier (GamesConfig*const, const Coupon& couponData, const qint32 iArea)
{
	return couponData.getArea( iArea )->getMultiplierValue();
}

/**
 * @sa updateCouponCost
 * @param gameConfig
 * @param couponData
 * @return updates coupon data with the cost. Even thought we pass in a const object we remove constness where appropriate to
 * update the cost.
 * @note Calculating cost for additional game is getting out of hand. Sofar we support the following options:
 * 1. AdditionalGame that reflects the whole coupon, with single selection. Its cost is added once. Supper66 LotteryWest
 * 2. AdditionalGame that reflects per area selection. The user can select an additional game in per area basis, that is,
 *    in AreaA additional game is selected, in AreaB is not, in AreaC is selected. Bull'sEye in Taiwan
 * 3. AdditionalGame that reflects the whole coupon, that is the user selects the additional game once and its cost is added
 *    based on the number of areas he/she has completed. Powerplay in Powerball.
 */
void CouponUtilities::updateCouponCost ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	if ( gameConfig && !couponData.isCouponEmpty() ) {

		int iTotalColumns = 0 ;
		int iAreaColumns = 0;

		double dAreaCost = 0.0;
		double dCouponCost = 0.0;

		QVariantMap qvmMap = gameConfig->readAdditionalGame ();
		QVariantList lAdditionalGameList = gameConfig->readAdditionalGamePerArea();

		for ( int iArea = 0; iArea < gameConfig->readNumberOfAreas (); ++iArea ) {

			iAreaColumns = getColumnsInArea ( gameConfig, couponData, iArea);
			couponData.getArea (iArea)->setAreaColumns ( iAreaColumns );

			dAreaCost = iAreaColumns * getMultiplier (gameConfig,couponData,iArea) * gameConfig->readColumnPrice();

			// Case 2 from comment
			double addOnsCost = 0.0;
			double additionalGameCostPerArea = getAdditionalGameCostPerArea(gameConfig,couponData,iArea);
			if ( !couponData.getArea (iArea)->getAdditionalGamePerArea ().isEmpty() ) {

				QVariantMap selectedAddOns = couponData.getArea (iArea)->getAdditionalGamePerArea ();

				for ( int addOn = 0; addOn < lAdditionalGameList.length(); addOn++ ) {
					if ( selectedAddOns.contains( lAdditionalGameList.at(addOn).toMap().value( QStringLiteral("Name") ).toString() ) ) {
						addOnsCost += lAdditionalGameList.at(addOn).toMap().value( QStringLiteral("Cost") ).toInt();
					}
				}
			}
			addOnsCost += additionalGameCostPerArea;
			dAreaCost += iAreaColumns * addOnsCost;
			dAreaCost *= couponData.getArea( iArea )->getMultiplierValue();

			// Case 3 from comment
			if ( couponData.getAdditionalGameMap ().value (QStringLiteral("UserSelection")).toInt () &&
				 qvmMap.value (QStringLiteral("AddCostInPerAreaBasis")).toBool () &&
				 iAreaColumns ) { // only add iff iAreaColumns!=0

				dAreaCost += gameConfig->readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();
			}

			couponData.getArea( iArea )->setAreaCost(dAreaCost);
			dCouponCost += dAreaCost;

			if ( getMultiplier (gameConfig,couponData,iArea) > 1 ) {
				iTotalColumns += getMultiplier (gameConfig,couponData,iArea)*iAreaColumns;
			} else {
				iTotalColumns += iAreaColumns;
			}

		}

		// Case 1 from comment
		double dAdditionalGameCost = getAdditionalGameCost (gameConfig,couponData);

		dCouponCost += dAdditionalGameCost;
		dCouponCost *= couponData.getMultiDrawValue()*CouponUtilities::getMultidrawsBasedOnDrawType ( gameConfig, couponData )/* * couponData.getNumberOfTickets () */;
		const_cast<Coupon*>(&couponData)->setCouponCost ( dCouponCost );

		if ( iTotalColumns ) {
			const_cast<Coupon*>(&couponData)->setCouponColumns ( iTotalColumns * couponData.getMultiDrawValue ()*CouponUtilities::getMultidrawsBasedOnDrawType ( gameConfig, couponData ) );
		}

	} else if ( gameConfig ) {

		for ( int iArea = 0; iArea < gameConfig->readNumberOfAreas (); ++iArea ) {
			couponData.getArea( iArea )->setAreaCost( 0. );
		}
		const_cast<Coupon*>(&couponData)->setCouponColumns ( 0 );
		const_cast<Coupon*>(&couponData)->setCouponCost ( 0. );

	}
}

/**
 * @sa createCouponDataFromGameTxData
 * @param qbaGameTxData
 * @return return a fully initialized GameTxData object
 * @brief Takes a partially initialized GameTxData mostly given by the exchange process, and constructs
 * Coupon data. We can now check the data using the utilities we provide as well as calculate the cost
 * in per Area basis. The last information is needed before we print an exchange ticket and I decided
 * to update that information only using CouponUtilities object, not elsewere.
 *
 * The method will do the reverse of what createGameTxDataFromCouponData does.
 */
QByteArray CouponUtilities::createCouponDataFromGameTxData( const QByteArray& qbaGameTxData, Coupon& couponData, GamesConfig *const pcGamesConfig )
{
	GameTxData cGameTxData;
	QJson::JsonOperations::JsonToqObject( qbaGameTxData, &cGameTxData ); // some values have already been initialized by the ExchangeDataRx.cpp and GamesFamilyxxxx.cpp objects in Trss.

	// Now we need to initialise Coupon from given GameTxData. Then we can call relative available methods to complete GameTxData.

	couponData.addAreas           ( pcGamesConfig->readNumberOfAreas () );
	couponData.setGameCode        ( pcGamesConfig->readGameCode () );
	couponData.setGameName        ( pcGamesConfig->readGameName () );
	couponData.setNumberOfPanels  ( pcGamesConfig->readNumberOfPanels () );

	couponData.setInputMethod       ( cGameTxData.readInputMethod () );
	couponData.setMultiDrawSingle   ( cGameTxData.readMultidraws () );

	// Do Additional game, that is if selection is true we need to know its cost and name. Take it from config and update the map just the same as we do for gui.
	QVariantMap mAdditionalGameMap = cGameTxData.readAdditionalGame ();
	if ( !mAdditionalGameMap.isEmpty () ) {
		double dAdditionalGameCost = pcGamesConfig->readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();

		mAdditionalGameMap.insert (QStringLiteral("Price"), dAdditionalGameCost );
		mAdditionalGameMap.insert (QStringLiteral("GameName"), pcGamesConfig->readAdditionalGame ().value(QStringLiteral("Name")).toString () );
	}
	couponData.setAdditionalGameMap ( mAdditionalGameMap );

	couponData.setFutureDrawSingle  ( cGameTxData.readFuturedraws () );
	couponData.setDrawType          ( ImtsGamesEnums::DrawTypeFlags(cGameTxData.readDrawType ()) );

	QVariantList lAreaList             = cGameTxData.readAreaList ();
	quint8 iNumberOfAreasToCreate      = lAreaList.size ();
	quint8 iNumberOfPanels             = pcGamesConfig->readNumberOfPanels();
	QVariantMap mAreaValues            = QVariantMap ();
	QVariantList lPanelList            = QVariantList ();
	QList<int> lMarks                  = QList<int> ();
	QVariantMap mAdditionalGamePerArea = QVariantMap ();

	for ( quint8 iArea = 0; iArea < iNumberOfAreasToCreate; ++iArea ) {

		mAreaValues = lAreaList.at (iArea).toMap ();

		if ( mAreaValues.value("IsAreaEmpty").toBool () ) {
			couponData.getArea (iArea)->clearArea ();
			continue;
		}

		lPanelList = mAreaValues.value (QStringLiteral("SelectionMarksInPanels")).toList();

		for ( quint8 iPanel = 0; iPanel < iNumberOfPanels; ++iPanel ) {
			lMarks.clear ();

			QListIterator<QVariant> i(lPanelList.at (iPanel).toList ()); //lPanelList contains the lists of numbers.
			while (i.hasNext () ) {
				lMarks << i.next ().toInt ();
			}
			couponData.getArea (iArea)->initializePanelX (iPanel,lMarks);
		}

		//! Do multiplier
		couponData.getArea (iArea)->setMultiplierSingle (mAreaValues.value (QStringLiteral("Multiplier")).toInt () );

		//! Do system bet
#pragma message "//TODO: NONDAS System Bet for OPAP, needs fixing"

		//! Do bet type
		couponData.getArea (iArea)->setBetTypeSingle (mAreaValues.value (QStringLiteral("DefaultMarks")).toInt ());

		//! Do QuickPick
		couponData.getArea (iArea)->setQp (Area::eQpVariations(mAreaValues.value (QStringLiteral("Gmx000Flags")).toUInt ()));

		//! Do additional game per area. I don't set Name and Cost. Άστο για μετά εάν χρειαστεί. Τα'χω δει όλα!!!!
		mAdditionalGamePerArea =  mAreaValues.value ( QStringLiteral("AdditionalGamePerArea") ).toMap ();

		couponData.getArea (iArea)->setAdditionalGamePerArea ( mAdditionalGamePerArea );
		mAdditionalGamePerArea.clear ();

		//!Pick Play Type Selection
		ImtsGamesEnums::PickXPlayTypeFlags flags (mAreaValues.value (QStringLiteral("PickXPlayType")).toInt () );
		couponData.getArea (iArea)->setPickXPlayType (flags );

		//! Area Custom Data
		couponData.getArea (iArea)->setCustomData( mAreaValues.value( QStringLiteral("CustomData") ).toMap() );

	}

	CouponError cCouponError = getCouponErrors ( pcGamesConfig, couponData );

	if ( !cCouponError.isEmpty () ) {

		QString qsErrorString = QString();

		qsErrorString += cCouponError.getCouponErrorsInArea( 100 );

		for ( int iArea = 0; iArea < pcGamesConfig->readNumberOfAreas (); ++iArea ) {
			qsErrorString += cCouponError.getCouponErrorsInArea( iArea );
		}

		LOG(QStringLiteral("Ticket regeneration creation generated errors:"));
		LOG(qsErrorString);

		return QByteArray ();
	}

	updateCouponCost ( pcGamesConfig, couponData );
	return createGameTxDataFromCouponData ( pcGamesConfig, couponData );
}

/**
 * @sa createGameTxDataFromCouponData
 * @param gameConfig
 * @param couponData
 * @return create a json object that contains the data we use to send to Trss to initialize a game transmission data.

   QList<int>   lMarkList   = QList<int>(); this list holds user's selection numbers. We need to convert the list
   into QList<QVariant> so that json object understands. The only way (afaik) to do this, it is to do it value by
   value. Qt does not allow to do this: QVariant(lMarkList)

   Hence, we employ the following list:

   QVariantList qvlMarkList = QVariantList(); // where this list is initialized with the items found in QList<int> lMarkList.


   Wait a sec. Why don't you have getPanelXList(iPanel) returning a QVariantList instead of QList<int>? Then you wouldn't
   have to do the conversion. The reason is that, doing so, we cannot use qSort(QVariantList), which is needed to sort
   user's marks. I am not writing my own qSort that supports qVariants (at least the intParts). I don't have the energy
   for that at the moment.

   Let's see what the rest of the lists do:
   QVariantList lPanelList  = QVariantList(); // This list holds qvlMarkList. That is the marks (sorted) the user has selected.
   example: lPanelList = [
   qvlMarkList, // at(0) marks in panelA
   qvlMarkList, // at(1) marks in panelB
   qvlMarkList, // at(2) marks in panelC
   etc....
	]

   continue now with a QVariantMap:

   QVariantMap  mAreaValues = QVariantMap(); // this map holds all values that describe an area's parameters.
   That is:

   "IsAreaVoid": true,
   "IsAreaEmpty": true,
   "QpA": 0,
   "QpB": 0,
   "PricePerArea":0.0,
   "BetType": 0,
   "SystemBet": 0,
   "Multiplier": 1,
   "SelectionMarksInPanels": [], // this is lPanelList we have previously described.


   finally we continue with
   QVariantList lAreaList   = QVariantList(); // list that holds QVariantMaps, the number of which is equal
   to the number of areas for this game.

   Done my homework.
 */
QByteArray CouponUtilities::createGameTxDataFromCouponData (GamesConfig *const gameConfig, const Coupon& couponData)
{

	QByteArray qbaPlayDataToTx = QByteArray ();

	if ( gameConfig && !couponData.isCouponEmpty() ) {

		GameTxData cGameTxData;

		int iNumberOfAreas  = gameConfig->readNumberOfAreas();
		int iNumberOfPanels = gameConfig->readNumberOfPanels();
		int iSessionId      = 0;

#if defined IMTS_PCLUB && (defined(IMTS_LINUX) || defined(IMTS_ARM))

		QDBusReply<int> reply = DbusWrapper::getPClubSessionManagerInterface ()->getPClubSessionId ( 0 ); // check if there is an open pclub card session. 0 means that only one customer is supported at the moment.
		iSessionId = reply.value ();

#elif defined(IMTS_ANDROID)
		qDebug ("PClub is currently not support for ANDROID");
#endif

		cGameTxData.setTxProduct           ( gameConfig->readTxProduct () );
		cGameTxData.setRxProduct           ( gameConfig->readRxProduct () );
		cGameTxData.setProtocol            ( LOTOS5 );
		cGameTxData.setPriority            ( HIGH_PRI );

		cGameTxData.setHeader              ( QString(tr("Play ")).append (gameConfig->readGameName())); // transaction history header

		cGameTxData.setGameCode                ( gameConfig->readGameCode() );
		cGameTxData.setSubGameCode             ( gameConfig->readSubGameCode () );
		cGameTxData.setGameName                ( gameConfig->readGameName() );
		cGameTxData.setGameLogo                ( gameConfig->readGameLogoImageLocation() );
		cGameTxData.setGameHtmlTemplate        ( gameConfig->readGameHtmlTemplate() );
		cGameTxData.setGameHtmlPreviewTemplate ( gameConfig->readGameHtmlPreviewTemplate () );

		// Open relative xxxx.txt xxxx=gameCode and get game messages for receipt.
		QString qsOnReceiptGameMessageFile = GetConfigValue::getDownloadPath ();
		qsOnReceiptGameMessageFile.append (QString("%1.json").arg (gameConfig->readGameCode()));
		cGameTxData.setOnTicketMessageList ( QJson::JsonOperations::JsonObjectFromFile(qsOnReceiptGameMessageFile).value ("onTicketMessages").toList () );

		cGameTxData.setNumberOfAreas       ( iNumberOfAreas );
		cGameTxData.setNumberOfPanels      ( iNumberOfPanels );
		cGameTxData.setSessionId           ( iSessionId );
		cGameTxData.setAdditionalGame      ( couponData.getAdditionalGameMap () );


		cGameTxData.setMarksInPanelsList   ( gameConfig->readMarksCfgMap ().value (QStringLiteral("MarksInPanelsList")).toList () );

		cGameTxData.setInputMethod         ( couponData.getInputMethod() );
		cGameTxData.setMultidraws          ( couponData.getMultiDrawValue() );
		cGameTxData.setFuturedraws         ( couponData.getFutureDrawValue() );

		cGameTxData.setIsCouponVoid        ( couponData.isCouponVoid() );
		cGameTxData.setIsCouponEmpty       ( couponData.isCouponEmpty() );
		cGameTxData.setColumns             ( couponData.getCouponColumns () );
		cGameTxData.setCost                ( couponData.getCouponCost () );
		cGameTxData.setEmail               ( couponData.getEmail () );
		cGameTxData.setEmailPassword       ( couponData.getEmailPassword () );
		cGameTxData.setAdvancePlay         ( int(couponData.getAdvancePlay ()) );
		cGameTxData.setDrawType            ( int(couponData.getDrawType () ) );

		cGameTxData.setCouponOrigin		   ( couponData.getCouponOrigin () );
		cGameTxData.setCustomData          ( couponData.getMiscellaneousData ()); // Misc data could anything you wish
		cGameTxData.setPromotionData       ( couponData.getPromotionData () );

		// Create local scope variables that they will be used inside the following for loop.
		Area *areaUnderProcess = 0;
		QList<int>   lMarkList   = QList<int>();
		QVariantList qvlMarkList = QVariantList();
		QVariantList lAreaList   = QVariantList();
		QVariantList lPanelList  = QVariantList();
		QVariantMap  mAreaValues = QVariantMap();

		//----------> Double checking parameters
		QMap<int,QList<int>> mNumbers;
		QList<int> lAreaNumbers;
		lAreaNumbers.clear ();
		mNumbers.clear ();
		//<--------- Double checking parameters

		QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, 0 ); // passing 0 will set the default value to currently selected bet type. However not used, so please don't call it inside the for loop.

		QString qsLogNumbers = QString ();

		for ( int iArea = 0; iArea < iNumberOfAreas; ++iArea ) {

			lPanelList.clear();
			mAreaValues.clear();

			areaUnderProcess = couponData.getArea( iArea );

			for ( int iPanel = 0; iPanel <  iNumberOfPanels; ++iPanel ) {

				qvlMarkList.clear();
				lMarkList.clear ();

				lMarkList = areaUnderProcess->getPanelXList(iPanel); // Get marks from PanelX

				if ( !lMarkList.isEmpty () ) {

					qSort(lMarkList); // sort them out

					for ( int iMark = 0; iMark < lMarkList.size(); ++iMark ) {
						qvlMarkList << QVariant(lMarkList.at(iMark) );

						//-----------> Logging Starts
						qsLogNumbers.append (QString::number (lMarkList.at(iMark)+1).rightJustified (2,'0',false));
						qsLogNumbers.append (",");
						//<----------- Logging Ends
					}

					lPanelList.insert( iPanel, qvlMarkList );

					//-----------> Logging Starts
					if ( qsLogNumbers.at (qsLogNumbers.size ()-1) == QChar(',') ) {
						qsLogNumbers.chop (1);
					}
					LOG(QString("Selected Numbers GameCode[%1] Area[%2] Panel[%3]: %4").arg(gameConfig->readGameCode ()).arg(iArea).arg(QChar('A'+iPanel)).arg (qsLogNumbers));
					qsLogNumbers.clear ();
					//<----------- Logging Ends


				} else {

					LOG(QString("Selected Numbers GameCode[%1] Area[%2] Panel[%3]: %4").arg(gameConfig->readGameCode ()).arg(iArea).arg(QChar('A'+iPanel)).arg (qsLogNumbers));

					lPanelList.insert( iPanel, qvlMarkList );
				}


				lAreaNumbers.append (lMarkList);
			}


			// We'll check later whether doublicate entries exist. As a result of a bug found in Ireland, where
			// the system selects QP numbers but they appear to be the same for AreaB&AreaD and AreaC&AreaE
			if ( areaUnderProcess->getQp() != Area::eNoQp ) {
				 mNumbers.insert (iArea,lAreaNumbers);
			}

			lAreaNumbers.clear ();

			mAreaValues.insert(QStringLiteral("SelectionMarksInPanels"), lPanelList );

			// Rest of Area fields are stored in a variant map
			mAreaValues.insert (QStringLiteral("IsAreaVoid")           , areaUnderProcess->isVoidArea() );
			mAreaValues.insert (QStringLiteral("IsAreaEmpty")          , areaUnderProcess->isAreaEmpty() );
			mAreaValues.insert (QStringLiteral("Gmx000Flags")          , quint8(areaUnderProcess->getQp()) );

			mAreaValues.insert (QStringLiteral("PricePerArea")         , areaUnderProcess->getAreaCost() );
			mAreaValues.insert (QStringLiteral("DefaultMarks")         , areaUnderProcess->getBetTypeValue ()?areaUnderProcess->getBetTypeValue():mMaxSelectedMarksInPanels.value (0).value ("Default"));
			mAreaValues.insert (QStringLiteral("SystemBet")            , areaUnderProcess->getSystemBet () );
			mAreaValues.insert (QStringLiteral("Multiplier")           , areaUnderProcess->getMultiplierValue() );
			mAreaValues.insert (QStringLiteral("AdditionalGamePerArea"), areaUnderProcess->getAdditionalGamePerArea () );
			mAreaValues.insert (QStringLiteral("PickXPlayType")        , quint32(areaUnderProcess->getPickXPlayType ()) );
			mAreaValues.insert (QStringLiteral("AreaColumns")          , areaUnderProcess->getAreaColumns () );
			mAreaValues.insert (QStringLiteral("CustomData")           , areaUnderProcess->getCustomData () );

			// done. append map to our lAreaList (tmp list)
			lAreaList << mAreaValues;

		}


		// Now use the tmp list we have just created to initialize json object list. Hope the whole thing makes sence.
		cGameTxData.setAreaList( lAreaList );
		qbaPlayDataToTx = QJson::JsonOperations::qObjectToJson( &cGameTxData );


		// Check whether doublicate entries exist. As a result of a bug found in Ireland, where
		// the system selects QP numbers but they appear to be the same for AreaB&AreaD and AreaC&AreaE
		QList<int> lOrig;
		QList<int> lTmp;
		qsLogNumbers.clear ();
		for ( int iArea = 0; iArea < iNumberOfAreas; ++iArea ) {

			lOrig = mNumbers.value (iArea);

			for ( int j=iArea+1; j<iNumberOfAreas; ++j ) {

				lTmp = mNumbers.value (j);

				if ( lTmp==lOrig && !lOrig.isEmpty () && !lTmp.isEmpty () ) {

					for ( int iMark = 0; iMark < lTmp.size(); ++iMark ) {
						qsLogNumbers.append (QString::number (lTmp.at(iMark)+1).rightJustified (2,'0',false));
						qsLogNumbers.append (",");
					}

					if ( qsLogNumbers.at (qsLogNumbers.size ()-1) == QChar(',') ) {
						qsLogNumbers.chop (1);
					}

					LOG(QString("Dublicate numbers GameCode[%1] Area[%2] : %3").arg(gameConfig->readGameCode ()).arg(iArea).arg (qsLogNumbers));

					// Clear returned data. The caller will display an error to user.
					qsLogNumbers.clear ();
					qbaPlayDataToTx.clear ();
				}
			}
		}
	}

	return qbaPlayDataToTx;

}



/**
 * @sa pickXSelectionsBasedOnType
 * @param area interested in
 * @param pickX playType
 * @return a list of pickX selections based on playType
 * @brief returns a list of digits based on the given play type.
 */
QList<int> CouponUtilities::pickXSelectionsBasedOnType( GamesConfig*const gameConfig, const Coupon& couponData, const int &iArea, const ImtsGamesEnums::PickXPlayTypeFlags& flag )
{
	QList<int> lBetLine;
	lBetLine.clear ();
	if ( gameConfig && !couponData.isCouponEmpty () ) {

		if ( IS_PICK(gameConfig->readGameCode () ) ) {

			if ( gameConfig->readPickXGameUseCalculator () ) { // pick games that use calculator

				lBetLine = couponData.getArea (iArea)->getPickGameBetline (); // get current list of digit numbers and manipulate based on play type

				// Based on pick game trim the list.
				for ( int i = gameConfig->readNumberOfPanels (); i < lBetLine.size (); ++i ) {
					lBetLine.removeLast ();
				}

			} else { // pick games with full blown panels

				QList<int> iBetLine = QList<int>();

				for ( int iPanel = 0; iPanel < gameConfig->readNumberOfPanels (); ++iPanel ) {

					iBetLine = couponData.getArea (iArea)->getPanelXList (iPanel);
					if ( !iBetLine.isEmpty () ) {
						lBetLine<<iBetLine.first ();
					} else {
						lBetLine<<ImtsGamesEnums::InvalidDigit;
					}
				}
			}

			if ( flag &  ImtsGamesEnums::ResetAllNumbersDigit ) { // handles pick3-4-5 and basically replaces all AllNumbers(*) with InvalidDigit(?)

				for ( int i = 0; i<lBetLine.size (); ++i ) {
					if ( lBetLine.at (i) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (i,ImtsGamesEnums::InvalidDigit);
				}

			} else if ( flag & ImtsGamesEnums::FrontGameTypes ) { // handles pick3-4-5

				for ( int i = 0; i<lBetLine.size (); ++i ) {

					if ( ( i <= 1 && flag.testFlag (ImtsGamesEnums::FrontPair )) ||
						 ( i <= 2 && flag.testFlag (ImtsGamesEnums::FrontThree)) ||
						 ( i <= 3 && flag.testFlag (ImtsGamesEnums::FrontFour )) )

					{
						if ( lBetLine.at (i) == ImtsGamesEnums::AllNumbers )
							lBetLine.replace (i,ImtsGamesEnums::InvalidDigit);
						continue;
					}

					lBetLine.replace (i,ImtsGamesEnums::AllNumbers);}

			} else if ( flag & ImtsGamesEnums::BackGameTypes ) { // handles pick3-4-5

				int iSize = lBetLine.size ()-1;

				for ( int i = iSize; i>=0; --i ) {

					if ( ( i >= iSize-3 && flag.testFlag (ImtsGamesEnums::BackFour )) ||
						 ( i >= iSize-2 && flag.testFlag (ImtsGamesEnums::BackThree)) ||
						 ( i >= iSize-1 && flag.testFlag (ImtsGamesEnums::BackPair )) )

					{
						if ( lBetLine.at (i) == ImtsGamesEnums::AllNumbers )
							lBetLine.replace (i,ImtsGamesEnums::InvalidDigit);
						continue;
					}

					lBetLine.replace (i,ImtsGamesEnums::AllNumbers);

				}

			} else if ( flag.testFlag (ImtsGamesEnums::MiddlePair) ) { // handle pick4 only

				if ( lBetLine.size () == 4 ) {

					lBetLine.replace (0, ImtsGamesEnums::AllNumbers);

					if ( lBetLine.at (1) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (1,ImtsGamesEnums::InvalidDigit);

					if ( lBetLine.at (2) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (2,ImtsGamesEnums::InvalidDigit);

					lBetLine.replace (3, ImtsGamesEnums::AllNumbers);

				}

			} else if ( flag.testFlag (ImtsGamesEnums::SplitPair) ) { // handle pick3 only Note: Split Pair for pick3 is same as SecondDigit type.

				if ( lBetLine.size () == 3 ) {

					if ( lBetLine.at (0) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (0,ImtsGamesEnums::InvalidDigit);

					lBetLine.replace (1, ImtsGamesEnums::AllNumbers);

					if ( lBetLine.at (2) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (2,ImtsGamesEnums::InvalidDigit);
				}

			} else if ( flag & ImtsGamesEnums::DigitsGameTypes ) { // handle 1st/2nd/3rd etc... digits for pick3-4-5

				for ( int i = 0; i<lBetLine.size (); ++i ) {

					if ( ( i==0 && flag.testFlag (ImtsGamesEnums::FirstDigit) ) ||
						 ( i==1 && flag.testFlag (ImtsGamesEnums::SecondDigit)) ||
						 ( i==2 && flag.testFlag (ImtsGamesEnums::ThirdDigit))  ||
						 ( i==3 && flag.testFlag (ImtsGamesEnums::FourthDigit)) ||
						 ( i==4 && flag.testFlag (ImtsGamesEnums::FifthDigit)) )

					{
						lBetLine.replace (i,ImtsGamesEnums::AllNumbers);
						continue;
					}

					if ( lBetLine.at (i) == ImtsGamesEnums::AllNumbers )
						lBetLine.replace (i,ImtsGamesEnums::InvalidDigit);
				}

			}
		}
	}
	return lBetLine;
}

/**
 * @sa pickXFormatBetline
 * @param lBetline (Vector, QList)
 * @return the betline formated
 * @brief take a bet line and formats it as string "x, x, x"
 * Great canditate for a template function.
 */
template <class T>
QString CouponUtilities::pickXFormatBetline (const T& betline)
{
	QString qsBetline = QString ();
	int iLen = betline.size ();

	for ( int i = 0; i < iLen; ++ i ) {
		qsBetline.append (QString::number (betline.at (i)));
		if ( i < iLen-1 ) {
			qsBetline.append (", ");
		}
	}

	//	qDebug () << qsBetline;

	return qsBetline;
}

#if !defined(C_PLUS_PLUS)
/**
 * @brief CouponUtilities::reverseList
 * @param lBetLine
 */
void CouponUtilities::reverseList( QList<int>& lBetLine)
{
	unsigned int i, j;
	int len = lBetLine.size ();

	for (i = 0, j = len - 1; i < j; i++, j--) {
		lBetLine.swap(i, j);
	}
}

/**
 * @brief CouponUtilities::reverseList
 * @param lBetLine
 * @param iStartAt
 */
void CouponUtilities::reverseList( QList<int>& lBetLine, int iStartAt)
{
	unsigned int i = 0;
	unsigned int j = 0;
	int len = lBetLine.size ();

	for (i = iStartAt, j = len - 1; i < j; i++, j--) {
		lBetLine.swap(i, j);
	}
}
/**
 * @brief CouponUtilities::permutations
 * @param lBetLine
 * @return
 *
 * Algorithm
 * 1. Find the highest index, i1 such that lBetLine[i1] is the first of a pair of elements in ascending order.
 *    If there isn't one, the sequence is the highest permutation, so reverse the whole thing to begin again.
 * 2. Find the highest index i2, such that i2 > i1 and lBetLine[i2] > lBetLine[i1].
 * 3. Swap lBetLine[i1] and lBetLine[i2].
 * 4. The elements from lBetLine[i1 + 1] to the end are now in descending order (a later permutation), so reverse them.
 */
unsigned int CouponUtilities::permutations(QList<int>& lBetLine)
{
	unsigned int i1 = 0;
	unsigned int i2 = 0;
	unsigned int result = 0;
	int len = lBetLine.size ();

	// Find the rightmost element that is the first in a pair in ascending order
	for (i1 = len - 2, i2 = len - 1; lBetLine.at(i2) <= lBetLine.at(i1) && i1 != 0; i1--, i2--);

	if (lBetLine.at(i2) <= lBetLine.at(i1)) {

		// If not found, array is highest permutation
		reverseList(lBetLine);

	} else {

		// Find the rightmost element to the right of i1 that is greater than lBetLine.at(i1)
		for (i2 = len - 1; i2 > i1 && lBetLine.at(i2) <= lBetLine.at(i1); i2--);

		// Swap it with the first one
		lBetLine.swap(i1, i2);

		// Reverse the remainder
		reverseList(lBetLine, i1 + 1);

		result = 1;
	}

	return result;
}

#endif



/**
 * @sa pickXGetNumbersSet
 * @param area interested in
 * @return the number of permutations
 * @brief calculates the permutations for the passed int area
 */
int CouponUtilities::pickXGetNumbersSet( GamesConfig*const gameConfig, const Coupon& couponData, const int &iArea )
{
	int iNumberOfPermutations = 0;

	if ( gameConfig && !couponData.isCouponEmpty () ) {

		if ( IS_PICK(gameConfig->readGameCode () ) ) {

			QList<int> lBetLine = couponData.getArea (iArea)->getPickGameBetline (); // get current list of digit numbers and manipulate based on play type

				// Based on pick game trim the list.
				for ( int i = gameConfig->readNumberOfPanels (); i < lBetLine.size (); ++i ) {
					lBetLine.removeLast ();
				}

				if ( !lBetLine.contains (ImtsGamesEnums::InvalidDigit) /*&& !lBetLine.contains (ImtsGamesEnums::AllNumbers)*/ ) { // only do permutations for

					qSort(lBetLine);

					// NOTE: Both methods below are really fast. I decided to use the std:: one. If for some reason your compiler does not support
					// std::next_permutation, undef C_PLUS_PLUS above and you will be able to get the same outcome with minor possible performance
					// penalty if not at all.
#if defined(C_PLUS_PLUS)

					QVector<int> vBetline = QVector<int>::fromList (lBetLine);
					do {
						++iNumberOfPermutations;
					} while ( std::next_permutation (vBetline.data (), vBetline.data ()+vBetline.size ()));

#else
					do {
						++iNumberOfPermutations;
					} while (permutations(lBetLine));
#endif
			}
		}
	}
	return iNumberOfPermutations;
}


/**
 * @sa pickXGetNumbersSet
 * @param area interested in
 * @param optionally fill a string list with the generated permutations
 * @return the number of permutations
 * @brief calculates the permutations for the passed int area
 * @note: if you want the numbers for example {1,2,3} arraged as follows use std::next_permutation ( default )
 *        	1, 2, 3
 *			1, 3, 2
 *			2, 1, 3
 *			2, 3, 1
 *			3, 1, 2
 *			3, 2, 1
 * whereas you can get the following sequence if you use std::prev_permutation
 *			3, 2, 1
 *			3, 1, 2
 *			2, 3, 1
 *			2, 1, 3
 *			1, 3, 2
 *			1, 2, 3
 */
int CouponUtilities::pickXGetNumbersSet(GamesConfig *const gameConfig, const Coupon &couponData, const int &iArea, QStringList& qslNumbersSet, const bool bReverse = false )
{

	if ( gameConfig && !couponData.isCouponEmpty () ) {

		if ( IS_PICK(gameConfig->readGameCode () ) ) {

				QList<int> lBetLine = couponData.getArea (iArea)->getPickGameBetline (); // get current list of digit numbers and manipulate based on play type

				// Based on pick game trim the list.
				for ( int i = gameConfig->readNumberOfPanels (); i < lBetLine.size (); ++i ) {
					lBetLine.removeLast ();
				}

				if ( !lBetLine.contains (ImtsGamesEnums::InvalidDigit) /*&& !lBetLine.contains (ImtsGamesEnums::AllNumbers)*/ ) { // only do permutations for

					qSort(lBetLine);

#if defined(C_PLUS_PLUS)
					QVector<int> vBetline = QVector<int>::fromList (lBetLine);
					if ( bReverse ) {

						do {
							qslNumbersSet.append (CouponUtilities::pickXFormatBetline (vBetline));
						} while ( std::prev_permutation (vBetline.data (), vBetline.data ()+vBetline.size ()));

					} else { // default

						do {
							qslNumbersSet.append (CouponUtilities::pickXFormatBetline (vBetline));
						} while ( std::next_permutation (vBetline.data (), vBetline.data ()+vBetline.size ()));
					}
#else
					do {
						qslNumbersSet.append (CouponUtilities::pickXFormatBetline (lBetLine));
					} while (permutations(lBetLine));

#endif
				}
			}
		}
	return qslNumbersSet.size ();
}

/**
 * @sa getCouponErrors
 * @param gameConfig
 * @param couponData
 * @return CouponError object where it contains coupon errors. If emtpy the passed in coupon data are OK.
 * @brief check coupons for erros and returns a coupon error object. Caller can use it
 * to retrieve the possible coupon errors.
 */
CouponError CouponUtilities::getCouponErrors ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	CouponError couponError;

	if ( gameConfig && !couponData.isCouponEmpty() ) {


		if ( IS_PICK(gameConfig->readGameCode ())) { // Pick Games

			if ( gameConfig->readPickXGameUseCalculator () ) {

				couponError = CouponUtilities::checkPickGameCouponWithCalcSupport ( gameConfig, couponData );

			} else {

				couponError = CouponUtilities::checkPickGameCoupon ( gameConfig, couponData );

			}

		} else if ( !gameConfig->readBetTypeCfgMap ().value (QStringLiteral("BetTypeSelectionsList")).toList ().isEmpty () ) { // Keno

			couponError =  CouponUtilities::checkBetTypeCoupon ( gameConfig, couponData );

		} else { // Lotto Games

			couponError = CouponUtilities::checkLottoCoupon ( gameConfig, couponData );

		}
	}

	cLastCouponErrors = couponError;
	return couponError;

}

/**
 * @sa getLastCouponErrors
 * @return coupon errors since the last time we checked.
 */
CouponError CouponUtilities::getLastCouponErrors ()
{
	return cLastCouponErrors;
}

/**
 * @sa setLastCouponErrors
 * @return set coupon errors
 */
void CouponUtilities::setLastCouponErrors (CouponError couponError)
{
	cLastCouponErrors=couponError;
}


/**
 * @sa checkBetTypeCoupon
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkBetTypeCoupon ( GamesConfig*const gameConfig, const Coupon& couponData )
{
	// Create local scope variables that they will be used inside the following for loop.
	Area* areaUnderProcess = 0;
	int iArea = 0;
	int iCountMarksPanelA = 0;
	bool bHasAnAreaMarked = false;
	CouponError couponError;
	couponError.clearCouponErrors();

	bool bBetTypePerArea = gameConfig->readBetTypeCfgMap ().value (QStringLiteral("BetTypePerArea")).toBool (); // check if betType reflects whole coupon or per area.
	int iBetType = bBetTypePerArea?0:couponData.getBetTypeValue ();


	if ( !bBetTypePerArea && couponData.getBetTypeList ().size () > 1 ) {

		couponError.setCouponError(100, CouponErrorDefinitions::TOO_MANY_BETTYPES_SELECTED); // It's a coupon error not an area error so break

	} else {

		QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels;
		mMaxSelectedMarksInPanels.clear ();

		for ( iArea = 0; iArea < gameConfig->readNumberOfAreas(); ++iArea ) {

			areaUnderProcess = couponData.getArea ( iArea );
			iCountMarksPanelA = areaUnderProcess->getPanelXList(0).count ();
			mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, iArea );
			iBetType = bBetTypePerArea?areaUnderProcess->getBetTypeValue ():iBetType; // if betType per panel then get new value else use the one set before entering the for loop

			if ( areaUnderProcess->isVoidArea () || areaUnderProcess->isAreaEmpty () )
				continue;

			if ( bBetTypePerArea && areaUnderProcess->getBetTypeList ().size () > 1 ) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_BETTYPES_SELECTED);
				areaUnderProcess->setBetTypeSingle(ImtsGamesEnums::InvalidBetType);
				bHasAnAreaMarked = true;
				continue;
			}

			if ( iBetType == 0 && iCountMarksPanelA >= 0) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::NO_BETTYPE_SELECTED);
				bHasAnAreaMarked = true;
				continue;
			}

			if ( !bHasAnAreaMarked && !areaUnderProcess->isAreaEmpty() )
				bHasAnAreaMarked = true;

			if ( iBetType == 0 && (int)areaUnderProcess->getQp () > 0  ) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::QP_REQUIRES_BETTYPE);
				continue;
			}
			if ( areaUnderProcess->getQp () == Area::eInvalidQP) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::QP_WITH_MARKS);
				areaUnderProcess->setQp(Area::eNoQp);
				continue;
			}

			if ( couponData.getArea (iArea)->getMultiplierValue () > 1  &&  iCountMarksPanelA == 0 ) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::MULTIPLIER_SELECTED_ON_AN_EMPTY_AREA);
			}

			if ( couponData.getArea (iArea)->getMultiplierValue () == ImtsGamesEnums::TooManyMultipliers ) {
				couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MULTIPLIERS_SELECTED);
			}

			// Bettype and number of marks in Panel A must be equal, for those games that don't have fullSystemBet support
			if ( !(mMaxSelectedMarksInPanels.value (0).value ("GameType") & ImtsGamesEnums::SystemSupport) ) { // Typical Keno game and LottoGames with bettypes where the bettype dictates the maximum allowed mark selections

				if ( iBetType > iCountMarksPanelA ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS);
					continue;
				}

				if ( iBetType < iCountMarksPanelA ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS);
					continue;
				}

			} else { // refering to Taiwan's mark games and Keno Game with system support. You can have maxMark selection independent of bettype/playtype

				int iMaxSelectionMarks = mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Max"));  // these games have only one panel.
				int iMinSelectionMarks = mMaxSelectedMarksInPanels.value (0).value (QStringLiteral("Min"));; // these games have only one panel.

				if ( iBetType == 0 || iMinSelectionMarks > iCountMarksPanelA ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS);
					continue;
				}

				if ( iMaxSelectionMarks < iCountMarksPanelA ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS);
					continue;
				}
			}

			if ( !gameConfig->readAdditionalGamePerArea ().isEmpty () ) {

				checkAdditionalGamePerArea ( iArea, gameConfig, couponData, bHasAnAreaMarked, couponError );
			}
		}
	}

	if ( !bBetTypePerArea && iBetType > 0 && !bHasAnAreaMarked ) {
		couponError.setCouponError(100, CouponErrorDefinitions::BETTYPE_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !bBetTypePerArea && !bHasAnAreaMarked ) {
		couponError.setCouponError(100, CouponErrorDefinitions::COUPON_IS_EMPTY); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getMultiDrawValue () > 1 && !bHasAnAreaMarked ) {
		couponError.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
		couponError.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getFutureDrawValue () > 0 && !bHasAnAreaMarked) {
		couponError.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !gameConfig->readAdditionalGame ().isEmpty () ) {
		checkAdditionalGame ( gameConfig, couponData, bHasAnAreaMarked, couponError );
	}

	customCheckBetTypeCoupon ( gameConfig, couponData, bHasAnAreaMarked, couponError );

	return couponError;

}


/**
 * @sa checkLottoCouponNoSystem
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkLottoCouponNoSystem ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	// Create local scope variables that they will be used inside the following for loop.
	Area* areaUnderProcess = 0;
	int iArea = 0;
	int iPanel = 0;
	int iCountMarksPanelX = 0;
	int iTotalMarksInPanels = 0;
	bool bHasAnAreaMarked = false;

	CouponError couponError;
	couponError.clearCouponErrors();


	QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, 0 ); // passing 0 will set the default value to currently selected bet type. However not used, so please don't call it inside the for loop.


	for ( iArea = 0; iArea < gameConfig->readNumberOfAreas(); ++iArea ) {

		areaUnderProcess = couponData.getArea( iArea );

		if ( areaUnderProcess->isVoidArea() || areaUnderProcess->isAreaEmpty() )
			continue;

		if ( bHasAnAreaMarked == false && !areaUnderProcess->isAreaEmpty() )
			bHasAnAreaMarked = true;

		for ( iPanel = 0; iPanel <  gameConfig->readNumberOfPanels (); ++iPanel ) {

			iCountMarksPanelX = areaUnderProcess->getPanelXList(iPanel).count();
			iTotalMarksInPanels += iCountMarksPanelX;


			if ( iCountMarksPanelX < mMaxSelectedMarksInPanels.value (iPanel).value (QStringLiteral("Min")) ) {
				switch (iPanel) {
					case 1:
						couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS_IN_PANEL_B);
					break;
					default:  // covers panel0 and cases where more than 2 panels exist
						if ( gameConfig->readNumberOfPanels ()  > 1 )
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS_IN_PANEL_A);
						else
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS);
					break;
				}
				continue;
			}

			if ( iCountMarksPanelX > mMaxSelectedMarksInPanels.value (iPanel).value (QStringLiteral("Max")) ) {
				switch (iPanel) {
					case 1:
						couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS_IN_PANEL_B);
					break;
					default: // covers panel0 and cases where more than 2 panels exist
						if ( gameConfig->readNumberOfPanels ()  > 1 )
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS_IN_PANEL_A);
						else
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS);
					break;
				}
				continue;
			}
		}
		if ( areaUnderProcess->getQp () == Area::eInvalidQP) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::QP_WITH_MARKS);
			areaUnderProcess->setQp(Area::eNoQp);
			continue;
		}

		if (areaUnderProcess->getMultiplierValue () > 1  &&  iTotalMarksInPanels == 0 ) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::MULTIPLIER_SELECTED_ON_AN_EMPTY_AREA);
		}

		if ( couponData.getArea (iArea)->getMultiplierValue () == ImtsGamesEnums::TooManyMultipliers ) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MULTIPLIERS_SELECTED);
		}

		if ( !gameConfig->readAdditionalGamePerArea ().isEmpty () ) {
			checkAdditionalGamePerArea ( iArea, gameConfig, couponData, bHasAnAreaMarked, couponError );
		}
	}

	if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
		couponError.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.

	}
	if ( couponData.getMultiDrawValue () > 1 && !bHasAnAreaMarked ) {
		couponError.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getFutureDrawValue () > 0 &&  !bHasAnAreaMarked ) {
		couponError.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !gameConfig->readAdditionalGame ().isEmpty () ) {
		checkAdditionalGame ( gameConfig, couponData, bHasAnAreaMarked, couponError );
	}

	customCheckLottoCouponNoSystem ( gameConfig, couponData, bHasAnAreaMarked, couponError );

	return couponError;
}

/**
 * @sa checkLottoCouponFullSystemOnly
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkLottoCouponFullSystemOnly ( GamesConfig*const gameConfig, const Coupon& couponData )
{
	// Create local scope variables that they will be used inside the following for loop.
	Area* areaUnderProcess = 0;
	int iArea = 0;
	int iCountMarksPanelX = 0;
	int iTotalMarksInPanels = 0;
	int iMinSelectionMarksForFullSystem = 0;
	int iMaxSelectionMarksForFullSystem = 0;
	bool bHasAnAreaMarked = false;

	CouponError couponError;
	couponError.clearCouponErrors();

	QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, 0 ); // passing 0 will set the default value to currently selected bet type. However not used, so please don't call it inside the for loop.

	for ( iArea = 0; iArea < gameConfig->readNumberOfAreas(); ++iArea ) {

		areaUnderProcess = couponData.getArea( iArea );

		if ( areaUnderProcess->isVoidArea() || areaUnderProcess->isAreaEmpty() )
			continue;

		if ( bHasAnAreaMarked == false && !areaUnderProcess->isAreaEmpty() )
			bHasAnAreaMarked = true;

		for ( int iPanel = 0; iPanel < gameConfig->readNumberOfPanels(); ++iPanel ) {

			iCountMarksPanelX = areaUnderProcess->getPanelXList(iPanel).count();
			iTotalMarksInPanels += iCountMarksPanelX;

			iMinSelectionMarksForFullSystem = mMaxSelectedMarksInPanels.value (iPanel).value (QStringLiteral("Min"));
			iMaxSelectionMarksForFullSystem = mMaxSelectedMarksInPanels.value (iPanel).value (QStringLiteral("Max"));

			if ( iCountMarksPanelX < iMinSelectionMarksForFullSystem ) {
				switch (iPanel) {
					case 1:
						couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS_IN_PANEL_B);
					break;
					default: // covers panel0 and cases where more than 2 panels exist
						if ( couponData.getNumberOfPanels()  > 1 )
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS_IN_PANEL_A);
						else
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS);
					break;
				}
				continue;
			}

			if ( iCountMarksPanelX > iMaxSelectionMarksForFullSystem ) {
				switch (iPanel) {
					case 1:
						couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS_IN_PANEL_B);
					break;
					default: // covers panel0 and cases where more than 2 panels exist
						if ( couponData.getNumberOfPanels()  > 1 )
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS_IN_PANEL_A);
						else
							couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS);
					break;
				}
				continue;
			}
		}

		if ( areaUnderProcess->getQp () == Area::eInvalidQP) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::QP_WITH_MARKS);
			areaUnderProcess->setQp(Area::eNoQp);
			continue;
		}

		if ( areaUnderProcess->getMultiplierValue () > 1  &&  iTotalMarksInPanels == 0 ) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::MULTIPLIER_SELECTED_ON_AN_EMPTY_AREA);
		}

		if ( couponData.getArea (iArea)->getMultiplierValue () == ImtsGamesEnums::TooManyMultipliers ) {
			couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MULTIPLIERS_SELECTED);
		}

		if ( !gameConfig->readAdditionalGamePerArea ().isEmpty () ) {
			checkAdditionalGamePerArea ( iArea, gameConfig, couponData, bHasAnAreaMarked, couponError );
		}
	}

	if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
		couponError.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getMultiDrawValue () > 1 && !bHasAnAreaMarked  ) {
		couponError.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getFutureDrawValue () > 0 &&  !bHasAnAreaMarked) {
		couponError.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !gameConfig->readAdditionalGame ().isEmpty () ) {
		checkAdditionalGame ( gameConfig, couponData, bHasAnAreaMarked, couponError );
	}
	customCheckLottoCouponFullSystemOnly  ( gameConfig, couponData, bHasAnAreaMarked, couponError );

	return couponError;
}

/**
 * @sa checkLottoForAreaCombinationalSystem
 * @param gameConfig
 * @param couponData
 * @return whether there is an area combinational system in place.
 * @return coupon error object
 */
CouponError CouponUtilities::checkLottoForAreaCombinationalSystem ( GamesConfig*const gameConfig, const Coupon& couponData, bool& bIsThereAnAreaComboSystemBet  )
{

	int iArea = 0;
	int iSystemBet = 0;
	int iAreaComboSysBet = 0;
	QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, 0 );
	int iMaxMarkSelectionsForANormalBet =  mMaxSelectedMarksInPanels.value (0).value ("Max"); // (Panel A we only need, hence .at(0) )
	int iAreaCombinational = gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value ("SystemCfgMap").toMap ().value ("SystemBetSupportAreaCombinational").toInt();
	Area* areaUnderProcess = 0;
	bool bCheckForEmptyArea = false;
	bIsThereAnAreaComboSystemBet = false;

	CouponError couponError;
	couponError.clearCouponErrors ();

	// We quicky need to identify if the coupon contains a combinational system. If it does. we continue parsing it otherwise we
	// return to continue with the rest of the checks.

	for ( iArea = 0; iArea < iAreaCombinational; ++iArea ) { // Opap's joker has 5, opap's lotto has 3

		areaUnderProcess = couponData.getArea( iArea );

		if ( bCheckForEmptyArea == false ) {

			iSystemBet = areaUnderProcess->getSystemBet ();

			if ( iSystemBet > 0 && iSystemBet < iMaxMarkSelectionsForANormalBet ) { // system bet selection must be between 1 and 4 for joker and 5 for lotto.
				iAreaComboSysBet += iSystemBet;

			} else if ( iSystemBet == 0 && iArea == 0 ) { // Area 0 must always have a system bet selection

				return couponError;
			}

			if ( iAreaComboSysBet == iMaxMarkSelectionsForANormalBet ) { // 1st condition for combo system bet is met. We now got to make sure that the remaining areas are empty.

				bCheckForEmptyArea = true;
			}

		} else {

			if ( areaUnderProcess->isAreaEmpty() == false )
				return couponError;
		}
	}

	if ( iAreaComboSysBet != iMaxMarkSelectionsForANormalBet ) { // another type of system is in place or not at all. So we won't bother continueing.

		return couponError;
	}


	if ( iAreaComboSysBet == iMaxMarkSelectionsForANormalBet ) { // This is a valid combinational system bet, and we ought to find out if everything else is ok.

		int iNumber = 0;
		int iDuplicateNumber = 0;
		int iCountNumbersInPanelB = 0;
		QList<int> lAllNumbers;
		lAllNumbers.clear();

		bIsThereAnAreaComboSystemBet = true;

		for ( iArea = 0; iArea < iAreaCombinational; ++iArea ) {
			areaUnderProcess = couponData.getArea( iArea );

			lAllNumbers << areaUnderProcess->getPanelXList(0); // Create a list of all numbers in areas (Panel 0). It will come handy l8r.

			if ( gameConfig->readNumberOfPanels() > 1 ) { // deal with panelB if one exists

				if ( iArea == 0 ) {

					iCountNumbersInPanelB = areaUnderProcess->getPanelXList(1).count(); // count the marks for area 0, in panelB. We'll use l8r

				} else { // It is an invalid system if panelB other than that of area 0 contain numbers.

					if ( areaUnderProcess->getPanelXList(1).count() > 0 ) {
						couponError.setCouponError(100, CouponErrorDefinitions::INVALID_COUPON);
						return couponError;
					}
				}
			}
		}

		if ( iAreaComboSysBet != iMaxMarkSelectionsForANormalBet ) { // The addition of individual systembet selections on areas must equal the total number of a normal play, that is 6 for lotto, 5 for joker.
			// That is the user can select e.g Joker, AreaA sysbet 2, AreaB sysbet 1, AreaC sysbet 2. 2+1+2 must equal to 5.

			couponError.setCouponError(100, CouponErrorDefinitions::INVALID_COUPON);
			return couponError;

		} else if ( lAllNumbers.count() <= iAreaComboSysBet  ) { // The total number of marks in all areas should be one more than the sum of systemBets or iMaxMarkSelectionsForANormalBet

			couponError.setCouponError(100, CouponErrorDefinitions::INVALID_COUPON);
			return couponError;

		} else if ( gameConfig->readNumberOfPanels() > 1  &&  iCountNumbersInPanelB < 1 ) { // such systems require to record joker(s)/bonusball(s) in panelB in area0 only.

			couponError.setCouponError(100, CouponErrorDefinitions::INVALID_COUPON);
			return couponError;
		}

		for ( iNumber = 0; iNumber < lAllNumbers.count(); ++iNumber ) { // Need to check for duplicate numbers. lAllNumbers list we have created comes handy.

			iDuplicateNumber = lAllNumbers.count(iNumber);

			if ( iDuplicateNumber > 1 ) {
				couponError.setCouponError( 100, CouponErrorDefinitions::DUPLICATE ); // There exists at least one duplicate number. The rest we'll find out when we display them on the message box.
				return couponError;
			}
		}
	}

	return couponError;

}

/**
 * @sa checkLottoCouponAllSystems
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkLottoCouponAllSystems ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	// Create local scope variables that they will be used inside the following for loop.
	Area* areaUnderProcess = 0;
	int iArea = 0;
	int iCountMarksPanelA = 0;
	bool bHasAnAreaMarked = false;
	bool bIsThereAnAreaComboSystemBet = false;

	CouponError couponError;
	couponError.clearCouponErrors();

	couponError = checkLottoForAreaCombinationalSystem( gameConfig, couponData, bIsThereAnAreaComboSystemBet ); // Before anything check for AreaCombinational system

	if ( !bIsThereAnAreaComboSystemBet ) {

		for ( iArea = 0; iArea < gameConfig->readNumberOfAreas (); ++iArea ) {

			areaUnderProcess = couponData.getArea( iArea );

			if ( areaUnderProcess->isVoidArea() || areaUnderProcess->isAreaEmpty() )
				continue;

			if ( bHasAnAreaMarked == false && !areaUnderProcess->isAreaEmpty() )
				bHasAnAreaMarked = true;

			if ( !areaUnderProcess->getSystemBet () ) { // No system bet selection is made

				CouponUtilities::checkLottoCouponFullSystemOnly ( gameConfig, couponData );

			} else { // System bet selection is made.

				int iSystemBet = areaUnderProcess->getSystemBet ();

				// First check that a valid system has been selected
				if ( !gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value ("FixedSystemCfgMap").toMap ().value ("SystemTypeList").toList ().contains(iSystemBet) ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::INVALID_SYSTEM_BET);
					continue;
				}

				iCountMarksPanelA = areaUnderProcess->getPanelXList(0).count();

				// We need to find out what system has the user selected, and get the number of required marks from config.
				// Do not get intimidated by the following statement, it is a map with a nested map wich the later has as values, lists of size 2.
				int iMarksInSystemBet = gameConfig->readMarksCfgMap ().value ("SystemCfgMap").toMap ().value ("FixedSystemCfgMap").toMap ().value ("SystemTypeMap").toMap().value(QString::fromLatin1("%1").arg(iSystemBet)).toList().at(0).toInt();
				if ( iCountMarksPanelA < iMarksInSystemBet ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_FEW_MARKS);
					continue;
				}

				if ( iCountMarksPanelA > iMarksInSystemBet ) {
					couponError.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MARKS);
					continue;
				}
			}
		}

		if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
			couponError.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.
		}

		if ( couponData.getMultiDrawValue () > 1 && bHasAnAreaMarked == false ) {
			couponError.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
		}

		if ( couponData.getFutureDrawValue () > 0 &&  bHasAnAreaMarked == false ) {
			couponError.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
		}
	}

	customCheckLottoCouponAllSystems  ( gameConfig, couponData, bHasAnAreaMarked, couponError );

	return couponError;
}


/**
 * @sa checkLottoCoupon
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkLottoCoupon ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	// We will brake checkCoupon into the following categories: ( drawback: dublicated code, cons: simplicity )

	/*
	   SystemBetSupport      FullSystemBetSupport      FixedSystemBetSupport     AreaCombinationalSystemBetSupport
	 1.       false                   false                     false                          false
	 2.       true                    true                      false                          false
	 3.       true                    true                      true                           true

	 1. games with no system support, US games, AFAIK
	 2. games with full system bet support only, taiwan's games, AFAIK
	 3. games with all available systembet support, opap's games lotto/joker, AFAIK
	*/

	CouponError couponError;
	couponError.clearCouponErrors ();

	if ( gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().value (QStringLiteral("FixedSystemCfgMap")).toMap ().isEmpty() &&
		 gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().isEmpty()) {

		couponError = CouponUtilities::checkLottoCouponNoSystem ( gameConfig, couponData );

	} else if ( !gameConfig->readMarksCfgMap ().value (QStringLiteral("SystemCfgMap")).toMap ().isEmpty() ) {

		couponError = CouponUtilities::checkLottoCouponFullSystemOnly ( gameConfig, couponData );

	} else {

		couponError = CouponUtilities::checkLottoCouponAllSystems ( gameConfig, couponData );
	}
	return couponError;
}



/**
 * @brief checkPickGameCoupon
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 */
CouponError CouponUtilities::checkPickGameCoupon ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	Area* areaUnderProcess = 0;
	int iArea = 0;
	quint8 iPanel = 0;
	bool bXruple = false;
	bool bHasAnAreaMarked = false;
	QList<int> lBetline = QList<int>();
	quint8 iNumberOfPanels = gameConfig->readNumberOfPanels ();

	QMap<int, QMap<QString,int> > mMaxSelectedMarksInPanels = getMinMaxMarksInPanels ( gameConfig, couponData, 0 ); // passing 0 will set the default value to currently selected bet type. However not used, so please don't call it inside the for loop.

	CouponError couponErrors;
	couponErrors.clearCouponErrors ();

	for ( ; iArea < gameConfig->readNumberOfAreas (); ++iArea ) {

		areaUnderProcess = couponData.getArea ( iArea );

		if ( areaUnderProcess->isVoidArea () || areaUnderProcess->isAreaEmpty () )
			continue;

		if ( !bHasAnAreaMarked && !areaUnderProcess->isAreaEmpty() ) {
			bHasAnAreaMarked = true;
		}

		for ( iPanel = 0; iPanel < iNumberOfPanels; ++ iPanel ) {
			if ( areaUnderProcess->panelXEmpty ( iPanel ) ) {
				couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_FEW_MARKS);
				break;
			}
		}

		lBetline = areaUnderProcess->getPickGameBetline ();
		if ( lBetline.size () > mMaxSelectedMarksInPanels.value (0).value ("Max")*iNumberOfPanels) {
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_MANY_MARKS);
		}

		if ( !lBetline.isEmpty () ) {

			bXruple = false;

			for ( quint8 iMark = 0; iMark < lBetline.count (); ++iMark ) {

				if ( lBetline.count (lBetline.at (iMark)) == iNumberOfPanels ) {
					bXruple = true;
					break; // if betline's digits is contained as many times as numberOfPanels we got a ruple betline, i.e., "1,1,1,1" or "0,0,0" etc
				}
			}

			if ( ( areaUnderProcess->getPickXPlayType () &  ( ImtsGamesEnums::Box | ImtsGamesEnums::Combo ) ) && bXruple ) { // do not allow a ruple number in case BOX or COMBO is selected.
				couponErrors.setCouponError (iArea, CouponErrorDefinitions::INVALID_NUMBERS_FOR_PLAYTYPE );
			}
		}

		if (areaUnderProcess->getPickGameBetline ().contains (ImtsGamesEnums::TooManyDigits) ) {
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_MANY_MARKS);
		}

		if ( areaUnderProcess->getPickXPlayType ().testFlag (ImtsGamesEnums::NoPlayType) ) {
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::NO_PLAYTYPE_SELECTED);
		}

		if ( areaUnderProcess->getPickXPlayType ().testFlag (ImtsGamesEnums::ScannedPlayType ) ) {
			bHasAnAreaMarked = true;
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_MANY_PLAYTYPES_SELECTED);
		}

		if ( areaUnderProcess->getMultiplierValue () > 1 && lBetline.isEmpty () && !bHasAnAreaMarked) {
			couponErrors.setCouponError(iArea, CouponErrorDefinitions::MULTIPLIER_SELECTED_ON_AN_EMPTY_AREA);
		}

		if ( areaUnderProcess->getMultiplierValue () == ImtsGamesEnums::TooManyMultipliers ) {
			couponErrors.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MULTIPLIERS_SELECTED);
		}
	}

	if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getMultiDrawValue () > 1 && !bHasAnAreaMarked ) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getFutureDrawValue () > 0 &&  !bHasAnAreaMarked ) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !gameConfig->readAdditionalGame ().isEmpty () ) {
		checkAdditionalGame ( gameConfig, couponData, bHasAnAreaMarked, couponErrors );
	}

	customCheckPickGameCoupon ( gameConfig, couponData, bHasAnAreaMarked, couponErrors );

	return couponErrors;
}



/**
 * @brief checkPickGameCouponWithCalcSupport
 * @param gameConfig
 * @param couponData
 * @return coupon error object
 * @attention ****not fully tested*****
 */
CouponError CouponUtilities::checkPickGameCouponWithCalcSupport ( GamesConfig*const gameConfig, const Coupon& couponData )
{

	Area* areaUnderProcess = 0;
	int iArea = 0;
	bool bHasAnAreaMarked = false;
	bool bXruple = false;
	QList<int> lBetline = QList<int>();
	quint8 iNumberOfPanels = gameConfig->readNumberOfPanels ();

	CouponError couponErrors;
	couponErrors.clearCouponErrors ();

	// NOTE: Remember that for pick games using a calculator we haven't defined number of panels in config.

	for ( ; iArea < gameConfig->readNumberOfAreas (); ++iArea ) {

		areaUnderProcess = couponData.getArea ( iArea );

		if ( areaUnderProcess->isVoidArea () || areaUnderProcess->isAreaEmpty () )
			continue;

		if ( bHasAnAreaMarked == false && !areaUnderProcess->isAreaEmpty() )
			bHasAnAreaMarked = true;

		lBetline = areaUnderProcess->getPickGameBetline ();

		if ( gameConfig->readPickXGameUseCalculator () ) {

			if ( areaUnderProcess->getPickGameBetline ().contains (ImtsGamesEnums::InvalidDigit) ) {
				couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_FEW_MARKS);
			}
		} else {
			if ( lBetline.size () != iNumberOfPanels ) {
				couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_FEW_MARKS);
			}
		}

		if (areaUnderProcess->getPickGameBetline ().contains (ImtsGamesEnums::TooManyDigits) ) {
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::TOO_MANY_MARKS);
		}

		if ( areaUnderProcess->getMultiplierValue () > 1 && lBetline.isEmpty () ) {
			couponErrors.setCouponError(iArea, CouponErrorDefinitions::MULTIPLIER_SELECTED_ON_AN_EMPTY_AREA);
		}

		if ( areaUnderProcess->getMultiplierValue () == ImtsGamesEnums::TooManyMultipliers ) {
			couponErrors.setCouponError(iArea, CouponErrorDefinitions::TOO_MANY_MULTIPLIERS_SELECTED);
		}

		if ( areaUnderProcess->getPickXPlayType ().testFlag (ImtsGamesEnums::NoPlayType) ) {
			couponErrors.setCouponError (iArea,CouponErrorDefinitions::INVALID_PLAYTYPE_SELECTED);
		}


		bXruple = false;

		if ( !lBetline.isEmpty () ) {
			// Based on pick game trim the list.
			for ( int i = iNumberOfPanels; i < lBetline.size (); ++i ) {
				lBetline.removeLast ();
			}

			if ( !lBetline.contains (ImtsGamesEnums::InvalidDigit) && !lBetline.contains (ImtsGamesEnums::AllNumbers) ) {

				for ( quint8 iMark = 0; iMark < lBetline.count (); ++iMark ) {

					if ( lBetline.count (lBetline.at (iMark)) == iNumberOfPanels ) {
						bXruple = true;
						break; // if betline's digits is contained as many times as numberOfPanels we got a ruple betline, i.e., "1,1,1,1" or "0,0,0" etc
					}
				}
			}
		}

		if ( ( areaUnderProcess->getPickXPlayType () &  ( ImtsGamesEnums::Box | ImtsGamesEnums::Combo ) ) && bXruple ) { // do not allow a ruple number in case BOX or COMBO is selected.
			couponErrors.setCouponError (iArea, CouponErrorDefinitions::INVALID_NUMBERS_FOR_PLAYTYPE );
		}
	}

	if ( couponData.getMultiDrawValue() == ImtsGamesEnums::TooManyDraws) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::TOO_MANY_MULTIDRAWS_SELECTED); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getMultiDrawValue () > 1 && !bHasAnAreaMarked ) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::MULTIDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( couponData.getFutureDrawValue () > 0 &&  !bHasAnAreaMarked ) {
		couponErrors.setCouponError(100, CouponErrorDefinitions::FUTUREDRAWS_SELECTED_ON_AN_EMPTY_COUPON); // Store global coupon errors with key 100. Check CouponError.cpp for details.
	}

	if ( !gameConfig->readAdditionalGame ().isEmpty () ) {
		checkAdditionalGame ( gameConfig, couponData, bHasAnAreaMarked, couponErrors );
	}

	customCheckPickGameCouponWithCalcSupport ( gameConfig, couponData, bHasAnAreaMarked, couponErrors );

	return couponErrors;
}

/**
 * @brief CouponUtilities::checkAdditionalGamePerArea
 * @param iArea
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief checks errors on the additional game. Project specific
 */
void CouponUtilities::checkAdditionalGamePerArea (const int& iArea, GamesConfig*const, const Coupon& couponData, const bool& bHasAnAreaMarked, CouponError& couponErrors )
{
	// do your implementation here.
	// some games have an addiional game on per area basis. And because additional games is game specific in per project
	// basis you got to override and do your own checking.

	if ( couponData.getArea (iArea)->getAdditionalGamePerArea ().value ("UserSelection").toInt () == 0 && !bHasAnAreaMarked ) {
		couponErrors.setCouponError(iArea, CouponErrorDefinitions::ADDITIONAL_GAME_SELECTED_ON_AN_EMPTY_AREA);
	}

}

/**
 * @sa checkAdditionalGame
 * @param gameConfig
 * @param couponData
 * @param couponError
 * @return coupon error object
 * @brief checks errors on the additional game. Project specific
 */
void CouponUtilities::checkAdditionalGame ( GamesConfig*const, const Coupon&, const bool&, CouponError& )
{
	// do your implementation here. Check Taiwan's High/Low for Keno to see how it is done.
	// note: if you are overriding this class then you probably have to override couponProcess as well.
}


/**
 * @sa customCheckLottoCouponNoSystem
 * @param gameConfig
 * @param couponData
 * @param couponError
 * @return Coupon errors
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckLottoCouponNoSystem ( GamesConfig*const, const Coupon &, const bool&, CouponError& )
{
	// do what ever you like in here.
	// For instance in Ireland project one of their lotto games must have two areas filled.
}

/**
 * @sa customCheckLottoCouponFullSystemOnly
 * @param gameConfig
 * @param couponData
 * @param couponError
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckLottoCouponFullSystemOnly ( GamesConfig*const, const Coupon&, const bool&, CouponError& )
{
	// do what ever you like in here.
}

/**
 * @sa customCheckLottoCouponAllSystems
 * @param gameConfig
 * @param couponData
 * @param couponError
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckLottoCouponAllSystems ( GamesConfig*const, const Coupon&, const bool&, CouponError& )
{
	// do what ever you like in here.
}

/**
 * @sa CouponUtilities::customCheckBetTypeCoupon
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckBetTypeCoupon (GamesConfig*const, const Coupon&, const bool&, CouponError& )
{
	// do what ever you like in here.
}

/**
 * @sa customCheckPickGameCoupon
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckPickGameCoupon ( GamesConfig*const , const Coupon&, const bool&, CouponError& )
{
	// do what ever you like in here.
}

/**
 * @sa customCheckPickGameCouponWithCalcSupport
 * @param gameConfig
 * @param couponData
 * @param bHasAnAreaMarked
 * @param couponError
 * @brief does customize check for this type of lotto game.
 */
void CouponUtilities::customCheckPickGameCouponWithCalcSupport ( GamesConfig*const, const Coupon &, const bool&, CouponError& )
{
	// do what ever you like in here.
}



/**
 * @sa updateQpFlag
 * @param gameTypeFlag
 * @param couponData
 * @param iArea
 *
 */
void CouponUtilities::updateQpFlag(ImtsGamesEnums::GameTypeFlags gameTypeFlag,
								int&iNumberOfGeneratedNumbers,
								int &iDefaultMarksForCoupon,
								int &iNumberOfPanels, int &iArea, Coupon& couponData  )
{
		// now set the flags for QP or PQP
		if ( gameTypeFlag.testFlag (ImtsGamesEnums::PartialQp) ) {

		   if ( iNumberOfGeneratedNumbers!=0 && iNumberOfGeneratedNumbers < iDefaultMarksForCoupon ) {
				couponData.getArea( iArea )->setQp( Area::ePartialQp);
			} else if ( iDefaultMarksForCoupon == iNumberOfGeneratedNumbers ) {
			   if ( iNumberOfPanels > 1 ) {
				   couponData.getArea( iArea )->setQp( Area::eQpPanelAB);
			   } else {
				   couponData.getArea( iArea )->setQp( Area::eQpPanelA);
			   }
			} else {
			   // qDebug () << "Don't set QP";
			}
		}
}
