/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file CouponProcessManager.cpp
  * @class CouponProcess
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include "CouponProcessManager.h"
#include "GamesUtilities.h"
#include "QpGeneration/QpGeneration.h"
#include "JsonOperations.h"
#include "SystemWideConstValues.h"
#include "LocalEventLoggerEvents.h"
#include "CheckCoupon/CouponUtilities.h"
#include "Dialogs/QmlMessageBox.h"
#include "DbusWrapper.h"
#include "IMTSDbusArmInterfaces/DbusWrapperArm.h"
#include "Nvram/Nvram.h"
#include "Plays/ExternalPlay.h"
#include <QtDebug>
#include <QElapsedTimer>
#if QT_VERSION >= 0x050000
#include <QtWidgets/QMainWindow>
#else
#include <QtGui/QMainWindow>
#endif
class CouponProcessManagerPrivate
{
public:
	CouponProcessManagerPrivate ();
	~CouponProcessManagerPrivate ();

	void populateCouponData ( const int& iPlayArea, const QStringList& qslPanelA, const QStringList& qslPanelB, const int& iQP, const int& iMp );
	QStringList detectMultipleTickets ( QString& qsQRBarcode );

	QList< QPair<ImtsGamesEnums::CouponSource, QByteArray>  > m_lCoupons;
	GamesConfig m_cGameConfig;
	Coupon m_cCouponData;
	QSemaphore* m_lockCouponProcess;
	QScopedPointer<CouponUtilities> m_pcCouponUtilities;
	QMetaObject::Connection m_connection;
	QMetaObject::Connection m_msgBoxConnection;
	QMetaObject::Connection m_trainingConnection;
	QMetaObject::Connection m_signOnOffConnection;

	quint16 m_iLastGivenDataChecksum;
	bool m_bScanningDeviceEnabled;
	quint32 m_iDropSameDataInterval;
	quint32 m_iQuestionSameDataInterval;
	bool m_bAlwaysPromptOnSameCoupon;
	qint32 m_iPopUpTimeout;
	bool m_bIsTraining;

	QElapsedTimer m_timer;
};

CouponProcessManagerPrivate::CouponProcessManagerPrivate ()
	: m_pcCouponUtilities         ( new CouponUtilities )
	, m_iLastGivenDataChecksum    ( 0 )
	, m_bScanningDeviceEnabled    ( true )
	, m_iDropSameDataInterval     ( 2000 ) // in ms
	, m_iQuestionSameDataInterval ( 5000 ) // in ms
	, m_bAlwaysPromptOnSameCoupon ( false )
	, m_iPopUpTimeout             ( 10000 ) // in ms
	, m_bIsTraining               ( false )

{
	m_bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();
	m_trainingConnection = QObject::connect ( DbusWrapper::getConfigManagerInterface (), &DbusWrapper::ConfigManagerInterface::trainingChanged, [this] {
		m_bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();
	});


	m_signOnOffConnection = QObject::connect ( DbusWrapper::getConfigManagerInterface (), &DbusWrapper::ConfigManagerInterface::signOnChanged, [this] {

		if ( DbusWrapper::getConfigManagerInterface ()->signOn () ) {
			m_iLastGivenDataChecksum = 0;
		}
	});



	m_timer.start ();
}

CouponProcessManagerPrivate::~CouponProcessManagerPrivate ()
{
	delete m_lockCouponProcess;

	QObject::disconnect ( m_connection );
	QObject::disconnect ( m_trainingConnection );
	QObject::disconnect ( m_msgBoxConnection );
	QObject::disconnect ( m_signOnOffConnection );
}

CouponProcessManager::CouponProcessManager( QObject* parent )
	: QObject ( parent )
	, d_ptr ( new CouponProcessManagerPrivate )
{

	Q_D ( CouponProcessManager );


	bool bCouponProcessingBlocked = DbusWrapper::getConfigManagerInterface ()->couponProcessingBlocked ();
	blockSignals (bCouponProcessingBlocked);

	d->m_connection = QObject::connect ( DbusWrapper::getConfigManagerInterface (), &DbusWrapper::ConfigManagerInterface::couponProcessingBlockedChanged, [this,d](const bool& barcodeProcessingBlockedStatus)
	{
		QMutex mutex;
		mutex.lock ();
		d->m_lCoupons.clear ();
		mutex.unlock ();

		int iResources = d->m_lockCouponProcess->available ();
		if ( iResources == 0 ) {
			d->m_lockCouponProcess->release ();
		} else if ( iResources > 1 ) { // should never happen.
			d->m_lockCouponProcess->release ();
			LOG("Semaphore resources in CPM got out of hand.")
		}
		blockSignals (barcodeProcessingBlockedStatus);
	});


	initializeCouponData ();

	// do metaType registrations needed due to being running on a separate thread, an Qt::QueueConnection is being used.
	qRegisterMetaType<ImtsGamesEnums::CouponSource>("CouponSource");
	qRegisterMetaType<GamesConfig*>("GamesConfig");
	qRegisterMetaType<Coupon>("Coupon");
	qRegisterMetaType<QList<Coupon>>();

	QObject::connect ( this, &CouponProcessManager::processPendingCoupons,
					   this, &CouponProcessManager::processPendingCouponsSlot, Qt::QueuedConnection);

	QObject::connect ( this, &CouponProcessManager::procceedOnDuplicateData,
					   this, &CouponProcessManager::procceedOnDuplicateDataSlot, Qt::QueuedConnection );

	QObject::connect ( this, &CouponProcessManager::resumeCouponProcess,
					   this, &CouponProcessManager::resumeCouponProcessSlot, Qt::QueuedConnection );

	d->m_lockCouponProcess = new QSemaphore(1); // single source semaphore. Like QMutex. However, with the available interface it saves us flooding events for data processing.

}

CouponProcessManager::~CouponProcessManager()
{
}


/**
 * @sa initializeCouponData
 */
void CouponProcessManager::initializeCouponData ()
{

	Q_D ( CouponProcessManager );

	QVariantMap qvmGameConfigMap = QVariantMap();

	// we could just leave couponData empty without areas. Those would be dynamically added
	// when needed. However, due to processing newly received data in an asynchronous manner
	// we need to know in advance the numbers of areas our games use, in order to avoid initial
	// coupon parsing errors, (2/3 of them until coupon data in this object populates all needed
	// areas). Remove m_cCouponData.addAreas (iNumberOfAreasAlreadyCreated) to see what happens.

	DbusWrapper::getAllGamesConfig( qvmGameConfigMap );
	int iNumberOfAreasAlreadyCreated = 0;

	if ( !qvmGameConfigMap.isEmpty() ) {


		int iGameCode = 0;
		QMap<QString, QVariant>::const_iterator i = qvmGameConfigMap.constBegin();
		while ( i != qvmGameConfigMap.constEnd() ) {

			iGameCode = i.key().toInt();
			d->m_cGameConfig.clearConfig ();

			bool bOk =  QJson::JsonOperations::JsonToqObject( i.value().toByteArray(), &d->m_cGameConfig );

			if ( bOk ) {

				if ( d->m_cGameConfig.readNumberOfAreas () >= iNumberOfAreasAlreadyCreated ) {
					iNumberOfAreasAlreadyCreated += d->m_cGameConfig.readNumberOfAreas ()-iNumberOfAreasAlreadyCreated;
				}

			} else {

				LOG ( QString(QStringLiteral("ERROR parsing config data for game %1")).arg (iGameCode));
			}
			++i;
		}
	} else {

		LOG ( QStringLiteral ("Games Config Map is empty"));
	}

	d->m_cCouponData.addAreas (iNumberOfAreasAlreadyCreated);
}

/**
 * @sa getCouponData
 * @return coupon data. Usually because the object that inherits us, should want
 * to call us to avoid calling initializeCouponData again.
 */
Coupon CouponProcessManager::getCouponData ()
{
	Q_D ( CouponProcessManager );
	return d->m_cCouponData;
}

bool CouponProcessManager::scanningDeviceEnabled () const
{
	Q_D ( const CouponProcessManager );
	return d->m_bScanningDeviceEnabled;
}

void CouponProcessManager::setScanningDeviceEnabled (const bool& bEnabled )
{
	Q_D ( CouponProcessManager );

	if ( d->m_bScanningDeviceEnabled == bEnabled ) return;
	d->m_bScanningDeviceEnabled = bEnabled;
	emit scanningDeviceEnabledChanged ();
	LOG(QString("Func[%1] scanner/camera enabled: %2 ").arg (Q_FUNC_INFO).arg (bEnabled));
#if defined IMTS_ARM
		DbusWrapperArm::setEnabled (bEnabled);
#else
	DbusWrapper::getReadingDeviceOperationsInterface ()->setEnabled (bEnabled);
#endif
}

quint32 CouponProcessManager::dropSameDataInterval () const
{
	Q_D ( const CouponProcessManager );
	return d->m_iDropSameDataInterval;
}

void CouponProcessManager::setDropSameDataInterval ( const quint32& iInterval )
{
	Q_D ( CouponProcessManager );
	d->m_iDropSameDataInterval = iInterval;
}


quint32 CouponProcessManager::questionSameDataInterval () const
{
	Q_D ( const CouponProcessManager );
	return d->m_iQuestionSameDataInterval;
}

void CouponProcessManager::setQuestionSameDataInterval ( const quint32& iInterval )
{
	Q_D ( CouponProcessManager );
	d->m_iQuestionSameDataInterval = iInterval;
}

bool CouponProcessManager::alwaysPromptOnSameCoupon () const
{
	Q_D ( const CouponProcessManager );
	return d->m_bAlwaysPromptOnSameCoupon;
}

void CouponProcessManager::setAlwaysPromptOnSameCoupon ( const bool& bAlwaysPrompt )
{
	Q_D ( CouponProcessManager );
	d->m_bAlwaysPromptOnSameCoupon = bAlwaysPrompt;
}

qint32 CouponProcessManager::popUpTimeout () const
{
	Q_D ( const CouponProcessManager );
	return d->m_iPopUpTimeout;
}

void CouponProcessManager::setPopUpTimeout ( const qint32& iTimeOut  )
{
	Q_D ( CouponProcessManager );
	d->m_iPopUpTimeout = iTimeOut;
}


bool CouponProcessManager::isTraining () const
{
	Q_D ( const CouponProcessManager );
	return d->m_bIsTraining;
}

void CouponProcessManager::setIsTraining ( const bool& bTraining )
{
	Q_D ( CouponProcessManager );
	if ( d->m_bIsTraining == bTraining ) return;
	d->m_bIsTraining = bTraining;
}

/**
 * @sa promptForGeneralError
 * @param qsDisplayText
 * @param qsBtn1Text
 * @param qsMsgBoxTitle
 */
void CouponProcessManager::promptForGeneralError ( const QString& qsDisplayText, const QString& qsBtn1Text, const QString& qsMsgBoxTitle, int iTimeOut )
{
	Q_D ( CouponProcessManager );

	setScanningDeviceEnabled (false);

	auto hadleUserChoice = [this,d]() {
		d->m_cCouponData.clearCouponData ();
		emit resumeCouponProcess ();
	};

	QStringList l = GamesUtilities::getActiveWindow ();

	if ( !l.isEmpty () ) {

		QDBusInterface remoteApp( l.at (0), l.at (1) );
		QDBusPendingCall pCall = remoteApp.asyncCall ( QStringLiteral("displayMessageBox"),
													   qsDisplayText,
													   qsBtn1Text,
													   qsMsgBoxTitle,
													   QString (),
													   QString (),
													   QString (),
													   iTimeOut );

		QDBusPendingCallWatcher *watcher = new QDBusPendingCallWatcher(pCall, this);

		d->m_msgBoxConnection = QObject::connect ( watcher, &QDBusPendingCallWatcher::finished, [=](QDBusPendingCallWatcher* call) {


			QDBusPendingReply<int> reply = *call;

			if ( !reply.isError() ) {

				hadleUserChoice();

			} else {

				QDBusError dbusError = reply.error();
				LOG ( dbusError.message () );
				LOG ( dbusError.errorString(dbusError.type()));
				LOG(QString("Failed to place displayMessageBox call from: %1").arg (Q_FUNC_INFO));
				hadleUserChoice ();
			}

			disconnect (d->m_msgBoxConnection);
			call->deleteLater();

		});

	} else {
		qDebug () << "Error getting active window";
		hadleUserChoice ();
	}
}


/**
 * @sa procceedOnDuplicateDataSlot
 */
void CouponProcessManager::procceedOnDuplicateDataSlot ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData )
{
	Q_D ( CouponProcessManager );

	setScanningDeviceEnabled (false);

	auto hadleUserChoice = [this]( const QmlMessageBox::eeQmlMessageBoxResult& eUsersChoice, const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData ) {

		if ( eUsersChoice == QmlMessageBox::eOK ) { // Yes

			// Dont' resume CTM because
			acceptIncomingCouponData ( eCouponSource, qbaCouponData );

		} else if ( eUsersChoice == QmlMessageBox::eCANCEL || eUsersChoice == QmlMessageBox::eTIMEOUT ) { // No

			// just don't do anything. Ignore incoming data, but resume CTM.
		}
		setScanningDeviceEnabled (true);
	};

	QString qsDisplayText = QString(tr("Current play is the same as last\nWould you like to proceed?"));

	QStringList l = GamesUtilities::getActiveWindow ();

	if ( !l.isEmpty () ) {

		QDBusInterface remoteApp( l.at (0), l.at (1) );
		QDBusPendingCall pCall = remoteApp.asyncCall ( QStringLiteral("displayMessageBox"),
													   qsDisplayText,
													   tr("Yes"),
													   tr("Information"),
													   tr("No"),
													   QString (),
													   QString (),
													   popUpTimeout () );

		QDBusPendingCallWatcher *watcher = new QDBusPendingCallWatcher(pCall, this);

		d->m_msgBoxConnection = QObject::connect ( watcher, &QDBusPendingCallWatcher::finished, [=](QDBusPendingCallWatcher* call) {


			QDBusPendingReply<int> reply = *call;

			if ( !reply.isError() ) {

				QmlMessageBox::eeQmlMessageBoxResult eUsersChoice = QmlMessageBox::eeQmlMessageBoxResult(reply.argumentAt<0>());
				hadleUserChoice ( eUsersChoice, eCouponSource, qbaCouponData );

			} else {

				QDBusError dbusError = reply.error();
				LOG ( dbusError.message () );
				LOG ( dbusError.errorString(dbusError.type()));
				LOG(QString("Failed to place displayMessageBox call from: %1").arg (Q_FUNC_INFO));
				hadleUserChoice ( QmlMessageBox::eTIMEOUT, eCouponSource, qbaCouponData );
			}

			disconnect (d->m_msgBoxConnection);
			call->deleteLater();

		});

	} else {
		hadleUserChoice ( QmlMessageBox::eTIMEOUT, eCouponSource, qbaCouponData );
	}

}


/**
 * @sa preCouponProcessOperations
 * @param qbaCouponData
 * @return true/false
 * @brief There are cases where the last given coupon data is provided twice. In that
 * case we need to ask the retailer whether he/she wants to proceed or not. The default
 * implementation does the following:
 * If same data within a 2seconds window it will drop it.
 * If same data within a 10seconds window will prompt the retailer for action. (continue/drop)
 * Notice that we block signals processing by this object until a decision is made. That is,
 * we'll not be accepting camera data in case signalsBlocked returns true. In addition, to be
 * on the safe side we disable camera upon entering this method. We enable it when we're about
 * to exit.
 */
void CouponProcessManager::preCouponProcessOperations ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData )
{
	Q_D ( CouponProcessManager );

	//    For debugging uncomment the following two lines
	//    acceptIncomingCouponData ( eCouponSource, qbaCouponData );
	//    return;

	quint16 iCurrentChecksum = qChecksum ( qbaCouponData.data (), qbaCouponData.size () );

	if ( d->m_iLastGivenDataChecksum == iCurrentChecksum ) {

		if ( alwaysPromptOnSameCoupon () ) { // There are customers where they want to always prompt on same coupon and ignore the timeouts. Default is false. Set property after instantiation based on customer's requirement.

			emit procceedOnDuplicateData ( eCouponSource, qbaCouponData );

		} else {

			quint64 iEllapsedTime = d->m_timer.elapsed ();

			if ( iEllapsedTime <= dropSameDataInterval () ) {

				qWarning () << "Same data in the last 2 seconds. No data processing";

			} else if ( iEllapsedTime > dropSameDataInterval () && iEllapsedTime <= questionSameDataInterval () ) {

				qWarning () << "Same data in the last 5 seconds. Prompt user";
				emit procceedOnDuplicateData ( eCouponSource, qbaCouponData );

			} else {

				d->m_iLastGivenDataChecksum = iCurrentChecksum;
				acceptIncomingCouponData ( eCouponSource, qbaCouponData );
			}
		}

	} else {

		d->m_iLastGivenDataChecksum = iCurrentChecksum;
		acceptIncomingCouponData ( eCouponSource, qbaCouponData );
	}

	d->m_timer.restart ();
}

/**
 * @sa acceptIncomingCouponData
 * @param eCouponSource
 * @param qbaCouponData
 * @brief accepts incoming data for processing and triggers processing pending coupons if necessary.
 */
void CouponProcessManager::acceptIncomingCouponData ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData )
{
	Q_D ( CouponProcessManager );

	QMutex mutex;
	mutex.lock ();
	d->m_lCoupons.append ( QPair<ImtsGamesEnums::CouponSource, QByteArray> ( eCouponSource, qbaCouponData) );
	mutex.unlock ();

	if ( d->m_lCoupons.size () == 1  &&  d->m_lockCouponProcess->available () ) { // emit processPendingCoupons iff size is one and ->available is > 0. We save, causing extra signal emitions for data processing when the slot is not available due to waiting edit results. It's an overkill but anyway....

		emit processPendingCoupons ();

	} else {

		LOG("Incoming data were rejected!!! Why?")
	}
}

/**
  * @sa  addCouponForProcessingSlot
  * @param source of coupon
  * @param coupon data
  * @brief adds coupon in a queue and if necessary emits a signal to start processing
  */
void CouponProcessManager::addCouponForProcessingSlot ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData )
{
	Q_D ( CouponProcessManager );

	if ( !signalsBlocked () && d->m_bScanningDeviceEnabled ) {

		if ( eCouponSource == ImtsGamesEnums::Camera || eCouponSource == ImtsGamesEnums::QR ) {

			preCouponProcessOperations ( eCouponSource, qbaCouponData );

		} else {

			acceptIncomingCouponData ( eCouponSource, qbaCouponData );
		}

	} else {

		LOG (QString(QStringLiteral("Coupon Process is blocked because signalsBlocked: %1 and scanningDeviveEnabled: %2")).arg (signalsBlocked ()).arg (d->m_bScanningDeviceEnabled));
	}

}

/**
 * @sa suspendCouponProcessSlot
 * @brief suspends processing coupons from m_lCoupons queue.
 * Also blocks accepting new coupons from Camera.
 */
void CouponProcessManager::suspendCouponProcessSlot ()
{
	Q_D ( CouponProcessManager );

	LOG("Disable Camera suspendCouponProcessSlot");

	setScanningDeviceEnabled (false);
	blockSignals (true);

	if ( d->m_lockCouponProcess->available () ) {
		d->m_lockCouponProcess->acquire ();
	}
}

/**
  * @sa resumeCouponProcessSlot
  * @brief wakes up coupon process thread to carry on processing incoming pending coupons.
  * Basically it unblocks the processPendingCouponsSlot() slot, which is responsible to process
  * m_lCoupons queue.
  */
void CouponProcessManager::resumeCouponProcessSlot ()
{
	Q_D ( CouponProcessManager );

	LOG("Enable Camera resumeCouponProcessSlot");

	if ( !d->m_lockCouponProcess->available () ) { // this is a single source semaphore, so only release it once. If you attempt to release it more, then the semaphore is not longer a single source and it will cause problems.
		d->m_lockCouponProcess->release ();
	}

	blockSignals (false);
	if ( d->m_lCoupons.size () ) {
		emit processPendingCoupons ();
	}
	setScanningDeviceEnabled(true);
}

/**
  * @sa processCameraCoupon
  * @param coupon data coming from camera
  * @brief
  */
void CouponProcessManager::processCameraCoupon (const QByteArray& )
{
	qWarning ("Overide to do your camera data processing");
	emit resumeCouponProcess ();
}

/**
 * @brief CouponProcessManager::updateCouponCost
 */
void CouponProcessManager::updateCouponCost ( GamesConfig& cGamesConfig, const Coupon& cCouponData  )
{
	Q_D ( CouponProcessManager );
	d->m_pcCouponUtilities->updateCouponCost ( &cGamesConfig, cCouponData );
}

/**
 * @sa finalizeQpPlay
 * @param cGamesConfig
 * @param cCouponData
 * @return finalize qp play. Project depended
 */
void CouponProcessManager::finalizeQpPlay ( GamesConfig&, Coupon&, ExternalPlay& )
{
	return;
}

/**
 * @sa selectBetType
 * @param cGamesConfig
 * @param cCouponData
 * @return selects bettype for such games. The default does random selection from available bettypes.
 */
int CouponProcessManager::selectBetType ( const int& iNumberOfBetTypes )
{
	return QpGeneration::getQpGenerationInstance () ->getRandomNumbers (1,1,iNumberOfBetTypes).at (0);
}

/**
 * @sa overrideQpPlayData
 * @param list of coupons
 * @param qbaCouponData
 * @return list of coupons for transmission
 * @return continue or not
 */
bool CouponProcessManager::overrideQpPlayData ( QList<Coupon>&, const QByteArray&)
{
	return true;
}

/**
  * @sa addQpPlay
  * @param json object that contains play parameteres
  * @brief Adds qp plays based on the passed in parameters.
  * Promotion manager can also generate externalPlays.
  * We just handle the case just before we send data for processing.
  */
void CouponProcessManager::processQpPlay ( const QByteArray& qbaExternalPlay )
{
	Q_D ( CouponProcessManager );

	d->m_cCouponData.clearCouponData();

	ExternalPlay cExternalPlay;

	bool bOK = QJson::JsonOperations::JsonToqObject ( qbaExternalPlay, &cExternalPlay );
	if ( bOK ) {

		int iGameCode              = cExternalPlay.readGameCode ();
		int iNumberOfTickets       = cExternalPlay.readNumberOfTickets ();
		int iNumberOfAreas         = cExternalPlay.readNumberOfAreas ();
		int iNumberOfDraws         = cExternalPlay.readNumberOfDraws ();
		int iNumberOfFutureDraws   = cExternalPlay.readFutureDraws ();
		int iMultiplier            = cExternalPlay.readMultiplier ();
		int iAdditionalGame        = cExternalPlay.readAdditionalGame ();
		QVariantList lAdditionalGamePerArea = cExternalPlay.readAdditionalGamePerArea ();
		int iBetType               = cExternalPlay.readBetType ();
		int iDrawType              = cExternalPlay.readDrawType ();
        int iSystem                = cExternalPlay.readSystem ();
		bool bDirectTransmission   = cExternalPlay.readDirectTransmission ();
		QVariantMap mCustomData    = cExternalPlay.readCustomData ();

		// Originally CouponSource property was not part of ExternalPlay class. I've added l8r when I did the integration for
		// promotions. Up until then, couponSource was directly set based on the operation that takes place in this method.
		// Howerever, this method is called when we got a free promotion ticket. Hence, setting couponSource is a bit stupid
		// on how we set it, but I don't have the time to change all the relative code that generates externalPlays. Now,
		// if you asked me what miscGame is, I really have no idea. I can't remember whether I was the one to add such
		// property. Anyway.

		ImtsGamesEnums::CouponSource eCouponSource = ImtsGamesEnums::CouponSource( cExternalPlay.readCouponSource () );

		if ( eCouponSource == ImtsGamesEnums::UndefinedSource ) {
			// Currently only promotion manager sets the flag correctly. All other subsystem do not, hence the check
			eCouponSource = ImtsGamesEnums::GuiQp;
		}


		if ( !CouponUtilities::getGameConfig (CouponUtilities::eByGameCode, iGameCode, d->m_cGameConfig ) ) {

			promptForGeneralError ( tr("Invalid qp play"), tr("OK"), tr("Information") );

		} else {

			QList<Coupon> lCouponBatch = QList<Coupon> ();

			// You can bypass the code below here, for example see TellyBingo for PLI.
			bool bContinue = overrideQpPlayData (lCouponBatch, qbaExternalPlay);

			if ( lCouponBatch.isEmpty () && bContinue) {

				d->m_cCouponData.setCouponOrigin ( eCouponSource );

				//! Do game code
				d->m_cCouponData.setGameCode ( d->m_cGameConfig.readGameCode () );

				//! Do sub game code
				d->m_cCouponData.setSubGameCode ( d->m_cGameConfig.readSubGameCode () );

				//! Do game name
				d->m_cCouponData.setGameName (d->m_cGameConfig.readGameName ());

				d->m_cCouponData.setInputMethod( int(ImtsGamesEnums::ECoupon) );
				d->m_cCouponData.setIsDirectTransmission ( bDirectTransmission );

				if ( !d->m_cGameConfig.readAdditionalGame ().isEmpty () && iAdditionalGame > 0 ) {

					QVariantMap mAdditionalGameMap = d->m_cCouponData.getAdditionalGameMap ();
					double dAdditionalGameCost = d->m_cGameConfig.readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();

					mAdditionalGameMap.insert (QStringLiteral("UserSelection"), iAdditionalGame);
					mAdditionalGameMap.insert (QStringLiteral("Price"), dAdditionalGameCost );
					mAdditionalGameMap.insert (QStringLiteral("GameName"), d->m_cGameConfig.readAdditionalGame ().value(QStringLiteral("Name")).toString () );
					d->m_cCouponData.setAdditionalGameMap (mAdditionalGameMap);
				}

				// Promotion data are part of miscellaneous game in Coupon data.
				// Coupon source will help us identify whether we need to process them or not.
				if ( eCouponSource == ImtsGamesEnums::PromotionTicket ) {
					d->m_cCouponData.setPromotionData ( cExternalPlay.readPromotionData () );
				}

				for ( int iTicket = 0; iTicket < iNumberOfTickets; ++iTicket ) {

					bool bBetTypePerArea = false;

					d->m_cCouponData.setMultiDrawSingle (iNumberOfDraws);

					if ( iNumberOfFutureDraws ) {
						d->m_cCouponData.setFutureDrawSingle (iNumberOfFutureDraws);
					}

					d->m_cCouponData.setDrawType (ImtsGamesEnums::DrawTypeFlag(iDrawType));

					if ( !d->m_cGameConfig.readBetTypeCfgMap ().isEmpty () ) {

						bBetTypePerArea = d->m_cGameConfig.readBetTypeCfgMap ().value (QStringLiteral("BetTypePerArea")).toBool (); // check if betType reflects whole coupon or per area.

						if ( !bBetTypePerArea ) { // set bet type for the whole coupon.
							d->m_cCouponData.setBetTypeSingle (d->m_cGameConfig.readBetTypeCfgMap ().value ("DefaultBetType").toInt ());
						}
					}

                    d->m_cCouponData.setSystemBet(iSystem);

					for ( int iArea = 0; iArea < iNumberOfAreas; ++iArea ) {

						d->m_cCouponData.getArea (iArea)->clearArea ();

						if ( !d->m_cGameConfig.readMultiplierCfgMap ().isEmpty () ) {

							d->m_cCouponData.getArea (iArea)->setMultiplierSingle (iMultiplier);
						}

						if ( !d->m_cGameConfig.readBetTypeCfgMap ().isEmpty () && bBetTypePerArea ) {  // this means that the game is Keno, or a game that supports betTypes in per area basis.

							if ( iBetType == -1 ) { //This means that the user didn't set a bet type. So we go for a random.

								int iNumberOfBetTypes = d->m_cGameConfig.readBetTypeCfgMap ().value (QStringLiteral("BetTypeSelectionsList")).toList ().count();

								d->m_cCouponData.getArea (iArea)->setBetTypeSingle ( selectBetType (iNumberOfBetTypes) ); // select randomly a bettype.

							} else {

								d->m_cCouponData.getArea (iArea)->setBetTypeSingle ( iBetType ); //If we have a bet type from the user input then use it.
							}
						}

						// all we have to do for qp generation is handle config, couponData and the area, and the routine
						// will update couponData with qp numbers for us. Please note that m_cCouponData are passed by a
						// non const reference
						QpGeneration::getQpGenerationInstance ()->updateCouponDataWithQpMarks ( &d->m_cGameConfig, d->m_cCouponData, iArea );

						if ( !d->m_cGameConfig.readAdditionalGamePerArea ().isEmpty () && !lAdditionalGamePerArea.isEmpty() ) {

							QVariantMap mAdditionalGameMap = d->m_cCouponData.getArea (iArea)->getAdditionalGamePerArea ();

							for ( int addOnGame = 0; addOnGame < lAdditionalGamePerArea.length(); addOnGame++ ) {
								mAdditionalGameMap.insert( lAdditionalGamePerArea.at(addOnGame).toString(), 1 );
							}

							d->m_cCouponData.getArea (iArea)->setAdditionalGamePerArea (mAdditionalGameMap);
						}


						if ( !mCustomData.isEmpty() ) {
							d->m_cCouponData.getArea(iArea)->setCustomData(mCustomData);
						}
					}

					finalizeQpPlay ( d->m_cGameConfig, d->m_cCouponData, cExternalPlay );

					// we need to calculate columns cause we need to update coupon data.
					updateCouponCost ( d->m_cGameConfig, d->m_cCouponData );

					addCouponToList (d->m_cCouponData, d->m_cGameConfig, eCouponSource, lCouponBatch);

				}
			}

			preProcessCouponsBatch(d->m_cGameConfig, lCouponBatch, eCouponSource); // maybe pop up a cost warning etc

			if ( !lCouponBatch.isEmpty () ) {

				emit processCouponsBatch ( &d->m_cGameConfig, lCouponBatch, eCouponSource ); // non-blocking emit
			}

			emit resumeCouponProcess ();
		}

	} else {

		promptForGeneralError ( tr("Invalid qp play data"), tr("OK"), tr("Information") );
	}
}


/**
 * @sa preprocessCouponsBatch
 */

void CouponProcessManager::preProcessCouponsBatch ( GamesConfig& cGamesConfig, QList<Coupon>&lCouponList, const ImtsGamesEnums::CouponSource& eCouponSource)
{
	//nothing to do here
	Q_UNUSED(cGamesConfig);
	Q_UNUSED(lCouponList);
	Q_UNUSED(eCouponSource);
	return;

}

/**
  * @sa processFastGamePlay
  * @param gameCode to add a quick play for
  * @param number of plays
  * @param number of areas
  * @param number of draws
  * @param multiplier
  * @param additional game
  * @param additional game per area
  * @brief Adds qp plays based on the passed in parameters.
  */
void CouponProcessManager::processFastGamePlay ( const QByteArray& qbaExternalPlay )
{
	Q_D ( CouponProcessManager );

	d->m_cCouponData.clearCouponData();

	ExternalPlay cExternalPlay;

	bool bOK = QJson::JsonOperations::JsonToqObject ( qbaExternalPlay, &cExternalPlay );
	if ( bOK ) {

		int iGameCode              = cExternalPlay.readGameCode ();
		int iSubGameCode           = cExternalPlay.readSubGameCode ();
		int iNumberOfTickets       = cExternalPlay.readNumberOfTickets ();
		bool bDirectTransmission   = cExternalPlay.readDirectTransmission ();

			//if game 6000 or 16000
			if (IS_FASTPLAYNEW (iGameCode)) {
				iGameCode = iSubGameCode;
			}

			if ( !CouponUtilities::getGameConfig (CouponUtilities::eByGameCode, iGameCode, d->m_cGameConfig ) ) {

			promptForGeneralError ( tr("Invalid Fast play play"), tr("OK"), tr("Information") );

		} else {

			QList<Coupon> lCouponBatch = QList<Coupon> ();

			overrideQpPlayData (lCouponBatch, qbaExternalPlay); // you can by pass the code below here, for example see TellyBingo for PLI.

			if ( lCouponBatch.isEmpty () ) {

				d->m_cCouponData.setCouponOrigin (ImtsGamesEnums::GuiQp);

				//! Do game code
				d->m_cCouponData.setGameCode ( d->m_cGameConfig.readGameCode () );

				//! Do sub game code
				d->m_cCouponData.setSubGameCode ( d->m_cGameConfig.readSubGameCode () );

				//! Do game name
				d->m_cCouponData.setGameName (d->m_cGameConfig.readGameName ());

				//! Do cost
				d->m_cCouponData.setCouponCost ( d->m_cGameConfig.readColumnPrice ()  );

				d->m_cCouponData.setInputMethod( int(ImtsGamesEnums::ECoupon) );
				d->m_cCouponData.setIsDirectTransmission ( bDirectTransmission );

				for ( int iTicket = 0; iTicket < iNumberOfTickets; ++iTicket ) {

					finalizeQpPlay ( d->m_cGameConfig, d->m_cCouponData, cExternalPlay );

					lCouponBatch.append (d->m_cCouponData);
				}
			}

			if ( !lCouponBatch.isEmpty () ) {

				emit processCouponsBatch ( &d->m_cGameConfig, lCouponBatch, ImtsGamesEnums::FastPlayGame ); // non-blocking emit
			}

			emit resumeCouponProcess ();
		}

	} else {

		promptForGeneralError ( tr("Invalid qp play data"), tr("OK"), tr("Information") );
	}
}


/**
  * @sa populateCouponData
  * @param playArea
  * @param panelA
  * @param panelB
  * @param qp
  * @param mp
  * @brief assigns values to coupondata based on the passed in parameters
  */
void CouponProcessManagerPrivate::populateCouponData ( const int& iPlayArea, const QStringList& qslPanelA, const QStringList& qslPanelB, const int& iQP, const int& iMp )
{

	//! Do areas
	int iNumberOfPanels = m_cGameConfig.readNumberOfPanels();

	//! Do panels
	for ( int iPanel = 0; iPanel < iNumberOfPanels; ++iPanel ) {

		if ( iPanel == 0 ) { // PanelA

			for ( int iMark = 0; iMark < qslPanelA.size(); ++iMark ) { // do marks PanelA
				m_cCouponData.getArea (iPlayArea)->addMarkPanelX ( iPanel, qslPanelA.at(iMark).toInt ()-1 );
			}

		} else { // PanelB

			for ( int iMark = 0; iMark < qslPanelB.size(); ++iMark ) { // do marks PanelB
				m_cCouponData.getArea (iPlayArea)->addMarkPanelX ( iPanel, qslPanelB.at(iMark).toInt ()-1 );
			}
		}

	} // end of panel loop

	//! Do multiplier
	if ( iMp > 1 ) { // The list is initialized with an ace. If we attempt to set it, it thinks that we are the Gui and unsets the value. Weird stuff I've made....Why does it work with camera data? Don't know, got to check....
		m_cCouponData.getArea (iPlayArea)->setMultiplierSingle ( iMp );
	}


	//! Do bet type
	if ( !m_cGameConfig.readBetTypeCfgMap().isEmpty () ) {  // this means that the game is Keno, or a game that supports betTypes.			i

		//! Do QpA
		if ( iQP ) {

			int iNumberOfBetTypes = m_cGameConfig.readBetTypeCfgMap ().value ("BetTypeSelectionsList").toList ().count();

			m_cCouponData.getArea (iPlayArea)->setBetTypeSingle ( QpGeneration::getQpGenerationInstance () ->getRandomNumbers (1,1,iNumberOfBetTypes).at (0)); // select randomly a bettype

			QpGeneration::getQpGenerationInstance ()->updateCouponDataWithQpMarks ( &m_cGameConfig, m_cCouponData, iPlayArea );

		} else {
			m_cCouponData.getArea (iPlayArea)->setBetTypeSingle ( qslPanelA.count () ); // count the numbers to make betType for Keno. It will work only for Keno. For other games we'll see how to do it.
		}

	} else { // game does not support betTypes, but we still need to check for qp selection and set it if true.

		//! Do QpA
		if ( iQP ) {

			QpGeneration::getQpGenerationInstance ()->updateCouponDataWithQpMarks ( &m_cGameConfig, m_cCouponData, iPlayArea );
		}

	}
}

/**
 * @sa detectMultipleTickets
 * @param qsQRBarcode
 * @return a list of play barcordes each of which has email and password prepended.
 * The orig data is:
 * masalis@intralot.com#1234@5175@A,0@U,08,10,15,46,48@L,22@QP,000@MP,001@MD,001@FD,001@AG,000+@1100@U,23,29,44,47,62@L@QP,000@MP,001@MD,001@FD,000+
 *                      @1100@U,14,23,39,53,59@L@QP,000@MP,001@MD,001@FD,000+
 *                      @5104@U,11,17,19,28,39@L,19@QP000@MP,001@MD,001@FD,000+
 *                      @5175@A,0@U,01,27,38,47,48@L,26@QP,000@MP,001@A,1@U,03,07,28,32,46@L,01@QP,000@MP,001@A,2@U,04,06,16,25,50@L,08@QP,000@MP,001@A,3@U,08,18,21,39,43@L,21@QP,000@MP,001@A,4@U,17,26,38,50,59@L,18@QP,000@MP,001@MD,001@FD,001@AG,000+
 *                      @5104@U,01,02,16,32,41@L,18@QP000@MP,001@MD,001@FD,000
 *
 *
 * sarlis@intralot.com#1234@5145@A,0@U,24,37,39,47,56@L,13@QP,000@MP,001         @MD,001@FD,001@AG,000+
 *                         @5143@A,0@U,07,62,64,67,72@L,07@QP,000@MP,001         @MD,001@FD,001@AG,000+
 *                         @1105@A,0@U,01,04,08,09,21,24,27,33,35,43,65,69@L@QP,000@MP,001@MD,001@FD,001@AG,000
 *
 * @brief try to split barcode with +. If the resulted list is non empty then we take the list's first entry
 * and construct an e-mail and password string "qsGivenEmailPass". In continue, we append the "qsGivenEmailPass"
 * to all list's strings starting from 1 and return the list.
 */
QStringList CouponProcessManagerPrivate::detectMultipleTickets ( QString& qsQRBarcode )
{
	QStringList qslTickets = QStringList ();
	QStringList qslMultipleTickets = QStringList ();
	QString qsGivenEmailPass = QString ();

	if ( qsQRBarcode.contains (QChar('+'))) {
		qslTickets = qsQRBarcode.split (QChar('+'));
	}

	if ( !qslTickets.isEmpty () ) {

		QString qsTmp = qslTickets.at (0);

		// Get email and password
		int iIndex = qsQRBarcode.indexOf (QLatin1Char('#'));
		QString qsEmail = QString ();
		if ( iIndex != -1 ) {
			qsEmail = qsTmp.left (iIndex);
			qsTmp.remove (qsEmail); // done with email
		}

		QString qsEmailPassword = QString ();
		if ( !qsEmail.isEmpty ()) { // if there is an email, expect a password too. Worse case will be empty.
			iIndex = qsTmp.indexOf (QLatin1Char('@'));
			qsEmailPassword = qsTmp.left (iIndex);
			qsTmp.remove (qsEmailPassword); // done with password
			qsEmailPassword.remove ( QLatin1Char('#') );
		}

		if ( !qsEmail.isEmpty () ) {
			qsGivenEmailPass.append (qsEmail);
			qsGivenEmailPass.append (QChar('#'));
			qsGivenEmailPass.append (qsEmailPassword);
		}

		QString qsMultipleGames = QString ();

		for ( int iNewTicket = 0; iNewTicket < qslTickets.size (); ++ iNewTicket ) {

			if ( iNewTicket ) {

				qsMultipleGames = qslTickets.at (iNewTicket);
				if ( !qsGivenEmailPass.isEmpty () ) {
					qsMultipleGames.prepend (qsGivenEmailPass);
				}
				qslMultipleTickets.append (qsMultipleGames);
				qsMultipleGames.clear ();

			} else {
				qslMultipleTickets.append (qslTickets.at (iNewTicket));
			}
		}

	} else {

		qslMultipleTickets.append (qsQRBarcode);
	}

	return qslMultipleTickets;
}

/**
  * @sa processQrData
  * @param data received from an external source, when a QR barcode was scanned.
  * @brief generates coupon play data from given QR barcode.
  * QRBarcode has the following format:
  * email#password@GameCode@A,@U,nn,nn,nn,nn,nn,nn@L,nn,nn,nn,nn,nn@QP,000@MP,mmm@MD,mmm@FD,mmm
  *
  * email: yourname@mycompany.com
  * password: encrypt email data with password. (I beleive it's optional)
  * A: Area number
  * nn: numbers (01,02,etc)
  * mmm: number (001 etc)
  * U: upper area
  * L: lower area
  * QP: quick pick (000 NoQP, 001 if QP is selected)
  * MP: multiplier
  * MD: multidraws
  * FD: futuredraws
  * AG: AdditionalGame
  * R: repeat
  *
  * example:
  * keno
  * masalis@intralot.com#@1100@U,01,02@L@QP,000@MP,001@MD,001@FD,000
  * note: keno does not have L area, so it remains empty.
  *
  * joker
  * masalis@intralot.com#@5104@U,01,02,03,04,05,06@L,01@QP,000@MP,001@MD,001@FD,000@R,001
  *
  * Powerball
  * masalis@intralot.com#1234@5175@A,0@U,16,24,34,44@L,08@QP,000@MP,001@A,1@U,02,04,10,25,34@L,05@QP,000@MP,001@A,2@U,27,35,38,44,59@L,24@QP,000@MP,001@A,3@U,03,35,38,49,54@L,30@QP,000@MP,001@A,4@U,01,08,12,14,57@L,01@QP,000@MP,001@MD,012@FD,000@AG,001
  */
void CouponProcessManager::processQrData ( const QByteArray& qbaCouponData )
{
	Q_D ( CouponProcessManager );
	d->m_cCouponData.clearCouponData();

	QString qsQRBarcode (qbaCouponData);

	// Test string for multi tickets.
	// qsQRBarcode = QString("masalis@intralot.com#1234@5145@A,0@U,24,37,39,47,56@L,13@QP,000@MP,001@MD,001@FD,001@AG,000+@5143@A,0@U,07,62,64,67,72@L,07@QP,000@MP,001@MD,001@FD,001@AG,000+@1105@A,0@U,01,04,08,09,21,24,27,33,35,43,65,69@L@QP,000@MP,001@MD,001@FD,001@AG,000");

	// First of all we got to extract necessary information contained in QRBarcode
	QStringList qslBarcodeList = d->detectMultipleTickets ( qsQRBarcode );

	if ( !qslBarcodeList.isEmpty () ) {

		qsQRBarcode.clear ();

		bool bQrDataProcessedSuccessfully = true;

		for ( quint8 iPlayData = 0; iPlayData < qslBarcodeList.size (); ++iPlayData ) {

			qsQRBarcode = qslBarcodeList.at (iPlayData);
			// Get email and password
			int iIndex = qsQRBarcode.indexOf (QLatin1Char('#'));
			QString qsEmail = QString ();
			if ( iIndex != -1 ) {
				qsEmail = qsQRBarcode.left (iIndex);
				qsQRBarcode.remove (qsEmail); // done with email
			}


			QString qsEmailPassword = QString ();
			if ( !qsEmail.isEmpty ()) { // if there is an email, expect a password too. Worse case will be empty.
				iIndex = qsQRBarcode.indexOf (QLatin1Char('@'));
				qsEmailPassword = qsQRBarcode.left (iIndex);
				qsQRBarcode.remove (qsEmailPassword); // done with password
				qsEmailPassword.remove ( QLatin1Char('#') );
			}

			int iGameCode = qsQRBarcode.mid (1,4).toInt (); // get gameCode.
			LOG(QString("QR Coupon with GameCode: %1 received").arg (iGameCode));

			if ( !CouponUtilities::getGameConfig (CouponUtilities::eByGameCode, iGameCode, d->m_cGameConfig ) ) {

				promptForGeneralError ( tr("Invalid QR code."), tr("OK"), tr("Information") ); // call resumes couponProcess don't worry
				bQrDataProcessedSuccessfully = false;
				break;

			}  else {

				QList<Coupon> lCouponBatch = QList<Coupon> ();


				if ( lCouponBatch.isEmpty () ) {


					qsQRBarcode.remove (0,5); // get rid of game code

					QString qsWholeCouponValues = qsQRBarcode.mid ( qsQRBarcode.indexOf ("@MD,", 0) ); // @MD,001@FD,000@AG,000@R,001
					qsQRBarcode.remove (qsWholeCouponValues); // get rid of them. We have stored them and we are going to split them into a list for easier manipulation.

					uint iMd = 1;
					uint iFd = 0;
					uint iAg = 0;
					uint iR  = 1;
					// iPhone app does not support AG (AdditionalGame) for joker and kino, only for powerball, i.e., Powerplay
					// So we need to do special treatment here. R (NumberOfTickets) is currently only support from a Genion application.
					QStringList qslWholeCouponValuesInAList = qsWholeCouponValues.split (QLatin1Char('@'));
					qslWholeCouponValuesInAList.removeFirst (); // get rid of first empty generate string due to first '@'
					for ( int iCouponValues = 0 ; iCouponValues < qslWholeCouponValuesInAList.count (); ++iCouponValues ) {

						switch (iCouponValues) {

							case 0 : // Md
								iMd = qslWholeCouponValuesInAList.at (iCouponValues).right (3).toInt (); // MD,001
							break;
							case 1 : // Fd
								iFd = qslWholeCouponValuesInAList.at (iCouponValues).right (3).toInt (); // FD,001
							break;
							case 2 : // Ag
							case 3 : // R
							{
								if ( qslWholeCouponValuesInAList.at (iCouponValues).contains ("AG,")) {
									iAg = qslWholeCouponValuesInAList.at (iCouponValues).right (3).toInt (); // AG,000
								}

								if ( qslWholeCouponValuesInAList.at (iCouponValues).contains ("R,")) {
									iR = qslWholeCouponValuesInAList.at (iCouponValues).right (3).toInt ();  // R,001
								}
							}
							break;
						}
					}


					QStringList qslGameDataList = qsQRBarcode.split ( QLatin1String("@A,") ); // get all areas. List contains strings of: "0@U,@L,@QP,@MP" "1@U,@L,@QP,@MP" ... "5@U,@L,@QP,@MP,"
					qslGameDataList.removeFirst (); // get rid of first empty generate string due to first '@'
					int iNumberOfAreas = qslGameDataList.count (); // so we can get the number of areas sent to us.


					QStringList playData  = QStringList ();
					QStringList qslPanelA = QStringList ();
					QStringList qslPanelB = QStringList ();
					int iQP = 0;
					int iMp = 1;
					int iPlayArea = 0;

					for ( uint iTicketCount = 0; iTicketCount < iR; ++iTicketCount ) {

						d->m_cCouponData.setGameCode ( iGameCode );
						d->m_cCouponData.setGameName ( d->m_cGameConfig.readGameName () );
						d->m_cCouponData.setInputMethod( 0 ); //TODO: need input method from QR readers scanner?

						for ( int iArea = 0; iArea<iNumberOfAreas; ++iArea ) { // go through the data as many times as @A, appears. The first char in each qslGameDataList is the area number

							playData = qslGameDataList.at (iArea).split (QLatin1Char('@')); // get all areas data in a list. playData list should contain strings of: "0,U,L,QP,MP" "1,U,L,QP,MP" .. "5,U,L,QP,MP"
							iPlayArea = playData.at (0).toInt (); // this is the area we are going to populate with numbers QP and MP
							qslPanelA = playData.at (1).split (QLatin1Char(',')); // qslPanelA list should contain strings of the numbers
							qslPanelA.removeAt (0); // get rid of U

							qslPanelB = playData.at (2).split (QLatin1Char(','));
							qslPanelB.removeAt (0); // get rid of L

							iQP = playData[ 3 ].remove ("QP,").toUInt ();
							iMp = playData[ 4 ].remove ("MP,").toUInt ();

							d->populateCouponData ( iPlayArea, qslPanelA, qslPanelB, iQP, iMp );


						}

						if ( iMd > 1 ) { // The list is initialized with an ace. If we attempt to set it, it thinks that we are the Gui and unsets the value. Weird stuff I've made....Why does it work with camera data? Don't know, got to check....
							d->m_cCouponData.setMultiDrawSingle ( iMd );
						}

						if ( iAg ) {
							QVariantMap mAdditionalGameMap;
							double dAdditionalGameCost = d->m_cGameConfig.readAdditionalGame ().value (QStringLiteral("Price")).toDouble ();

							mAdditionalGameMap.insert (QStringLiteral("UserSelection"), 1);
							mAdditionalGameMap.insert (QStringLiteral("Price"), dAdditionalGameCost );
							mAdditionalGameMap.insert (QStringLiteral("GameName"), d->m_cGameConfig.readAdditionalGame ().value(QStringLiteral("Name")).toString () );
							d->m_cCouponData.setAdditionalGameMap ( mAdditionalGameMap );
						}

						d->m_cCouponData.setFutureDrawSingle ( iFd );

						d->m_cCouponData.setEmail (qsEmail);
						d->m_cCouponData.setEmailPassword (qsEmailPassword);


						// Normally we shouldn't check for errors. But do you trust the application that sends us the data, or the way
						// we parsed the sent data? I don't.
						CouponError cCouponError = d->m_pcCouponUtilities->getCouponErrors ( &d->m_cGameConfig, d->m_cCouponData );
						if ( cCouponError.isEmpty () ) {

							// we need to calculate columns cause we need to update coupon data.
							updateCouponCost ( d->m_cGameConfig, d->m_cCouponData );
							bool bOk = addCouponToList (d->m_cCouponData, d->m_cGameConfig, ImtsGamesEnums::QR , lCouponBatch, false); // DirectConnection does not matter
							if (bOk) {
								emit processCouponsBatch ( &d->m_cGameConfig, lCouponBatch, ImtsGamesEnums::QR ); // non-blocking emit
							}

						} else {
							QString qsErrorString = QString();

							qsErrorString += cCouponError.getCouponErrorsInArea( 100 );

							for ( int iArea = 0; iArea < d->m_cGameConfig.readNumberOfAreas (); ++iArea ) {
								qsErrorString += cCouponError.getCouponErrorsInArea( iArea );
							}

							LOG(qsErrorString);
							promptForGeneralError ( tr("QR code contains invalid game data."), tr("OK"), tr("Information") ); // call resumes couponProcess don't worry
							lCouponBatch.clear ();
							d->m_cCouponData.clearCouponData ();
							bQrDataProcessedSuccessfully = false;
							break;
						}

						d->m_cCouponData.clearCouponData ();
						playData.clear ();
						qslPanelA.clear ();
						qslPanelB.clear ();
						iQP = iPlayArea = 0;
						iMp = 1;
					}
				}

			}

			qsQRBarcode.clear ();

		}

		if ( bQrDataProcessedSuccessfully ) {
			emit resumeCouponProcess ();
		}

	} else {

		promptForGeneralError ( tr("Invalid QR code."), tr("OK"), tr("Information") ); // call resumes couponProcess don't worry
	}
}

/**
 * @sa processScannerCoupon
 * @param qbaCouponData
 * @return true if all ok false otherwise
 */
void CouponProcessManager::processScannerCoupon (const QByteArray& )
{
	qWarning ("We don't scanner yet, if ever!!!");
	emit resumeCouponProcess ();
}

/**
 * @brief processAdditionalGame
 * @param qbaCouponData
 * @return true if all OK false otherwise
 */
void CouponProcessManager::processAdditionalGame( const QByteArray& )
{
	qWarning ("Re-implement to get game data initialized with your stuff. Check High/Low for Taiwan if you want.");
	emit resumeCouponProcess ();
}

/**
 * @sa createCouponDataFromGameTxData
 * @param GameTxData
 * @param CouponData
 * @param GamesConfig
 * @brief calls the createCouponDataFromGameTxData
 */
void CouponProcessManager::createCouponDataFromGameTxData ( const QByteArray& qbaGameTxData, Coupon& couponData, GamesConfig *const pcGamesConfig )
{
	Q_D ( CouponProcessManager );

	d->m_pcCouponUtilities->createCouponDataFromGameTxData (qbaGameTxData, couponData, pcGamesConfig );
}

/**
 * @sa processRegenerationCoupon
 * @param GameTxData
 * @brief processes ready GameTxData. Data come from ticket regeneration process
 */
void CouponProcessManager::processRegenerationCoupon ( const QByteArray& qbaGameTxData )
{
	Q_D ( CouponProcessManager );

	GameTxData cGameTxData;
	QJson::JsonOperations::JsonToqObject( qbaGameTxData, &cGameTxData );

	if ( !CouponUtilities::getGameConfig (CouponUtilities::eByGameCode, cGameTxData.readGameCode (), d->m_cGameConfig ) ) {

		QString errMsg = QString("call %1 getGameConfig returned an empty reply").arg (Q_FUNC_INFO);
		LOG(errMsg);

	} else {

		d->m_cCouponData.clearCouponData();
		createCouponDataFromGameTxData ( qbaGameTxData, d->m_cCouponData, &d->m_cGameConfig );
		d->m_cCouponData.setIsDirectTransmission (true);

		QList<Coupon> lCouponBatch = QList<Coupon> ();
		lCouponBatch.append (d->m_cCouponData);

		emit processCouponsBatch ( &d->m_cGameConfig, lCouponBatch, ImtsGamesEnums::RegeneratedTicket ); // non-blocking emit
	}

	emit resumeCouponProcess ();
}

/**
* @sa processMiscellaneousGame
* @param miscellaneous games' data
* @brief processes miscellaneous games
*/
void CouponProcessManager::processMiscellaneousGame(const QByteArray& qbaMiscData )
{
	QVariantMap qvmMiscPlay = QJson::JsonOperations::JsonObjectFromData(qbaMiscData);

	QVariantList qvlMiscPlay = qvmMiscPlay.value("List").toList();
	int iMiscPlay = 0;

	if ( !qvlMiscPlay.isEmpty() ) {
		QVariantList::Iterator qvlMiscPlayIterator = NULL;

		for ( qvlMiscPlayIterator = qvlMiscPlay.begin(); qvlMiscPlayIterator != qvlMiscPlay.end(); ++qvlMiscPlayIterator) {
			QVariantMap qvmMiscGame = qvlMiscPlay.at(iMiscPlay).toMap();

			ExternalPlay cExternalPlay;
			cExternalPlay.clearData();

			cExternalPlay.setGameCode(qvmMiscGame.value("GameCode").toInt());
			cExternalPlay.setNumberOfAreas(qvmMiscGame.value("NumberOfAreas").toInt());
			cExternalPlay.setNumberOfDraws(qvmMiscGame.value("NumberOfDraws").toInt());
			cExternalPlay.setAdditionalGame(qvmMiscGame.value("AdditionalGameData").toInt());
			cExternalPlay.setNumberOfTickets(qvmMiscGame.value("NumberOfTickets").toInt());
			cExternalPlay.setCouponSource(ImtsGamesEnums::MiscellaneousGame);

			processQpPlay ( QJson::JsonOperations::qObjectToJson (&cExternalPlay) );
			iMiscPlay++;
		}

	} else {
		promptForGeneralError ( tr("Invalid qp play data"), tr("OK"), tr("Information") );
	}
}

/**
 * @sa processGuiFlexBetData
 * @param qbaCouponData
 */
void CouponProcessManager::processGuiFlexBetData ( const QByteArray& )
{
	qWarning ("Do your own flexBet data processing!!!");
	emit resumeCouponProcess ();
}

/**
 * @sa processGuiRacesData
 * @param qbaCouponData
 */
void CouponProcessManager::processGuiRacesData ( const QByteArray& )
{
	qWarning ("Do your own races data processing!!!");
	emit resumeCouponProcess ();
}

/**
 * @sa processGuiGBIRacesData
 * @param qbaCouponData
 */
void CouponProcessManager::processGuiGBIRacesData ( const QByteArray& )
{
	qWarning ("Do your own GBIRaces data processing!!!");
	emit resumeCouponProcess ();
}

/**
 * @sa processPendingCouponsLogic
 * @param eSource
 * @param qbaCouponData data received from external source for parsing/processing
 * @brief internal logic on coupons' processing. Normally for IMTS complient projects
 * you won't have to override this method. However, for other projects that are not
 * complient with IMTS like, introducing flexbet in IMTS you might have to override it.
 */
void CouponProcessManager::processPendingCouponsLogic ( const ImtsGamesEnums::CouponSource& eSource, const QByteArray& qbaCouponData )
{

	switch ( eSource ) {
		case ImtsGamesEnums::Camera :
			processCameraCoupon ( qbaCouponData );
		break;
		case ImtsGamesEnums::Scanner :
			processScannerCoupon ( qbaCouponData );
		break;
		case ImtsGamesEnums::GuiQp :
		case ImtsGamesEnums::PromotionTicket : // Consider Promotion ticke as if it was a QP. Passed in data contains some more info promotion manager added.
			processQpPlay ( qbaCouponData );
		break;
		case ImtsGamesEnums::FastPlayGame :
			processFastGamePlay ( qbaCouponData );
		break;
		case ImtsGamesEnums::QR :
			processQrData ( qbaCouponData );
		break;
		case ImtsGamesEnums::AdditionalGame :
			processAdditionalGame ( qbaCouponData );
		break;
		case ImtsGamesEnums::RegeneratedTicket :
			processRegenerationCoupon ( qbaCouponData );
		break;
		case ImtsGamesEnums::MiscellaneousGame :
			processMiscellaneousGame ( qbaCouponData );
		break;
		case ImtsGamesEnums::FlexBet :
		case ImtsGamesEnums::FlexBetCamera :
			processGuiFlexBetData ( qbaCouponData );
		break;
		case ImtsGamesEnums::Races :
		case ImtsGamesEnums::RacesCamera :
			processGuiRacesData ( qbaCouponData );
		break;
		case ImtsGamesEnums::GBIRaces :
		case ImtsGamesEnums::GBIRacesCamera :
		processGuiGBIRacesData ( qbaCouponData );
		break;

		default: {
			qDebug () << "unknown coupon source identify";
			LOG("unknown coupon source identify");
			emit resumeCouponProcess ();
		}
		break;

	}
}

/**
  * @sa processPendingCouponSlot
  * @brief processes queued coupon data. The idea is: The main event loop keeps on adding coupons in m_lCoupons
  * and signals only once when the queue has size 1, so that this slot is executed to process them. After that
  * the main event loop will just append coupons in m_lCoupons without emitting the signal that triggers this
  * slot. This slot, executes for the first time, and upon finishing emits a signal to re-trigger itself. So,
  * we only have enough signals for every coupon added.
  */
void CouponProcessManager::processPendingCouponsSlot ()
{
	Q_D ( CouponProcessManager );

	if ( d->m_lockCouponProcess->tryAcquire () ) { // lock transmit process

		if ( !d->m_lCoupons.isEmpty () ) {

			QPair<ImtsGamesEnums::CouponSource, QByteArray>  couponData = d->m_lCoupons.takeAt (0);

			processPendingCouponsLogic ( couponData.first, couponData.second );

		} else {

			if ( !d->m_lockCouponProcess->available () ) { // this is a single source semaphore, so only release it once. If you attempt to release it more, then the semaphore is not longer a single source and it will cause problems.
				d->m_lockCouponProcess->release ();
			}
			LOG ("Coupon Process Queue is empty. No coupon was processed.");
		}

	} else {
		LOG("Waiting for user action");
	}
}


/**
  * @sa addCouponToList
  * @brief
  */

bool CouponProcessManager::addCouponToList(Coupon &cCouponData, GamesConfig& cGamesConfig, const ImtsGamesEnums::CouponSource &eCouponSource, QList<Coupon>& lCouponList,const bool bCheckForDirectConnection)
{
	Q_UNUSED(eCouponSource);
	Q_UNUSED(cGamesConfig);
	Q_UNUSED (bCheckForDirectConnection);

	lCouponList.append (cCouponData);

	return true;
}

