/******************************************************************************
 Copyright (C) 2016

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once
#ifndef WSFLEXBETODDSRX_H
#define WSFLEXBETODDSRX_H


#include "CssItParseMessageInterface.h"
/**
 * @file WsFlexBetOddsRx.h
 * @class WsFlexBetOddsRx
 * @brief Concrete Product, that is concrete implementation of CssItParseMessageInterface
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief It is the product that defines the receive product to be created by the corresponding
 * concrete factory. It implements createCssIt() method which returns a new object when
 * the client requests one via the concrete factory. It also implements processReceivedData()
 * where the received packet will be manipulated based based on Transaction type business logic.
 */
class WsFlexBetOddsRx : public CssItParseMessageInterface
{
public:
    explicit WsFlexBetOddsRx ();
    ~WsFlexBetOddsRx (){}

private:

    /*virtual*/ CssItParseMessageInterface *createCssIt() const Q_DECL_OVERRIDE;
    /*virtual*/ ImtsRxErrors::eeRxStatus processReceivedData(const QByteArray& qbaGuiData,
                                                             const int& iCsReply,
                                                             const char* const pReceivedData,
                                                             QVariantMap& qvmDataForGui) Q_DECL_OVERRIDE;

    QVariantMap m_mHtmlData;
    static const WsFlexBetOddsRx* const m_WsFlexBetOddsRx;

};

#endif // WSFLEXBETODDSRX_H
