/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file WbsRestfullRequestTx.cpp
 * @author: Nondas Masalis masalis@intralot.com
*/

#include "WbsRestfullRequestTx.h"
#include "WebServicesTxRxFactoryPlugin.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "JsonOperations.h"
/** Forces registration */
const WbsRestfullRequestTx* const WbsRestfullRequestTx::m_WbsRestfullRequestTx = new WbsRestfullRequestTx;


/**
 * @sa WbsRestfullRequestTx Constructor
 * @brief It is responsible to register itself with Lotos5PluginFactory. Register the class name
 * with our factory so the client calls the class name as the transaction type identification when
 * a product is requested from LotosFactory.
 */
WbsRestfullRequestTx::WbsRestfullRequestTx ()
{

	static bool bIsProductRegistered = false;

	if ( !bIsProductRegistered ) {
		WebServicesTxRxFactoryPlugin::registerItCssObject ( QStringLiteral("WbsRestfullRequestTx"), this);
		bIsProductRegistered = !bIsProductRegistered;
	}
}

/**
 * @sa ~WbsRestfullRequestTx Destructor
 */
WbsRestfullRequestTx::~WbsRestfullRequestTx()
{
	// perform any possible clean up
}


/**
 * @sa InitializeMessageWithData
 * @param pcGuiData a pointer to gui's collected data. Use them to do tx packet initialization
 * @param pcTxPacket a pointer to the packet to be transmitted.
 * @return eeTxStatus indicating whether the initialization was successful or not.
 * @brief This routine encapsulates the business logic on the tx path for WbsRestfullRequestTx
 */
eeTxStatus WbsRestfullRequestTx::initializeMessageWithData ( const QByteArray& qbaGuiData,
															 char* const pTxBuffer )
{
	eeTxStatus eReturnTxStatus = TX_SUCCESS;

	Lotos5DataRequestJsonObj jsonGuiData;
	QJson::JsonOperations::JsonToqObject( qbaGuiData, &jsonGuiData );
	QVariantMap mEndPointParams = QVariantMap ();

	QVariant variant = QVariant::fromValue(jsonGuiData.readTrnsSpecificDataMap ().value ("params").toList ());

	if (variant.canConvert<QVariantList>()) {

		QString qsEndPointParams = QString ();
        qsEndPointParams.append (jsonGuiData.readProject ());

        QSequentialIterable iterable = variant.value<QSequentialIterable>();
            foreach (const QVariant &v, iterable) {
                qsEndPointParams.append (QStringLiteral("/"));
                qsEndPointParams.append (QString::number (v.toDouble ()));
        }

		mEndPointParams.insert (QStringLiteral("EndPointParams"),qsEndPointParams);

	} else {
		mEndPointParams.insert (QStringLiteral("EndPointParams"),jsonGuiData.readProject ());
	}

	QByteArray qbaDataForCs = QJson::JsonOperations::VariantToByteArray (mEndPointParams);

	memcpy (pTxBuffer,qbaDataForCs.data (),qbaDataForCs.size ());

	return eReturnTxStatus;
}


/**
 * @sa createItCss
 * @brief creates and return a product to plugin factory.
 * // NOTE: we could instead do "return new WbsRestfullRequestTx( *this );" and automatically
 * we would return a clone of the product so our model would turn into prototype creational pattern.
 * In that case the client would not have delete the product. But for this type of pattern we MUST
 * guarantee that the object will not be used by two clients at the same time....I don't take the risk
 * eventhough I beleive in our model we could use the clone version just described....Anyway...go the
 * safe way, there is enough memory for the moment.
 */
ItCssMessagePayloadInterface* WbsRestfullRequestTx::createItCss() const
{
	return new WbsRestfullRequestTx;
}
