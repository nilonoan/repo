/* ############################################################################
Name           : l5_strc_gm_5000.h
Company        : Intralot S.A.
Project        : LOTOS Rel 5.0
Programmer     : John Zacharakis
Revisor        : John Zacharakis
Description    : game Structures

Programmer     Date           Action
============== ============== =================================================
J.Zacharakis   06/05/2004     Creation

############################################################################ */

/* Mandatory single inclusion */
#ifndef _L5_STRC_GM_5000_H
#define _L5_STRC_GM_5000_H

/* @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
GAME:               5000
Descriprion:        P-Lotto Game - Parametrical Lotto
Characteristics:    Multiple Group (1..15), 1..120 numbers, Continuous Draws
					Supports all cases of Lotto, Powerball/Joker:
						 - Lotto x/y (6/49, 5/35, 3/90, etc)
						 - Powerball (5/45 + 1/20, 5/53 + 1/42, etc)
					Parametric type of winning categories:
						 - Fixed Amount
						 - Minimum/Maximum Amount
						 - Dividend Amount
						 - Differential with adjacent winning categories
						 - Share winners/amounts with other categories
					Algorithm for calculation of winners
						 - A string to direct calculation
						 - A repeated string xxyy:
							  - xx winning number from yy winning column

Example of algorithm calculation:
- Lotto 6/49 [OPAP]
	 Cat  Algorithm
	 0    A0600
	 1    A0500
	 2    A0400
	 3    A0300
- Joker [OPAP]
	 Cat  Algorithm           Description
	 0    A0500B0101          5 numbers from 1 wcol + 1 number from 2 wcol (2nd area)
	 1    A0500
	 2    A0400B0101
	 3    A0400
	 4    A0300B0101
	 5    A0300
	 6    A0200B0101
	 7    A0100B0101
- Powerball [NEB]
	 Cat  Algorithm
	 0    05000101
	 1    0500
	 2    04000101
	 3    0400
	 4    03000101
	 5    0300
	 6    02000101
	 7    01000101
	 8    0101
- Lotto 6/X [VISMIN]
	 Cat  Algorithm
	 0    A0600
	 1    A0500
	 2    A0400
	 3    A0300
- Lotto 2D [VISMIN]
	 0    0101 (Straight)
	 1    0101 (Llave)
- Lotto5/30 & 1/5 [MOLDOVA]
	 Cat  Algorithm           Description
	 0    A0500B0101          5 numbers from 1 wcol + 1 number from 2 wcol (2nd area)
	 1    A0500
	 2    A0400B0101
	 3    A0400
	 4    A0300B0101
	 5    A0300
- Lotto 6/41 [ARGENTINA]
	 Cat  Algorithm
	 0    A0600
	 1    A0500
	 2    A0400
	 3    A0300
	 4    B0600
	 5    B0500
	 6    C0600
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */

/* Maximum number of groups */
#if !defined(MAX_GRP_5000)
#define   MAX_GRP_5000   15
#endif

/* Maxumum number of player selections */
#define   MAX_SEL_5000   120

/* Maximum number of winning categories */
#if !defined(MAX_CAT_5000)
#define   MAX_CAT_5000   15
#endif

/* Maximum number of winning numbers per column */
#if !defined(MAX_WIN_5000)
#define   MAX_WIN_5000   10
#endif

/* Maximum number of winning columns */
#define   MAX_WCOL_5000  5

#define L5_CLM_VAL 6

/* Transaction group data (repeated for number of groups) */
typedef struct trns_gm_5000
	 {
	 unsigned char       grp;           /* Group ID: 1.. */
	 unsigned char       flags;         /* Groups flags:
											 0: Normal
											 1: Quick Pick - A
											 2: Quick Pick - B
											 3: Quick Pick - A+B
											 4: Topup
											 5: Partial Quick Pick

										   +x0: +subgame x (clm_val x)
												x -> 0,1,2 (simple subgames)
													 3-> 0,1
													 4-> 0,2
													 5-> 1,2
													 6-> 0,1,2 (together)

										   Argentina:
												Game 5163:
												Desquite +50
												Sale     +100

										   LOUISIANA:
												ezmatch winning category
										   LWEST: Powerball
												  +100 -> PPik
										   CZECH: Game 5208
												  +100 -> LOTO+ Selection
										*/
	 unsigned char       type;          /* Type ID:
											 0: System [Predefined] - A
											 1..(x-1): Combinational - A
											 x: Normal/Full - A
										   Area B is considered Normal/Full

										  5121,5122,5156 signifies Game Type
										*/
	 unsigned char       sys[2];        /* System ID: xxyy (maximum: 9999)
											 [0]: yy
											 [1]: xx

										   5114
											 sys[0]
												  1:Straight
												  2:Llave
											 sys[1]:multiplier

										   5106
										   5156
										   5211
										   5216
											 sys[1]:multiplier

										   Other:
											 sys[0]:Area A played numbers
											 sys[1]:Area B played numbers

										   5209
											 sys[0]:
												  0x01 : DAY
												  0x02 : MONTH
												  0x04 : YEAR
												  0x08 : DAY-MONTH
												  0x10 : DAY-MONTH-YEAR
										*/
	 unsigned char       data[15];      /* Numbers 1..120 */
										/* LOUISIANA:
											 ezmatch reply data
											 data[2x]  :amount
											 data[2x+1]:number
										*/
	 } TRNS_GM_5000;

/* Coupon file structure */
typedef struct cpn_gm_5000
	 {
	 CPN_HDR             header;        /* Coupon Header */
	 TRNS_GM_5000        group[MAX_GRP_5000];
										/* Group data */
	 } CPN_GM_5000;

/* Return data [Only if subgames used and defined in return data flags] */
typedef struct rstrns_gm_5000
	 {
	 unsigned long       clm[L5_CLM_VAL];        /* Columns for each subgame (max:3) */
	 double              amount[L5_CLM_VAL];     /* Amount for each subgame (max:3) */
	 } RSTRNS_GM_5000;

/* Strict Games. Based on primary/normal game */
typedef   CPN_GM_5000    CPN_GM_5100;
typedef   CPN_GM_5000    CPN_GM_5101;
typedef   CPN_GM_5000    CPN_GM_5102;
typedef   CPN_GM_5000    CPN_GM_5103;
typedef   CPN_GM_5000    CPN_GM_5104;
typedef   CPN_GM_5000    CPN_GM_5105;
typedef   CPN_GM_5000    CPN_GM_5106;

/* Powerball -> Powerplay (flags in trns_cpn_hdr->flags = 0x00010000) */
typedef   CPN_GM_5000    CPN_GM_5107;
typedef   CPN_GM_5000    CPN_GM_5108;
typedef   CPN_GM_5000    CPN_GM_5109;
typedef   CPN_GM_5000    CPN_GM_5110;

typedef   CPN_GM_5000    CPN_GM_5111;
typedef   CPN_GM_5000    CPN_GM_5112;
typedef   CPN_GM_5000    CPN_GM_5113;
typedef   CPN_GM_5000    CPN_GM_5114;
typedef   CPN_GM_5000    CPN_GM_5115;
typedef   CPN_GM_5000    CPN_GM_5116;
typedef   CPN_GM_5000    CPN_GM_5117;
typedef   CPN_GM_5000    CPN_GM_5118;
typedef   CPN_GM_5000    CPN_GM_5119;
typedef   CPN_GM_5000    CPN_GM_5120;
typedef   CPN_GM_5000    CPN_GM_5121;
typedef   CPN_GM_5000    CPN_GM_5122;
typedef   CPN_GM_5000    CPN_GM_5123;
typedef   CPN_GM_5000    CPN_GM_5124;
typedef   CPN_GM_5000    CPN_GM_5125;
typedef   CPN_GM_5000    CPN_GM_5126;
typedef   CPN_GM_5000    CPN_GM_5127;
typedef   CPN_GM_5000    CPN_GM_5128;
typedef   CPN_GM_5000    CPN_GM_5129;
typedef   CPN_GM_5000    CPN_GM_5130;
typedef   CPN_GM_5000    CPN_GM_5131;
typedef   CPN_GM_5000    CPN_GM_5132;
typedef   CPN_GM_5000    CPN_GM_5133;
typedef   CPN_GM_5000    CPN_GM_5134;
typedef   CPN_GM_5000    CPN_GM_5135;
typedef   CPN_GM_5000    CPN_GM_5136;
typedef   CPN_GM_5000    CPN_GM_5137;
typedef   CPN_GM_5000    CPN_GM_5138;
typedef   CPN_GM_5000    CPN_GM_5139;
typedef   CPN_GM_5000    CPN_GM_5140;
typedef   CPN_GM_5000    CPN_GM_5141;
typedef   CPN_GM_5000    CPN_GM_5142;
typedef   CPN_GM_5000    CPN_GM_5143;
typedef   CPN_GM_5000    CPN_GM_5144;
typedef   CPN_GM_5000    CPN_GM_5145;
typedef   CPN_GM_5000    CPN_GM_5146;
typedef   CPN_GM_5000    CPN_GM_5147;
typedef   CPN_GM_5000    CPN_GM_5148;
typedef   CPN_GM_5000    CPN_GM_5149;
typedef   CPN_GM_5000    CPN_GM_5150;
typedef   CPN_GM_5000    CPN_GM_5151;
typedef   CPN_GM_5000    CPN_GM_5155;
typedef   CPN_GM_5000    CPN_GM_5156;
typedef   CPN_GM_5000    CPN_GM_5157;
typedef   CPN_GM_5000    CPN_GM_5158;
typedef   CPN_GM_5000    CPN_GM_5159;
typedef   CPN_GM_5000    CPN_GM_5160;
typedef   CPN_GM_5000    CPN_GM_5161;
typedef   CPN_GM_5000    CPN_GM_5162;
typedef   CPN_GM_5000    CPN_GM_5163;
typedef   CPN_GM_5000    CPN_GM_5164;
typedef   CPN_GM_5000    CPN_GM_5165;
typedef   CPN_GM_5000    CPN_GM_5166;
typedef   CPN_GM_5000    CPN_GM_5167;
typedef   CPN_GM_5000    CPN_GM_5168;
typedef   CPN_GM_5000    CPN_GM_5169;
typedef   CPN_GM_5000    CPN_GM_5173;
typedef   CPN_GM_5000    CPN_GM_5174;
typedef   CPN_GM_5000    CPN_GM_5175;
typedef   CPN_GM_5000    CPN_GM_5176;
typedef   CPN_GM_5000    CPN_GM_5177;
typedef   CPN_GM_5000    CPN_GM_5178;
typedef   CPN_GM_5000    CPN_GM_5179;
typedef   CPN_GM_5000    CPN_GM_5180;
typedef   CPN_GM_5000    CPN_GM_5181;
typedef   CPN_GM_5000    CPN_GM_5182;
typedef   CPN_GM_5000    CPN_GM_5183;
typedef   CPN_GM_5000    CPN_GM_5184;
typedef   CPN_GM_5000    CPN_GM_5185;
typedef   CPN_GM_5000    CPN_GM_5186;
typedef   CPN_GM_5000    CPN_GM_5187;
typedef   CPN_GM_5000    CPN_GM_5188;
typedef   CPN_GM_5000    CPN_GM_5189;
typedef   CPN_GM_5000    CPN_GM_5190;
typedef   CPN_GM_5000    CPN_GM_5191;
typedef   CPN_GM_5000    CPN_GM_5192;
typedef   CPN_GM_5000    CPN_GM_5193;
typedef   CPN_GM_5000    CPN_GM_5194;
typedef   CPN_GM_5000    CPN_GM_5195;
typedef   CPN_GM_5000    CPN_GM_5196;
typedef   CPN_GM_5000    CPN_GM_5197;
typedef   CPN_GM_5000    CPN_GM_5200;
typedef   CPN_GM_5000    CPN_GM_5201;
typedef   CPN_GM_5000    CPN_GM_5202;
typedef   CPN_GM_5000    CPN_GM_5203;
typedef   CPN_GM_5000    CPN_GM_5204;
typedef   CPN_GM_5000    CPN_GM_5205;
typedef   CPN_GM_5000    CPN_GM_5206;
typedef   CPN_GM_5000    CPN_GM_5207;
typedef   CPN_GM_5000    CPN_GM_5208;
typedef   CPN_GM_5000    CPN_GM_5209;
typedef   CPN_GM_5000    CPN_GM_5210;
typedef   CPN_GM_5000    CPN_GM_5211;
typedef   CPN_GM_5000    CPN_GM_5212;
typedef   CPN_GM_5000    CPN_GM_5213;
typedef   CPN_GM_5000    CPN_GM_5216;
typedef   CPN_GM_5000    CPN_GM_5241;
typedef   CPN_GM_5000    CPN_GM_5242;
typedef   CPN_GM_5000    CPN_GM_5243;
typedef   CPN_GM_5000    CPN_GM_5244;

/* Specific parameters for game */
typedef struct cat_gm_5000
	 {
	 unsigned char       type;          /* Winning category type:
											 0  : Normal dividend
											 1  : Dividend shared with other
											 2  : Fixed amount
											 3  : Fixed odds
											 4  : WIN Promotion
											 5  : Progressive Jackpot
										*/
	 unsigned char       cats[5];       /* Other categories ID:
											 0: Share dividends
											 1: Receive winner amounts
											 2: Transfer rounding amounts
											 3: Transfer in case of jackpot:
												  - x  : Other category
												  - 255: Next draw
											 4: Roll Over (Original)
												  Number of jackpots before
												  passing amount to next
												  category
										*/
	 unsigned long       amount[10];    /* Various amounts:
											 0: Fixed Amount
											 1: Minimum Dividend Amount
											 2: Minimum Distributed Amount
											 3: Maximum Distributed Amount
												(More: share)
												OHIO
												Funding Factor for Classic Lotto (5152)
											 4: Minimum difference with lower
											 5: Distribution % (Normal dividend)
												Value: XXXYYYY
												  XXX  : Integer part
												  YYYY : Fractional part
											 6: Fund Percentage
											 7: Maximum Distribution percentage (%)
												Value: XXXYYYY
											 8: WIN Promotion ID
										*/
	 char                alg[20];       /* Winner calculation algorithm:
											 xxyy[xxyy]* where:
											 xx: Numbers matched with winning
											 yy: Winning column
											 []: Optional
											 * : Can occur multiple times
										*/
	 } CAT_GM_5000;

typedef struct par_gm_5000
	 {
	 unsigned char       grps;          /* Number of allowed groups */
	 unsigned short      psys;          /* Predefined systems:
											 0: No predefined systems
											 x: Total predefined systems
										*/
	 unsigned char       max_pnum[2];   /* Maximum played numbers allowed
										   per area
											 [0]: Area A
											 [1]: Area B
										*/
	 unsigned char       area;          /* Start of second area:
											 0: No Area B
											 x: Start of Area B
												0..(x-1)    : Area A
												x..(MAX)    : Area B
										*/
	 unsigned char       win_cols;      /* Actual number of winning columns */
	 unsigned char       win_col_lng[MAX_WCOL_5000];
										/* Actual lengh (drawn numbers) of
										   each winning column */
#if PAR_5000_REV > 0
	 unsigned long       win_dstr[3];        /*
											 [0]: Normal
											 [1]: Sub-Game/Variation 1
											 [2]: Sub-Game/Variation 2

											  Winner distribution % (Normal dvd)
												Value: XXXYYYY
												  XXX  : Integer part
												  YYYY : Fractional part
											 */

	 unsigned char       win_dstr_type[3];   /* Winner distribution type:
											 [0]: Normal
											 [1]: Sub-Game/Variation 1
											 [2]: Sub-Game/Variation 2

											 0: Gross amount
											 1: (Gross - TAX) amount
											 2: (Gross - VAT) amount
											 3: (Gross - TAX - VAT) amount
											 4: Other amount (DB Calculation)

											 */
#else
	 unsigned long       win_dstr;      /* Winner distribution % (Normal dvd)
												Value: XXXYYYY
												  XXX  : Integer part
												  YYYY : Fractional part
										*/
	 unsigned char       win_dstr_type; /* Winner distribution type:
											 0: Gross amount
											 1: (Gross - TAX) amount
											 2: (Gross - VAT) amount
											 3: (Gross - TAX - VAT) amount
											 4: Other amount (DB Calculation)
										*/
#endif

	 /* Rounding Parameters (winning dividends) */
	 unsigned char       rnd_type;      /* Rounding type:
											 0: Truncation
											 1: Rounding
										*/
	 unsigned char       rnd_digit;     /* Rounding digit:
											 0,1,...,10
										*/

	 /* Category parameters */
	 CAT_GM_5000         cat[MAX_CAT_5000];
										/* Winning category parameters */
	 } PAR_GM_5000;

/* Winning category information */
typedef struct wcat_gm_5000
	 {
	 unsigned long       win;           /* Winners */
	 double              c_amn[6];      /* Category amounts:
											 0: Distributed
											 1: Dividend
											 2: Taxation
											 3: Rounding
											 4: Bonus amount (add on to [0])
												  Russia :Fund
												  Argentina Demo :Fund
												  Moldova Game 5162 :Fund
											 5: Jackpot from other category or
												previous draw
										*/
	 } WCAT_GM_5000;

/* Statistical/Cumulative information for game */
typedef struct stat_gm_5000
	 {
	 unsigned long       cpn;           /* Played coupons */
	 unsigned long       clm;           /* Played columns */
	 unsigned char       win_nr[MAX_WCOL_5000][MAX_WIN_5000];
										/* Winning columns */
	 WCAT_GM_5000        cat[MAX_CAT_5000];
										/* Winning category information */
	 } STAT_GM_5000;

#endif
