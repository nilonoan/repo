/******************************************************************************
Copyright (C) 2016

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file WsFlexBetOddsRx.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */
#include "WsFlexBetOddsRx.h"
#include "JsonOperations.h"
#include "WebServicesTxRxFactoryPlugin.h"
#include "SystemWideConstValues.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "WebServices/ReportReply.h"
#include <QDebug>
#include <QBuffer>
#include "DbusWrapper.h"
#include "LocalEventLoggerEvents.h"

/** Forces registration */
const WsFlexBetOddsRx* const WsFlexBetOddsRx::m_WsFlexBetOddsRx = new WsFlexBetOddsRx;

WsFlexBetOddsRx::WsFlexBetOddsRx ()
{
    static bool bIsProductRegistered = false;

    if ( !bIsProductRegistered ) {
        WebServicesTxRxFactoryPlugin::registerCssItObject(QStringLiteral("WsFlexBetOddsRx"), this);
        bIsProductRegistered = !bIsProductRegistered;
    }
}

/**
 * @sa processReceivedData
 * @param gui data in json format
 * @param cs reply
 * @param pointer to received buffer from c/s
 * @param a map that contains the data to be returned to the caller of WsFlexBetOddsRx
 * @brief prepare the reply for Gui to display
 */
ImtsRxErrors::eeRxStatus WsFlexBetOddsRx::processReceivedData( const QByteArray &qbaGuiData,
                                                            const int&,
                                                            const char* const pReceivedData,
                                                            QVariantMap& qvmDataForGui )
{
    Q_UNUSED (qbaGuiData);

    ImtsRxErrors::eeRxStatus eReturnRxStatus = ImtsRxErrors::RX_SUCCESS;

    if ( !DbusWrapper::getConfigManagerInterface ()->training () ) {


        QByteArray qbaCsJsonData(pReceivedData); // qbaCsReply data is assumed to point to a nul-terminated string and its length is determined dynamically. The terminating nul-character is not considered part of the byte array.

        if ( !qbaCsJsonData.isEmpty () ) {

            QBuffer buffer(&qbaCsJsonData);
            buffer.open(QIODevice::ReadOnly);

            if (buffer.isOpen()) {

                QXmlStreamReader reader;
                bool bEventWithOutcomes;
                QString qsEventKickOffTime, qsEventCode, qsEventStatus, qsEventDescription;
                QString qsMarketCode, qsHomeWinOdd, qsDrawOdd, qsAwayWinOdd;

                reader.setDevice(&buffer);

                if (reader.readNextStartElement()) {
                    if (reader.name() == "DrawData") { // We are only interested in the contents of the root element "DrawData"
                        while (reader.readNextStartElement()) {
                            if (reader.name() == "Event") { // We are only interested in "Event" elements that are "Active", "Started" or "Blocked"
                                qsEventStatus = reader.attributes().value("EventStatus").toString();
                                bEventWithOutcomes = false;

                                if (qsEventStatus == "Active" || qsEventStatus == "Running") {
                                    qsEventKickOffTime = reader.attributes().value("Date").toString(); // Event kick-off time
                                    qsEventCode = reader.attributes().value("ID").toString(); // Event code
                                    qsEventDescription = reader.attributes().value("Descr").toString(); // Event description

                                    while (reader.readNextStartElement()) {
                                        if (reader.name() == "Outcome") { // We are only interested in "Outcome" elements
                                            bEventWithOutcomes = true;
                                            qsMarketCode = reader.attributes().value("ID").toString();

                                            if (qsMarketCode == "400" || qsMarketCode == "445")
                                                qsHomeWinOdd = (reader.attributes().value("SpecialCodeStatus") == "Blocked")?"BL.":reader.attributes().value("Odd").toString();
                                            else if (qsMarketCode == "401" || qsMarketCode == "446")
                                                qsDrawOdd = (reader.attributes().value("SpecialCodeStatus") == "Blocked")?"BL.":reader.attributes().value("Odd").toString();
                                            else if (qsMarketCode == "402" || qsMarketCode == "447")
                                                qsAwayWinOdd = (reader.attributes().value("SpecialCodeStatus") == "Blocked")?"BL.":reader.attributes().value("Odd").toString();

                                            reader.skipCurrentElement();
                                        }
                                        else
                                            reader.skipCurrentElement();
                                    }

                                    if (bEventWithOutcomes) {
                                        qDebug() << "Kick-off time:" << qsEventKickOffTime << ", Event code:" << qsEventCode << "(" << qsEventStatus << "), Event description:" << qsEventDescription;
                                        qDebug() << "L:" << qsHomeWinOdd << "E:" << qsDrawOdd << "V:" << qsAwayWinOdd;

                                        qvmDataForGui.insertMulti("kickOffTime", qsEventKickOffTime);
                                        qvmDataForGui.insertMulti("code", qsEventCode);
                                        qvmDataForGui.insertMulti("description", qsEventDescription);
                                        qvmDataForGui.insertMulti("homeWinOdd", qsHomeWinOdd);
                                        qvmDataForGui.insertMulti("drawOdd", qsDrawOdd);
                                        qvmDataForGui.insertMulti("awayWinOdd", qsAwayWinOdd);
                                    }
                                }
                                else if (qsEventStatus == "Blocked") {
                                    qsEventKickOffTime = reader.attributes().value("Date").toString(); // Event kick-off time
                                    qsEventCode = reader.attributes().value("ID").toString(); // Event code
                                    qsEventDescription = reader.attributes().value("Descr").toString(); // Event description

                                    qDebug() << "Kick-off time:" << qsEventKickOffTime << ", Event code:" << qsEventCode << "(" << qsEventStatus << "), Event description:" << qsEventDescription;

                                    qsHomeWinOdd = qsDrawOdd = qsAwayWinOdd = "BL.";

                                    qDebug() << "L:" << qsHomeWinOdd << "E:" << qsDrawOdd << "V:" << qsAwayWinOdd;

                                    qvmDataForGui.insertMulti("kickOffTime", qsEventKickOffTime);
                                    qvmDataForGui.insertMulti("code", qsEventCode);
                                    qvmDataForGui.insertMulti("description", qsEventDescription);
                                    qvmDataForGui.insertMulti("homeWinOdd", qsHomeWinOdd);
                                    qvmDataForGui.insertMulti("drawOdd", qsDrawOdd);
                                    qvmDataForGui.insertMulti("awayWinOdd", qsAwayWinOdd);

                                    reader.skipCurrentElement();
                                }
                                else
                                    reader.skipCurrentElement();
                            }
                            else
                                reader.skipCurrentElement();
                        }
                    }
                    else
                        qDebug() << "Invalid XML format";
                }

                buffer.close();

                //            qvmDataForGui.insert ( PREVIEW_DATA, html);
            }
        } else {
            LOG(QStringLiteral("c/s sent an empty odds data xml file"));
            eReturnRxStatus = ImtsRxErrors::RX_DATA_PROCESS_ERROR;
        }

    } else {
        // training ?
    }


    return eReturnRxStatus;

}

/**
 * @sa createCssIt
 * @brief creates and return a product to plugin factory.
 */
CssItParseMessageInterface* WsFlexBetOddsRx::createCssIt() const
{
    return new WsFlexBetOddsRx;
}

