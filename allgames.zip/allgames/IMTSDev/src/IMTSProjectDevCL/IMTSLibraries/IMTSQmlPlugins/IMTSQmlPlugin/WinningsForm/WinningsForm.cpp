/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
 * @file WinningsForm.cpp
 * @brief Handles WinningsForm and it is exported to qml context
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
#include "WinningsForm.h"
#include "Dialogs/QmlMessageBox.h"
#include "LocalEventLoggerEvents.h"
#include "SystemWideConstValues.h"
#include "RequestDataFromCs.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "JsonOperations.h"
#include "ImtsEnumerations.h"
#include "GetConfigValue.h"

#if defined(IMTS_LINUX) || defined(IMTS_ARM)
#include "DbusWrapper.h"
#elif defined(IMTS_ANDROID)
#include "HostCallWrapper.h"
#endif

/**
 * @file WinningsForm_p.h
 * @class WinningsFormPrivate
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */

class WinningsFormPrivate : public QObject
{
public:

    WinningsFormPrivate ( QObject* parent );
    virtual ~WinningsFormPrivate ();

    CommonReportsForm* m_pcCommonReportsForm;
    quint16 m_iGameCode;
    quint16 m_iSubGame;
    QString m_qsDrawNumber;
    QDate m_drawDate;
    quint8 m_iNumberOfDraws;
    WinningsEnums::Request_51_X_ActionFlag m_flagAction;
    quint32 m_iNumberOfPrintCopies;
    QString m_qsGameName;
    QString m_qsGameLogo;
    QString m_qsRpcMethod;
    QList<RequestDataFromCs*> m_lRequestDataFromCs;

};

WinningsFormPrivate::WinningsFormPrivate ( QObject* parent )
    : QObject ( parent )
    , m_pcCommonReportsForm ( new CommonReportsForm (this ) )
    , m_iGameCode           ( 0 )
    , m_iSubGame            ( 0 )
    , m_qsDrawNumber        ( QString () )
    , m_drawDate            ( QDate(1970,1,1) )
    , m_flagAction          ( WinningsEnums::NoAction )
    , m_iNumberOfPrintCopies( 1 )
    , m_qsGameName          ( QString () )
    , m_qsGameLogo          ( QString () )
    , m_lRequestDataFromCs  ( QList<RequestDataFromCs*> () )
{

    m_pcCommonReportsForm->setTrnsTxProduct ( QStringLiteral ("RequestLotos5TxData") );

}

WinningsFormPrivate::~WinningsFormPrivate()
{
}


WinningsForm::WinningsForm( QObject* parent )
    : QObject ( parent )
    , d_ptr ( new WinningsFormPrivate ( this ) )
{
    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::WinningNumbers
    QObject::connect ( this, SIGNAL (requestWinningNumbers ( int, int )),
                       SLOT   (requestWinningNumbersSlot ( int, int)), Qt::QueuedConnection );

    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::DrawResults
    QObject::connect ( this, SIGNAL (requestDrawResults ( int, int )),
                       SLOT	(requestDrawResultsSlot ( int, int )), Qt::QueuedConnection );

    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::DrawOdds
    QObject::connect ( this, SIGNAL (requestDrawOdds ( int, int )),
                       SLOT	(requestDrawOddsSlot ( int, int )), Qt::QueuedConnection );

    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::DrawInfo
    QObject::connect ( this, SIGNAL (requestDrawInfo ( int, int )),
                       SLOT	(requestDrawInfoSlot ( int, int )), Qt::QueuedConnection );

    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::LiabilityRisk
    QObject::connect ( this, SIGNAL (requestFastPlay ( int, int )),
                       SLOT	(requestFastPlaySlot ( int, int )), Qt::QueuedConnection );

    // where int,int WinningsEnums::ReportTypeFlag, WinningsEnums::LiabilityRisk
    QObject::connect ( this, SIGNAL (requestLiabilityRisk ( int, int )),
                       SLOT	(requestLiabilityRiskSlot ( int, int )), Qt::QueuedConnection );

    QObject::connect ( this, SIGNAL (performPrint()),
                       SLOT   (performPrintSlot()), Qt::QueuedConnection );
}

WinningsForm::~WinningsForm()
{
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////
CommonReportsForm* WinningsForm::readCommonReportsForm () const
{
    Q_D ( const WinningsForm );
    return d->m_pcCommonReportsForm;

}

quint16 WinningsForm::readGameCode () const
{
    Q_D ( const WinningsForm );
    return d->m_iGameCode;
}

quint16 WinningsForm::readSubGame () const
{
    Q_D ( const WinningsForm );
    return d->m_iSubGame;
}

QString WinningsForm::readDrawNumber () const
{
    Q_D ( const WinningsForm );
    return d->m_qsDrawNumber;
}

QDate WinningsForm::readDrawDate() const
{
    Q_D ( const WinningsForm );
    return d->m_drawDate;
}

quint8 WinningsForm::readNumberOfDraws () const
{
    Q_D ( const WinningsForm );
    return d->m_iNumberOfDraws;
}

WinningsEnums::Request_51_X_ActionFlag WinningsForm::readAction () const
{
    Q_D ( const WinningsForm );
    return d->m_flagAction;
}

quint32 WinningsForm::readNumberOfPrintCopies () const
{
    Q_D ( const WinningsForm );
    return d->m_iNumberOfPrintCopies;
}

QString WinningsForm::readGameName () const
{
    Q_D ( const WinningsForm );
    return d->m_qsGameName;
}

QString WinningsForm::readGameLogo () const
{
    Q_D ( const WinningsForm );
    return d->m_qsGameLogo;
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////

void WinningsForm::setCommonReportsForm (CommonReportsForm* pCommonReportsForm )
{
    Q_D ( WinningsForm );

    if ( pCommonReportsForm ) {
        if ( d->m_pcCommonReportsForm == pCommonReportsForm ) return;
        d->m_pcCommonReportsForm = pCommonReportsForm;
        emit commonReportsFormChanged ();
    }
}

void WinningsForm::setGameCode (const quint16& iGameCode )
{
    Q_D ( WinningsForm );
    if ( d->m_iGameCode == iGameCode ) return;
    d->m_iGameCode = iGameCode;
    emit gameCodeChanged ();

#if defined(IMTS_LINUX) || defined(IMTS_ARM)
    // Get and set GameName from config.
    QVariantList lGame = DbusWrapper::getGameInfo ( iGameCode );
#elif defined(IMTS_ANDROID)
    HostCallWrapper hostCallWrapper;
    QVariantList lGame = hostCallWrapper.getGameInfo ( iGameCode );
#endif

    if ( !lGame.isEmpty () ) {
        setGameName ( lGame.at(0).toString() );
        QString qsGameLogoLocation = QString ();
#if defined(IMTS_LINUX) || defined(IMTS_ARM)
        QDBusReply<QString> qsReply = DbusWrapper::getConfigManagerInterface ()->getGameColorLogoBySize( iGameCode, "Large" );
        qsGameLogoLocation = qsReply.value ();
#elif defined(IMTS_ANDROID)
        qsGameLogoLocation = hostCallWrapper.getGameColorLogoBySize( iGameCode, "Large" );
#endif
        setGameLogo ( qsGameLogoLocation );
    }
}

void WinningsForm::setSubGame (const quint16& iSubGame )
{
    Q_D ( WinningsForm );
    if ( d->m_iSubGame == iSubGame ) return;
    d->m_iSubGame = iSubGame;
    emit subGameChanged ();
}

void WinningsForm::setDrawNumber (const QString& qsDrawNumber )
{
    Q_D ( WinningsForm );
    if ( d->m_qsDrawNumber == qsDrawNumber ) return;
    d->m_qsDrawNumber = qsDrawNumber;
    emit drawNumberChanged ();
}

void WinningsForm::setDrawDate (const QDate& drawDate )
{
    Q_D ( WinningsForm );
    if ( d->m_drawDate == drawDate ) return;
    d->m_drawDate = drawDate;
    emit drawDateChanged ();
}

void WinningsForm::setNumberOfDraws (const quint8& iNumberOfDraws )
{
    Q_D ( WinningsForm );
    if ( d->m_iNumberOfDraws == iNumberOfDraws ) return;
    d->m_iNumberOfDraws = iNumberOfDraws;
    emit numberOfDrawsChanged ();
}

void WinningsForm::setAction (const WinningsEnums::Request_51_X_ActionFlag &flagAction )
{
    Q_D ( WinningsForm );
    if ( d->m_flagAction == flagAction ) return;
    d->m_flagAction = flagAction;
    emit actionChanged ();
}

void WinningsForm::setNumberOfPrintCopies (const quint32& iNumberOfCopies )
{
    Q_D ( WinningsForm );
    if ( d->m_iNumberOfPrintCopies == iNumberOfCopies ) return;
    d->m_iNumberOfPrintCopies = iNumberOfCopies;
    emit numberOfPrintCopiesChanged ();
}

void WinningsForm::setGameName (const QString& qsGameName )
{
    Q_D ( WinningsForm );
    if ( d->m_qsGameName == qsGameName ) return;
    d->m_qsGameName = qsGameName;
    emit gameNameChanged ();
}

void WinningsForm::setGameLogo (const QString& qsGameLogo )
{
    Q_D ( WinningsForm );
    if ( d->m_qsGameName == qsGameLogo ) return;
    d->m_qsGameLogo = qsGameLogo;
    emit gameLogoChanged ();
}

/**
 * @sa showMessage
 * @param message to be shown onto front-end
 * @brief shows the message onto front-end. The way the message is displayed onto the front-end
 * is driven by reading the configuration file. Either using a pop up or inside the preview window.
 */
void WinningsForm::showMessage ( QString qsErrorMessage )
{
    QmlMessageBox msgBox ( qsErrorMessage );
    msgBox.exec ();
}

/**
 * @sa processCsResultsSlot
 * @param qvmMessageReply is the map returned by the receive product created in Trss,
 * that contains the data we need.
 * @brief First of all we delete the object we have dynamically created to place a C/S
 * call. The we proceed processing the received results contained in the passed in
 * map parameter
 */
void WinningsForm::processCsResultsSlot (const QVariantMap& qvmMessageReply )
{
    Q_D ( WinningsForm );
    QString qsErrorMessage = QString();

    emit endPleaseWait ();

    if ( !d->m_lRequestDataFromCs.isEmpty () )
        delete d->m_lRequestDataFromCs.takeAt (0);


    if ( qvmMessageReply.isEmpty() ) {

        qsErrorMessage = tr("Remote proccess returned an empty reply");
        LOG(qsErrorMessage);

    } else {

        qsErrorMessage = qvmMessageReply.value(CS_ERROR_MSG).toString(); // this is the error in case the transaction failed, i.e., css_it_1.res

        if ( qsErrorMessage.isEmpty () ) {
#if defined (IMTS_LINUX) || defined(IMTS_ARM)
            d->m_pcCommonReportsForm->setHtml ( QString::fromUtf8(qvmMessageReply.value(PREVIEW_DATA).toByteArray().data()) );
#elif defined (IMTS_ANDROID)
            d->m_pcCommonReportsForm->setUrl ("/sdcard/IMTSResources/WDCAndroid/HtmlTemplates/en-us/WorkInProgress.html");
#endif
        }
    }

    if ( !qsErrorMessage.isEmpty() ) {
        showMessage (qsErrorMessage);
    }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////// Winning Numbers Request /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareWinningNumberTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareWinningNumberTxData ( const int& action, const int& type )
{
    Q_D(WinningsForm);

    Lotos5DataRequestJsonObj lotos5DataRequestJsonObj;

    lotos5DataRequestJsonObj.setTxProduct ( d->m_pcCommonReportsForm->readTrnsTxProduct ());
    lotos5DataRequestJsonObj.setRxProduct ( d->m_pcCommonReportsForm->readTrnsRxProduct ());
    lotos5DataRequestJsonObj.setProtocol  ( LOTOS5 );
    lotos5DataRequestJsonObj.setPriority  ( HIGH_PRI );
    lotos5DataRequestJsonObj.setProject   ( "" );
    lotos5DataRequestJsonObj.setHeader    ( d->m_pcCommonReportsForm->readTrnsHistory ()->readHeader ());
    lotos5DataRequestJsonObj.setBody      ( d->m_pcCommonReportsForm->readTrnsHistory ()->readBody ());
    lotos5DataRequestJsonObj.setImage     ( d->m_pcCommonReportsForm->readTrnsHistory ()->readImage ());

    lotos5DataRequestJsonObj.setMsg  ( 51 );
    lotos5DataRequestJsonObj.setSMsg ( WinningsEnums::Type_51_0_WinningNumbers );
    lotos5DataRequestJsonObj.setD0   ( type );

    // Do Game
    if ( action&WinningsEnums::AllGames ) {

        lotos5DataRequestJsonObj.setD1 (0);

    } else if ( action&WinningsEnums::SpecificGame ) {

        lotos5DataRequestJsonObj.setD1 (d->m_iGameCode);
    }

    // Do Draw Date or Draw Number
    if ( action&WinningsEnums::SearchByDate && d->m_drawDate.isValid () ) {

        QDateTime drawDate = QDateTime(d->m_drawDate);
        lotos5DataRequestJsonObj.setD2 (drawDate.toTime_t ());

    } else if ( action&WinningsEnums::SearchByDraw ) {

        lotos5DataRequestJsonObj.setD2 (d->m_qsDrawNumber.toInt ());
    }

    // Do Part
    lotos5DataRequestJsonObj.setD3 ( 0 );

    // Do Sub
    lotos5DataRequestJsonObj.setD4 ( 0) ;


    QVariantMap trnsSpecificDataMap = QVariantMap ();
    trnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"), d->m_pcCommonReportsForm->readHtmlTemplate ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportHeader"), d->m_pcCommonReportsForm->readReportHeader ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportBitmap"), d->m_pcCommonReportsForm->readReportBitmap ());

    lotos5DataRequestJsonObj.setTrnsSpecificDataMap (trnsSpecificDataMap);

    QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&lotos5DataRequestJsonObj);

    return qbaJsonData;
}


/**
 * @sa requestWinningNumbersSlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs RetrieveWinningNumbers transaction with c/s and update gui with the results.
 */
void WinningsForm::requestWinningNumbersSlot ( const int& action, const int& type )

{
    Q_D(WinningsForm);

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareWinningNumberTxData ( action, type );

    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////// Draw Results Request ////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareDrawResultsTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareDrawResultsTxData ( const int& action, const int& type )
{
    Q_D(WinningsForm);

    Lotos5DataRequestJsonObj lotos5DataRequestJsonObj;

    lotos5DataRequestJsonObj.setTxProduct ( d->m_pcCommonReportsForm->readTrnsTxProduct () );
    lotos5DataRequestJsonObj.setRxProduct ( d->m_pcCommonReportsForm->readTrnsRxProduct () );
    lotos5DataRequestJsonObj.setProtocol  ( LOTOS5 );
    lotos5DataRequestJsonObj.setPriority  ( HIGH_PRI );
    lotos5DataRequestJsonObj.setProject   ( "" );
    lotos5DataRequestJsonObj.setHeader    ( d->m_pcCommonReportsForm->readTrnsHistory ()->readHeader () );
    lotos5DataRequestJsonObj.setBody      ( d->m_pcCommonReportsForm->readTrnsHistory ()->readBody ()  );
    lotos5DataRequestJsonObj.setImage     ( d->m_pcCommonReportsForm->readTrnsHistory ()->readImage () );

    lotos5DataRequestJsonObj.setMsg  ( 51 );
    lotos5DataRequestJsonObj.setSMsg ( WinningsEnums::Type_51_1_DrawResults );
    lotos5DataRequestJsonObj.setD0   ( type );
    lotos5DataRequestJsonObj.setD4   ( 0 );// D4_Sub is Date for game results. 0: no specific date, x: timeElapsed


    // Do Game
    if ( action&WinningsEnums::AllGames ) {

        lotos5DataRequestJsonObj.setD1 (0);

    } else if ( action&WinningsEnums::SpecificGame ) {

        lotos5DataRequestJsonObj.setD1 (d->m_iGameCode);
    }

    // Do Draw Date or Draw Number
    if ( action&WinningsEnums::SearchByDraw ) {

        lotos5DataRequestJsonObj.setD2 (d->m_qsDrawNumber.toInt () ); // Do Draw Number
    }

    // Do Part
    lotos5DataRequestJsonObj.setD3 (0);

    if ( action&WinningsEnums::SearchByDate && d->m_drawDate.isValid () ) { // Do Date

        QDateTime drawDate = QDateTime(d->m_drawDate);
        lotos5DataRequestJsonObj.setD4 (drawDate.toTime_t ());
    }

    QVariantMap trnsSpecificDataMap = QVariantMap ();
    trnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"), d->m_pcCommonReportsForm->readHtmlTemplate ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportHeader"), d->m_pcCommonReportsForm->readReportHeader ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportBitmap"), d->m_pcCommonReportsForm->readReportBitmap ());

    lotos5DataRequestJsonObj.setTrnsSpecificDataMap (trnsSpecificDataMap);

    QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&lotos5DataRequestJsonObj);

    return qbaJsonData;
}

/**
 * @sa requestDrawResultsSlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs draw results request transaction with c/s and update gui with the results.
 */
//void WinningsForm::requestDrawResultsSlot ( const WinningsEnums::ReportTypeFlag& action, const WinningsEnums::DrawResults& type)
void WinningsForm::requestDrawResultsSlot ( const int& action, const int& type )
{
    Q_D(WinningsForm);

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareDrawResultsTxData ( action, type );

    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////// Draw Odds Request ///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareDrawOddsTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareDrawOddsTxData ( const int& action, const int& type )
{
    Q_D ( WinningsForm );
    Q_UNUSED ( action )
    Q_UNUSED ( type )
    Q_UNUSED ( d )

    qWarning () << Q_FUNC_INFO << " not implemented yet";
    return QByteArray ();

}

/**
 * @sa requestDrawOddsSlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs draw odds request transaction with c/s and update gui with the results.
 */
//void WinningsForm::requestDrawOddsSlot ( const WinningsEnums::ReportTypeFlag& action, const WinningsEnums::DrawOdds& type )
void WinningsForm::requestDrawOddsSlot ( const int& action, const int& type )
{
    Q_D ( WinningsForm );

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareDrawOddsTxData ( action, type );


    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////// Draw Info Request ///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareDrawOddsTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareDrawInfoTxData ( const int& action, const int& type )
{
    Q_D ( WinningsForm );
    Q_UNUSED ( action )
    Q_UNUSED ( type )
    Q_UNUSED ( d )

    qWarning () << Q_FUNC_INFO << " not implemented yet";
    return QByteArray ();

}

/**
 * @sa requestDrawInfoSlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs draw info request transaction with c/s and update gui with the results.
 */
//void WinningsForm::requestDrawInfoSlot ( const WinningsEnums::ReportTypeFlag& action, const WinningsEnums::DrawInfo& type )
void WinningsForm::requestDrawInfoSlot ( const int& action, const int& type )
{
    Q_D ( WinningsForm );

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareDrawInfoTxData ( action, type );


    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// Liability Risk Request ///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareDrawOddsTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareLiabilityRiskTxData ( const int& action, const int& type )
{
    Q_D ( WinningsForm );
    Q_UNUSED ( action )
    Q_UNUSED ( type )
    Q_UNUSED ( d )

    qWarning () << Q_FUNC_INFO << " not implemented yet";
    return QByteArray ();

}

/**
 * @sa requestLiabilityRiskSlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs liability and rist request transaction with c/s and update gui with the results.
 */
//void WinningsForm::requestLiabilityRiskSlot ( const WinningsEnums::ReportTypeFlag& action, const WinningsEnums::LiabilityRisk& type )
void WinningsForm::requestLiabilityRiskSlot ( const int& action, const int& type )
{
    Q_D ( WinningsForm );

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareLiabilityRiskTxData ( action, type );


    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// Fast Play Request ////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @sa prepareFastPlayTxData
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @return data for trss lotos5
 */
QByteArray WinningsForm::prepareFastPlayTxData ( const int& action, const int& type )
{
    Q_D(WinningsForm);
    Q_UNUSED ( action )

    Lotos5DataRequestJsonObj lotos5DataRequestJsonObj;

    lotos5DataRequestJsonObj.setTxProduct ( d->m_pcCommonReportsForm->readTrnsTxProduct ());
    lotos5DataRequestJsonObj.setRxProduct ( d->m_pcCommonReportsForm->readTrnsRxProduct ());
    lotos5DataRequestJsonObj.setProtocol  ( LOTOS5 );
    lotos5DataRequestJsonObj.setPriority  ( HIGH_PRI );
    lotos5DataRequestJsonObj.setProject   ( "" );
    lotos5DataRequestJsonObj.setHeader    ( d->m_pcCommonReportsForm->readTrnsHistory ()->readHeader ());
    lotos5DataRequestJsonObj.setBody      ( d->m_pcCommonReportsForm->readTrnsHistory ()->readBody ());
    lotos5DataRequestJsonObj.setImage     ( d->m_pcCommonReportsForm->readTrnsHistory ()->readImage ());

    lotos5DataRequestJsonObj.setMsg  ( 51 );
    lotos5DataRequestJsonObj.setSMsg ( WinningsEnums::Type_51_4_LiabilityRisk );
    lotos5DataRequestJsonObj.setD0   ( type );
    lotos5DataRequestJsonObj.setD1   ( 0 );
    lotos5DataRequestJsonObj.setD2   ( 0 );
    lotos5DataRequestJsonObj.setD3   ( 0 );
    lotos5DataRequestJsonObj.setD4   ( 0 );

    QVariantMap trnsSpecificDataMap = QVariantMap ();
    trnsSpecificDataMap.insert (QStringLiteral("HtmlTemplate"), d->m_pcCommonReportsForm->readHtmlTemplate ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportHeader"), d->m_pcCommonReportsForm->readReportHeader ());
    trnsSpecificDataMap.insert (QStringLiteral("ReportBitmap"), d->m_pcCommonReportsForm->readReportBitmap ());

    lotos5DataRequestJsonObj.setTrnsSpecificDataMap (trnsSpecificDataMap);

    QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&lotos5DataRequestJsonObj);

    return qbaJsonData;
}

/**
 * @sa requestFastPlaySlot
 * @param WinningsEnums::Request_51_X_ActionFlag
 * @param WinningsEnums::Request_51_0_Type
 * @brief performs liability and rist request transaction with c/s and update gui with the results.
 */
void WinningsForm::requestFastPlaySlot ( const int& action, const int& type )
{
    Q_D ( WinningsForm );

    emit startPleaseWait ();

    QByteArray qbaJsonData = prepareLiabilityRiskTxData ( action, type );


    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult      (QVariantMap)),
                       this,                            SLOT  (processCsResultsSlot (QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );
}


/**
 * @sa WinningsForm::isPrintingAllowed
 * @return
 */
bool WinningsForm::isPrintingAllowed ( QString& )
{
    return true;
}

/**
 * @sa pendingPrintingSlot
 */
void WinningsForm::pendingPrintingSlot(QDBusPendingCallWatcher* call)
{

    QDBusPendingReply<int> reply = *call;
    eePrintErrors eRPCReply = ePrintOK;

    QString qsErrorPrintMessage = QString();

    if ( !reply.isError() ) {

        eRPCReply = eePrintErrors(reply.argumentAt<0>());

        if ( eRPCReply!= ePrintOK ) {
            qsErrorPrintMessage = ErrorHandling::getPrintErrors(eRPCReply);
        }

    } else {

        QDBusError dbusError = reply.error();
        LOG ( dbusError.message () );
        LOG ( dbusError.errorString(dbusError.type()));

        qsErrorPrintMessage = ErrorHandling::getPrintErrors(ePrintSwPrintingServiceIsUnavailable);

    }

    emit endPleaseWait ();

    if ( !qsErrorPrintMessage.isEmpty () ) {
        showMessage(qsErrorPrintMessage);
        LOG(qsErrorPrintMessage);
    }


    call->deleteLater();

}
/**
  * @sa performPrintSlot
  * @brief print data in the preview window.
  */
void WinningsForm::performPrintSlot ()
{
    Q_D ( WinningsForm );

    QString qsErrorMessage = QString ();

    if ( !isPrintingAllowed ( qsErrorMessage ) ) {

        if ( !qsErrorMessage.isEmpty () ) {
            showMessage(qsErrorMessage);
        }

    } else {

        emit startPleaseWait ();

        QString qsWinningsHtml = d->m_pcCommonReportsForm->readHtml ();

        if ( qsWinningsHtml.isEmpty () ) {

            qsErrorMessage = tr("There is no Winnings data to print");

        } else {
            DbusWrapper::PrintingServiceInterface* printingServiceIFace = DbusWrapper::getPrintingServiceInterface ();

            // load html data first to webView
            for ( quint32 i = 0; i < readNumberOfPrintCopies(); ++i ) {

                QDBusReply<int> iReply = DbusWrapper::getHtmlInterface()->loadHtmlData ( qsWinningsHtml );

                if ( iReply.isValid () ) {

                    if ( (eePrintErrors)iReply.value () !=  ePrintOK ) {

                        qsErrorMessage = ErrorHandling::getPrintErrors(eePrintErrors(iReply.value ()));

                    } else {

                        // now print and check the result.
                        QDBusPendingCall pCall = printingServiceIFace->printDataSlot ( int(PrinterTypes::Chief));
                        QDBusPendingCallWatcher *watcher = new QDBusPendingCallWatcher(pCall, this);
                        QObject::connect ( watcher, SIGNAL(&QDBusPendingCallWatcher::finished(QDBusPendingCallWatcher*)), this, SLOT(pendingPrintingSlot(QDBusPendingCallWatcher*)));
                    }


                } else {
                    qsErrorMessage = tr("Printing Service is not responding");
                }
            }
        }
        emit endPleaseWait ();
    }



    if ( !qsErrorMessage.isEmpty () ) {

        LOG(qsErrorMessage);
        showMessage(qsErrorMessage);

    } else {
        // clear preview on print. Shall it be on config?
        readCommonReportsForm ()->setHtml ("");
    }
}

QString WinningsForm::readHtml()
{
    Q_D ( WinningsForm );
    return d->m_pcCommonReportsForm->readHtml ();
}
