#include "WinningsFormWs.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "JsonOperations.h"
#include "SystemWideConstValues.h"
#include "QDebug"
#include "RequestDataFromCs.h"
#include "QDBusReply"
#include "DbusWrapper.h"

/**
 * @file WinningsFormWs_p.h
 * @class WinningsFormWsPrivate
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
class WinningsFormWsPrivate: public QObject
{
public:

    WinningsFormWsPrivate ( WinningsFormWs* qq );
    ~WinningsFormWsPrivate ();

    Q_DECLARE_PUBLIC (WinningsFormWs)
    WinningsFormWs* q_ptr;


    QString m_qsRpcMethod;
    Lotos5DataRequestJsonObj m_cLotos5DataRequestJsonObj;
    QList<RequestDataFromCs*> m_lRequestDataFromCs;
    void initializeCommonWsData ();
    QByteArray createTxData ();

};

WinningsFormWsPrivate::WinningsFormWsPrivate ( WinningsFormWs* qq  )
    : q_ptr( qq )
    , m_qsRpcMethod ( QString () )
    , m_lRequestDataFromCs  ( QList<RequestDataFromCs*> () )
{
    m_cLotos5DataRequestJsonObj.clear ();

}

WinningsFormWsPrivate::~WinningsFormWsPrivate()
{
}


WinningsFormWs::WinningsFormWs( QObject* parent )
    : WinningsForm ( parent )
    , d_ptr ( new WinningsFormWsPrivate (this) )
{
    // Polla Gol
    QObject::connect(this,SIGNAL (requestPollaGolProgram(int)),
                     SLOT(requestPollaGolProgramSlot(int)),Qt::QueuedConnection);
    // Xperto (FlexBet)
    QObject::connect(this,SIGNAL (requestFlexBetOdds(int)),
                     SLOT(requestFlexBetOddsSlot(int)),Qt::QueuedConnection);

    readCommonReportsForm ()->setTrnsTxProduct (  QStringLiteral ("WsWinningResultsRequestTx") );
    readCommonReportsForm ()->setTrnsRxProduct (  QStringLiteral ("WsWinningResultsRequestRx") );
}

// Methods for Polla Gol
void WinningsFormWs::requestPollaGolProgramSlot(const int drawNumber)
{
    Q_D(WinningsFormWs);

    emit startPleaseWait ();
    QByteArray qbaJsonData = preparePollaGolTxData (drawNumber);

    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult(QVariantMap)),
                       this,SLOT  (processCsResultsPollaSlot(QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );
}

QByteArray WinningsFormWs::preparePollaGolTxData(const int drawNumber)
{
    Lotos5DataRequestJsonObj lotos5DataRequestJsonObj;

    // Populate transaction data.
    lotos5DataRequestJsonObj.setTxProduct (QStringLiteral("WbsRestfullRequestTx"));
    lotos5DataRequestJsonObj.setRxProduct (QStringLiteral("WsPollaGolRx"));
    lotos5DataRequestJsonObj.setProtocol  (WBS_RESTFULL);
    lotos5DataRequestJsonObj.setPriority  (HIGH_PRI);
    lotos5DataRequestJsonObj.setHeader    (tr("Polla Gol Matches Request"));
    lotos5DataRequestJsonObj.setProject   (QStringLiteral("RetrieveTotoDrawProgram")); // By convention rpc method call goes to project property

    QVariantMap m;
    m.insert (QStringLiteral("params"),QVariantList () << PollaGol_CL<< drawNumber); // gameCode/activeDraw
    lotos5DataRequestJsonObj.setTrnsSpecificDataMap (m);
    QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&lotos5DataRequestJsonObj);

    return qbaJsonData;

}

void WinningsFormWs::processCsResultsPollaSlot(const QVariantMap& qvmReply)
{
    Q_D (WinningsFormWs);

    m_mHtmlData = QVariantMap();
    m_mHtmlData.clear();

    auto qsErrorMessage = QString();

    if (qvmReply.isEmpty()) {

        qsErrorMessage = tr("Remote proccess returned an empty reply");
    } else {

        QByteArray qbaPollaGolProgram = QByteArray::fromBase64 (qvmReply.value (QStringLiteral("pollaGolProgram")).toByteArray ());
        QVariantMap mPollGolInfo      = QJson::JsonOperations::JsonObjectFromData (qbaPollaGolProgram);

        QVariantList qvlMatches       = mPollGolInfo.value (QStringLiteral("information")).toList ();
        QString htmlTemplate = "/IMTSResources/LinkToYourProject/HtmlTemplates/en-us/Games/3125_results.html";
        QVariantMap mMatch = QVariantMap ();
        if(qsErrorMessage.isEmpty())
        {
            for ( quint32 iMatch = 0; iMatch<14; ++iMatch) { // Update existing model with incoming data.
                    mMatch = qvlMatches.at (iMatch).toMap ();
                    m_mHtmlData.insertMulti(QStringLiteral("matchesSpan"),QStringLiteral("CLONE_ONLY"));
                    m_mHtmlData.insertMulti(QStringLiteral("homeDescription"),mMatch.value (QStringLiteral("homeDescription")).toString());
                    m_mHtmlData.insertMulti(QStringLiteral("visitorDescription"),mMatch.value (QStringLiteral("awayDescription")).toString());
                    m_mHtmlData.insertMulti(QStringLiteral("homeScore"),mMatch.value (QStringLiteral("homeScore")).toString());
                    m_mHtmlData.insertMulti(QStringLiteral("visitorScore"),mMatch.value (QStringLiteral("awayScore")).toString());
            }
            QDBusReply<QByteArray> reply = DbusWrapper::getHtmlInterface()->makeGuiData(htmlTemplate, m_mHtmlData);
            readCommonReportsForm()->setHtml(QString::fromUtf8(reply));//qvlMatches.value(1).toString());//QString::fromUtf8(qvlMatches.value("awayScore").toByteArray().data()) );
        }
    }
    if ( !qsErrorMessage.isEmpty() ) {
        showMessage (qsErrorMessage);
    }
    emit endPleaseWait ();
}
// Methods for Polla Gol

// Methods for Xperto (FlexBet)
void WinningsFormWs::requestFlexBetOddsSlot(const int sportID)
{
    Q_D(WinningsFormWs);

    emit startPleaseWait ();
    QByteArray qbaJsonData = prepareFlexBetTxData (sportID);

    d->m_lRequestDataFromCs << new RequestDataFromCs ( this );

    QObject::connect ( d->m_lRequestDataFromCs.last (), SIGNAL(deliverCsResult(QVariantMap)),
                       this,SLOT  (processCsResultsFlexBetSlot(QVariantMap)), Qt::QueuedConnection );


    d->m_lRequestDataFromCs.last()->getCsDataAsync ( qbaJsonData );
}

QByteArray WinningsFormWs::prepareFlexBetTxData(const int sportID)
{
    Lotos5DataRequestJsonObj lotos5DataRequestJsonObj;

    // Populate transaction data.
    lotos5DataRequestJsonObj.setTxProduct (QStringLiteral("WbsRestfullRequestTx"));
    lotos5DataRequestJsonObj.setRxProduct (QStringLiteral("WsFlexBetOddsRx"));
    lotos5DataRequestJsonObj.setProtocol  (WBS_RESTFULL);
    lotos5DataRequestJsonObj.setPriority  (HIGH_PRI);
    lotos5DataRequestJsonObj.setHeader    (tr("Xperto Bet Data Request"));
    lotos5DataRequestJsonObj.setProject   (QString("L5CHSrv/GetBetData.ashx?oddprn=%1").arg(sportID)); // By convention rpc method call goes to project property

    QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&lotos5DataRequestJsonObj);

    return qbaJsonData;
}

void WinningsFormWs::processCsResultsFlexBetSlot(const QVariantMap& qvmReply)
{
    Q_D (WinningsFormWs);

    m_mHtmlData.clear();

    auto qsErrorMessage = QString();

    if (qvmReply.isEmpty()) {

        qsErrorMessage = tr("Requested report contains no data");
    } else {

        qsErrorMessage = qvmReply.value(CS_ERROR_MSG).toString();

        if(qsErrorMessage.isEmpty()) {

            QList<QVariant> qlKickOffTimes = qvmReply.values("kickOffTime");
            QList<QVariant> qlCodes = qvmReply.values("code");
            QList<QVariant> qlDescriptions = qvmReply.values("description");
            QList<QVariant> qlHomeWinOdds = qvmReply.values("homeWinOdd");
            QList<QVariant> qlDrawOdds = qvmReply.values("drawOdd");
            QList<QVariant> qlAwayWinOdds = qvmReply.values("awayWinOdd");

            int i, iNoEvents = qlKickOffTimes.size();
            QString htmlTemplate="/IMTSResources/LinkToYourProject/HtmlTemplates/en-us/Games/xperto_results.html";
            for (i = 0; i < iNoEvents; i++) {

                m_mHtmlData.insertMulti(QStringLiteral("matchesSpan"),QStringLiteral("CLONE_ONLY"));
                m_mHtmlData.insertMulti(QStringLiteral("kickOffTime"),qlKickOffTimes.at(i).toString());
                m_mHtmlData.insertMulti(QStringLiteral("code"),qlCodes.at(i).toString());
                m_mHtmlData.insertMulti(QStringLiteral("description"),qlDescriptions.at(i).toString());
                m_mHtmlData.insertMulti(QStringLiteral("homeWinOdds"),qlHomeWinOdds.at(i).toString());
                if(qlDrawOdds.at(i).toString() == "")
                    m_mHtmlData.insertMulti(QStringLiteral("drawOdds"),QStringLiteral("---"));
                else
                    m_mHtmlData.insertMulti(QStringLiteral("drawOdds"),qlDrawOdds.at(i).toString());
                m_mHtmlData.insertMulti(QStringLiteral("awayWinOdds"),qlAwayWinOdds.at(i).toString());
            }
            QDBusReply<QByteArray> reply = DbusWrapper::getHtmlInterface()->makeGuiData(htmlTemplate, m_mHtmlData);
            readCommonReportsForm()->setHtml(QString::fromUtf8(reply));
        }
    }
    if ( !qsErrorMessage.isEmpty() ) {
        showMessage (qsErrorMessage);
    }

    emit endPleaseWait ();
}
// Methods for Xperto (FlexBet)

WinningsFormWs::~WinningsFormWs()
{
}

/**
 * @sa initializeCommonWsData
 * @brief common initialization stuff. You can always override default values in qml.
 * That's why is private and there is no need to provide an interface to override it.
 */
void WinningsFormWsPrivate::initializeCommonWsData ()
{

    Q_Q ( WinningsFormWs );

    m_cLotos5DataRequestJsonObj.clear ();
    m_cLotos5DataRequestJsonObj.setTxProduct ( q->readCommonReportsForm ()->readTrnsTxProduct () );
    m_cLotos5DataRequestJsonObj.setRxProduct ( q->readCommonReportsForm ()->readTrnsRxProduct () );
    m_cLotos5DataRequestJsonObj.setProtocol  ( WEBSERVICES );
    m_cLotos5DataRequestJsonObj.setPriority  ( HIGH_PRI );
    m_cLotos5DataRequestJsonObj.setHeader    ( q->readCommonReportsForm ()->readTrnsHistory ()->readHeader () );
    m_cLotos5DataRequestJsonObj.setProject   ( q->readWsRpcMethod () );
}

QByteArray WinningsFormWsPrivate::createTxData ()
{
    QByteArray qbaJsonData;
    if( m_qsRpcMethod != "GetPollaGolProgram")
        qbaJsonData = QJson::JsonOperations::qObjectToJson (&m_cLotos5DataRequestJsonObj);
    else
    {
        QVariantMap m;
        m.insert (QStringLiteral("params"),QVariantList () << PollaGol_CL<<0); // gameCode/activeDraw
        m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (m);
        qbaJsonData = QJson::JsonOperations::qObjectToJson (&m_cLotos5DataRequestJsonObj);
    }

    return qbaJsonData;
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////
QString WinningsFormWs::readWsRpcMethod () const
{
    Q_D ( const WinningsFormWs );
    return d->m_qsRpcMethod;
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////

void WinningsFormWs::setWsRpcMethod ( const QString& newVal )
{
    Q_D ( WinningsFormWs );

    if ( d->m_qsRpcMethod == newVal ) return;
    d->m_qsRpcMethod = newVal;
    emit wsRpcMethodChanged ();
}

/**
 * @brief WinningsFormWs::prepareWinningNumberTxData
 * @param iAction
 * @param iType
 * @return
 */

QByteArray WinningsFormWs::prepareWinningNumberTxData ( const int& iAction, const int& iType )
{

    Q_D ( WinningsFormWs );
    d->initializeCommonWsData ();

    // We will use the following map to initialize using the WsWinningResultsRequestTx object in Trss the
    // input parameters for the WS method. C/S ws method needs to be more flexible on this.
    QVariantMap mTrnsSpecificDataMap;


    if ( iAction&WinningsEnums::AllGames ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("allGames"), true );
    }

    if ( iAction&WinningsEnums::SpecificGame ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("gameId"), readGameCode () );
    }

    if ( iType == WinningsEnums::Winnings_LastDraw) {

        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), 0 ); // The draw number (if draw is 0 results for last draw will be returned)

    } else if ( iType == WinningsEnums::Winnings_LastXDraws) {

        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), readNumberOfDraws () );

    } else if ( iType == WinningsEnums::Winnings_SpecificDraw) {
        mTrnsSpecificDataMap.insert (QStringLiteral("selectedDraw"), readDrawNumber ().toInt() );

    } else if ( iType == WinningsEnums::Winnings_SpecificDate) {

#pragma message("WATCH OUT!!!. C/S for the specific report does not convert GMT time to local time so add 5 hours to the time we send")
        // To be honnest I'm bored to override this now.
        mTrnsSpecificDataMap.insert (QStringLiteral("selectedDate"), QDateTime(readDrawDate ()).addSecs (3600*5).toTime_t ());
    }
    d->m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (mTrnsSpecificDataMap);


    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawResultsTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawResultsTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );
    d->initializeCommonWsData ();


    // We will use the following map to initialize using the WsWinningResultsRequestTx object in Trss the
    // input parameters for the WS method. C/S ws method needs to be more flexible on this.
    QVariantMap mTrnsSpecificDataMap;

    if ( iAction&WinningsEnums::AllGames ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("allGames"), true );
    }

    if ( iAction&WinningsEnums::SpecificGame ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("gameId"), readGameCode () );
    }

    if ( iType == WinningsEnums::Winnings_LastDraw) {
        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), 0 );
    }

    d->m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (mTrnsSpecificDataMap);

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawOddsTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawOddsTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawInfoTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawInfoTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareLiabilityRiskTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareLiabilityRiskTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareFastPlayTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareFastPlayTxData  ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}
