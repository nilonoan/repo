#ifndef WINNINGSFORMWS_H
#define WINNINGSFORMWS_H

#include "WinningsForm.h"

class WinningsFormWsPrivate;
class WinningsFormWs : public WinningsForm
{
    Q_OBJECT

    Q_PROPERTY ( QString wsRpcMethod  READ readWsRpcMethod  WRITE setWsRpcMethod NOTIFY wsRpcMethodChanged FINAL )
public:
    explicit WinningsFormWs ( QObject* parent = 0 );
    ~WinningsFormWs ();


    QString readWsRpcMethod  () const;
    void setWsRpcMethod ( const QString& );

Q_SIGNALS:
    void wsRpcMethodChanged ();
    void requestPollaGolProgram( int drawNumber);
    void requestFlexBetOdds( int sportID);

private:
    QScopedPointer<WinningsFormWsPrivate> const d_ptr;
    Q_DECLARE_PRIVATE ( WinningsFormWs )
    Q_DISABLE_COPY ( WinningsFormWs )

    QByteArray prepareWinningNumberTxData ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray prepareDrawResultsTxData   ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray prepareDrawOddsTxData      ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray prepareDrawInfoTxData      ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray prepareLiabilityRiskTxData ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray prepareFastPlayTxData      ( const int& iAction, const int& iType ) Q_DECL_OVERRIDE;
    QByteArray preparePollaGolTxData();
private slots:
    void requestPollaGolProgramSlot(const int drawNumber);
    void requestFlexBetOddsSlot( const int sportID);
protected:
    virtual QByteArray preparePollaGolTxData(const int drawNumber);
    virtual QByteArray prepareFlexBetTxData(const int sportID);
    QVariantMap m_mHtmlData;
protected slots:
    virtual void processCsResultsPollaSlot(const QVariantMap&);
    virtual void processCsResultsFlexBetSlot(const QVariantMap&);
};

#endif // WINNINGSFORMWS_H
