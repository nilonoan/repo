/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
 * @file GamesList.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */

#include "GamesList.h"
#include "JsonOperations.h"
#include "LocalEventLoggerEvents.h"
#include "Configuration/Games/GamesConfig.h"
#include "Components/Buttons/GameButton.h"
#include "Plays/ExternalPlay.h"
#if defined(IMTS_LINUX) || defined(IMTS_ARM)
#include "DbusWrapper.h"
#elif defined(IMTS_ANDROID)
#include "HostCallWrapper.h"
#endif
#define IS_FASTPLAYNEW(iSubGameCode) (iSubGameCode >= 100000) && (iSubGameCode <= 199999) ? true : false
#define IS_FASTPLAY(iGameCode)  ((iGameCode >= 6000 && iGameCode <= 6999)? true : false)

static const int QP_GAME_OFFSET = 100000; /*!<  constant offset we use to identify custopQp views. 100000+gameCode means game has CustomQp. Check games' module */

class GamesListPrivate : public QObject
{
public:
	GamesListPrivate ( QObject *parent = 0 );
	~GamesListPrivate();

	QList<GameButton*> m_ListOfGameButtons;
	QList<GameButton*> m_ListOfGameButtons2;
	QList<GameButton*> m_ListOfFastPlayGameButtons;


};


GamesListPrivate::GamesListPrivate ( QObject *parent )
	: QObject ( parent )
{
	m_ListOfGameButtons.clear();
	m_ListOfGameButtons2.clear ();
	m_ListOfFastPlayGameButtons.clear ();
}

GamesListPrivate::~GamesListPrivate ()
{

}

/**
 * @sa GamesList
 * @param QObject parent
 * @brief GamesList constructor. Creates the GameButtons list you see on the screen.
 * It contacts SystemConfigurationManager to provide the a map of all available games'
 * configuration data.
 */
GamesList::GamesList( QObject *parent )
	: QObject(parent)
	, d_ptr ( new GamesListPrivate )
{

	qRegisterMetaType<ExternalPlay>("ExternalPlay");

	getAvailableGamesFromConfigData();
	QObject::connect ( this, &GamesList::gameLogoButtonPressed,
					   this, &GamesList::showGameSlot, Qt::QueuedConnection );

	QObject::connect ( this, &GamesList::customQpPressed,
					   this, &GamesList::customQpPressedSlot, Qt::QueuedConnection);

	QObject::connect ( this, &GamesList::fastQpPressed,
					   this, &GamesList::fastQpPressedSlot, Qt::QueuedConnection);

	QObject::connect ( this, &GamesList::fastGamePlayPressed,
					   this, &GamesList::fastGamePlayPressedSlot, Qt::QueuedConnection);

	QObject::connect ( this, &GamesList::miscsQpPressed,
					   this, &GamesList::miscsQpPressedSlot, Qt::QueuedConnection);

	QObject::connect ( this, &GamesList::disableGame, this, &GamesList::disableGameSlot);
}

GamesList::~GamesList ()
{
	Q_D ( GamesList );
	qDeleteAll(d->m_ListOfGameButtons);
	qDeleteAll(d->m_ListOfGameButtons2);
	qDeleteAll(d->m_ListOfFastPlayGameButtons);
	d->m_ListOfGameButtons.clear ();
	d->m_ListOfGameButtons2.clear ();
	d->m_ListOfFastPlayGameButtons.clear ();

}

/**
 * @sa populateGamesList
 * @param: GamesConfig
 * @return: void
 * @brief It creates a new game button and adds it to the games list model.
 */
void GamesList::populateGamesList( GamesConfig& gameConfig  )
{
	Q_D ( GamesList );

	qint8 iListNumber = gameConfig.readListNumber ();

	if ( iListNumber != 1 ) {
		return;
	}

	GameButton* pGameButton = new GameButton ( this );

	if ( !gameConfig.readGameLogoImageLocation().isEmpty() ) { // If there exists logo location get it and ignore text. Otherwise just use text.

		pGameButton->setGameLogoImg ( gameConfig.readGameLogoImageLocation() );

	} else { // if you forget to set an image in config show game's name

		pGameButton->setGameName ( gameConfig.readGameName () );
	}

	pGameButton->setGameInfoImg ( gameConfig.readGameInfoImageLocation() );
	pGameButton->setGameQpImg ( gameConfig.readGameQpImageLocation() );
	pGameButton->setGameMoreImg ( gameConfig.readGameMoreImageLocation () );
    pGameButton->setCustomQp ( gameConfig.readCustomQp () );

	// We need to let our button object know, what's its gamecode is. So when it is pressed
	// it sends it back to C++ data model so that the game code is propagated to the games
	// center in order to use it to get the config for the specific game. Just having
	// the button's index or Game's name was not good enough because the QMap config has as
	// a key the game code.
	pGameButton->setGameCode( gameConfig.readGameCode() );

	pGameButton->setFastQp ( gameConfig.readFastQpPlayList () );

	qint8 iGamePosAt = gameConfig.readDisplayAtPos ();
	if ( iGamePosAt >= 0 && iGamePosAt < d->m_ListOfGameButtons.size () ) {
		d->m_ListOfGameButtons.replace (iGamePosAt, pGameButton);
	} else {
        if ( d->m_ListOfGameButtons.size() ) {
		d->m_ListOfGameButtons.removeLast ();
	}
}
}

/**
 * @sa populateGamesList2
 * @param: GamesConfig
 * @return: void
 * @brief It creates a new game button and adds it to the games list model.
 */
void GamesList::populateGamesList2( GamesConfig& gameConfig )
{
	Q_D ( GamesList );

	qint8 iListNumber = gameConfig.readListNumber ();

	if ( iListNumber != 2 ) {
		return;
	}

	GameButton* pGameButton = new GameButton ( this );

	if ( !gameConfig.readGameLogoImageLocation().isEmpty() ) { // If there exists logo location get it and ignore text. Otherwise just use text.

		pGameButton->setGameLogoImg ( gameConfig.readGameLogoImageLocation() );

	} else { // if you forget to set an image in config show game's name

		pGameButton->setGameName ( gameConfig.readGameName () );
	}

	pGameButton->setGameInfoImg ( gameConfig.readGameInfoImageLocation() );
	pGameButton->setGameQpImg ( gameConfig.readGameQpImageLocation() );
	pGameButton->setGameMoreImg ( gameConfig.readGameMoreImageLocation () );

	// We need to let our button object know, what's its gamecode is. So when it is pressed
	// it sends it back to C++ data model so that the game code is propagated to the games
	// center in order to use it to get the config for the specific game. Just having
	// the button's index or Game's name was not good enough because the QMap config has as
	// a key the game code.
	pGameButton->setGameCode    ( gameConfig.readGameCode() );
	pGameButton->setSubGameCode ( gameConfig.readSubGameCode () );
	pGameButton->setFastQp      ( gameConfig.readFastQpPlayList () );

	qint8 iGamePosAt = gameConfig.readDisplayAtPos ();
	if ( iGamePosAt >= 0 ) {
		d->m_ListOfGameButtons2.replace (iGamePosAt, pGameButton);
	} else {
		d->m_ListOfGameButtons2.removeLast ();
	}
}

/**
 * @sa populateFastPlayGamesList
 * @param: GamesConfig
 * @return: void
 * @brief It creates a new game button and adds it to the games list model.
 */
void GamesList::populateFastPlayGamesList( GamesConfig& gameConfig  )
{
	Q_D ( GamesList );

	GameButton* pGameButton = new GameButton ( this );

	if ( !gameConfig.readGameLogoImageLocation().isEmpty() ) { // If there exists logo location get it and ignore text. Otherwise just use text.

		pGameButton->setGameLogoImg ( gameConfig.readGameLogoImageLocation() );

	} else { // if you forget to set an image in config show game's name

		pGameButton->setGameName ( gameConfig.readGameName () );
	}

	pGameButton->setGameInfoImg ( gameConfig.readGameInfoImageLocation() );
	pGameButton->setGameQpImg ( gameConfig.readGameQpImageLocation() );
	pGameButton->setGameMoreImg ( gameConfig.readGameMoreImageLocation () );

	// We need to let our button object know, what's its gamecode is. So when it is pressed
	// it sends it back to C++ data model so that the game code is propagated to the games
	// center in order to use it to get the config for the specific game. Just having
	// the button's index or Game's name was not good enough because the QMap config has as
	// a key the game code.
	pGameButton->setGameCode    ( gameConfig.readGameCode() );
	pGameButton->setSubGameCode ( gameConfig.readSubGameCode () );
	pGameButton->setFastQp      ( gameConfig.readFastQpPlayList () );

	qint8 iGamePosAt = gameConfig.readDisplayAtPos ();
	if ( iGamePosAt >= 0 ) {
		d->m_ListOfFastPlayGameButtons.replace (iGamePosAt, pGameButton);
	} else {
		d->m_ListOfFastPlayGameButtons.removeLast ();
	}
}


/**
 * @sa getAvailableGamesFromConfigData
 * @brief This routine gets the configuration data for every game provided that its config file exists.
 * // NOTE: The configuration data contained in a QMultiMap where key: xxxx and key:yyyyCR map the same
 * game config data. xxxx is the gameCode yyyyCR is the gameRiga (CR:camera riga).
 * When we iterate the retrieved config map, we just need to ignore one or the other, so that we populate
 * the gamesList button only ONCE depending on what key we choose. I have picked to use gameCode, and therefore
 * I ignore the config data retrieved by the key that contains the string "CR".
 */
void GamesList::getAvailableGamesFromConfigData ()
{

	Q_D ( GamesList );

	QVariantMap qvmGameConfigMap = QVariantMap();

	DbusWrapper::getAllGamesConfig(qvmGameConfigMap);

	if ( qvmGameConfigMap.isEmpty() ) {
		LOG("Remote proccess returned an empty reply");
	} else {

		GamesConfig gamesConfig;

		QVariantMap::const_iterator i = qvmGameConfigMap.constBegin();


		// Pre-initialize lists with null values.
		while ( i != qvmGameConfigMap.constEnd() ) {

			QJson::JsonOperations::JsonToqObject(i.value().toByteArray(), &gamesConfig);

			if ( IS_FASTPLAYNEW(i.key ().toUInt () ) ) {

			   d->m_ListOfFastPlayGameButtons << nullptr;

            } else if ( IS_FASTPLAY( (i.key()).toUInt () ) ) {

               d->m_ListOfFastPlayGameButtons << nullptr;

			} else if ( gamesConfig.readListNumber () == 2 ) {

				d->m_ListOfGameButtons2 << nullptr;

			} else {

				d->m_ListOfGameButtons << nullptr;

			}
			gamesConfig.clearConfig ();
			++i;
		}

		i = qvmGameConfigMap.constBegin();
		while ( i != qvmGameConfigMap.constEnd() ) {

			QJson::JsonOperations::JsonToqObject(i.value().toByteArray(), &gamesConfig);

            if ( IS_FASTPLAYNEW(i.key ().toUInt () ) || IS_FASTPLAY(i.key ().toUInt () )  ) {

				populateFastPlayGamesList ( gamesConfig );

			} else if ( gamesConfig.readListNumber () == 2 ) {

				populateGamesList2 ( gamesConfig );

			} else {

				populateGamesList ( gamesConfig );
			}

			gamesConfig.clearConfig ();
			++i;
		}
	}
}

/**
 * @sa readGamesList
 * @return: a QList of available gameButton objects
 * @brief Returns the list of created game buttons
 */
#if defined (QtQuick2)
QQmlListProperty<GameButton> GamesList::readGamesList ()
{
	Q_D ( GamesList );
	return QQmlListProperty<GameButton>( this, d->m_ListOfGameButtons );
}
#else
QDeclarativeListProperty<GameButton> GamesList::readGamesList ()
{
	Q_D ( GamesList );
	return QDeclarativeListProperty<GameButton>( this, d->m_ListOfGameButtons );
}
#endif

/**
 * @sa readGamesList2
 * @return: a QList of available gameButton objects
 * @brief Returns the list of created game buttons
 */
#if defined (QtQuick2)
QQmlListProperty<GameButton> GamesList::readGamesList2 ()
{
	Q_D ( GamesList );
	return QQmlListProperty<GameButton>( this, d->m_ListOfGameButtons2 );
}
#else
QDeclarativeListProperty<GameButton> GamesList::readGamesList2 ()
{
	Q_D ( GamesList );
	return QDeclarativeListProperty<GameButton>( this, d->m_ListOfGameButtons2 );
}
#endif


/**
 * @sa readFastPlaysGamesList
 * @return: a QList of available fast play game button objects
 * @brief Returns the list of created game buttons
 */
#if defined (QtQuick2)
QQmlListProperty<GameButton> GamesList::readFastPlaysGamesList ()
{
	Q_D ( GamesList );
	return QQmlListProperty<GameButton>( this, d->m_ListOfFastPlayGameButtons );
}
#else
QDeclarativeListProperty<GameButton> GamesList::readFastPlaysGamesList ()
{
	Q_D ( GamesList );
	return QDeclarativeListProperty<GameButton>( this, d->m_ListOfFastPlayGameButtons );
}
#endif

/**
 * @sa getGameButton
 * @param int index
 * @return : pointer to GameButton object
 * @brief returns the GameButton object mapped by the index param passed in.
 * I don't see that we are using it at the moment, but leave in once I wrote it.
 */
GameButton* GamesList::getGameButton( const int& index ) const
{
	Q_D ( const GamesList );
	return (index >= 0 && index < d->m_ListOfGameButtons.count()) ? d->m_ListOfGameButtons.at(index) : 0;
}

/**
 * @sa getGameButton2
 * @param int index
 * @return : pointer to GameButton object
 * @brief returns the GameButton object mapped by the index param passed in.
 * I don't see that we are using it at the moment, but leave in once I wrote it.
 */
GameButton*GamesList::getGameButton2(const int& index) const
{
	Q_D ( const GamesList );
	return (index >= 0 && index < d->m_ListOfGameButtons2.count()) ? d->m_ListOfGameButtons2.at(index) : 0;
}

/**
 * @sa getFastPlayGameButton
 * @param int index
 * @return : pointer to FastGameButton object
 * @brief returns the FastGameButton object mapped by the index param passed in.
 * I don't see that we are using it at the moment, but leave in once I wrote it.
 */
GameButton* GamesList::getFastPlayGameButton( const int& index ) const
{
	Q_D ( const GamesList );
	return (index >= 0 && index < d->m_ListOfFastPlayGameButtons.count()) ? d->m_ListOfFastPlayGameButtons.at(index) : 0;
}



/**
  * @sa customQpPressedSlot
  * @param int iGameCode
  * @brief asks game center to show custom qp for the associative game.
  */
void GamesList::customQpPressedSlot( const int& iGameCode )
{

	LOG( QString("Custom QP play for game: %1").arg(iGameCode) );

	DbusWrapper::getGameOperationsInterface()->showGamesCenterSlot ( iGameCode+QP_GAME_OFFSET );
}

/**
 * @sa fastQpPressedSlot
 * @param External play data. Object comes from QML. This is where it lives.
 */
void GamesList::fastQpPressedSlot ( ExternalPlay *pcExternalPlay )
{
	// qDebug () << "fast QP values: " << qvmAdditionalGame;
	if ( pcExternalPlay->readCustomData ().isEmpty () ) {

		DbusWrapper::getGameOperationsInterface()->addQpPlaySlot ( QJson::JsonOperations::qObjectToJson (pcExternalPlay));

	} else {

		if ( pcExternalPlay->readCustomData ().value (QStringLiteral("StandAlone")).toBool () ) {

			QVariantMap mAdditionalGame;
			mAdditionalGame.insert (QStringLiteral("GameCode"),             pcExternalPlay->readGameCode ());
			mAdditionalGame.insert (QStringLiteral("NumberOfAreas"),        pcExternalPlay->readNumberOfAreas ());
			mAdditionalGame.insert (QStringLiteral("NumberOfDraws"),        pcExternalPlay->readNumberOfDraws ());
			mAdditionalGame.insert (QStringLiteral("NumberOfAdvanceDraws"), pcExternalPlay->readFutureDraws ());
			mAdditionalGame.insert (QStringLiteral("Multiplier"),           pcExternalPlay->readMultiplier ());
			mAdditionalGame.insert (QStringLiteral("NumberOfTickets"),      pcExternalPlay->readNumberOfDraws ());
			mAdditionalGame.insert (QStringLiteral("AdditionalGameData"),   pcExternalPlay->readAdditionalGamePerArea ());

			DbusWrapper::getGameOperationsInterface()->addAdditionalGame ( QJson::JsonOperations::VariantToByteArray (mAdditionalGame ) );

		}

	}

}

/**
 * @sa fastGamePlayPressedSlot
 * @param External play data. Object comes from QML. This is where it lives.
 */
void GamesList::fastGamePlayPressedSlot ( ExternalPlay* pcExternalPlay )
{
	DbusWrapper::getGameOperationsInterface()->addFastGamePlaySlot ( QJson::JsonOperations::qObjectToJson (pcExternalPlay));
}

/**
 * @sa miscsQpPressedSlot
 * @brief places a miscellaneous game play request , like Works, with game center. Per project implementation (e.g. IMTSProjectMT)
 */
void GamesList::miscsQpPressedSlot()
{
}

/**
  * @sa showGameSlot
  * @param int iGameCode
  * @brief contact games center to show the game indicated by the input parameter
  */
void GamesList::showGameSlot( const int& iGameCode )
{

	LOG( QString("Show game: %1").arg(iGameCode) );
	DbusWrapper::getGameOperationsInterface()->showGamesCenterSlot ( iGameCode ); // D-Bus call to games operations to show game with iGameCode.

}

/**
 * @sa disableGameSlot
 * @param int iGameCode
 * @brief disables game given by the input parameter
 */
void GamesList::disableGameSlot ( const int& iGameCode )
{
	Q_D ( GamesList );
	foreach ( GameButton* gameButton, d->m_ListOfGameButtons ) {
		if ( gameButton->readGameCode () == iGameCode ) {
			gameButton->setGameEnabled (false);
			break;
		}
	}

	foreach ( GameButton* gameButton2, d->m_ListOfGameButtons2 ) {
		if ( gameButton2->readGameCode () == iGameCode ) {
			gameButton2->setGameEnabled (false);
		}
	}

	foreach ( GameButton* fastPlayGameButton, d->m_ListOfFastPlayGameButtons ) {
		if ( fastPlayGameButton->readGameCode () == iGameCode ) {
			fastPlayGameButton->setGameEnabled (false);
			break;
		}
	}
}

/**
 * @sa getAvailableGames
 * @return game codes for available games.
 */
QList<int> GamesList::getAvailableGames ()
{
	Q_D ( GamesList );
	QList<int> lGameCodes = QList<int>();

	foreach ( GameButton* gameButton, d->m_ListOfGameButtons ) {
		if ( gameButton->readGameCode () != 0 ) {
			lGameCodes.append (gameButton->readGameCode () );
		}
	}

	foreach ( GameButton* gameButton2, d->m_ListOfGameButtons2 ) {
		if ( gameButton2->readGameCode () != 0 ) {
			lGameCodes.append ( gameButton2->readGameCode () );
		}
	}

	foreach ( GameButton* gameButton, d->m_ListOfFastPlayGameButtons ) {
		if ( gameButton->readGameCode () != 0 ) {
			lGameCodes.append (gameButton->readGameCode () );
			lGameCodes.append (gameButton->readSubGameCode () );
		}
	}

	return lGameCodes;
}

/**
 * @sa updateFastPlayGamesListSlot
 * @return: void
 * @brief rebuilds the model and updated properties
 */
void GamesList::updateFastPlayGamesListSlot ()
{
	// we'll see in the future. Not now.
}



