/******************************************************************************
 Copyright (C) 2016

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once
#ifndef WBSRESTFULLSTRATEGY_H
#define WBSRESTFULLSTRATEGY_H

#include <QtCore/QObject>
#include "BusinessLogic/ProtocolStrategyInterface.h"
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <QHostAddress>
#include "PluginManager.h"

/**
 * @file WbsRestfullStrategy.h
 * @class WbsRestfullStrategy
 * @brief Concrete Strategy for LotosX Communication protocol
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0

 Implements the way transactions (tx/rx) should be placed when LotosX strategy is
 selected by the user. This class is implemented as a Singleton.
 */
class QTimer;
class WbsRestfullStrategy : public ProtocolStrategyInterface
{
	Q_OBJECT
	Q_DISABLE_COPY(WbsRestfullStrategy)

public:
	static WbsRestfullStrategy *getWbsRestfullStrategyInstance (QObject *parent);
	static void deleteWbsRestfullStrategyInstance ();

	/**
	 * @sa processItCssMsgRequest
	 * @param transaction type
	 * @param training true/false
	 * @param gui data in json format
	 * @param buffer to be initialized with WbsRestfull json rpc data.
	 * @return eeTxStatus
	 * @brief This routine is responsible to get a transmit product and initialize the given buffer
	 * with WbsRestfull json rpc data. It returns the status of the request.
	 */
	virtual eeTxStatus processItCssMsgRequest( const QString& qsTransactionType,
											   const bool&bTraining,
											   const QByteArray&qbaGuiData,
											   QByteArray& qbaWbsRestfullTxData);

	/**
	 * @sa processCssItMessage
	 * @param transaction's type
	 * @param training true/false
	 * @param data collected from user interface within a QByteArray
	 * @param data transmitted to C/S
	 * @param data received from C/S
	 * @param qvmDataForClient: the reply data destined for client that placed the call.
	 * @brief Pure virtual Method which implements the business logic for Rx Packet
	 */
	virtual void processCssItMessage( const QString& qsTransactionType,
									  const bool& bTraining,
									  const QByteArray& qbaGuiData,
									  const QByteArray&,
									  const QByteArray& qbaWebServiceRxData,
									  QVariantMap& qvmDataForGui );

	/**
	 * @sa transmitPacket
	 * @param the connection id the data are meant to be.
	 * @param training
	 * @param gui data stored in a map
	 * @param c/s binary Tx data.
	 * @return the transmission error prior handing the data for transmission to the server.
	 */
	/*virtual*/ eeCommError transmitPacket (const int& iConnId,
											const bool &bTraining,
											const TransmissionType&,
											const QVariantMap& qvmGuiDataMap,
											const QByteArray& qbaCsTxData);


signals:
	void dataTransmissionRequest ();

private:
	explicit WbsRestfullStrategy();
	explicit WbsRestfullStrategy(QObject* parent = Q_NULLPTR);
	~WbsRestfullStrategy();

	static WbsRestfullStrategy * m_WbsRestfullStrategyInstance;

	PluginManager* m_PluginManager;

	eeTxStatus finalizeWbsRestfullTxData( QByteArray& qbaWbsRestfullTxData );
	void updateTransactionHistory ( const bool &bIsTraining,
									const QByteArray &qbaGuiData,
									const QVariantMap& qvmDataForGui,
									const QByteArray& qbaWbsRestfullRxData );

	QNetworkAccessManager* m_pcNetworkManager;
	QNetworkReply* m_pcNetworkReply;
	QNetworkRequest m_NetworkRequest;
	int m_iConnId;
	QVariantMap m_qvmGuiDataMap;
	QByteArray m_qbaCsTxData;
	QUrl m_primaryUrl;
	QUrl m_secondaryUrl;
	QUrl m_activeUrl;
	QList<QMetaObject::Connection>  m_lConnections;
	QHostAddress m_wsPrimaryHost;
	QHostAddress m_wsSecondaryHost;
	quint16 m_iPrimaryUrlPort;
	quint16 m_iSecondaryUrlPort;
	QTimer* m_guardTimer;
	quint32 m_iWebserviceTimeout;
    bool m_bFlexBetOdds; // stergioua : Member added for CL, due to the URL for FlexBet odd retrieval being different than for other WS calls


private slots:
	void rpcRequestFinishedSlot ( QNetworkReply* );
	void dataTransmissionRequestSlot ();
	void connectionTimeOutSlot ();

};

#endif // WBSRESTFULLSTRATEGY_H
