/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
 * @file WbsRestfullStrategy.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */

#include <QtCore/QMutex>
#include "WbsRestfullStrategy.h"
#include "LocalEventLoggerEvents.h"
#include "Interfaces/ItCssMessagePayloadInterface.h"
#include "Interfaces/CssItParseMessageInterface.h"
#include "Interfaces/ProtocolFactoryPluginInterface.h"
#include "SystemWideConstValues.h"
#include "JsonOperations.h"
#include "DbusWrapper.h"
#include <QDateTime>
#include "Crypt/SimpleCrypt.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "PlaceServerManagerRequest.h"
#include "ClientServerDefinitions.h"
#include "UpdateTransactionHistoryJsonObj.h"
#include "FormatDate/FormatDate.h"
#include "GetConfigValue.h"
#include <QtCore/QTimer>
#include "Compression/IMTSCompressor.h"

const int TX_BUFFER_SIZE = 4096;

WbsRestfullStrategy* WbsRestfullStrategy::m_WbsRestfullStrategyInstance = Q_NULLPTR;


WbsRestfullStrategy::WbsRestfullStrategy(QObject *parent)
	: ProtocolStrategyInterface ( parent )
	, m_pcNetworkReply          ( nullptr )
	, m_iConnId                 ( 0 )
	, m_qvmGuiDataMap           ( QVariantMap () )
	, m_wsPrimaryHost           ( QHostAddress () )
	, m_wsSecondaryHost         ( QHostAddress () )
	, m_iPrimaryUrlPort         ( 0 )
	, m_iSecondaryUrlPort       ( 0 )
	, m_iWebserviceTimeout      ( 40000 )
    , m_bFlexBetOdds            ( false ) // stergioua : Default value is false
{

	// this timer guards requests. If a reply is not received within the pre-defined timeout value the software will abort.
	m_guardTimer = new QTimer (this);
	m_guardTimer->setSingleShot (true);
	connect ( m_guardTimer, SIGNAL(timeout()), this, SLOT(connectionTimeOutSlot()));

	m_iWebserviceTimeout = GetConfigValue::webServiceTimeout ();
	LOG(QString("WbsRestfull wait timeout was set to: %1seconds").arg (m_iWebserviceTimeout/1000));

	m_lConnections.clear ();
	m_qbaCsTxData.fill('\0',TX_BUFFER_SIZE);

	QDBusReply<QVariantMap> reply = DbusWrapper::getNvramComItInterface ()->getWebServicesServersAndPorts ();

	QVariantMap m = reply.value ();
	if ( !m.isEmpty () ) {
		m_wsPrimaryHost     = QHostAddress ( m.value ("PrimaryUrl").toUInt () );
		m_wsSecondaryHost   = QHostAddress ( m.value ("SecondaryUrl").toUInt () );
		m_iPrimaryUrlPort   = quint16 ( m.value ("PrimaryPort").toUInt () );
		m_iSecondaryUrlPort = quint16 ( m.value ("SecondaryPort").toUInt () );

	} else {
		LOG ("Failed to retrieve WbsRestfull urls and port");
	}

	m_primaryUrl.setUrl   ( QString("http://%1:%2/lotoswebservice/").arg (m_wsPrimaryHost.toString ()).arg (QString::number (m_iPrimaryUrlPort)));
	m_secondaryUrl.setUrl ( QString("http://%1:%2/lotoswebservice/").arg (m_wsSecondaryHost.toString ()).arg (QString::number (m_iSecondaryUrlPort)));
	m_activeUrl.setUrl    ( m_primaryUrl.toString () );

	LOG(QString("PrimaryUrl: %1").arg (m_primaryUrl.toString ()));
	LOG(QString("SecondaryUrl: %1").arg (m_secondaryUrl.toString ()));

	m_NetworkRequest.setUrl ( m_activeUrl );

	m_PluginManager = PluginManager::getPluginManagerInstance ();

	// Well load plugin for the first time, not from inside the path transmission/reception takes
	// place because I faced problems when loading the plugin for the first time. !!!!????? Don't know
	// what that is/was.
	QObject *plugin = Q_NULLPTR;
#ifdef IMTS_TXRX_DEBUG
	plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin_d"));
#elif IMTS_TXRX_RELEASE
	plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin"));
#endif

	if (!plugin) {
		LOG( ErrorHandling::getTxPathError( TX_FAILED_TO_LOAD_TXRX_PLUGIN ));
	}


	QMetaObject::Connection connection = QObject::connect ( DbusWrapper::getNvramManagerInterface (), &com::intralot::IMTSScm::NvramManager::comItFileChanged, [this](){

		QDBusReply<QVariantMap> reply = DbusWrapper::getNvramComItInterface ()->getWebServicesServersAndPorts ();

		if ( reply.isValid () ) {
			QVariantMap m = reply.value ();
			if ( !m.isEmpty () ) {

				bool bPrimaryChanged = false;
				bool bSecondaryChanged = false;

				if ( m_wsPrimaryHost != QHostAddress ( m.value ("PrimaryUrl").toUInt () ) ) {
					m_wsPrimaryHost = QHostAddress ( m.value ("PrimaryUrl").toUInt () );
					bPrimaryChanged = true;
				}

				if ( m_wsSecondaryHost != QHostAddress ( m.value ("SecondaryUrl").toUInt () ) ) {
					m_wsSecondaryHost = QHostAddress ( m.value ("SecondaryUrl").toUInt () );
					bSecondaryChanged = true;
				}

				if ( m_iPrimaryUrlPort  != quint16 ( m.value ("PrimaryPort").toUInt () ) ) {
					m_iPrimaryUrlPort = quint16 ( m.value ("PrimaryPort").toUInt () );
					bPrimaryChanged = true;
				}

				if ( m_iSecondaryUrlPort != quint16 ( m.value ("SecondaryPort").toUInt () ) ) {
					m_iSecondaryUrlPort = quint16 ( m.value ("SecondaryPort").toUInt () );
					bSecondaryChanged = true;
				}

				if ( bPrimaryChanged ) {
					m_primaryUrl.setUrl ( QString("http://%1:%2/lotoswebservice/").arg (m_wsPrimaryHost.toString ()).arg (QString::number (m_iPrimaryUrlPort)));
					m_activeUrl.setUrl (m_primaryUrl.toString ());
				}

				if ( bSecondaryChanged ) {
					m_secondaryUrl.setUrl ( QString("http://%1:%2/lotoswebservice/").arg (m_wsSecondaryHost.toString ()).arg (QString::number (m_iSecondaryUrlPort)));
				}

				LOG(QString("Updated PrimaryUrl: %1").arg (m_primaryUrl.toString ()));
				LOG(QString("Updated SecondaryUrl: %1").arg (m_secondaryUrl.toString ()));
			}

		} else {

			LOG(QStringLiteral("Error updating new webserver data from comm data"));
		}

	});
	m_lConnections.append (connection);

	m_pcNetworkManager = new QNetworkAccessManager ( this );

	QObject::connect ( this, &WbsRestfullStrategy::dataTransmissionRequest,
					   this, &WbsRestfullStrategy::dataTransmissionRequestSlot, Qt::QueuedConnection );

}

WbsRestfullStrategy::~WbsRestfullStrategy ()
{
	for ( int i = 0; i < m_lConnections.size (); ++i ) {
		QObject::disconnect (m_lConnections.at (i));
	}
}

/**
 * @sa getWbsRestfullStrategyInstance
 * @param the parent
 * @return a pointer to WbsRestfullStrategy object
 * @brief This routine is used to return an instance of the Strategy object.  If not created it creates the object.
 * It implements the Double-Check Locking Pattern (DCLP).  DCLP is not panacea but works well for single CPUs.
 */
WbsRestfullStrategy *WbsRestfullStrategy::getWbsRestfullStrategyInstance (QObject *parent)
{
	if (!m_WbsRestfullStrategyInstance) {
		QMutex mutex;
		mutex.lock();
		if (!m_WbsRestfullStrategyInstance) {
			m_WbsRestfullStrategyInstance = new WbsRestfullStrategy(parent);
		}
		mutex.unlock();
	}
	return m_WbsRestfullStrategyInstance;
}

/**
 * @sa deleteWbsRestfullStrategyInstance
 * @brief This routine deletes the creates WbsRestfullStrategy object
 */
void WbsRestfullStrategy::deleteWbsRestfullStrategyInstance ()
{
	if (m_WbsRestfullStrategyInstance)
		delete m_WbsRestfullStrategyInstance;
	m_WbsRestfullStrategyInstance = Q_NULLPTR;
}

/**
 * @sa finalizeWbsRestfullTxData
 * @param qbaWbsRestfullTxData data about to be transmitted
 * @return eReturnTxStatus whether packet's header initialization was successfull or not.
 * @brief Finanlizes WbsRestfull request initialization.
 */
eeTxStatus WbsRestfullStrategy::finalizeWbsRestfullTxData( QByteArray& qbaWbsRestfullTxData )
{

	// everything after \0 char just drop it away
	qbaWbsRestfullTxData.truncate (qbaWbsRestfullTxData.indexOf ('\0'));

	eeTxStatus eReturnTxStatus = TX_SUCCESS;

    QString qsEndPoint = m_activeUrl.url ();
    QVariantMap mEndPointParams = QJson::JsonOperations::JsonObjectFromData (qbaWbsRestfullTxData);

    m_bFlexBetOdds = mEndPointParams.value ("EndPointParams").toString ().contains("GetBetData.ashx?oddprn"); // stergioua : The WS call for CL FlexBet (Xperto) contains this substring

    if (m_bFlexBetOdds) {
        qsEndPoint.chop(QString("/lotoswebservice").length()); // stergioua : Remove the trailing path for the FlexBet odds WS call
    }

    qsEndPoint.append (mEndPointParams.value ("EndPointParams").toString ());

	m_NetworkRequest.setUrl ( qsEndPoint );

	QString qsLogString = QString("Invoke WbsRestfull: %1").arg(qsEndPoint);

#ifdef IMTS_TXRX_DEBUG
	qDebug () << "This is what c/s gets: " << qsEndPoint;
#endif
	LOG(qsLogString);

	return eReturnTxStatus;
}


/**
 * @sa updateTransactionHistory
 * @brief update Transaction history. The object that processed the data has set the header and the footer.
 */
void WbsRestfullStrategy::updateTransactionHistory (const bool& bIsTraining,
													const QByteArray& qbaGuiData,
													const QVariantMap& qvmDataForGui,
													const QByteArray& qbaWbsRestfullRxData )
{

    // When retriving odds just ignore everything.
    if (m_bFlexBetOdds) // stergioua : Too much work to handle this for the CL FlexBet odds call, so there will be no trace of it in the transaction history...
        return;

	Lotos5DataRequestJsonObj jsonGuiData;
	QJson::JsonOperations::JsonToqObject( qbaGuiData, &jsonGuiData );

	QString qsHeader = jsonGuiData.readHeader ();
	QString qsBody = jsonGuiData.readBody ();

	QString qsFooter = QString ();
	qsFooter.reserve (128);
	qsFooter = jsonGuiData.readFooter ();

	QString qsImage = jsonGuiData.readImage ();

	// The Footer should be empty, and we need to construct it. I have given the option for gui to set footer in case if we ever need it.
	// Currently I don't see why should gui need to set the footer...Anyway let's proceed.

	QLocale locale (GetConfigValue::getLocale () );

	QVariantMap csReplyMap = QJson::JsonOperations::JsonObjectFromData (qbaWbsRestfullRxData);

	if ( bIsTraining ) {
		QDateTime trnsDateTime = QDateTime::currentDateTime ();
		qsFooter.append (tr("Training Mode Date: "));
		if ( locale.country () == QLocale::Taiwan ) {
			qsFooter.append ( FormatDate::toTaiwanDateTime (trnsDateTime,FormatDate::ShortDateWithTime ) );
		} else {
			qsFooter.append (trnsDateTime.toLocalTime ().toString (locale.dateTimeFormat (QLocale::ShortFormat)));
		}
	}

	if ( !csReplyMap.isEmpty () ) {

		QVariantMap headerMap = csReplyMap.value (QStringLiteral("header")).toMap ();

		qsFooter.append (tr("WSTR: "));
		qsFooter.append ( QString("%1").arg( headerMap.value ( QStringLiteral("transactionId")).toUInt () ).rightJustified(10, QLatin1Char('0') ) );


		QDateTime trnsDateTime;
		trnsDateTime.setTime_t ( headerMap.value (QStringLiteral("systemTime")).toUInt () );

		qsFooter.append (tr("   Date: "));

		if ( locale.country () == QLocale::Taiwan ) {
			qsFooter.append ( FormatDate::toTaiwanDateTime (trnsDateTime,FormatDate::IsoDateWithRocSymbolAndTime ) );
		} else {
			qsFooter.append (trnsDateTime.toLocalTime ().toString (locale.dateTimeFormat (QLocale::ShortFormat)));
		}
	}

	// Here you can by-pass the header. Basically the Rx product can override the transaction header
	// gui sets. This could be the case for play transactions where you also want to display the cost.
	QString qsNewTransactionHeader = qvmDataForGui.value (NEW_TRANSACTION_HEADER).toString ();
	if ( !qsNewTransactionHeader.isEmpty () || !qsNewTransactionHeader.isNull () ) {
		qsHeader = qsNewTransactionHeader;
	}

	UpdateTransactionHistoryJsonObj updateTransactionHistoryJsonObj;
	updateTransactionHistoryJsonObj.setHeader ( qsHeader );
	updateTransactionHistoryJsonObj.setBody   ( qsBody );
	updateTransactionHistoryJsonObj.setFooter ( qsFooter );
	updateTransactionHistoryJsonObj.setImage  ( qsImage );
	QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&updateTransactionHistoryJsonObj);

	// Send request to serverManager and it will be the one to do the distribution to clients. FYI, if there were no support
	// for multiple clients we could just have called dbus method directly....
	PlaceServerManagerRequest placeServerManagerRequest;
    placeServerManagerRequest.aSyncRequest ( ClientServerDefinitions::TransactionHistoryUpdate, qbaJsonData );
}

/**
 * @sa processItCssMsgRequest
 * @param transaction type
 * @param training true/false
 * @param gui data in json format
 * @param buffer to be initialized with WbsRestfull json rpc data.
 * @return eeTxStatus
 * @brief This routine is responsible to get a transmit product and initialize the given buffer
 * with WbsRestfull json rpc data. It returns the status of the request.
 */
eeTxStatus WbsRestfullStrategy::processItCssMsgRequest( const QString& qsTransactionType,
														const bool& bTraining,
														const QByteArray& qbaGuiData,
														QByteArray& qbaWbsRestfullTxData )
{

	eeTxStatus eReturnTxStatus = TX_SUCCESS;

	if ( !bTraining ) { // In training mode return TX_SUCCESS

		QObject *plugin = 0;
#ifdef IMTS_TXRX_DEBUG
		plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin_d"));
#elif IMTS_TXRX_RELEASE
		plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin"));
#endif

		if (plugin) {

			ProtocolFactoryPluginInterface* txPluginInterface = qobject_cast<ProtocolFactoryPluginInterface *>(plugin);

			// Get the Transmission product dictated by qsTransactionType
			ItCssMessagePayloadInterface* qcItCss = txPluginInterface->createItCssObject ( qsTransactionType );

			if (qcItCss) {

				eReturnTxStatus = qcItCss->initializeMessageWithData( qbaGuiData, qbaWbsRestfullTxData.data () );

				if ( eReturnTxStatus == TX_SUCCESS ) {
					eReturnTxStatus = finalizeWbsRestfullTxData ( qbaWbsRestfullTxData );
				}

				if ( eReturnTxStatus!=TX_SUCCESS ) {

					LOG( QString(QStringLiteral("TXRX_ERROR: Product:%1 initialization failed ")).arg(qsTransactionType) + ErrorHandling::getTxPathError(TX_INIT_ERROR));
				}

				// Got to delete created object before return, we don't need it any more.
				delete qcItCss;

			} else { // FAILURE CASE

				eReturnTxStatus = TX_PRODUCT_NOT_REGISTERED;
				LOG( QString(QStringLiteral("WbsRestfullStrategy::processItCssMsgRequest Product:%1 is probably not registered ")).arg(qsTransactionType) +
					 ErrorHandling::getTxPathError(TX_PRODUCT_NOT_REGISTERED) )
			}

		} else {
			eReturnTxStatus = TX_FAILED_TO_LOAD_TXRX_PLUGIN;
			LOG( ErrorHandling::getTxPathError(TX_FAILED_TO_LOAD_TXRX_PLUGIN ));
		}
	}

	return eReturnTxStatus;
}


/**
 * @sa processCssItMessage
 * @param transaction's type
 * @param training true/false
 * @param data collected from user interface within a QByteArray
 * @param data transmitted to C/S
 * @param data received from C/S
 * @param qvmDataForClient: the reply data destined for client that placed the call.
 * @brief Pure virtual Method which implements the business logic for Rx Packet
 */
void WbsRestfullStrategy::processCssItMessage( const QString& qsTransactionType,
											   const bool& bTraining,
											   const QByteArray& qbaGuiData,
											   const QByteArray&,
											   const QByteArray& qbaWbsRestfullRxData,
											   QVariantMap& qvmDataForGui )
{

	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;


	QObject *plugin = 0;
#ifdef IMTS_TXRX_DEBUG
	plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin_d"));
#elif IMTS_TXRX_RELEASE
	plugin = m_PluginManager->getPluginObject (QStringLiteral("libIMTSWbsRestfullTxRxPlugin"));
#endif

	if (plugin) {

		ProtocolFactoryPluginInterface* txPluginInterface = qobject_cast<ProtocolFactoryPluginInterface *>(plugin);

		// Get the receive product dictated by qsTransactionType
		CssItParseMessageInterface *qcCssIt = txPluginInterface->createCssItObject (qsTransactionType);


		if ( qcCssIt ) { //SUCCESS CASE
			eRxStatus = qcCssIt->processReceivedData( qbaGuiData,
													  0/*iCsReply*/,
													  qbaWbsRestfullRxData.data (),
													  qvmDataForGui );

			if ( eRxStatus != ImtsRxErrors::RX_SUCCESS ) {

				qvmDataForGui.insert(CS_ERROR_MSG, ErrorHandling::getRxPathError(eRxStatus) );
			}

			// Got to delete created object before return, we don't need it any more.
			delete qcCssIt;

		} else { // FAILURE CASE

			QString qsErrMsg = ErrorHandling::getRxPathError(ImtsRxErrors::RX_PRODUCT_NOT_REGISTERED);
			LOG (QString(QStringLiteral("WbsRestfullStrategy::processItCssMsgRequest Product:%1 is probably not registered ")).arg(qsTransactionType) );
			qvmDataForGui.insert(CS_ERROR_MSG, qsErrMsg );
		}

	} else {

		QString qsErrMsg = ErrorHandling::getRxPathError(ImtsRxErrors::RX_FAILED_TO_LOAD_TXRX_PLUGIN );
		LOG( qsErrMsg );
		qvmDataForGui.insert(CS_ERROR_MSG, qsErrMsg );
	}


	updateTransactionHistory ( bTraining, qbaGuiData, qvmDataForGui, qbaWbsRestfullRxData );

}

/**
 * @sa connectionTimeOutSlot
 * @brief time out connection
 */
void WbsRestfullStrategy::connectionTimeOutSlot ()
{
	if ( m_pcNetworkReply->isRunning () ) {
		m_pcNetworkReply->abort ();
	}
}

/**
 * @sa rpcRequestFinishedSlot
 * @param reply
 */
void WbsRestfullStrategy::rpcRequestFinishedSlot (QNetworkReply *reply)
{

	if ( m_guardTimer->isActive () ) {
		m_guardTimer->stop ();
	}

	if ( reply ) {

		if ( m_pcNetworkReply == reply ) {

			if ( reply->error() == QNetworkReply::NoError  ) {

				QByteArray qbaCsReply = reply->readAll ();

#ifdef IMTS_TXRX_DEBUG
				qDebug () << "The received w/s data: " << qbaCsReply;
#endif

                if (m_bFlexBetOdds) { // stergioua : The CL FlexBet odds WS call returns an XML object instead of JSON content (no header info etc.) so no JSON parsing should be done

                    // All OK emit to process data. CsRx object takes control.
                    emit ProtocolStrategyInterface::processRxData ( m_iConnId,
                                                                    m_qvmGuiDataMap,
                                                                    m_qbaCsTxData,  // Tx data
                                                                    qbaCsReply );    // Rx data, just the result
                } else {

                    QVariantMap mReply = QJson::JsonOperations::JsonObjectFromData (qbaCsReply);
                    QByteArray qbaResult = QJson::JsonOperations::VariantToByteArray (mReply);

                    // All OK emit to process data. CsRx object takes control.
                    emit ProtocolStrategyInterface::processRxData ( m_iConnId,
                                                                    m_qvmGuiDataMap,
                                                                    m_qbaCsTxData,  // Tx data
                                                                    qbaResult );    // Rx data, just the result
                }






			} else {

				if ( m_activeUrl == m_primaryUrl ) {

					m_activeUrl = m_secondaryUrl;
					LOG(QString("Switched to secondary url: %1").arg (m_activeUrl.toString ()));

				} else {

					m_activeUrl = m_primaryUrl;
					LOG(QString("Switched to primary url: %1").arg (m_activeUrl.toString ()));
				}

				m_NetworkRequest.setUrl ( m_activeUrl );

				// get http status code
				int iHttpStatus = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
				QString qsErrorMsg = QString ( QStringLiteral("NetworkError: %1 %2 HttpStatus: %3") ).arg ( reply->error () ).arg(reply->errorString ()).arg (iHttpStatus);
				qDebug () << qsErrorMsg;
				LOG ( qsErrorMsg );

				emit ProtocolStrategyInterface::reportTransmissionError ( m_iConnId, ErrorHandling::getCommServerError(COMM_WEBSERVICE_DOES_NOT_RESPOND) );
			}


		} else { // this is bad.
			qDebug () << "----------------------------------------------------------------------------------------------------";
			qDebug () << "--------------------------------------------this is bad 1 ------------------------------------------";
			qDebug () << "------------------------------- Lost synchronization ----------------------------------------------";

			LOG ( QStringLiteral("WbsRestfull replies don't match.") );

			QString qsErrorMsg = ErrorHandling::getCommServerError ( COMM_WEBSERVICE_ERROR_REPLIES_DO_NOT_MATCH );
			emit ProtocolStrategyInterface::reportTransmissionError ( m_iConnId, qsErrorMsg );
		}


	} else { // this is bad.

		qDebug () << "----------------------------------------------------------------------------------------------------";
		qDebug () << "--------------------------------------------this is bad 2 ------------------------------------------";
		qDebug () << "------------------------------- Received a null network reply --------------------------------------";

		LOG ( QStringLiteral("WbsRestfull Null replied received.") );

		QString qsErrorMsg = ErrorHandling::getCommServerError ( COMM_WEBSERVICE_ERROR_NULL_REPLY_RECEIVED );
		emit ProtocolStrategyInterface::reportTransmissionError ( m_iConnId, qsErrorMsg );
	}

	m_pcNetworkManager->disconnect ();
	m_pcNetworkReply = nullptr;
	reply->deleteLater ();

}

/**
 * @sa dataTransmissionRequestSlot
 * @param qbaGuiData
 * @brief I jsust wish commserver could dynamically tell us when primary or secondary is in place, rather
 * than asking each time....
 */
void WbsRestfullStrategy::dataTransmissionRequestSlot ()
{
	QObject::connect( m_pcNetworkManager, &QNetworkAccessManager::finished, this, &WbsRestfullStrategy::rpcRequestFinishedSlot );
	m_pcNetworkReply = m_pcNetworkManager->get (m_NetworkRequest);
}

/**
 * @sa transmitPacket
 * @param the connection id the data are meant to be.
 * @param training
 * @param gui data stored in a map
 * @param c/s binary Tx data.
 * @return the transmission error prior handing the data for transmission to the server.
 */
eeCommError  WbsRestfullStrategy::transmitPacket (const int& iConnId,
												  const bool &bTraining,
												  const TransmissionType&,
												  const QVariantMap& qvmGuiDataMap,
												  const QByteArray& qbaCsTxData)
{

	m_iConnId = iConnId;
	m_qvmGuiDataMap = qvmGuiDataMap;
	m_qbaCsTxData = qbaCsTxData;

	if ( !bTraining ) {

		m_guardTimer->start (m_iWebserviceTimeout);
		emit dataTransmissionRequest ();

	} else {

		// CsRx object takes control.
		emit ProtocolStrategyInterface::processRxData ( m_iConnId,
														m_qvmGuiDataMap,
														m_qbaCsTxData,   // c/s binary Tx data
														QByteArray () ); // c/s binary Rx data
	}

	return COMM_TX_SUCCESS;
}
