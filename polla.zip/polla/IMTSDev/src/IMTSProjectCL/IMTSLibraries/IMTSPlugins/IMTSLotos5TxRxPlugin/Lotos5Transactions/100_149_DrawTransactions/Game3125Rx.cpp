/******************************************************************************
Copyright (C) 2016

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file Game3125Rx.cpp
 */
#include "Game3125Rx.h"
#include "Lotos5TxRxFactoryPlugin.h"
#include "DbusWrapper.h"
#include "SystemWideConstValues.h"
#include "GetConfigValue.h"
#include <QStringBuilder>

/** Forces registration */
const Game3125Rx* const Game3125Rx::m_Game3125Rx = new Game3125Rx;

/**
 * @sa Game3125Rx
 * @brief Constructor. Register's the class name with factory plugin
 */
Game3125Rx::Game3125Rx ()
{
	static bool bIsProductRegistered = false;

	if (!bIsProductRegistered) {
		Lotos5TxRxFactoryPlugin::registerCssItObject("Game3125Rx", this);
		bIsProductRegistered = !bIsProductRegistered;
	}

	m_mHtmlData = QVariantMap ();
}

/**
 * @sa processReceivedData
 * @param guidata
 * @param cs reply
 * @param pointer to receivedData
 * @param data for client
 * @brief implements the business logic when we got fresh play rx data.
 */
ImtsRxErrors::eeRxStatus Game3125Rx::processReceivedData(const QByteArray& qbaGuiData,
														  const int& iCsReply,
														  const char* const pReceivedData,
														  QVariantMap& qvmDataForGui)
{

	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;

	if (iCsReply != RD_OK) {
		return eRxStatus;
	}

	bool bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();

	eRxStatus = GamesCommonRx::initializeGameRxData(qbaGuiData, pReceivedData, bIsTraining);

	if (eRxStatus == ImtsRxErrors::RX_SUCCESS) {

		PlayPrintReceiptFlags eReceiptFor(NormalTicket);

		if (bIsTraining) {
			eReceiptFor = GamesCommonRx::Training;

		} else {

			quint32 iPlayActionFlag = getPlayAction ();

			if (iPlayActionFlag & Imts::PilotOperation) {
				eReceiptFor |= Pilot;
			}
		}

		eRxStatus = createReceipt (eReceiptFor, qvmDataForGui);
		addPlayTransactionToCustomerSession(); // The call will also add the last play to play list

		if (eRxStatus == ImtsRxErrors::RX_PAPER_LOW) {

			qvmDataForGui.insert(MSGBOX_MSG, ErrorHandling::getRxPathError(eRxStatus));
			eRxStatus = ImtsRxErrors::RX_SUCCESS;

		} else { // if we don't do the following, then Games center would think transaction failed, because the returned map will be empty.

			QString qsTransactionHeader = QString(getGameTxData ()->readHeader () % QString(QObject::tr(" Cost: ")));
			qvmDataForGui.insert(NEW_TRANSACTION_HEADER, QString(qsTransactionHeader % getFormatedCouponCost ()));
		}

	}

	return eRxStatus;

}

/**
 * @sa createReceipt
 * @return
 */
ImtsRxErrors::eeRxStatus  Game3125Rx::createReceipt (const PlayPrintReceiptFlags& eReceiptFor, QVariantMap&)
{
	ImtsRxErrors::eeRxStatus eReturnRxStatus = ImtsRxErrors::RX_SUCCESS;

	m_mHtmlData.clear ();

	generateCommonReceiptContent ( eReceiptFor );

	QVariantMap mAreaValues = m_pcGameTxData->readCustomData ().value (QStringLiteral("Area0")).toMap ();
	QVariantMap mMatches = mAreaValues.value (QStringLiteral("matches")).toMap ();
	QVariantMap mMatch = QVariantMap ();
	QString qsPrognostics = QString ();
	qint32 iPrognostics = 0;

	for (auto iMatch = 0; iMatch<mMatches.size (); ++iMatch) {

		m_mHtmlData.insertMulti (QStringLiteral("match_entry"), QStringLiteral("CLONE_ONLY"));

		mMatch = mMatches.value (QString::number (iMatch)).toMap ();

		iPrognostics =  mMatch.value (QStringLiteral("prognostics")).toInt ();

		m_mHtmlData.insertMulti (QStringLiteral("code"),QString::number (iMatch+1));
		m_mHtmlData.insertMulti (QStringLiteral("home"),mMatch.value (QStringLiteral("home")).toString ());
		m_mHtmlData.insertMulti (QStringLiteral("visitor"),mMatch.value (QStringLiteral("visitor")).toString ());

		if (iPrognostics&1) { // HomeWin
			qsPrognostics.append ("L");
		}

		if (iPrognostics&2) { // Draw
			if (qsPrognostics.contains ("L"))
				qsPrognostics.append ("-E");
			else {
				qsPrognostics.append ("E");
			}
		}

		if (iPrognostics&4) { // VisitorWin
			if (qsPrognostics.contains ("L") || qsPrognostics.contains ("E"))
				qsPrognostics.append ("-V");
			else {
				qsPrognostics.append ("V");
			}
		}

		m_mHtmlData.insertMulti (QStringLiteral("prognostics"),qsPrognostics);


		if (iPrognostics==3 || iPrognostics==5 || iPrognostics==6 ) {
			m_mHtmlData.insertMulti (QStringLiteral("double"),"X");
		} else {
			m_mHtmlData.insertMulti (QStringLiteral("double")," ");
		}

		if (iPrognostics==7) {
			m_mHtmlData.insertMulti (QStringLiteral("triple"),"X");
		} else {
			m_mHtmlData.insertMulti (QStringLiteral("triple")," ");
		}

		qsPrognostics.clear ();

	}

    if(mAreaValues.value(QStringLiteral("QP")).toBool())
        m_mHtmlData.insert(QStringLiteral("qp"),("AZAR"));

	eReturnRxStatus = DbusWrapper::makeGuiDataAndPrint( getHtmlTemplateFile(), m_mHtmlData, PrinterTypes::Chief );

	return eReturnRxStatus;
}



/**
 * @sa createCssIt
 * @brief creates and return a product to plugin factory.
 */
CssItParseMessageInterface* Game3125Rx::createCssIt() const
{
	return new Game3125Rx;
}
