/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file CouponTransmissionManagerDerived.cpp
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include "CouponTransmissionManagerDerived.h"
#include "FormatAmount/FormatAmount.h"
#include "DbusWrapper.h"
#include "LocalEventLoggerEvents.h"
#include "GetConfigValue.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "RequestDataFromCs.h"
#include "ImtsLotos5Enumerations.h"
#include "JsonOperations.h"
#include "SystemWideConstValues.h"

CouponTransmissionManagerDerived::CouponTransmissionManagerDerived ( QObject* parent, bool bFiFo )
	: CouponTransmissionManager ( parent, bFiFo )
	, m_pcCouponUtilitiesDerived ( new CouponUtilitiesDerived )
	, m_ePrinterStatus ( Tsp_ErrorStatusOK )
{

	setPopUpTimeout (15*1000); // 15seconds
	setClearBasketOnError (false);

	registerPrinters ();

	// For Ireland they want the last coupons entered in Shoppiling list to be transmitted first. LIFO
	// The default is FIFO and we got to override property
	// Note that when direct connection is ON then we got to default to FIFO.

	auto txMethod = [this](){

		bool bDirectConnection = DbusWrapper::getImtsGlobalConfigInterface ()->directConnection ();

		if ( bDirectConnection ) {
			setFifo (bDirectConnection);

		} else {
			setFifo (false);
		}

	};

	txMethod ();

	// We shouldn't capture this, just d->m_bDirectConnection but arm ToolChain compiler wines.
	m_connection = QObject::connect (DbusWrapper::getImtsGlobalConfigInterface (), &DbusWrapper::ImtsGlobalConfigInterface::directConnectionChanged, [=](){
		txMethod ();
	});
}

/**
 * @sa ~CouponTransmissionManagerDerived
 */
CouponTransmissionManagerDerived::~CouponTransmissionManagerDerived ()
{
	QObject::disconnect ( m_connection );

	if ( m_iTimerId != 0 ) {
		killTimer ( m_iTimerId );
	}

	m_iTimerId = 0;
}

/**
 * @sa registerPrinters
 */
void CouponTransmissionManagerDerived::registerPrinters ()
{
	QObject::connect (  DbusWrapper::getPrinterInterface (), SIGNAL(sgnStatus(int)),
						this,                                SLOT  (handlePrinterErrorSlot(int)));

}

/**
 * @sa handlePrinterErrorSlot
 * @param iPrinterStatus
 * @brief just stops please wait and we rely on desktop to display the message about printer's error.
 * If iPrinterStatus is ok we'll resume from where we were left.
 */
void CouponTransmissionManagerDerived::handlePrinterErrorSlot (int iPrinterStatus )
{
	bool bUpdate = true;

	if ( m_ePrinterStatus != TspStatus(iPrinterStatus) ) {

		m_ePrinterStatus = TspStatus(iPrinterStatus);

	} else if ( TspStatus(iPrinterStatus) == Tsp_StatusNotInitialised ) {

		bUpdate = true;

	} else {

		bUpdate = false;
	}

	if ( bUpdate ) {

		if ( m_ePrinterStatus == Tsp_ErrorStatusOK ) {

			if ( !isPrinterRollReplacementInProgress () ) { // If we haven't finished yet with the paper change don't resume.
				suspendCouponsTransmissionSlot (false);
			}

		} else {

			suspendCouponsTransmissionSlot (true);
		}
	}
}

/**
 * @brief checkForCouponErrors
 * @param cGamesConfig
 * @param cCouponData
 * @return CouponError object
 */
CouponError CouponTransmissionManagerDerived::checkForCouponErrors ( GamesConfig*const gameConfig, const Coupon& cCouponData )
{
	CouponError cCouponError = m_pcCouponUtilitiesDerived->getCouponErrors ( gameConfig, cCouponData );
	return cCouponError;
}

/**
 * @sa getTransmissionData
 * @param couponData
 * @return
 */
QByteArray CouponTransmissionManagerDerived::getTransmissionData (const Coupon& couponData)
{

	QByteArray qbaPlayDataToTx = QByteArray ();

	if (couponData.getGameCode() == iFlex_CL) {
		qbaPlayDataToTx = couponData.getAdditionalGameMap ().value (QStringLiteral("ExternalTxData")).toByteArray (); // FlexBet or Races have already initialized TxData.
	} else if (couponData.getGameCode() == PollaGol_CL) {
		qbaPlayDataToTx = QJson::JsonOperations::VariantToByteArray (couponData.getMiscellaneousData ());
	}

	return qbaPlayDataToTx;

}

void CouponTransmissionManagerDerived::timerEvent (QTimerEvent *event)
{
	Q_UNUSED ( event )

	if ( m_localLoop.isRunning () ) {
		if ( m_iTimerId != 0 ) {
			killTimer(m_iTimerId);
		}
		m_iTimerId = 0;
		m_localLoop.exit (1);
	}
}

/**
 * @sa CouponTransmissionManager::preProcessOutcomeResults
 * @brief you can consume cs reply and divert processing to your own slot. We do so for flexbet and races games.
 * @return false
 */
QString CouponTransmissionManagerDerived::preProcessOutcomeResults ( )
{

	QString qsErrorMessage = QString ();
	QList<QVariant> lResults = getFutureWatcher ()->result ();
	QVariantMap qvmCsReply = lResults.at (eCsReply).toMap ();
	QString qsCsErrorMessage =  lResults.at (eMessageResult).toString ();

	auto handleReply = [this] (QDBusPendingCallWatcher* call, const ImtsGamesEnums::CouponSource& couponSource )->QString {

		QDBusPendingReply<QString> reply = *call;
		QString qsErrorMessage = QString ();

		if ( !reply.isError() ) {

			qsErrorMessage = QString(reply.argumentAt<0>());

		} else {

			switch(couponSource){
			case ImtsGamesEnums::FlexBet:
			qsErrorMessage = QString(tr("%1 interface is temporal down")).arg (tr("FlexBet")); break;
			case ImtsGamesEnums::Races:
			qsErrorMessage = QString(tr("%1 interface is temporal down")).arg (tr("Races"));break;
			break;
			default:
			qsErrorMessage = QString(tr("%1 interface is temporal down")).arg (tr("Games"));
			}
			//qsErrorMessage = QString(tr("%1 interface is temporal down")).arg (couponSource==ImtsGamesEnums::FlexBet?tr("FlexBet"):tr("Races"));
			QDBusError dbusError = reply.error();
			LOG ( dbusError.message () );
			LOG ( dbusError.errorString(dbusError.type()));

			switch(couponSource){
				case ImtsGamesEnums::FlexBet:
					LOG(QString("Failed to place consumeCsReplySlot call to %1 game interface from: %2").arg (tr("FlexBet")).arg (Q_FUNC_INFO));break;
				case ImtsGamesEnums::Races:
					LOG(QString("Failed to place consumeCsReplySlot call to %1 game interface from: %2").arg (tr("Races")).arg (Q_FUNC_INFO));break;
				default:
				break;

			}
		}

		disconnect (m_betConnection);

		if ( m_iTimerId != 0 ) {
			killTimer(m_iTimerId);
			m_iTimerId = 0;
		}

		call->deleteLater();

		if ( m_localLoop.isRunning () ) {
			m_localLoop.exit ();
		}

		return qsErrorMessage;
	};

	auto handleTimer = [this] {

		if ( m_iTimerId == 0 ) {
			m_iTimerId = startTimer (GetConfigValue::commserverTimeout ()+5000);
		} else {
			qDebug("timer in CouponTransmissionManagerDerived class is out of sync");
			LOG("timer in CouponTransmissionManagerDerived class is out of sync");
		}

		if ( !m_localLoop.isRunning () ) {
			m_localLoop.exec ();
		}
	};


	if ( qsCsErrorMessage.isEmpty () ) { // preprocess data iff c/s error message is empty.

		// C/S edit requests for both flexbet and races are handled by CTM
		if ( eeEditAction(lResults.at (eEditResult).toInt () ) != CsEditRequest ) { // If there was an edit request don't do anything CTM will do the job for us.

			Coupon lastTransmittedCouponData;

			if (lResults.at (eCouponDataResult).canConvert<Coupon>())  {
				lastTransmittedCouponData = lResults.at (eCouponDataResult).value<Coupon>();
			}

			if ( !lastTransmittedCouponData.isCouponEmpty () ) { // just in case there is something wrong with our data.

				// make an asychronous call to Bet or Races and wait to respond back to tell us about the outcome.
				if ( lastTransmittedCouponData.getGameCode() == iFlex_CL ) {

					QScopedPointer<QDBusInterface> flexBetInterface (new QDBusInterface (QStringLiteral("com.intralot.IMTSFlexBet"), QStringLiteral("/FlexBetOperations"), QStringLiteral(""), QDBusConnection::sessionBus(), 0 ));

					if ( flexBetInterface->connection ().isConnected () ) { // Check dbusconnection to see if it is connected to dbus. Only then try to call an exit on it.

						flexBetInterface->setTimeout (GetConfigValue::commserverTimeout ());
						QDBusPendingCall pcall = flexBetInterface->asyncCall (QStringLiteral("consumeCsReplySlot"), lastTransmittedCouponData.getAdditionalGameMap ().value (QStringLiteral("ExternalTxData")).toByteArray (), qvmCsReply );
						QDBusPendingCallWatcher *watcher = new QDBusPendingCallWatcher(pcall, this);

						m_betConnection = QObject::connect ( watcher, &QDBusPendingCallWatcher::finished, [=,&qsErrorMessage](QDBusPendingCallWatcher* call) {

							qsErrorMessage = handleReply(call, ImtsGamesEnums::FlexBet);
						});

						handleTimer();

					} else {

						qsErrorMessage = QString(tr("FlexBet game interface is temporallily down."));
					}

				} else if ( lastTransmittedCouponData.getGameCode() == Races_BG  && lastTransmittedCouponData.getSubGameCode() == 0 ) {


					QScopedPointer<QDBusInterface> racesInterface (new QDBusInterface (QStringLiteral("com.intralot.IMTSRaces"), QStringLiteral("/RacesOperations"), QStringLiteral(""), QDBusConnection::sessionBus(), 0 ));

					if ( racesInterface->connection ().isConnected () ) { // Check dbusconnection to see if it is connected to dbus. Only then try to call an exit on it.

						racesInterface->setTimeout (GetConfigValue::commserverTimeout ());
						QDBusPendingCall pcall = racesInterface->asyncCall (QStringLiteral("consumeCsReplySlot"), lastTransmittedCouponData.getAdditionalGameMap ().value (QStringLiteral("ExternalTxData")).toByteArray (), qvmCsReply );
						QDBusPendingCallWatcher *watcher = new QDBusPendingCallWatcher(pcall, this);

						m_betConnection = QObject::connect ( watcher, &QDBusPendingCallWatcher::finished, [=,&qsErrorMessage](QDBusPendingCallWatcher* call) {

							qsErrorMessage = handleReply(call, ImtsGamesEnums::Races);
						});

						handleTimer();

					} else {

						qsErrorMessage = QString(tr("Races games interface is termporallily down."));
					}

				// end of races data processing
				}

			} else { // Coupon is empty. How come....?

				qsErrorMessage = QString ( tr("Games interface is termporallily down.") );

				static const QString qsMsg = QStringLiteral("An empty coupon was provided for pre-processing.");
				qDebug () << qsMsg;
				LOG(qsMsg);
			}

		} // process either flexbet or races data

	} // no need to process any data because c/s send an error.

	return qsErrorMessage;
}

/**
 * @brief byPassCouponChecks
 * @return hijack in case transmission data is for bet.
 */
bool CouponTransmissionManagerDerived::byPassCouponChecks (const Coupon& couponData)
{
	return couponData.getGameCode() == iFlex_CL || couponData.getGameCode () == PollaGol_CL;
}
