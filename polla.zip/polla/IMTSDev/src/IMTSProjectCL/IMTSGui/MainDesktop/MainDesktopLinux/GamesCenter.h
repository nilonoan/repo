/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once

#ifndef GAMESCENTERAPPLICATION_H
#define GAMESCENTERAPPLICATION_H

#include "GamesData/Coupon.h"
#include "Configuration/Games/GamesConfig.h"
#include "Dialogs/PleaseWaitNew.h"
#include <QVariant>

/**
  * @file GamesCenter.h
  * @class GamesCenter
  * @brief initializes games components
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
class GamesUi;
class CouponTransmissionManager;
class GamesOperationsDerived;
class CouponTransmissionManagerDerived;
class GamesLogicDerived;
class CouponProcessManagerDerived;
class CouponCollectorManager;
class QDBusPendingCallWatcher;
class QQuickView;
class PollaGol;
class GamesCenter : public QObject
{
    Q_OBJECT
    Q_PROPERTY ( bool showGames READ showGames WRITE setShowGames NOTIFY showGamesChanged )


public:
    explicit GamesCenter( QObject* parent = 0 );
    ~GamesCenter ();

    bool showGames () const;
    void setShowGames ( const bool& );

signals:
	void showGamesChanged ();

public slots:
    void requestCouponDataEditSlot      ( const Coupon& couponData, const ImtsGamesEnums::EditModesFlags& editRequestFrom );
    void selectGameSlot                 ( const int& iSelectGameCode );

private slots:
    void generateQpNumbersSlot (const int iSamples, const QList<QVariant> lGames );

private:
    void initializeGamesComponents ();
    void initializeGamesUi ();
    void getGameConfig ();
    bool getGameConfig( const int& iSelectGameCode );

#if defined (QtQuick2)
    QQuickView*  m_qGraphicsObject;
#endif
    qint64 m_pid;
    bool m_bShowGames;
    GamesConfig m_cGameConfig;
    GamesUi* m_pcGamesUi;
    CouponTransmissionManagerDerived* m_pcCouponTransmissionManager;
    GamesOperationsDerived* m_pcGamesOperations;
    GamesLogicDerived* m_pcGamesLogic;
    CouponProcessManagerDerived* m_pcCouponProcessManager;
    CouponCollectorManager* m_pcCouponCollectorManager;
    PleaseWaitNew* m_pcPleaseWaitNew;
    QList<QMetaObject::Connection> m_lConnections;
	PollaGol* m_pcPollaGol;

};

#endif // GAMESCENTERAPPLICATION_H
