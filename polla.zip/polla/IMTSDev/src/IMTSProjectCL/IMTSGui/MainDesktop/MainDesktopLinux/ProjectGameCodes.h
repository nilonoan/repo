/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once
#ifndef PROJECTGAMECODES_H
#define PROJECTGAMECODES_H

static const int RACHA_CL = 5272;
static const int LOTO3_CL = 2181;
static const int LOTO4_CL = 5270;
static const int LOTO_CL = 5271;
static const int POLLAGOL_CL = 3125;
#endif // PROJECTGAMECODES_H
