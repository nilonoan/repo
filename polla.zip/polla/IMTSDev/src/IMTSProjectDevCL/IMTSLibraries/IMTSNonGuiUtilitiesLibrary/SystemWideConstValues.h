/******************************************************************************
  Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
 * @file SystemWideConstValues.h
 * @author Nondas Masalis masalis@intralot.com
 * @brief Global constants used throughout IMTS.
 * This file contains constants strings used to describe the transaction types.
 */
#pragma once

#ifndef SYSTEMWIDECONSTVALUES_H
#define SYSTEMWIDECONSTVALUES_H

#include <QtCore/QString>

// NOTE: NONDAS I got to move all of the following into ImtsEnumarations.h inside Imts namespace.
// It's a lot of work thought.
static const QString CS_ERROR_MSG           = QLatin1String ("CsErrorMsg");             //!<< Use it to convey the c/s error message to Gui
static const QString MSGBOX_MSG             = QLatin1String ("MsgBoxData");             //!<< Use it to display a message onto the screen
static const QString PREVIEW_DATA           = QLatin1String ("PreviewData");            //!<< Use it to get the preview data for displaying
static const QString EDIT_ACTION            = QLatin1String ("EditAction");             //!<< Use it to tell games whether the user should edit a coupon or not
static const QString COMMAND_ACTION         = QLatin1String ("ConnandAction");          //!<< Use it to send a command action to Gui.
static const QString BINARY_DATA            = QLatin1String ("BinanryData");            //!<< Use it to send binary data to Gui. Mainly for Nvram oper/disp/com data.
static const QString CS_DATA                = QLatin1String ("SingleData");             //!<< Use it to send data to Gui. Mainly for version reporting.
static const QString CS_REPLY_CODE          = QLatin1String ("CsReplyCode");            //!<< Use it to send c/s reply to gui.
static const QString CDU_MSG                = QLatin1String ("CduMsg");                 //!<< Use it to display data to customer display.
static const QString NEW_TRANSACTION_HEADER = QLatin1String ("NewTransactionHeader");   //!<< Use it if you want to override the transaction history header. We do that for the plays and for webservices.
static const QString NEW_TRANSACTION_FOOTER = QLatin1String ("NewTransactionFooter");   //!<< Use it if you want to override the transaction history footer. We do that for webservices.
static const QString REGENERATE_TICKET_DATA = QLatin1String ("RegenerateTicketData");   //!<< Use it to send to gui the data we have created during ticket regeneration (TicketRepeat case)
static const QString CS_RX_DATA             = QLatin1String ("CsRxData");               //!<< Use it to send to caller c/s received buffer.
static const QString PROMOTION_DATA         = QLatin1String ("PromotionData");          //!<< Use it to send to caller promotion data.
#if defined (QtQuick2)
static const QString PLEASE_WAIT_HTML = QLatin1String ("/IMTSResources/IMTSUiMaterial/Material/External/IndicatorsPleaseWait.html"); //!< please wait gif for html
#else
static const QString PLEASE_WAIT_HTML = QLatin1String ("/IMTSResources/IMTSUiComponents/External/Indicators/PleaseWait.html"); //!< please wait gif for html
#endif
static const QString LOTOS5           = QLatin1String ("LOTOS5");        //!< Use LOTOS5 as the strategy to tx/rx packets.
static const QString WEBSERVICES      = QLatin1String ("WEBSERVICES");   //!< Use WEBSERVICES as the strategy to tx/rx packets.
static const QString WBS_RESTFULL     = QLatin1String ("WBS_RESTFULL");  //!< Use WBS_RESTFULL as the strategy to tx/rx packets.

static const QString LOW_PRI       = QLatin1String ("LOW");        //!< Transmit packet with low priority.
static const QString NORMAL_PRI    = QLatin1String ("NORMAL");     //!< Transmit packet with normal priority.
static const QString HIGH_PRI      = QLatin1String ("HIGH");       //!< Transmit packet with high priority.
static const QString CRITICAL      = QLatin1String ("CRITICAL");   //!< Transmit packet with critical priority. DO NOT USE FROM UI. ONLY USE FOR more data flag. Ask me!!!!!!!



static const QString FROM_GUI      = QLatin1String ("GUI");        //!< Use gui collected data to initialize the tx packet.
static const QString FROM_JSON     = QLatin1String ("JSON");       //!< Use a json file to read the tx packet's initialization data.
static const QString FROM_BUFFER   = QLatin1String ("BUFFER");     //!< The transmit packet is initialized by reading a binary buffer.

static const qint32 REGENERATE_TICKET = 0xfffffffe;


/**
 * @brief *_BARCODE used as keywords in HtmlPrinting
 */
static const QString PDF417_BARCODE  = QLatin1String("PDF417_GRAPHICAL_BARCODE");
static const QString CODE128_BARCODE = QLatin1String("CODE128_GRAPHICAL_BARCODE");
static const QString CODE39_BARCODE  = QLatin1String("CODE39_GRAPHICAL_BARCODE");
static const QString CODE93_BARCODE  = QLatin1String("CODE93_GRAPHICAL_BARCODE");
static const QString EAN13_BARCODE   = QLatin1String("EAN13_GRAPHICAL_BARCODE");
static const QString EAN8_BARCODE    = QLatin1String("EAN8_GRAPHICAL_BARCODE");
static const QString I2OF5_BARCODE   = QLatin1String("I2OF5_GRAPHICAL_BARCODE");
static const QString CODABAR_BARCODE = QLatin1String("CODABAR_GRAPHICAL_BARCODE");
static const QString QR_BARCODE      = QLatin1String("QR_GRAPHICAL_BARCODE");

static const quint64 key = Q_UINT64_C(0x0e816655e5cee0bd);

enum GameCodes {

	//--------------------- 1xxx -------------------------

	// DC
	Keno_DC            = 1105,

	// MT
	TenSpot_MT         = 1113,

	// OH
	TenOh_OH           = 1106,
	Keno_OH            = 1107,
	KenoBooster_OH     = 1111,


	//--------------------- 2xxx -------------------------

	// OH
	Kicker_OH         = 2126,
	Pick3_OH          = 2127,
	Pick4_OH          = 2128,
	Raffle_OH         = 2130,
	ClassicKicker_OH  = 2161,
	Pick5_OH          = 2162,
	MuslRaffle_OH     = 2169,

	// MT
	MontanaMillionaire_MT = 2112,

	// PLI
	MillionaireRaffle_IE  = 2176,

		// LW
	Super66_LW        = 2115,
	Cash3_LW          = 2116,

	// CL
	LOTTO_3_CL               = 2181,


	//--------------------- 3xxx -------------------------
	// CL
	PollaGol_CL           = 3125,



	//--------------------- 5xxx -------------------------
	// AZ
	Lotto536_AZ       = 5232,
	Lotto640_AZ       = 5233,

	// MT
	Powerball_MT      = 5107,
	MegaMillions_MT   = 5184,
	MontanaCash_MT    = 5108,
	WildCard_MT       = 5109,
	HotLotto_MT       = 5110,
	LuckyForLife_MT   = 5249,
	BigSkyBonus_MT      = 5269,
	FantasyFootball_MT  = 5148,
	FantasyRacing_MT    = 5151,
	// DC
	MegaMillions_DC   = 5143,
	Powerball_DC      = 5145,

	// OH
	Cash5_OH          = 5154,
	MegaMatch_OH      = 5140,
	Lotto_OH          = 5152,
	MegaMillions_OH   = 5153,
	Powerball_OH      = 5183,
	LuckyForLife_OH   = 5234,
	Monopoly_OH       = 5248,

	// PLI
	Lotto_IE          = 5241,
	EuroMillions_IE   = 5242,
	DailyMillion_IE   = 5243,
	Lotto54321_IE     = 5244,

	//LW
	SatLotto_LW       = 5127,
	MonLotto_LW       = 5128,
	WedLotto_LW       = 5129,
	OzLotto_LW        = 5130,
	SoccerPools_LW    = 5131,
	PowerBall_LW      = 5132,
	SetForLife_LW     = 5237,

	// CL
	LOTTO_4_CL        = 5270,
	LOTTO_CL		  = 5271,
    RACHA             = 5272,


	//--------------------- 6xxx -------------------------


	//--------------------- 7xxx -------------------------

	// AZ
	KlassikLoto_AZ  = 7108, //bingo 90
	Bingo_AZ        = 7109, //bingo 60

	// PLI
	TellyBingo_IE    = 7114,


	// AZ
	Races_AZ         = 10105,
	GBIRaces_AZ      = 13100,
	iFlex_AZ         = 15108,

	//--------------------- 10xxx -------------------------
	// BG
	Races_BG         = 10111,
	Paroli_BG        = 10111,


	//--------------------- 14xxx -------------------------
	VFball_BG        = 14102,

	//--------------------- 15xxx -------------------------
	iFlex_BG         = 15001,
	iFlex_CL         = 15112,


	//--------------------- 11xxx -------------------------
	// CL
	PollaBolleto     = 11108

};



#endif // SYSTEMWIDECONSTVALUES_H
