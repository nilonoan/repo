/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once
#ifndef IMTSGAMESENUMS_H
#define IMTSGAMESENUMS_H

#include <QObject>
#include <QtCore/QMetaEnum>
#include "IMTSGamesUtilitiesLibrary_global.h"
#include <QList>

#define IS_KENO(iGameCode)        (iGameCode >= 1000) && (iGameCode <= 1999) ? true : false
#define IS_PICK(iGameCode)        (iGameCode >= 2000) && (iGameCode <= 2999) ? true : false
#define IS_RAFFLE(iGameCode)      (iGameCode >= 2000) && (iGameCode <= 2999) ? true : false
#define IS_PROPO(iGameCode)       (iGameCode >= 3000) && (iGameCode <= 3999) ? true : false
#define IS_LOTTO(iGameCode)       (iGameCode >= 5000) && (iGameCode <= 5999) ? true : false
#define IS_FASTPLAY(iGameCode)    (iGameCode >= 6000) && (iGameCode <= 6999) ? true : false
#define IS_PTVGAME(iGameCode)     (iGameCode >= 7000) && (iGameCode <= 7999) ? true : false
#define IS_FASTPLAYNEW(iGameCode) (iGameCode >= 16000) && (iGameCode <= 16999) ? true : false

/**
 * @file ImtsGamesEnums.h
 * @class ImtsGamesEnums
 * @brief Games enums. Object also registered to QML using qmlRegisterUncreatableType
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
class IMTSGAMESUTILITIESLIBRARYSHARED_EXPORT ImtsGamesEnums : public QObject
{
	Q_OBJECT

	Q_ENUMS ( DisplayOptions )
	Q_ENUMS ( InputOperations )
	Q_ENUMS ( CouponSource )
	Q_FLAGS ( EditModesFlag )
	Q_FLAGS ( ViewUpdateOptionsFlag )
	Q_FLAGS ( GameTypeFlag )
	Q_FLAGS ( PickXPlayTypeFlag )
	Q_FLAGS ( ScannedErrorsFlag )
	//	Q_FLAGS ( DrawTypeFlag )
	//	Q_FLAGS ( AdvancePlayFlag )

public:

	explicit ImtsGamesEnums ( QObject* parent = 0 ) : QObject ( parent ) {}
	~ImtsGamesEnums() {}


	enum DisplayOptions  { NoDisplay,
						   MainGameView,
						   UsePanel,
						   UseCalculator,
						   UseCalendar
						 };

	enum InputOperations { NoInputOperation,
						   MultidrawsCalc,
						   MultidrawsCalendar,
						   FuturedrawsCalc,
						   FuturedrawsCalendar,
						   MultiplierCalc,
						   NumberOfTicketCalc
						 };

	enum CouponSource    { /*  0 */ UndefinedSource,                /**< Source is undefined */
						   /*  1 */ Camera,                         /**< Source from Camera. */
						   /*  2 */ Scanner,                        /**< Source from Scanner */
						   /*  3 */ GuiQp,                          /**< Source from Gui QP. Fast QP play for example. */
						   /*  4 */ FastPlayGame,                   /**< Source fast play game. Usually the source is MainDesktop's Gui */
						   /*  5 */ QR,                             /**< Source is from QR */
						   /*  6 */ AdditionalGame,                 /**< Source is from Addional Game */
						   /*  7 */ Verbal,                         /**< Source Verbal */
						   /*  8 */ VerbalEdit,                     /**< Source edit request due to user's request by selecting a game in GameProgress list */
						   /*  9 */ VerbalEditDueToCs,              /**< Source edit request due to C/S */
						   /* 10 */ VerbalEditDueToCouponProcessing,/**< Source edit request coming from CPM due to CouponErrors or CostEdit */
						   /* 11 */ RegeneratedTicket,              /**< Source for ticket regeneration process, mostly for ticketRepeat */
						   /* 12 */ MiscellaneousGame,              /**< Source Works games' batch */
						   /* 13 */ MiscellaneousGameModified,	    /**< Source Works games' batch modified*/
						   /* 14 */ PromotionTicket,             	/**< Source Promotion manager */
						   /* 15 */ FlexBet,                        /**< Source for ticket iFlex game */
						   /* 16 */ FlexBetCamera,                  /**< Source for ticket iFlex scanned game */
						   /* 17 */ Races,                          /**< Source for ticket races game */
						   /* 18 */ RacesCamera,                    /**< Source for ticket races scanned game */
						   /* 19 */ GBIRaces,                       /**< Source for ticket races game */
						   /* 20 */ GBIRacesCamera,                 /**< Source for ticket races scanned game */
						   /* 21 */ PropoBet,                       /**< Source for ticket propo like game */
						   /* 22 */ PropoBetCamera                  /**< Source for ticket propo like scanned game */


						   /*Do not change the order*/
						 };

	enum InputMethod { Scanned = 0,
					   ECoupon = 1,
					   MobilePhone = 6
					 }; // directly related to Input Method in IT_CSS_4 data[2]. Please check if you want to add more.

	enum TransmissionMethod { LetSystemDecide,
							  DirectTransmission,
							  NonDirectTransmission
							};


	enum EditModesFlag   { NoEdit           = 1 << 0,
						   GuiEditRequest   = 1 << 1,
						   HwEditRequest    = 1 << 2,
						   CSEditRequest    = 1 << 3,
						   OtherEditRequest = 1 << 4,
						   CostEdit         = 1 << 5,
						   AnyEditMode      = GuiEditRequest | HwEditRequest | CSEditRequest | OtherEditRequest | CostEdit
						 };

	Q_DECLARE_FLAGS ( EditModesFlags, EditModesFlag )

	enum ViewUpdateOptionsFlag { NoUpdate			            = 1 << 0,
								 UpdateCouponCost               = 1 << 1,
								 UpdateAreaCost                 = 1 << 2,
								 UpdateMultiDraws               = 1 << 3,
								 UpdateFutureDraws              = 1 << 4,
								 UpdateAdvancePlays             = 1 << 5,
								 UpdateDrawType                 = 1 << 6,
								 UpdateAreas                    = 1 << 7,
								 UpdatePanels                   = 1 << 8,
								 UpdateSystemBets               = 1 << 9,
								 UpdateBetTypes                 = 1 << 10,
								 UpdateMultipliers              = 1 << 11,
								 UpdateAdditionalGame           = 1 << 12,
								 UpdateAdditionalGamePerArea    = 1 << 13,
								 UpdateAdditionalAreaComponents = 1 << 14,
								 UpdatePickXPlayType            = 1 << 15,
								 UpdatePickPlayTypeLabel        = 1 << 16,
								 UpdateNumberOfTickets          = 1 << 17,

								 CheckCoupon                    = 1 << 18,
								 eEditMode                      = 1 << 19,

								 // Masks
								 UpdateAllAreaContents  = UpdateAreas | UpdatePanels | UpdateSystemBets | UpdateMultipliers | UpdateAdditionalGamePerArea | UpdatePickXPlayType | UpdatePickPlayTypeLabel | UpdateBetTypes,
								 UpdateCoupon           = UpdateMultiDraws | UpdateFutureDraws | UpdateAllAreaContents | UpdateAdvancePlays | UpdateDrawType | UpdateNumberOfTickets | UpdateBetTypes | UpdateAdditionalGame
							   };
	Q_DECLARE_FLAGS ( ViewUpdateOptionsFlags, ViewUpdateOptionsFlag )

	enum PickXNumber { TooManyDigits = -3, // basically helps for scanned coupon, for pickGames where their Ui is driven by a calculator.
					   InvalidDigit  = -2,
					   AllNumbers    = -1
					 };

	enum PickXPlayTypeFlag { NoPlayType  = 1 << 0,  //      1
							 Straight    = 1 << 1,  //      2
							 Box         = 1 << 2,  //      4
							 Combo       = 1 << 3,  //      8
							 FrontPair   = 1 << 4,  //     16
							 BackPair    = 1 << 5,  //     32
							 MiddlePair  = 1 << 6,  //     64
							 SplitPair   = 1 << 7,  //    128
							 FrontThree  = 1 << 8,  //    256
							 BackThree   = 1 << 9,  //    512
							 FrontFour   = 1 << 10, //   1024
							 BackFour    = 1 << 11, //   2048
							 PlusMinus   = 1 << 12, //   4096
							 FirstDigit  = 1 << 13, //   8192
							 SecondDigit = 1 << 14, //  16384
							 ThirdDigit  = 1 << 15, //  32768
							 FourthDigit = 1 << 16, //  65536
							 FifthDigit  = 1 << 17, // 131072
							 LastDigit   = 1 << 18, // 262144

							 Wheeled     = Combo,
							 StraightBox = Straight | Box,
							 Backup      = StraightBox,

							 FrontBackPairs = FrontPair | BackPair,

							 BackGameTypes    = BackPair | BackThree | BackFour,
							 FrontGameTypes   = FrontPair | FrontThree | FrontFour,
							 DigitsGameTypes  = FirstDigit | SecondDigit | ThirdDigit | FourthDigit | FifthDigit,
							 ResetAllNumbersDigit = Straight | Box | Combo | PlusMinus,

							 ScannedPlayType = 1 << 31 // used to indicate an invalid PlayType Selection in the playslip.
						   };

	Q_DECLARE_FLAGS ( PickXPlayTypeFlags, PickXPlayTypeFlag )

	enum DrawTypeFlag { InvalidDraw    = 0,
						NextDraw       = 1,
						NextTwoDraws   = 1 << 1,
						NextThreeDraws = 1 << 2,
						NextFourDraws  = 1 << 3,
						Morning        = 1 << 4,
						Noon           = 1 << 5,
						Afternoon      = 1 << 6,
						Evening        = 1 << 7
					  };


	Q_DECLARE_FLAGS ( DrawTypeFlags, DrawTypeFlag )

	enum AdvancePlayFlag { InvalidAdvancePlay = 0,
						   Sunday             = 1,
						   Monday	          = 1 << 1,
						   Tuesday            = 1 << 2,
						   Wednesday          = 1 << 3,
						   Thursday	          = 1 << 4,
						   Friday             = 1 << 5,
						   Saturday           = 1 << 6,

						   Today              = 1 << 7,

						   // do aliases
						   Current            = Today,
						   WeekDays           = Monday | Tuesday | Wednesday | Thursday | Friday,
						   Weekend            = Saturday | Sunday

						 };

	Q_DECLARE_FLAGS ( AdvancePlayFlags, AdvancePlayFlag )

	/**
	 * @brief The GameTypeFlag enum
	 */
	enum GameTypeFlag { InvalidGameType            = 0,
						DefaultGame                = 1,       //!< Normal Game withou system or bettypes. PowerBall is one case.
						BetTypeSupport             = 1 << 1,  //!< TW LottoMarkGames, Keno
						SystemSupport              = 1 << 2,  //!< TW Lotto, SuperLotto, Keno
						FixedSystemSupport         = 1 << 3,  //!< Opap Joker & Lotto
						PartialQp                  = 1 << 4,  //!< Well known partial qp
						SystemQp                   = 1 << 5,  //!< User selects one number and terminal gets as many qp marks.
						QpPerPanel                 = 1 << 6,  //!< QP per panel
						CalculatorSupport          = 1 << 7,  //!< Mostly for US pick games
						SystemPerArea              = 1 << 8,  //!< System is in place in per area basis.
						SystemBoundToUserSelection = 1 << 9,  //!< System is in place but the user selects it explicitly, just like BetType games. Check LW for such games. Not like in TW games where the system is defined by the number of marks in panel.

						BetTypeWithSystemSupport    = DefaultGame | BetTypeSupport | SystemSupport, //!< BetType games with system support, TW LottoMarkGames, and Keno with System.
						BetTypeWithoutSystemSupport = DefaultGame | BetTypeSupport
					  };

	Q_DECLARE_FLAGS ( GameTypeFlags, GameTypeFlag )

	/**
	 * @brief The ScannedErrorsFlag enum used for playslip errors. All additional errors must be inserted at the bottom of the enum
	 */

	enum ScannedErrorsFlag {
							TooManyMultipliers   = 1 << 14,   //!< Too Many Multipliers Selected
							TooManyDraws         = 1 << 15,   //!< Too Many Draws Selected
							TooManyFutureDraws   = 1 << 16,   //!< Too Many Advance Draws Selected
							InvalidSystemBet     = 1 << 17,   //!< Invalid System Bet
							InvalidBetType       = 1 << 18,   //!< Invalid BetType
							InvalidPlayType      = 1 << 19,   //!< Invalid PlayType
							InvalidDrawtype      = 1 << 20,   //!< Invalid DrawType
							InvalidNoOfQpPlays   = 1 << 21,   //!< Invalid Number Of QP Plays
							InvalidNoOfTickets   = 1 << 22,   //!< Invalid Number Of Tickets
							NoMultiplierSelected = 1 << 23    //!< No Multiplier Selected

						   };
	Q_DECLARE_FLAGS ( ScannedErrorsFlags, ScannedErrorsFlag )


	enum AdditionalGameScannedErrorsFlag {
							TooManyMultipliersOnAdditionalGame   = 1 << 23,   //!< Too Many Multipliers Selected
							TooManySelectionsOnAdditionalGame    = 1 << 24,   //!< Too Many Draws Selected
							InvalidQPSelectionOnAdditionalGame   = 1 << 25    //!< Both QP and UserSelection
	};
	Q_DECLARE_FLAGS ( AdditionalGameScannedErrorsFlags, AdditionalGameScannedErrorsFlag )
};

Q_DECLARE_METATYPE(ImtsGamesEnums::CouponSource)
Q_DECLARE_METATYPE(ImtsGamesEnums::EditModesFlags)
Q_DECLARE_METATYPE(ImtsGamesEnums::GameTypeFlags)
Q_DECLARE_METATYPE(ImtsGamesEnums::PickXPlayTypeFlag)
Q_DECLARE_METATYPE(ImtsGamesEnums::ScannedErrorsFlag)
Q_DECLARE_METATYPE(ImtsGamesEnums::AdditionalGameScannedErrorsFlag)

Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::PickXPlayTypeFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::DrawTypeFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::AdvancePlayFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::EditModesFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::ViewUpdateOptionsFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::GameTypeFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::ScannedErrorsFlags)
Q_DECLARE_OPERATORS_FOR_FLAGS(ImtsGamesEnums::AdditionalGameScannedErrorsFlags)



static const QList<int> PICK3_EMPTY_LIST = QList<int>() << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit;
static const QList<int> PICK4_EMPTY_LIST = QList<int>() << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit;
static const QList<int> PICK5_EMPTY_LIST = QList<int>() << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit << ImtsGamesEnums::InvalidDigit;



#endif // IMTSGAMESENUMS_H
