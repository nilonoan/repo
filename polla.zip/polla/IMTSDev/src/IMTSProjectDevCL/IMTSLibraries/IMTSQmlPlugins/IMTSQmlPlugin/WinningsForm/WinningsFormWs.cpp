#include "WinningsFormWs.h"
#include "Transactions/Lotos5DataRequestJsonObj.h"
#include "JsonOperations.h"
#include "SystemWideConstValues.h"
#include "QDebug"

/**
 * @file WinningsFormWs_p.h
 * @class WinningsFormWsPrivate
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
class WinningsFormWsPrivate
{
public:

    WinningsFormWsPrivate ( WinningsFormWs* qq );
    ~WinningsFormWsPrivate ();

    Q_DECLARE_PUBLIC (WinningsFormWs)
    WinningsFormWs* q_ptr;


    QString m_qsRpcMethod;
    Lotos5DataRequestJsonObj m_cLotos5DataRequestJsonObj;


    void initializeCommonWsData ();
    QByteArray createTxData ();

};

WinningsFormWsPrivate::WinningsFormWsPrivate ( WinningsFormWs* qq  )
    : q_ptr( qq )
    ,m_qsRpcMethod ( QString () )
{

    m_cLotos5DataRequestJsonObj.clear ();

}

WinningsFormWsPrivate::~WinningsFormWsPrivate()
{
}


WinningsFormWs::WinningsFormWs( QObject* parent )
    : WinningsForm ( parent )
    , d_ptr ( new WinningsFormWsPrivate (this) )
{
    readCommonReportsForm ()->setTrnsTxProduct (  QStringLiteral ("WsWinningResultsRequestTx") );
    readCommonReportsForm ()->setTrnsRxProduct (  QStringLiteral ("WsWinningResultsRequestRx") );
}

WinningsFormWs::~WinningsFormWs()
{
}

/**
 * @sa initializeCommonWsData
 * @brief common initialization stuff. You can always override default values in qml.
 * That's why is private and there is no need to provide an interface to override it.
 */
void WinningsFormWsPrivate::initializeCommonWsData ()
{

    Q_Q ( WinningsFormWs );

    m_cLotos5DataRequestJsonObj.clear ();
    if( m_qsRpcMethod != "GetPollaGolProgram")
    {
        m_cLotos5DataRequestJsonObj.setTxProduct ( q->readCommonReportsForm ()->readTrnsTxProduct () );
        m_cLotos5DataRequestJsonObj.setRxProduct ( q->readCommonReportsForm ()->readTrnsRxProduct () );
        m_cLotos5DataRequestJsonObj.setProtocol  ( WEBSERVICES );
        m_cLotos5DataRequestJsonObj.setPriority  ( HIGH_PRI );
        m_cLotos5DataRequestJsonObj.setHeader    ( q->readCommonReportsForm ()->readTrnsHistory ()->readHeader () );
        m_cLotos5DataRequestJsonObj.setProject   ( q->readWsRpcMethod () );
    }
    else
    {
        m_cLotos5DataRequestJsonObj.setTxProduct (QStringLiteral("WbsRestfullRequestTx"));
        m_cLotos5DataRequestJsonObj.setRxProduct (QStringLiteral("WsPollaGolRx"));
        m_cLotos5DataRequestJsonObj.setProtocol  (WBS_RESTFULL);
        m_cLotos5DataRequestJsonObj.setPriority  (HIGH_PRI);
        m_cLotos5DataRequestJsonObj.setHeader    ("Polla Gol Matches Request");
        m_cLotos5DataRequestJsonObj.setProject   (QStringLiteral("RetrieveTotoDrawProgram")); // By convention rpc method call goes to project property
    }
}

QByteArray WinningsFormWsPrivate::createTxData ()
{
    QByteArray qbaJsonData;
    if( m_qsRpcMethod != "GetPollaGolProgram")
        qbaJsonData = QJson::JsonOperations::qObjectToJson (&m_cLotos5DataRequestJsonObj);
    else
    {
        QVariantMap m;
        m.insert (QStringLiteral("params"),QVariantList () << PollaGol_CL<<0); // gameCode/activeDraw
        m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (m);
        qbaJsonData = QJson::JsonOperations::qObjectToJson (&m_cLotos5DataRequestJsonObj);
    }

    return qbaJsonData;
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////
QString WinningsFormWs::readWsRpcMethod () const
{
    Q_D ( const WinningsFormWs );
    return d->m_qsRpcMethod;
}

//////////////////////////////////// GETTERS ////////////////////////////////////////////////

void WinningsFormWs::setWsRpcMethod ( const QString& newVal )
{
    Q_D ( WinningsFormWs );

    if ( d->m_qsRpcMethod == newVal ) return;
    d->m_qsRpcMethod = newVal;
    emit wsRpcMethodChanged ();
}

QByteArray WinningsFormWs::preparePollaGolTxData()
{
    Q_D(WinningsFormWs);
    d->initializeCommonWsData ();
    return d->createTxData();
}

/**
 * @brief WinningsFormWs::prepareWinningNumberTxData
 * @param iAction
 * @param iType
 * @return
 */

QByteArray WinningsFormWs::prepareWinningNumberTxData ( const int& iAction, const int& iType )
{

    Q_D ( WinningsFormWs );
    d->initializeCommonWsData ();

    // We will use the following map to initialize using the WsWinningResultsRequestTx object in Trss the
    // input parameters for the WS method. C/S ws method needs to be more flexible on this.
    QVariantMap mTrnsSpecificDataMap;


    if ( iAction&WinningsEnums::AllGames ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("allGames"), true );
    }

    if ( iAction&WinningsEnums::SpecificGame ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("gameId"), readGameCode () );
    }

    if ( iType == WinningsEnums::Winnings_LastDraw) {

        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), 0 ); // The draw number (if draw is 0 results for last draw will be returned)

    } else if ( iType == WinningsEnums::Winnings_LastXDraws) {

        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), readNumberOfDraws () );

    } else if ( iType == WinningsEnums::Winnings_SpecificDraw) {
        mTrnsSpecificDataMap.insert (QStringLiteral("selectedDraw"), readDrawNumber ().toInt() );

    } else if ( iType == WinningsEnums::Winnings_SpecificDate) {

#pragma message("WATCH OUT!!!. C/S for the specific report does not convert GMT time to local time so add 5 hours to the time we send")
        // To be honnest I'm bored to override this now.
        mTrnsSpecificDataMap.insert (QStringLiteral("selectedDate"), QDateTime(readDrawDate ()).addSecs (3600*5).toTime_t ());
    }
    d->m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (mTrnsSpecificDataMap);


    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawResultsTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawResultsTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );
    d->initializeCommonWsData ();


    // We will use the following map to initialize using the WsWinningResultsRequestTx object in Trss the
    // input parameters for the WS method. C/S ws method needs to be more flexible on this.
    QVariantMap mTrnsSpecificDataMap;

    if ( iAction&WinningsEnums::AllGames ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("allGames"), true );
    }

    if ( iAction&WinningsEnums::SpecificGame ) {
        mTrnsSpecificDataMap.insert (QStringLiteral("gameId"), readGameCode () );
    }

    if ( iType == WinningsEnums::Winnings_LastDraw) {
        mTrnsSpecificDataMap.insert (QStringLiteral("draw"), 0 );
    }

    d->m_cLotos5DataRequestJsonObj.setTrnsSpecificDataMap (mTrnsSpecificDataMap);

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawOddsTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawOddsTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareDrawInfoTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareDrawInfoTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareLiabilityRiskTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareLiabilityRiskTxData ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}

/**
 * @brief WinningsFormWs::prepareFastPlayTxData
 * @param iAction
 * @param iType
 * @return
 */
QByteArray WinningsFormWs::prepareFastPlayTxData  ( const int& iAction, const int& iType )
{
    Q_D ( WinningsFormWs );

    Q_UNUSED (iAction)
    Q_UNUSED (iType)

    d->initializeCommonWsData ();

    return d->createTxData ();

}
