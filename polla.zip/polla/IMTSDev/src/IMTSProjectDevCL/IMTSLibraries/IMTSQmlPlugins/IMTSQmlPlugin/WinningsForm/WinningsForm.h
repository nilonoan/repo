/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once

#ifndef WINNINGSFORM_H
#define WINNINGSFORM_H

#include <QtCore/QObject>
#include <QtCore/QDate>
#include "ImtsLotos5Enumerations.h"
#include "CommonReportsForm.h"
#include <QDBusPendingCallWatcher>

/**
 * @file WinningsForm.h
 * @class WinningsForm
 * @brief Object exported in qml context
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
class WinningsFormPrivate;
class WinningsForm : public QObject
{
	Q_OBJECT

	Q_PROPERTY ( CommonReportsForm* commonReportsForm READ readCommonReportsForm   WRITE setCommonReportsForm   NOTIFY commonReportsFormChanged FINAL )
	Q_PROPERTY ( quint16 gameCode                     READ readGameCode            WRITE setGameCode            NOTIFY gameCodeChanged FINAL )
	Q_PROPERTY ( quint16 subGame                      READ readSubGame             WRITE setSubGame             NOTIFY subGameChanged FINAL )
	Q_PROPERTY ( QString drawNumber                   READ readDrawNumber          WRITE setDrawNumber          NOTIFY drawNumberChanged FINAL )
	Q_PROPERTY ( QDate   drawDate                     READ readDrawDate	           WRITE setDrawDate            NOTIFY drawDateChanged FINAL )
    Q_PROPERTY ( quint8  numberOfDraws                READ readNumberOfDraws       WRITE setNumberOfDraws       NOTIFY numberOfDrawsChanged FINAL )
	Q_PROPERTY ( QString gameName                     READ readGameName            WRITE setGameName            NOTIFY gameNameChanged FINAL )
	Q_PROPERTY ( QString gameLogo                     READ readGameLogo            WRITE setGameLogo            NOTIFY gameLogoChanged FINAL )
    Q_PROPERTY ( qint32  numberOfPrintCopies          READ readNumberOfPrintCopies WRITE setNumberOfPrintCopies NOTIFY numberOfPrintCopiesChanged FINAL )


	Q_PROPERTY ( WinningsEnums::Request_51_X_ActionFlag action READ readAction WRITE setAction NOTIFY actionChanged FINAL )

public:
	explicit WinningsForm( QObject* parent = 0 );
	virtual ~WinningsForm ();

public :

	CommonReportsForm* readCommonReportsForm () const;
	quint16 readGameCode     () const;
	quint16 readSubGame      () const;
	QString readDrawNumber   () const;
	QDate readDrawDate       () const;
    quint8 readNumberOfDraws () const;
	WinningsEnums::Request_51_X_ActionFlag readAction() const;
	QString readGameName     () const;
	QString readGameLogo     () const;


    quint32 readNumberOfPrintCopies() const;
    void setNumberOfPrintCopies(const quint32&iCopies) ;

	void setCommonReportsForm ( CommonReportsForm* );
	void setGameCode       ( const quint16& );
	void setSubGame        ( const quint16& );
	void setDrawNumber     ( const QString& );
	void setDrawDate       ( const QDate& );
    void setNumberOfDraws  ( const quint8& );
	void setAction         ( const WinningsEnums::Request_51_X_ActionFlag& );
	void setNumberOfCopies ( const quint8& );
	void setGameName       ( const QString& );
	void setGameLogo       ( const QString& );
    QString populateModelFromData (const QVariantList&);


Q_SIGNALS:
	void commonReportsFormChanged ();
	void gameCodeChanged ();
	void subGameChanged ();
	void drawNumberChanged ();
	void drawDateChanged ();
    void numberOfDrawsChanged ();
	void actionChanged ();
	void numberOfCopiesChanged ();
	void gameNameChanged ();
	void gameLogoChanged ();
    void wsRpcMethodChanged ();
    void numberOfPrintCopiesChanged();

    /**
      * Request the following reports by triggering the following signals.
      * Where:
      * action is one of: WinningsEnums::Request_51_X_ActionFlag
      * type is one of  : WinningsEnums::Request_51_0_Type
      *
      * example:
      * requestWinningNumbers for action=SpecificGame, type=LastXDraws
      * requestWinningNumbers for action=AllGames,     type=LastDraw
      */
    void requestWinningNumbers ( const int& action, const int& type );
    void requestDrawResults    ( const int& action, const int& type );
	void requestDrawOdds       ( const int& action, const int& type );
	void requestDrawInfo       ( const int& action, const int& type );
	void requestFastPlay       ( const int& action, const int& type );
    void requestLiabilityRisk  ( const int& action, const int& type );
    void requestPollaGolProgram();

	void performPrint ();

	void startPleaseWait ();
	void endPleaseWait ();

protected slots:
	virtual void processCsResultsSlot (const QVariantMap& );
    virtual void processCsResultsPollaSlot(const QVariantMap&);
	virtual void performPrintSlot ();
    virtual void pendingPrintingSlot(QDBusPendingCallWatcher*call);

protected:
    void showMessage( QString qsErrorMessage );

    // Where action: WinningsEnums::Request_51_X_ActionFlag
    // Where type  : WinningsEnums::Request_51_0_Type
    virtual QByteArray prepareWinningNumberTxData ( const int& action, const int& type );
    virtual QByteArray prepareDrawResultsTxData   ( const int& action, const int& type );
    virtual QByteArray prepareDrawOddsTxData      ( const int& action, const int& type );
    virtual QByteArray prepareDrawInfoTxData      ( const int& action, const int& type );
    virtual QByteArray prepareLiabilityRiskTxData ( const int& action, const int& type );
    virtual QByteArray prepareFastPlayTxData      ( const int& action, const int& type );
    virtual QByteArray preparePollaGolTxData();
    virtual bool isPrintingAllowed                ( QString &qsMessage );
	QString readHtml();
private slots:
    // Where action: WinningsEnums::Request_51_X_ActionFlag
    // Where type  : WinningsEnums::Request_51_0_Type
	void requestWinningNumbersSlot ( const int& action, const int& type );
	void requestDrawResultsSlot    ( const int& action, const int& type );
	void requestDrawOddsSlot       ( const int& action, const int& type );
	void requestDrawInfoSlot       ( const int& action, const int& type );
	void requestLiabilityRiskSlot  ( const int& action, const int& type );
    void requestFastPlaySlot       ( const int& action, const int& type );
    void requestPollaGolProgramSlot();

private:
    QScopedPointer<WinningsFormPrivate> const d_ptr;
	Q_DECLARE_PRIVATE ( WinningsForm )
	Q_DISABLE_COPY ( WinningsForm )
};

#endif // WINNINGSFORM_H
