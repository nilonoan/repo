/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#include <QCoreApplication>
#include "CustomerDisplay.h"
#include "CustomerDisplay_adaptor.h"
#include "LocalEventLoggerEvents.h"
#include "DbusWrapper.h"
#include "DisplayMessageJsonObj.h"
#include "JsonOperations.h"
#include "ImtsEnumerations.h"
#include "GetConfigValue.h"
#include "QDBusReply"
#include "IMTSPrintLibPublic/HtmlParsing.h"
/**
 * @file CustomerDisplay.cpp
 * @brief This class is responsible displaying data onto the CustomerDisplay
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */


/**
  * @sa CustomerDisplay
  * @brief CustomerDisplay constructor
  */
CustomerDisplay::CustomerDisplay( QObject* parent )
	: QObject(parent)
	, m_lHighPriMessageList   ( QList<QByteArray> () )
	, m_lNormalPriMessageList ( QList<QByteArray> () )
	, m_lLowPriMessageList    ( QList<QByteArray> () )
	, m_pHtmlParsing          ( new HtmlParsing(this,false))
{
	setUpDBusInterface();

	m_lockMessageDisplay = new QSemaphore(1);
	m_pcDisplayMessageJsonObj = new DisplayMessageJsonObj (this);


	QObject::connect ( this, &CustomerDisplay::enqueueMessage,
					   this, &CustomerDisplay::enqueueMessageSlot, Qt::QueuedConnection );

	QObject::connect ( this, &CustomerDisplay::displayMessage,
					   this, &CustomerDisplay::displayMessageSlot, Qt::QueuedConnection );

	initializeCduHardware ();

	m_bNeedsInitialize = false;

	timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(updateTimerSlot()));
	timer->start(2000);

	qint64 m_pid = QCoreApplication::applicationPid();
	QString qsMsg = QString(QStringLiteral("Application: %1 with pid: %2 started")).arg (qAppName ()).arg(m_pid);
	LOG ( qsMsg );
	qDebug () << qsMsg;

	emit imtsServiceUp ( qAppName (), m_pid );


}

CustomerDisplay::~CustomerDisplay()
{
	delete m_lockMessageDisplay;
}


/**
  * @sa setUpDBusInterface
  * @brief register cancellation's app service with DBus.
  */
void CustomerDisplay::setUpDBusInterface ()
{
	new CustomerDisplayOperationsAdaptor(this);
	QDBusConnection dBusConnection = QDBusConnection::sessionBus();

	if (!dBusConnection.registerService("com.intralot.IMTSCdu") ) {
		qDebug () << "Another Customer Display is already running";
		LOG( QStringLiteral("Another Customer Display is already running"));
		//QCoreApplication::instance()->quit();
		exit(0);
	}

	QString qsQDbusConnection = QStringLiteral("Connection name for Customer Dispaly") + dBusConnection.baseService();
	LOG(qsQDbusConnection);

	bool bWasRegistrationSuccessfull = dBusConnection.registerObject(QStringLiteral("/CustomerDisplayOperations"), this);
	if (!bWasRegistrationSuccessfull) {
		LOG("!!! ERROR !!! /CustomerDisplayOperations could not register to D-Bus");
		exit(0);
	}
}

/**
 * @sa initializeCduHardware
 * @brief takes all the necessary actions to initialize the CDU hardware so that it starts accepting
 * data. At the end of the initialization triggeres displayMessage so that that the default message
 * is shown onto the screen.
 */
void CustomerDisplay::initializeCduHardware ()
{
	clearAllCduMessagesSlot ();
	mimo.InitializeScreen(800,480,24);
	wakeUpDisplayMessageSlot ();
    QVariantMap mHtmlData;
    mHtmlData.insert(QStringLiteral("TotalInSession"),QStringLiteral("WELCOME"));
    displayCduBmpFromHtml(mHtmlData);
}

/**
 * @sa wakeUpDisplayMessageSlot
 * @brief triggers next message display upon timer expiration or when an empty message
 * was sent for displaying.
 */
void CustomerDisplay::wakeUpDisplayMessageSlot ()
{
	if ( !m_lockMessageDisplay->available () ) {
		m_lockMessageDisplay->release ();
	}

	if ( ( m_lHighPriMessageList.size   () ||
		   m_lNormalPriMessageList.size () ||
		   m_lLowPriMessageList.size    () )
		 && m_lockMessageDisplay->available () ) {

		emit displayMessage ();
	}
}


/**
  * @sa enqueueMessageSlot
  * @param message display json data
  * @brief This routine adds data the provided data in the available queues and if necessary will trigger
  * signal for message displaying.
  */
void CustomerDisplay::enqueueMessageSlot ( const QByteArray& qbaDisplayData )
{

	DisplayMessageJsonObj displayMessageJsonObj;

	QJson::JsonOperations::JsonToqObject ( qbaDisplayData, &displayMessageJsonObj );

	QString qsPriority = displayMessageJsonObj.readDisplayPriority ();

	m_mutex.lock ();
	// First In First Displayed fashion
	if ( qsPriority == QStringLiteral("HIGH") ) {

		m_lHighPriMessageList.append (qbaDisplayData);

	} else if ( qsPriority == QStringLiteral("NORMAL")) {

		m_lNormalPriMessageList.append (qbaDisplayData);

	} else if ( qsPriority == QStringLiteral("LOW")) {

		m_lLowPriMessageList.append (qbaDisplayData);
	}
	m_mutex.unlock ();

	// Only trigger signal when the queues have size of one and no semaphore is available
	// (meaning that a message display is in progress), to avoid fludding the system with events.
	if ( ( m_lHighPriMessageList.size   () == 1 ||
		   m_lNormalPriMessageList.size () == 1 ||
		   m_lLowPriMessageList.size    () == 1 )
		 && m_lockMessageDisplay->available () ) {

		emit displayMessage ();
	}
}


/**
  * @sa displayMessageSlot
  * @brief sends data to cdu for displaying.
  */


void CustomerDisplay::displayMessageSlot ()
{
	if ( !mimo.IsConnected() )
	{
		qDebug ("Display is disconnected, message ignored");
		return;
	}


	if ( m_lockMessageDisplay->tryAcquire () ) { // lock display process

		QByteArray qbaMsgDisplay = QByteArray ();

		m_mutex.lock ();

		if ( !m_lHighPriMessageList.isEmpty () ) {

			qbaMsgDisplay = m_lHighPriMessageList.takeFirst ();

		} else if ( !m_lNormalPriMessageList.isEmpty () ) {

			qbaMsgDisplay = m_lNormalPriMessageList.takeFirst ();

		} else if ( !m_lLowPriMessageList.isEmpty () ) {

			qbaMsgDisplay = m_lLowPriMessageList.takeFirst ();

		}

		m_mutex.unlock ();


		if ( !qbaMsgDisplay.isEmpty () ) {

			QJson::JsonOperations::JsonToqObject ( qbaMsgDisplay, m_pcDisplayMessageJsonObj );

			if ( !m_pcDisplayMessageJsonObj->readMessage ().isEmpty () ) {


				qint32 iDisplayTime = m_pcDisplayMessageJsonObj->readDisplayTime ();

				// Load bitmap, load message into the loaded bitmap, render to qimage and send to cdu
				QString msg = m_pcDisplayMessageJsonObj->readMessage ();
				LOG (QString(QStringLiteral("Cdu Msg: %1 %2")).arg (msg).arg (iDisplayTime==-1?QStringLiteral(""):QString(QStringLiteral("displayed for %1 secs")).arg (iDisplayTime/1000)));

				if ( m_useTemplate ) {

					QVariantMap mHtmlData;
					mHtmlData.insert      (QStringLiteral("description"),msg);
					mHtmlData.insert      (QStringLiteral("TotalInSession"),m_pcDisplayMessageJsonObj->readTotalAmount());
					displayCduBmpFromHtml(mHtmlData);

				} else {

					mimo.DisplayImage(QString("/IMTSResources/LinkToYourProject/CduBitmaps/Empty800x480.png").toLatin1 ().data (),true);
					mimo.ShowText(QRect(5,5,800,600), msg, QString("Roboto"), 60, true);
				}

				//writeDataToCduSlot (/*provide image data as a byteArray and transmit to physical*/);
				if ( iDisplayTime == -1 ) {

					wakeUpDisplayMessageSlot ();

				} else {

					QTimer::singleShot ( m_pcDisplayMessageJsonObj->readDisplayTime (), this, SLOT(wakeUpDisplayMessageSlot()) );
				}

			} else {

				LOG(QStringLiteral("An empty message was sent for displaying"));
				wakeUpDisplayMessageSlot ();
			}

		} else {

			// QString str1(tr("Welcome"));
			// mimo.DisplayImage(QString("/IMTSResources/LinkToYourProject/CduBitmaps/Empty800x480.png").toLatin1 ().data (),true);
			// mimo.ShowText(QRect(5,5,500,500), str1, QString("Arial"), 60, true);

			if ( !m_lockMessageDisplay->available () ) {
				m_lockMessageDisplay->release ();
			}
			qDebug () << QStringLiteral("High Normal Low Queues are empty. No display message was processed.");
			LOG(QStringLiteral("High Normal Low Queues are empty. No display message was processed."));

		}

	} else {

		qDebug ("Message display in progress....");

		LOG(QStringLiteral("Message display in progress...."));
	}
}


/**
  * @sa connectionWithServerManagerEstablishedSlot
  * @brief The slot is triggered upon application establishes connection with server manager.
  * It will initialize the user interface as well as all necessary objects for our customer
  * display.
  */
void CustomerDisplay::connectionWithServerManagerEstablishedSlot ()
{
	LOG("Customer Display Established connection with Server manager");
}

/**
 * @sa clearAll
 * @brief clear all pending messages
 */
void CustomerDisplay::clearAllCduMessagesSlot ()
{
	m_mutex.lock ();

	m_lHighPriMessageList.clear ();
	m_lNormalPriMessageList.clear ();
	m_lLowPriMessageList.clear ();

	m_mutex.unlock ();

	wakeUpDisplayMessageSlot (); // Will display the default message

}

/**
 * @sa displayCduMessageSlot
 * @param json data containing (DisplayMessageJsonObj). Info about how to
 * display message and the message
 * @brief triggers slot to queue data for display
 */
void CustomerDisplay::displayCduMessageSlot ( const QByteArray qbaMesasge )
{
	emit enqueueMessage ( qbaMesasge );
}

/**
 * @sa displayCduMessageSlotFromFile
 * @param qsFile
 * @brief just for debugging
 */
void CustomerDisplay::displayCduMessageSlotFromFile ( const QString qsFile )
{
	QVariantMap m = QJson::JsonOperations::JsonObjectFromFile (qsFile);
	displayCduMessageSlot (QJson::JsonOperations::VariantToByteArray (m));
}



/**
 * @sa displayCduMessageSlot
 * @param message
 * @param time for message to live in Cdu
 * @param message priority
 * @brief queue message data for display
 */
void CustomerDisplay::displayCduMessageSlot ( const QString qsMesasge, const int iTimeToLive, const QString qsPriority )
{

	DisplayMessageJsonObj displayMessageJsonObj;

	displayMessageJsonObj.setMessage (qsMesasge);
	displayMessageJsonObj.setDisplayPriority (qsPriority);
	displayMessageJsonObj.setDisplayTime (iTimeToLive);

	emit enqueueMessage ( QJson::JsonOperations::qObjectToJson ( &displayMessageJsonObj ) );
}



/**
 * @sa writeDataToCduSlot
 * @brief write actual data to physical.
 */
bool CustomerDisplay::writeDataToCduSlot ( const QByteArray& qbaCduData )
{
	Q_UNUSED ( qbaCduData )
	qDebug () << "Here get device handle and write data to it";
	return true;
}




/**
 * @sa updateTimerSlot
 * @brief check for connectivity every 2 secs.
 */
void CustomerDisplay::updateTimerSlot ()
{

	if ( !mimo.IsConnected() ) {

		m_bNeedsInitialize = true;
		mimo.RemoveDevice ();
		mimo.SetInitialized(false);
		emit sgnStatus ( int(Cdu_NotConnected) );

	} else  {

		if ( m_bNeedsInitialize ) {

			initializeCduHardware();
			m_bNeedsInitialize = false;

			if ( mimo.IsConnected () ) {
				emit sgnStatus ( int(Cdu_AllOK) );
			}
		}
	}
}

/**
 * @sa checkAndGetStatus
 * @brief return cdu status on demand;
 */
int CustomerDisplay::checkAndGetStatus ()
{
	if ( !mimo.IsConnected() || m_bNeedsInitialize ) {

		m_bNeedsInitialize = true;
		mimo.RemoveDevice ();
		mimo.SetInitialized(false);
		return int(Cdu_NotConnected);
	} else {

		return ( int(Cdu_AllOK) );
	}
}


/**
 * @sa wakeUpService
 */
void CustomerDisplay::wakeUpService ( const QString serviceNameThatsWakesMeUp)
{
	LOG ( QString("%1 wakes up by %2").arg (qAppName ()).arg (serviceNameThatsWakesMeUp));
}

/**
 * @sa exitService
 */
void CustomerDisplay::exitService ( const QString serviceNameThatKillsMe )
{
	LOG (QString("%1 was killed by %2").arg (qAppName ()).arg (serviceNameThatKillsMe));
	QEventLoop createLocalLoop;
	QTimer::singleShot ( 1000, &createLocalLoop, SLOT(quit()) );
	createLocalLoop.exec ();
	QCoreApplication::quit ();
}
/**
 * @sa displayCduBmpFromHtml
 * @param qvMessage
 */
void CustomerDisplay::displayCduBmpFromHtml(QVariantMap qvMessage)
{
	static QString qsPath = GetConfigValue::getHtmlTemplatesPath () + "CustomerDisplayUnit/CduImage.html";
	m_pHtmlParsing->makeGuiData (qsPath,qvMessage);
	QImage image = QImage::fromData (m_pHtmlParsing->renderHtmlToByteArray ());
	mimo.DisplayImageFromData(image,false);
}
