/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file Game527XTx.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */

#include "Game527XTx.h"
#include "Lotos5TxRxFactoryPlugin.h"
#include "SystemWideConstValues.h"

/** Forces registration */
const Game527XTx* const Game527XTx::m_Game527XTx = new Game527XTx;


Game527XTx::Game527XTx()
{
    static bool bIsProductRegistered = false;

    if ( !bIsProductRegistered ) {
        Lotos5TxRxFactoryPlugin::registerItCssObject(QStringLiteral("Game527XTx"), this);
        bIsProductRegistered = !bIsProductRegistered;
    }
}

/**
 * @sa setTrnsGm5000Type
 * @brief Initialiazes TRNS_GM_5000 type with data
 */
void Game527XTx::setTrnsGm5000Type ( const int& iArea )
{

    QVariantMap mAdditionalGamesPerArea;
    mAdditionalGamesPerArea = m_lAreaValues.at(iArea).toMap().value(QStringLiteral("AdditionalGamePerArea")).toMap();

    if ( m_pcGameTxData->readGameCode() == RACHA ) {
        if ( mAdditionalGamesPerArea.isEmpty() || ( mAdditionalGamesPerArea.contains("0") && mAdditionalGamesPerArea.contains("10") ) ) {
            m_pTrns_gm_5000->type = 3;
        } else if ( mAdditionalGamesPerArea.contains("0") ) {
            m_pTrns_gm_5000->type = 2;
        } else if ( mAdditionalGamesPerArea.contains("10") ) {
            m_pTrns_gm_5000->type = 1;
        }

    } else if ( m_pcGameTxData->readGameCode() == LOTTO_CL ) {
        if ( mAdditionalGamesPerArea.isEmpty() ) {
            m_pTrns_gm_5000->type = 1;
        } else {

            int combination = 1;    // Loto already selected
            if ( mAdditionalGamesPerArea.contains("Revancha") ) {
                combination += 2;
            }
            if ( mAdditionalGamesPerArea.contains("Desquite") ) {
                combination += 4;
            }
            if ( mAdditionalGamesPerArea.contains("Multiplicador") ) {
                combination += 32;
            }
            if ( mAdditionalGamesPerArea.contains("Ahora si que si!") ) {
                combination += 8;
            }
            if ( mAdditionalGamesPerArea.contains("Jubilazo") ) {
                combination += 16;
            }

            m_pTrns_gm_5000->type = combination;
        }
    } else {
        m_pTrns_gm_5000->type = m_lAreaValues.at(iArea).toMap().value(QStringLiteral("DefaultMarks")).toInt ();
    }

}

/**
 * @sa createItCss
 * @brief creates and return a product to plugin factory.
 */
ItCssMessagePayloadInterface * Game527XTx::createItCss() const
{
    return new Game527XTx;
}
