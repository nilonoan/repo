/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file Game5272Rx.cpp
 * @author: Andreas Stergiou stergioua@intralot.com
 */
#include "Game5272Rx.h"
#include "Lotos5TxRxFactoryPlugin.h"
#include "DbusWrapper.h"
#include "SystemWideConstValues.h"
#include "GetConfigValue.h"
#include <QStringBuilder>

/** Forces registration */
const Game5272Rx* const Game5272Rx::m_Game5272Rx = new Game5272Rx;

/**
 * @sa Game5272Rx
 * @brief Constructor. Register's the class name with factory plugin
 */
Game5272Rx::Game5272Rx ()
{
	static bool bIsProductRegistered = false;

	if ( !bIsProductRegistered ) {
		Lotos5TxRxFactoryPlugin::registerCssItObject("Game5272Rx", this);
		bIsProductRegistered = !bIsProductRegistered;
	}

	m_mHtmlData = QVariantMap ();
}

/**
 * @sa processReceivedData
 * @param guidata
 * @param cs reply
 * @param pointer to receivedData
 * @param data for client
 * @brief implements the business logic when we got fresh play rx data.
 */
ImtsRxErrors::eeRxStatus Game5272Rx::processReceivedData( const QByteArray& qbaGuiData,
											const int& iCsReply,
											const char* const pReceivedData,
											QVariantMap& qvmDataForGui )
{

	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;

	if ( iCsReply != RD_OK && iCsReply != REGENERATE_TICKET ) {
		QString qsRiskError = getRiskManagementError ( iCsReply, 10/*numberOfGroups*/ );
		if ( !qsRiskError.isEmpty () ) {
			qvmDataForGui.insert (CS_ERROR_MSG, "");        // Avoid on return overriding with generic message
			qvmDataForGui.insert (MSGBOX_MSG, qsRiskError); // Data for gui's msg box
			qvmDataForGui.insert (EDIT_ACTION, 1);          // eeEditAction::EditRequest.
		}
		return eRxStatus;
	}

	bool bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();

	eRxStatus = GamesCommonRx::initializeGameRxData( qbaGuiData, pReceivedData, bIsTraining );

	if ( eRxStatus == ImtsRxErrors::RX_SUCCESS ) {

		PlayPrintReceiptFlags eReceiptFor(NormalTicket);

		if ( bIsTraining ) {
			eReceiptFor = GamesCommonRx::Training;

		} else {

			quint32 iPlayActionFlag = getPlayAction ();

			if ( iPlayActionFlag & Imts::PilotOperation ) {
				eReceiptFor |= Pilot;
			}

			if(iPlayActionFlag & Imts::PromotionTriggeredGenDataFollow) {
				GamesCommonRx::HandlePromotions(pReceivedData);
			}
		}

		if ( iCsReply == REGENERATE_TICKET ) {


			// In training mode ProcessCouponRegenrateDataRx object provides from a file game's data. No need to generate them.
			if ( !bIsTraining ) {

				eRxStatus = generateExchangeTicketFor5000 ( qbaGuiData, pReceivedData );

				if ( eRxStatus != ImtsRxErrors::RX_SUCCESS ) {
					return eRxStatus;
				}
			}

			if (qvmDataForGui.value(QStringLiteral("IsExchange")).toBool() ) {
				eReceiptFor |= Exchange;
			} else {
				eReceiptFor |= TicketRepeat;
			}

			eRxStatus = makeCommonReceipt ( eReceiptFor, qvmDataForGui, pReceivedData );

			addPlayToLastPlayList ();

		} else {

			eRxStatus = makeCommonReceipt ( eReceiptFor, qvmDataForGui, pReceivedData );
			addPlayTransactionToCustomerSession(); // The call will also add the last play to play list

			if ( eRxStatus == ImtsRxErrors::RX_PAPER_LOW ) {

				qvmDataForGui.insert(MSGBOX_MSG, ErrorHandling::getRxPathError(eRxStatus));
				eRxStatus = ImtsRxErrors::RX_SUCCESS;

			} else { // if we don't do the following, then Games center would think transaction failed, because the returned map will be empty.

				QString qsTransactionHeader = QString(getGameTxData ()->readHeader () % QString(QObject::tr(" Cost: ")));
				qvmDataForGui.insert(NEW_TRANSACTION_HEADER, QString(qsTransactionHeader % getFormatedCouponCost ()));
			}


			if ( !bIsTraining ) {
				quint32 iPlayActionFlag = getPlayAction ();
				if (iPlayActionFlag & Imts::PromotionTriggeredGenDataFollow) {
					GamesCommonRx::ExecutePromotionsActions();
				}
			}
		}
	}

	return eRxStatus;

}

/**
 * @sa createCssIt
 * @brief creates and return a product to plugin factory.
 */
CssItParseMessageInterface* Game5272Rx::createCssIt() const
{
	return new Game5272Rx;
}

