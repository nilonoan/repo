/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#include "ExternalPlay.h"

class ExternalPlayPrivate
{

public:

    ExternalPlayPrivate()
        :ref(1)
    {
    }

    QAtomicInt ref;

    // C++11 type of member initilization.
    quint32 m_iGameCode = 0;
    quint32 m_iSubGameCode = 0;
    quint32 m_iNumberOfTickets = 1;
    quint32 m_iNumberOfAreas = 1;
    quint32 m_iNumberOfDraws = 1;
    quint32 m_iFutureDraws = 0;
    quint32 m_iMultiplier = 1;
    quint32 m_iBetType = -1;
    quint32 m_iDrawType = 0;
    quint32 m_iSystem = 0;
    quint32 m_iAdditionalGame = -1;
    QVariantList m_iAdditionalGamePerArea = QVariantList ();
    bool    m_bDirectTransmission = false;
    QVariantMap m_mCustomData = QVariantMap ();
	quint32 m_iCouponSource = 0;
	QByteArray m_qbaPromotionData = QByteArray ();
};

ExternalPlay::ExternalPlay(QObject *parent)
    : QObject(parent)
    , d_ptr ( new ExternalPlayPrivate )
{
}

ExternalPlay::ExternalPlay( const ExternalPlay &other )
    : QObject () // call QObject default ctor
{
    d_ptr = other.d_ptr;
    d_ptr->ref.ref ();
}

ExternalPlay::~ExternalPlay ()
{
    if (!d_ptr->ref.deref()) {
        delete d_ptr;
    }
}

/**
 * @sa clearData
 * @brief clears data
 */
void ExternalPlay::clearData ()
{
    setGameCode (0);
    setSubGameCode (0);
    setNumberOfTickets (1);
    setNumberOfAreas (1);
    setNumberOfDraws (1);
    setFutureDraws (0);
    setMultiplier (1);
    setBetType (-1);
    setDrawType (0);
    setSystem (0);
    setAdditionalGame (-1);
    setAdditionalGamePerArea (QVariantList());
    setDirectTransmission (false);
    setCustomData (QVariantMap());
	setCouponSource (-1);
	setPromotionData ( QByteArray () );
}

/////////////////////////////////////////////// GETTERS //////////////////////////////////////////////////
quint32 ExternalPlay::readGameCode () const
{
    Q_D ( const ExternalPlay );
    return d->m_iGameCode;
}
quint32 ExternalPlay::readSubGameCode () const
{
    Q_D ( const ExternalPlay );
    return d->m_iSubGameCode;
}
quint32 ExternalPlay::readNumberOfTickets () const
{
    Q_D ( const ExternalPlay );
    return d->m_iNumberOfTickets;
}
quint32 ExternalPlay::readNumberOfAreas () const
{
    Q_D ( const ExternalPlay );
    return d->m_iNumberOfAreas;
}
quint32 ExternalPlay::readNumberOfDraws () const
{
    Q_D ( const ExternalPlay );
    return d->m_iNumberOfDraws;
}
quint32 ExternalPlay::readFutureDraws () const
{
    Q_D ( const ExternalPlay );
    return d->m_iFutureDraws;
}
quint32 ExternalPlay::readMultiplier () const
{
    Q_D ( const ExternalPlay );
    return d->m_iMultiplier;
}
quint32 ExternalPlay::readBetType () const
{
    Q_D ( const ExternalPlay );
    return d->m_iBetType;
}
quint32 ExternalPlay::readDrawType () const
{
    Q_D ( const ExternalPlay );
    return d->m_iDrawType;
}
quint32 ExternalPlay::readSystem () const
{
    Q_D ( const ExternalPlay );
    return d->m_iSystem;
}
quint32 ExternalPlay::readAdditionalGame () const
{
    Q_D ( const ExternalPlay );
    return d->m_iAdditionalGame;
}
QVariantList ExternalPlay::readAdditionalGamePerArea () const
{
    Q_D ( const ExternalPlay );
    return d->m_iAdditionalGamePerArea;
}
bool ExternalPlay::readDirectTransmission () const
{
    Q_D ( const ExternalPlay );
    return d->m_bDirectTransmission;
}
QVariantMap ExternalPlay::readCustomData () const
{
    Q_D ( const ExternalPlay );
    return d->m_mCustomData;
}
quint32 ExternalPlay::readCouponSource () const
{
	Q_D ( const ExternalPlay );
	return d->m_iCouponSource;
}
QByteArray ExternalPlay::readPromotionData () const
{
	Q_D ( const ExternalPlay );
	return d->m_qbaPromotionData;
}

/////////////////////////////////////////////// SETTERS //////////////////////////////////////////////////
void ExternalPlay::setGameCode ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iGameCode == iVal ) return;
    d->m_iGameCode = iVal;
    emit gameCodeChanged ();
}
void ExternalPlay::setSubGameCode ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iSubGameCode == iVal ) return;
    d->m_iSubGameCode = iVal;
    emit subGameCodeChanged ();
}
void ExternalPlay::setNumberOfTickets ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iNumberOfTickets == iVal ) return;
    d->m_iNumberOfTickets = iVal;
    emit numberOfTicketsChanged ();
}
void ExternalPlay::setNumberOfAreas ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iNumberOfAreas == iVal ) return;
    d->m_iNumberOfAreas = iVal;
    emit numberOfAreasChanged ();
}
void ExternalPlay::setNumberOfDraws ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iNumberOfDraws == iVal ) return;
    d->m_iNumberOfDraws = iVal;
    emit numberOfDrawsChanged ();
}
void ExternalPlay::setFutureDraws ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iFutureDraws == iVal ) return;
    d->m_iFutureDraws = iVal;
    emit futureDrawsChanged ();
}
void ExternalPlay::setMultiplier ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iMultiplier == iVal ) return;
    d->m_iMultiplier = iVal;
    emit multiplierChanged ();
}
void ExternalPlay::setBetType ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iBetType == iVal ) return;
    d->m_iBetType = iVal;
    emit betTypeChanged ();
}
void ExternalPlay::setDrawType ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iDrawType == iVal ) return;
    d->m_iDrawType = iVal;
    emit drawTypeChanged ();
}
void ExternalPlay::setSystem ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iSystem == iVal ) return;
    d->m_iSystem = iVal;
    emit systemChanged ();
}
void ExternalPlay::setAdditionalGame ( const quint32 &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iAdditionalGame == iVal ) return;
    d->m_iAdditionalGame = iVal;
    emit additionalGameChanged ();
}
void ExternalPlay::setAdditionalGamePerArea ( const QVariantList &iVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_iAdditionalGamePerArea == iVal ) return;
    d->m_iAdditionalGamePerArea = iVal;
    emit additionalGamePerAreaChanged ();
}
void ExternalPlay::setDirectTransmission (const bool& bVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_bDirectTransmission == bVal ) return;
    d->m_bDirectTransmission = bVal;
    emit directTransmissionChanged ();
}
void ExternalPlay::setCustomData ( const QVariantMap &mVal )
{
    Q_D ( ExternalPlay );
    if ( d->m_mCustomData == mVal ) return;
    d->m_mCustomData = mVal;
    emit customDataChanged ();
}
void ExternalPlay::setCouponSource ( const quint32& iVal )
{
	Q_D ( ExternalPlay );
	if ( d->m_iCouponSource == iVal ) return;
	d->m_iCouponSource = iVal;
	emit couponSourceChanged ();
}
void ExternalPlay::setPromotionData ( const QByteArray& qbaVal )
{
	Q_D ( ExternalPlay );
	if ( d->m_qbaPromotionData == qbaVal ) return;
	d->m_qbaPromotionData = qbaVal;
	emit promotionDataChanged ();
}
