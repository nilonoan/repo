/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/

#include <QtCore/QDateTime>
#include "GamesCommonRx.h"
#include "JsonOperations.h"
#include "BarcodeUtilities/BarcodeUtilities.h"
#include "LocalEventLoggerEvents.h"
#include "FormatAmount/FormatAmount.h"
#include "CustomerSession/CustomerSessionTrnsData.h"
#include "SystemWideConstValues.h"
#include "PlaceServerManagerRequest.h"
#include "ClientServerDefinitions.h"
#include "ImtsLotos5Enumerations.h"
#include "ImtsGamesEnums.h"
#include "FormatDate/FormatDate.h"
#include "DbusWrapper.h"
#include <QtCore/QSettings>
#include "promotionmanager.h"
#include <functional>
#include "Plays/ExternalPlay.h"
#include "Lotos5Helper/MiscReceiptInfo.h"

/**
 * @file GamesCommonRx.cpp
 * @class GamesCommonRx
 * @brief Performs all the necessary initialization for all game plays
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */

/**
 * @sa GamesCommonRx
 * @brief constructor
 */
GamesCommonRx::GamesCommonRx ()
	: HandlePromotionOutcomes  (HandlePromotionOutcomes::enTICKET)
	, m_pcGameTxData           ( nullptr )
	, m_qsSaveReceiptFileName  ( QString () )
	, m_pTrns_Hdr              ( nullptr )
	, m_pCss_It_1              ( nullptr )
	, m_pReply_100_1           ( nullptr )
	, m_qbaFakedData           ( QByteArray () )
	, m_PlayActionFlag         ( 0 )
	, m_bIsTraining            ( false )
	, m_lTrainingBarcode       ( QList<ulong>() )
	, m_promotionsActionsDataList (QVariantList())
{
	m_pcGameTxData = new GameTxData;
	setGameTxData(m_pcGameTxData);
}


GamesCommonRx::~GamesCommonRx()
{
	if ( m_pcGameTxData ) {
		delete m_pcGameTxData;
		m_pcGameTxData = 0;
	}
}

/**
  * @sa initializeGameRxData
  * @param byte array with gui data
  * @param pointer to received data
  * @return eeRxStatus
  * @brief Performs basic initializations to help us build the receipt
  */
ImtsRxErrors::eeRxStatus GamesCommonRx::initializeGameRxData ( const QByteArray& qbaGuiData, const char* pReceivedData, const bool& bIsTraining )
{
	ImtsRxErrors::eeRxStatus eReturnRxStatus = ImtsRxErrors::RX_OTHER_ERROR;

	setTraining (bIsTraining);

	bool bOK = false;
	bOK = QJson::JsonOperations::JsonToqObject( qbaGuiData, m_pcGameTxData );

	if ( bOK ) { // unlikely to be false. Sanity check.
		eReturnRxStatus = ImtsRxErrors::RX_SUCCESS;
	}

	if ( bIsTraining ) {

		setBarcode (); // need to do when in training mode.

		QSettings settings (QStringLiteral("Intralot"), QStringLiteral("Scm"));
		settings.sync ();

		quint32 iTrnsNumber = settings.value (QStringLiteral("TransactionNumberTraining"), QVariant(0)).toInt ();
		++iTrnsNumber;

		settings.setValue (QStringLiteral("TransactionNumberTraining"), QVariant(iTrnsNumber));
		settings.sync ();

	} else {

		if ( pReceivedData ) {

			m_pCss_It_1    = (CSS_IT_1*)    ( &pReceivedData [0] );
			m_pTrns_Hdr    = (TRNS_HDR*)    ( &m_pCss_It_1->hdr);
			m_pReply_100_1 = (REPLY_100_1*) ( &pReceivedData [ sizeof(CSS_IT_1) ] );

			setPlayAction ( m_pCss_It_1->flags );
			setReceivedData(pReceivedData);
		}
	}

	return eReturnRxStatus;
}


/**
 * @sa isTraining
 * @return true/false for training mode
 */
bool GamesCommonRx::isTraining () const
{
	return m_bIsTraining;
}

/**
 * @sa setTraining
 * @param bIsTraining
 */
void GamesCommonRx::setTraining (const bool& bIsTraining )
{
	m_bIsTraining = bIsTraining;
}

/**
  * @sa setBarcode
  * @brief sets the training barcode which contains the game code, and ticket's cost.
  */
void GamesCommonRx::setBarcode ()
{
	if ( m_bIsTraining ) {

		const int N_DECIMAL_POINTS_PRECISION = 100; // get from config, means 2 decimals.

		double dCost = float(m_pcGameTxData->readCost ());
		int decimalPart = ((int)(dCost*N_DECIMAL_POINTS_PRECISION)%N_DECIMAL_POINTS_PRECISION);

		QString s = QString::number (qrand()%9999);
		s.append (QString::number (getGameCode ()).rightJustified (5,'0',false));
		m_lTrainingBarcode << s.toInt ()
						   << (ulong)dCost // intergal part
						   << decimalPart; // franctional part
	}
}

/**
 * @sa makeReply_100_1_From_Reply_50_1
 * @param qbaGameData
 * @param pReceivedData buffer containing Reply50_1 data
 * @brief initializes Reply100_1 from Reply50_1 data
 */
void GamesCommonRx::makeReply_100_1_From_Reply_50_1 ( const char* pReceivedData )
{

	m_qbaFakedData.fill ('\0', 1024); // create the array that will be used to hold the fake data.

	REPLY_50_1  *pReply_50_1  = (REPLY_50_1*)&pReceivedData[sizeof(CSS_IT_1)];

	m_pCss_It_1     = (CSS_IT_1*)m_qbaFakedData.constData ();
	m_pReply_100_1  = (REPLY_100_1*)(&m_qbaFakedData.constData ()[sizeof(CSS_IT_1)]);

	memcpy( m_pCss_It_1, pReceivedData, sizeof(CSS_IT_1) );

	memcpy ( m_pReply_100_1->cpn_id,  pReply_50_1->cpn_id, 3*sizeof(long) );

	double dCost = pReply_50_1->hdr.data[Imts::Reply50_1_CouponAmountInt]/100.+0.00001; // in cents
	FormatAmount::convertDoubleToAMOUNTSTRC ( dCost, (AMOUNT_STRC *)&m_pReply_100_1->amount );

	m_pReply_100_1->game                                        = pReply_50_1->game;
	m_pReply_100_1->cpn                                         = pReply_50_1->cpn;
	m_pReply_100_1->data[Imts::Reply100_1_AcceptanceTime]       = m_pCss_It_1->sys_time;
	m_pReply_100_1->data[Imts::Reply100_1_Columns]              = 0;                                                             // Not used
	m_pReply_100_1->data[Imts::Reply100_1_StartingDraw]         = pReply_50_1->hdr.data[Imts::Reply50_1_NewStartingDraw];
	m_pReply_100_1->data[Imts::Reply100_1_StartingDrawDeadline] = pReply_50_1->hdr.data[Imts::Reply50_1_NewStartingDrawDeadline];
	m_pReply_100_1->data[Imts::Reply100_1_EndingDraw]           = pReply_50_1->hdr.data[Imts::Reply50_1_NewEndingDraw];
	m_pReply_100_1->data[Imts::Reply100_1_EndingDrawDeadline]   = pReply_50_1->hdr.data[Imts::Reply50_1_NewEndingDrawDeadline];
	m_pReply_100_1->data[7]                                     = pReply_50_1->hdr.data[Imts::Reply50_1_MultiDraws];             // Number of valid draws
	//    pCssIt_1->hdr.trns                                        = pCssIt_1->hdr.trns;                                        // Leave as is, EXCHANGE doesn't have a trnsnr
	//    pCssIt_1->hdr.crc                                         = pCssIt_1->data;                                            // This contains the CRC of the original coupon
	m_pReply_100_1->data[9]                                     = pReply_50_1->hdr.data[Imts::Reply50_1_TeamCoupons];            // This should contain the random in exchange
}


/**
 * @sa initCouponHeaderDataExchange
 * @param pReply_50_1
 */
void GamesCommonRx::initCouponHeaderDataExchange ( const REPLY_50_1* pReply_50_1 )
{
	Q_UNUSED ( pReply_50_1 )
}

/**
 * @sa initCouponHdrFlagsExchange
 * @param pReply_50_1
 */
void GamesCommonRx::initCouponHdrFlagsExchange ( const REPLY_50_1* pReply_50_1 )
{
	Q_UNUSED ( pReply_50_1 );
	qWarning() << "Override initCouponHdrFlagsExchange based on your project";
}

/**
 * @sa initFlagsFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the flags for exchange ticket. Very much project dependent. Default does TW.
 */
void GamesCommonRx::initFlagsFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 )
{

	if ( pTrns_gm_2000->flags == Imts::Gm2000QpSelectionMultiplier ) {

		mAreaValues.insert (QStringLiteral("Gmx000Flags"), 1/* eQpVariations::eQpPanelA*/ );  // 1 what Coupon data understands

	} else if ( pTrns_gm_2000->flags == Imts::Gm2000PartialQp ) {

		mAreaValues.insert (QStringLiteral("Gmx000Flags"), 5/* eQpVariations::ePartialQp*/ ); // 5 what Coupon data understands
	}

}

/**
 * @sa initTypeFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
 */
void GamesCommonRx::initTypeFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode  )
{
	Q_UNUSED( iGameCode )

	ImtsGamesEnums::PickXPlayTypeFlags ePickXPlayTypeFlag;

	if ( pTrns_gm_2000->type == 1 ) {

		ePickXPlayTypeFlag = ImtsGamesEnums::Straight;

	} else if ( pTrns_gm_2000->type == 2 ) {

		ePickXPlayTypeFlag = ImtsGamesEnums::Box;

	} else if ( pTrns_gm_2000->type == 4 ) {

		ePickXPlayTypeFlag = ImtsGamesEnums::StraightBox ;

	} else if ( pTrns_gm_2000->type == 8 ) {

		ePickXPlayTypeFlag = ImtsGamesEnums::FrontBackPairs;

	} else  if ( pTrns_gm_2000->type == 16 ) {

		ePickXPlayTypeFlag = ImtsGamesEnums::SecondDigit ;
	}

	mAreaValues.insert ( QStringLiteral("PickXPlayType"), ePickXPlayTypeFlag.operator int () );
}


/**
 * @sa initValueFor2000Exchange
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief initializes the value for exchange ticket. Very much project dependent. Default does TW.
 */
void GamesCommonRx::initValueFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode )
{
	Q_UNUSED( iGameCode )

	mAreaValues.insert ( QStringLiteral("Multiplier"), pTrns_gm_2000->value );
}

/**
 * @sa initCustomExchangeDataFor2000
 * @param mArea
 * @param pTrns_gm_2000
 * @return mArea modified
 * @brief do any other initialization you want for exchange
 */
void GamesCommonRx::initCustomExchangeDataFor2000 ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 )
{
	Q_UNUSED ( mAreaValues )
	Q_UNUSED ( pTrns_gm_2000 )
}

/**
 * @sa postExchangeOperations
 * @param pGameTxData
 * @param pReceivedData
 * @brief We have initialized GameTxData at the best we could do from C/S data. Now we need do
 * the final touches. Send GameTxData to Games which it will finalize GameTxData initialization.
 * GameTxData will be readily available after we receive the updated data, so that we can continue
 * printing an exchange ticket.
 * For TicketReplay case, we don't print but we send the data to TicketRepeat form which it will post
 * them as play to Games to initiate a play request. Be ready to face bugs arround Ticket Regeneration.
 * I'm not sure I've covered all cases.
 */
ImtsRxErrors::eeRxStatus GamesCommonRx::postExchangeOperations ( GameTxData* pGameTxData, const char* pReceivedData )
{
	Q_UNUSED ( pReceivedData)

	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;

	QByteArray qbaGameTxData = QJson::JsonOperations::qObjectToJson( pGameTxData );

	QDBusReply<QByteArray> dbusMessageReply = DbusWrapper::getGameOperationsInterface ()->getGameTxDataForTicketRegenerationSlot ( qbaGameTxData );

	if ( !dbusMessageReply.isValid () ) {
		QDBusError dbusError = dbusMessageReply.error();
		LOG( dbusError.message() );
		LOG( dbusError.errorString(dbusError.type()) );

		LOG("Games could not proces data for exchanged or ticketRepeat. Propably Games crashed!");

		eRxStatus = ImtsRxErrors::RX_REGENERATE_TICKET_ERROR;

	} else {

		QByteArray qbaUpdatedGameTxData = dbusMessageReply.value();

		if ( qbaUpdatedGameTxData.isEmpty() || qbaUpdatedGameTxData.isNull () ) {
			eRxStatus = ImtsRxErrors::RX_REGENERATE_TICKET_ERROR;
			LOG("Exchange/TicketRepeat data initialization failed. Empty data returned");
		} else {
			// Here we got a buffer from games that is ready to be transmitted to C/S as if a normal play was
			// to be placed. Games Gui however, do no know anything about iSecure, so when they return the data
			// for us that property is not set. So, we retrieve iSecure from original passed in pGameTxData data
			// termporalily store it here, and then back again to GameTxData object after conversion from byteArray
			// to Ojbect.
			QString qsISecurePrintable = pGameTxData->readIsecurePrintable ();
			QJson::JsonOperations::JsonToqObject ( qbaUpdatedGameTxData, pGameTxData );
			pGameTxData->setIsecurePrintable ( qsISecurePrintable );
		}
	}

	return eRxStatus;
}


/**
 * @brief generateExchangeTicketFor2000
 * @param qbaGameData
 * @param pReceivedData
 * @return status ImtsRxErrors::RX_SUCCESS if all OK else RX_EXCHANGE_TICKET_ERROR if something goes wrong in the process
 * @note this is pretty much Taiwan Based. If you want to do yours override.
 */
ImtsRxErrors::eeRxStatus GamesCommonRx::generateExchangeTicketFor2000 ( const QByteArray& qbaGameData, const char* pReceivedData )
{
	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;
	QJson::JsonOperations::JsonToqObject( qbaGameData, m_pcGameTxData ); // some values have already been initialized by the ExchangeDataRx.cpp object

	makeReply_100_1_From_Reply_50_1 (pReceivedData);

	REPLY_50_1* pReply_50_1     = (REPLY_50_1*)&pReceivedData[sizeof(CSS_IT_1)];
	TRNS_GM_2000* pTrns_gm_2000 = nullptr;
	QVariantMap  mAreaValues    = QVariantMap ();  // used to hold data for the area
	QVariantList lMarkList      = QVariantList (); // used to hold the makrs
	QVariantList lAreaList      = QVariantList (); // used to hold in a list all data for the areas
	QVariantList lPanelList     = QVariantList (); // is used to hold the list of numbers in each panel. (nested list)
	quint8 iMark = 0;


	// Initially populate with as many empty areas this game supports.
	mAreaValues.insert (QStringLiteral("IsAreaEmpty"), true );
	for ( quint8 iNewArea = 0; iNewArea < m_pcGameTxData->readNumberOfAreas (); ++iNewArea ){
		lAreaList.append (mAreaValues);
	}

	for ( quint8 iArea = 0; iArea < pReply_50_1->hdr.grps; ++iArea ) {

		pTrns_gm_2000 = (TRNS_GM_2000*)&pReceivedData[sizeof(CSS_IT_1)+sizeof(REPLY_50_1)+iArea*sizeof(TRNS_GM_2000)];

		mAreaValues.clear();
		lPanelList.clear  ();
		iMark = 0;


		mAreaValues.insert (QStringLiteral("IsAreaVoid"),  false );
		mAreaValues.insert (QStringLiteral("IsAreaEmpty"), false );


		for ( quint8 iPanel = 0; iPanel < m_pcGameTxData->readNumberOfPanels (); ++iPanel ) {

			lMarkList.clear ();

			iMark = 10*iPanel; // go to next panel. Picks always have 10 marks.

			for ( quint8 iMarkIdx = 0;  iMarkIdx < m_pcGameTxData->readMarksInPanelsList ().at (iPanel).toInt (); ++iMarkIdx ) { // readMarksInPanelList contains the numbers of available marks in each panel. Check config.

				if ( !isSet  ( (char*) pTrns_gm_2000->data, iMark+iMarkIdx ) ) {
					lMarkList.append (iMarkIdx);
				}
			}

			// Type 16 means second digit, in which case panel0 and panel2 for pick3 game would not have any digits.
			// C/S rightly so, sends the digit in panel1 only. Now, if we just leave the panels empty when we
			// generate the data, Games will complain for parsing errors. So, we need to detect the case second digit
			// case and add any digit, to those panels so we can pass through coupon error checking. During data
			// transmission, we detect the type being second digit and panel0 and panel2 numbers are ignored and
			// not sent to C/S.
			if ( pTrns_gm_2000->type == 16 && lMarkList.isEmpty () ) {
				lMarkList.append (0); // just init with any digit.
			}
			lPanelList.insert (iPanel, lMarkList);

		}

		mAreaValues.insert ( QStringLiteral("SelectionMarksInPanels"), lPanelList );

		initFlagsFor2000Exchange ( mAreaValues, pTrns_gm_2000 );

		initTypeFor2000Exchange ( mAreaValues, pTrns_gm_2000, pReply_50_1->game );

		initValueFor2000Exchange ( mAreaValues, pTrns_gm_2000, pReply_50_1->game );

		initCustomExchangeDataFor2000 ( mAreaValues, pTrns_gm_2000 );

		lAreaList.replace ( iArea, mAreaValues );

	}

	m_pcGameTxData->setAreaList( lAreaList );

	initCouponHeaderDataExchange ( pReply_50_1 );
	initCouponHdrFlagsExchange ( pReply_50_1 );

	eRxStatus = postExchangeOperations ( m_pcGameTxData , pReceivedData );

	return eRxStatus;
}

/**
 * @sa initTypeFor5000Exchange
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
 */
void GamesCommonRx::initTypeFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode )
{
	Q_UNUSED ( iGameCode )
	mAreaValues.insert ( QStringLiteral("DefaultMarks"), pTrns_gm_5000->type ); // Total number of min marks the user is allowed to select without system, i.e. lotto 6/49 6 is the number. For bettype games min is set to the betType user selected.
}

/**
 * @sa initGameFlagsFor5000Exchange
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief initializes the flags for exchange ticket.
 */
void GamesCommonRx::initGameFlagsFor5000Exchange (QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000 , const int& iGameCode )
{
	Q_UNUSED ( iGameCode )
	mAreaValues.insert (QStringLiteral("Gmx000Flags"), pTrns_gm_5000->flags );
}

/**
 * @sa initCustomExchangeDataFor5000
 * @param mArea
 * @param pTrns_gm_5000
 * @return mArea modified
 * @brief do any other initialization you want for exchange
 */
void GamesCommonRx::initCustomExchangeDataFor5000 ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000 )
{
	Q_UNUSED ( mAreaValues )
	Q_UNUSED ( pTrns_gm_5000 )
}


/**
 * @brief generateExchangeTicketFor5000
 * @param qbaGameData
 * @param pReceivedData
 * @return status ImtsRxErrors::RX_SUCCESS if all OK else RX_EXCHANGE_TICKET_ERROR if something goes wrong in the process
 */
ImtsRxErrors::eeRxStatus GamesCommonRx::generateExchangeTicketFor5000 ( const QByteArray &qbaGameData, const char* pReceivedData )
{
	ImtsRxErrors::eeRxStatus eRxStatus = ImtsRxErrors::RX_SUCCESS;
	QJson::JsonOperations::JsonToqObject( qbaGameData, m_pcGameTxData ); // some values have already been initialized by the ExchangeDataRx.cpp object

	makeReply_100_1_From_Reply_50_1 (pReceivedData);

	REPLY_50_1* pReply_50_1     = (REPLY_50_1*)&pReceivedData[sizeof(CSS_IT_1)];
	TRNS_GM_5000* pTrns_gm_5000 = nullptr;
	QVariantMap  mAreaValues    = QVariantMap  (); // is used to hold data for the area
	QVariantList lMarkList      = QVariantList (); // is used to hold the makrs
	QVariantList lAreaList      = QVariantList (); // is used to hold in a list all data for the areas
	QVariantList lPanelList     = QVariantList (); // is used to hold the list of numbers in each panel. (nested list)


	// Initially populate with as many empty areas this game supports.
	mAreaValues.insert (QStringLiteral("IsAreaEmpty"), true );

	for ( quint8 iNewArea = 0; iNewArea < m_pcGameTxData->readNumberOfAreas (); ++iNewArea ){
		lAreaList.append (mAreaValues);
	}

	for ( quint8 iArea = 0; iArea < pReply_50_1->hdr.grps; ++iArea ) {

		pTrns_gm_5000 = (TRNS_GM_5000*)&pReceivedData[sizeof(CSS_IT_1)+sizeof(REPLY_50_1)+iArea*sizeof(TRNS_GM_5000)];

		mAreaValues.clear ();
		lPanelList.clear  ();

		mAreaValues.insert (QStringLiteral("IsAreaVoid"),  false );
		mAreaValues.insert (QStringLiteral("IsAreaEmpty"), false );

		for ( int iPanel = 0; iPanel < m_pcGameTxData->readNumberOfPanels (); ++iPanel ) {

			lMarkList.clear   ();

			if ( iPanel == 0 ) {

				for ( quint8 iMark = 0;  iMark < m_pcGameTxData->readMarksInPanelsList ().at (iPanel).toInt (); ++iMark ) {

					if ( !isSet  ( (char*) pTrns_gm_5000->data, iMark ) ) {
						lMarkList.append (iMark);
					}
				}

			} else if ( iPanel == 1 ) {

				quint8 iAvailNumbersInPanelA = m_pcGameTxData->readMarksInPanelsList ().at (0).toInt (); // is used to tell as the number of avalailable marks for each panel. 6/49 49 is the number, 6/38 1/8: 38 is the number for panelA, 8 is the number for panelB
				quint8 iAvailNumbersInPanelB = m_pcGameTxData->readMarksInPanelsList ().at (1).toInt ();;

				for ( quint8 iMark = 0;  iMark < iAvailNumbersInPanelB; ++iMark ) {

					if ( !isSet  ( (char*) pTrns_gm_5000->data, iAvailNumbersInPanelA+iMark ) ) {
						lMarkList.append (iMark);
					}
				}
			}

			lPanelList.insert (iPanel, lMarkList);
		}

		mAreaValues.insert ( QStringLiteral("SelectionMarksInPanels"), lPanelList );

		initTypeFor5000Exchange ( mAreaValues, pTrns_gm_5000, pReply_50_1->game );

		initSysFor5000Exchange ( mAreaValues, pTrns_gm_5000, pReply_50_1->game );

		initGameFlagsFor5000Exchange ( mAreaValues, pTrns_gm_5000, pReply_50_1->game );

		initCustomExchangeDataFor5000 ( mAreaValues, pTrns_gm_5000 );

		lAreaList.replace ( iArea, mAreaValues);
	}

	m_pcGameTxData->setAreaList( lAreaList );

	initCouponHeaderDataExchange ( pReply_50_1 );
	initCouponHdrFlagsExchange ( pReply_50_1 );

	eRxStatus = postExchangeOperations ( m_pcGameTxData, pReceivedData );

	return eRxStatus;
}


/**
 * @sa setPlayAction
 * @param flags in css_it_1
 * @brief sets the play action as indicated in css_it_1 flags field.
 */
void GamesCommonRx::setPlayAction( const uint& flags )
{
	m_PlayActionFlag = flags;
}

/**
 * @sa getPlayAction
 * @param play action as indicated inside flags in css_it_1
 * @brief get play action as indicate in css_it_1 flags.
 */
quint32 GamesCommonRx::getPlayAction()
{
	return m_PlayActionFlag;
}

/**
  * @sa getHeaderCrc
  * @brief return header crc in string format
  */
QString GamesCommonRx::getHeaderCrc ()
{
	return QString::number( m_pCss_It_1->hdr.crc, 16 ).toUpper();
}

/**
  * @sa getTrnsNumber
  * @brief return the transaction number
  */
QString GamesCommonRx::getTrnsNumber ()
{
	if ( m_bIsTraining ) {

		QSettings settings (QStringLiteral("Intralot"), QStringLiteral("Scm"));
		settings.sync ();

		quint32 iTrnsNumber = settings.value (QStringLiteral("TransactionNumberTraining"), QVariant(0)).toInt ();

		return QString::number( iTrnsNumber ).rightJustified (10,'0');

	} else {

		return QString::number( m_pCss_It_1->hdr.trns ).rightJustified (10,'0');
	}

}


/**
 * @sa getSalesDate
 * @return sales date recorded at c/s
 */
QString GamesCommonRx::getSalesDate ( QString qsDateFormat )
{
	QDateTime dateTime = QDateTime::currentDateTime ();

	if ( !m_bIsTraining ) {
		dateTime.setTime_t ( getReply100_1_DataX(Imts::Reply100_1_AcceptanceTime) );
	}

	return FormatDate::toLocalDateTime ( dateTime, FormatDate::CustomDateFormatWithTime, qsDateFormat );
}

/**
 * @sa getCouponNumber
 * @param
 * @brief
 */
QString GamesCommonRx::getCouponNumber ()
{
	if ( m_bIsTraining ) {

		static quint16 iCouponNumber = 0;
		return QString::number ( ++iCouponNumber ).rightJustified (10,'0');

	} else {

		return QString::number ( m_pReply_100_1->cpn ).rightJustified (10,'0');
	}
}

/**
 * @sa getFirstDraw
 * @return first draw as string
 * @brief returns first draw as string
 */
QString GamesCommonRx::getFirstDraw ( int width )
{
	if ( m_bIsTraining ) {
		return QString::number ( 1 ).rightJustified (width,'0');
	}
	return QString::number ( m_pReply_100_1->data[Imts::Reply100_1_StartingDraw] );
}

/**
 * @sa getLastDraw
 * @return last draw as string
 * @brief returns last draw as string
 */
QString GamesCommonRx::getLastDraw ( int width )
{
	if ( m_bIsTraining ) {
		return QString::number ( m_pcGameTxData->readMultidraws () ).rightJustified (width,'0');
	}
	return QString::number ( m_pReply_100_1->data[Imts::Reply100_1_EndingDraw]);
}

/**
 * @sa getNumberOfValidDraws
 * @return
 * @note Very much bound to taiwan
 */
qint32 GamesCommonRx::getNumberOfValidDraws ()
{
	if ( m_bIsTraining ) {

		int iValidDraws = getLastDraw().toInt() - getFirstDraw().toInt();

		return ++iValidDraws;

	} else {

		return m_pReply_100_1->data[7];
	}
}

/**
  * @sa getFirstDrawDate
  * @return firstDrawDate
  * @brief returns the first draw in a pre-determined format
  */
QString GamesCommonRx::getFirstDrawDate ( QString qsDateFormat, bool bWithTime )
{
	QDateTime dateTime = QDateTime::currentDateTime ();


	if ( !m_bIsTraining  ) {

		dateTime.setTime_t ( m_pReply_100_1->data[Imts::Reply100_1_StartingDrawDeadline] ) ;

	} else {

		dateTime = dateTime.addDays ( m_pcGameTxData->readFuturedraws () );
	}

	FormatDate::DateFormatFlag dateFormatFlag = bWithTime?FormatDate::CustomDateFormatWithTime : FormatDate::CustomDateFormat;

	return FormatDate::toLocalDateTime ( dateTime, dateFormatFlag, qsDateFormat );

}

/**
  * @sa getLastDrawDate
  * @return lastDrawDate
  * @brief returns the last draw in a pre-determined format
  */
QString GamesCommonRx::getLastDrawDate ( QString qsDateFormat, bool bWithTime )
{
	QDateTime dateTime = QDateTime::currentDateTime ();

	if ( !m_bIsTraining  ) {

		dateTime.setTime_t ( getReply100_1_DataX(Imts::Reply100_1_EndingDrawDeadline) ) ;

	} else {

		if ( m_pcGameTxData->readFuturedraws () ) {
			dateTime.setTime_t (m_pcGameTxData->readFuturedraws ());
		}
		dateTime = dateTime.addDays (m_pcGameTxData->readMultidraws ());
	}

	FormatDate::DateFormatFlag dateFormatFlag = bWithTime?FormatDate::CustomDateFormatWithTime : FormatDate::CustomDateFormat;

	return FormatDate::toLocalDateTime ( dateTime, dateFormatFlag, qsDateFormat );
}

/**
 * @sa getReply100_1_Datax
 * @return reply_100_1 data[x]
 * @brief returns reply_100_1 data[x]
 */
long GamesCommonRx::getReply100_1_DataX( const uint& uiIndex )
{
	if ( !m_bIsTraining  ) {

		long iData = m_pReply_100_1->data[uiIndex ];
		return iData;

	} else {

		return 0;
	}
}


/**
  * @sa getBarcode
  * @return barcode ready for printing
  * @brief the barcode in stringformat ready for printing
  */
QString GamesCommonRx::getBarcode ()
{
	QString qsBarcode = QString ();

	if ( m_bIsTraining ) {

		unsigned long barcode_num[3] = { m_lTrainingBarcode.at (0),
										 m_lTrainingBarcode.at (1),
										 m_lTrainingBarcode.at (2) };

		qsBarcode = BarcodeUtilities::format35DigitBarcodeForPrinting((unsigned long*)barcode_num, QChar(' '));

	} else {

		QList<ulong> lBarcode = getPlainBarcode ();
		QString qsIsecure = getIsecurePrintable ().remove (QRegExp("\\D"));

		unsigned long barcode_num[5] = { lBarcode.at (0),
										 lBarcode.at (1),
										 lBarcode.at (2),
										 qsIsecure.left (10).toULong (),
										 qsIsecure.right (10).toULong ()
									   };

		qsBarcode = BarcodeUtilities::calcCrcForIsecureBarcode ( static_cast<unsigned long*>(&barcode_num[0]), QChar(' ') );
	}

	return qsBarcode;
}

/**
  * @sa getPlainBarcode
  * @return barcode in a QList
  * @brief returns the barcode in a QList<ulong>
  */
QList<ulong> GamesCommonRx::getPlainBarcode ()
{
	if ( m_bIsTraining ) {

		return m_lTrainingBarcode;

	} else {

		QList<ulong> lBarcode = QList<ulong>() << m_pReply_100_1->cpn_id[0] << m_pReply_100_1->cpn_id[1] << m_pReply_100_1->cpn_id[2];
		return lBarcode;
	}
}

/**
  * @sa getFormatedCouponCost
  * @return amount
  * @brief returns the amount. It is already formated.
  */
QString GamesCommonRx::getFormatedCouponCost ()
{
	QString qsFormatedAmount = QString ();

	if ( m_bIsTraining ) {

		qsFormatedAmount = FormatAmount::getFormatedAmount ( m_pcGameTxData->readCost () );

	} else {

		qsFormatedAmount = FormatAmount::getFormatedAmount ( (AMOUNT_STRC *)&m_pReply_100_1->amount );

	}

	return qsFormatedAmount;
}

/**
  * @sa getPlainCouponCost
  * @return amount as double
  * @brief returns the amount as double
  */
double GamesCommonRx::getPlainCouponCost ()
{
	double dPlainCost = 0.0;

	if ( m_bIsTraining ) {

		dPlainCost = m_pcGameTxData->readCost ();

	} else {

		dPlainCost = FormatAmount::convert_AMOUNTSTRC_db( (AMOUNT_STRC *)&m_pReply_100_1->amount );
	}

	return dPlainCost;
}

/**
  * @sa getColumns
  * @return columns
  * @brief returns number of columns in string format
  */
QString GamesCommonRx::getColumns ()
{
	QString qsColumns = QString ();

	if ( m_bIsTraining ) {

		qsColumns = QString::number ( m_pcGameTxData->readColumns () );

	} else {

		qsColumns = QString::number ( m_pReply_100_1->data[Imts::Reply100_1_Columns] );
	}

	return qsColumns;
}

/**
  * @sa getGameCode
  * @return the game's gamecode
  */
int GamesCommonRx::getGameCode() const
{
	if ( m_bIsTraining ) {

		return m_pcGameTxData->readGameCode() ;

	} else {

		return int(m_pReply_100_1->game);
	}
}

/**
 * @brief Returns the gamecode if the gamecode is not 16000. Returns the subgamecode if gamecode>16000
 * @return Returns the gamecode if the gamecode is not 16000. Returns the subgamecode if gamecode>16000
 */
unsigned int GamesCommonRx::getWorkingGamecode() const
{
	unsigned int iWorkingGamecode = 0;

	if ( getGameCode() < 16000 ) {

		iWorkingGamecode = getGameCode();

	} else {

		if ( !m_bIsTraining ) {

			char* buffer_start = (char*)m_pCss_It_1;
			RTRNS_GM_V16000* prtrns_gm_16000 = (RTRNS_GM_V16000*)&buffer_start[sizeof(REPLY_100_1) + sizeof(CSS_IT_1)];

			if ( prtrns_gm_16000->val[0]>0 ) {

				TRNS_GM_16000* ptrns_gm_16000 = (TRNS_GM_16000*)&buffer_start[sizeof(RTRNS_GM_V16000) + sizeof(REPLY_100_1) + sizeof(CSS_IT_1)];
				iWorkingGamecode =  ptrns_gm_16000->sub_game;
			}

		} else {

			iWorkingGamecode = m_pcGameTxData->readSubGameCode();
		}
	}
	return iWorkingGamecode;
}

/**
  * @sa getNumberOfAreas
  * @return the number of areas the game supports
  */
int GamesCommonRx::getNumberOfAreas()
{
	qint32 iNumberOfAreas = m_pcGameTxData->readNumberOfAreas();
	return iNumberOfAreas;
}

/**
  * @sa getNumberOfPanels
  * @return the number of panels the game supports
  */
int GamesCommonRx::getNumberOfPanels()
{
	qint32 iNumberOfPanels = m_pcGameTxData->readNumberOfPanels();
	return iNumberOfPanels;
}

/**
  * @sa getHtmlTemplateFile
  * @brief game's html file location
  */
QString GamesCommonRx::getHtmlTemplateFile()
{
	QString qsHtmlTemplate = m_pcGameTxData->readGameHtmlTemplate();
	return qsHtmlTemplate;
}

/**
  * @sa getHtmlPreviewTemplateFile
  * @brief game's html preview file location
  */
QString GamesCommonRx::getHtmlPreviewTemplateFile()
{
	QString qsHtmlTemplate = m_pcGameTxData->readGameHtmlPreviewTemplate ();
	return qsHtmlTemplate;
}

/**
  * @sa getLogo
  * @return logo game
  * @brief returns logo game
  */
QString GamesCommonRx::getLogo()
{
	QString qsGameLogo = m_pcGameTxData->readGameLogo ();
	return qsGameLogo;
}

/**
  * @sa getPanel
  * @param area
  * @param panel
  * @brief return the numbers for passed in parameteres.
  */
QVariantList GamesCommonRx::getPanel ( const int& iArea, const int& iPanel )
{
	if ( iPanel < m_pcGameTxData->readNumberOfPanels () ) {

		QVariantList qvlPanel = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("SelectionMarksInPanels")).toList().at(iPanel).toList();
		return qvlPanel;

	} else {

		return QVariantList ();
	}
}

/**
  * @sa getArea
  * @param area
  * @brief
  */
QVariantMap GamesCommonRx::getArea ( const int& iArea )
{
	QVariantMap mArea = m_pcGameTxData->readAreaList().at(iArea).toMap();
	return mArea;
}

/**
  * @sa getAreaCost
  * @param area
  * @brief
  */
double GamesCommonRx::getAreaCost ( const int& iArea )
{
	double dAreaCost = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("PricePerArea")).toDouble ();
	return dAreaCost;
}

/**
  * @sa getAreaMultiplier
  * @param area
  * @brief
  */
int GamesCommonRx::getAreaMultiplier ( const int& iArea )
{
	qint32 iMultiplier = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("Multiplier")).toInt ();
	return iMultiplier;
}

/**
  * @sa getAreaFlags
  * @param area
  * @brief
  */
quint8 GamesCommonRx::getAreaFlags ( const int& iArea )
{
	quint8 iFlags = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("Gmx000Flags")).toInt ();
	return iFlags;
}

/**
  * @sa getAreaDefaultMarks
  * @param area
  * @brief for mark games default marks is the playType
  */
quint8 GamesCommonRx::getAreaDefaultMarks ( const int& iArea )
{
	quint8 iDefaultMarks = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("DefaultMarks")).toInt ();
	return iDefaultMarks;
}

/**
 * @sa getPickPlayType
 * @param area
 * @return the playtype as set in gui for pick game.
 */
quint32 GamesCommonRx::getPickPlayType ( const int& iArea )
{
	quint32 iPickPlayType = m_pcGameTxData->readAreaList().at(iArea).toMap().value(QStringLiteral("PickXPlayType")).toInt ();
	return iPickPlayType;
}

/**
 * @sa getIsecurePrintable
 * @return the Isecure number in printing format
 */
QString GamesCommonRx::getIsecurePrintable ()
{
#if (ISEC_SCHEME == 1 || ISEC_SCHEME == 2)

	if ( m_bIsTraining ) {

#if (ISEC_SCHEME==1)
		QString qsDummyISecure = QString ().fill (QChar('0'),20);
		qsDummyISecure.insert (5,QChar(' '));
		qsDummyISecure.insert (11,QChar(' '));
		qsDummyISecure.insert (17,QChar(' '));

#elif ( ISEC_SCHEME == 2)
		QString qsDummyISecure = QString ().fill (QChar('0'),40);
#endif
		return qsDummyISecure;

	} else {

		QString qsISecurePrintable = m_pcGameTxData->readIsecurePrintable ();
		return qsISecurePrintable;
	}
#else
	return QString ();
#endif
}

/**
 * @sa getGameName
 * @return the game's name
 */
QString GamesCommonRx::getGameName ()
{
	return m_pcGameTxData->readGameName ();
}


/**
 * @sa getRiskManagementError
 * @param iCsReply
 * @param the number of groups petential blocked by risk management. It's all user driven.
 * @return The string containing the groups blocked in case risk management is in place.
 *
 * Reformat the risk managment reply. Replies are of power of two,
 * That is: 5007 means 2^0+2^1+2^2 group A B C are blocked
 *          5011 means 2^0+2^1+2^3 group A B D are blocked
 *          etc..
 */
QString GamesCommonRx::getRiskManagementError (const int& iCsReply , const uint& iNumberOfGroups )
{
	QString qsRiskMessage = QString ();

	if ( iCsReply == RD_RSK_TOL_BLK ) {

		qsRiskMessage = ErrorHandling::getCsError (iCsReply);

	} else if ( iCsReply > RD_RSK_TOL_BLK && iCsReply <= RD_RSK_TOL_BLK+pow(2,iNumberOfGroups)-1 ) { // special case for risk management, where (2^10)-1=1023, where 10=max number of groups (areas)

		quint32 iMask = 1;
		quint32 iRiskReply = iCsReply - RD_RSK_TOL_BLK;

		for ( uint iRiskMsgDefinition = 1; iRiskMsgDefinition <= iNumberOfGroups; ++iRiskMsgDefinition ) {

			if ( iMask&iRiskReply ) {

				qsRiskMessage += ErrorHandling::getCsError(RD_RSK_TOL_BLK+iRiskMsgDefinition);
				qsRiskMessage +="\n";
			}

			iMask<<=1;
		}

	} else if ( iCsReply >= RD_RSK_TOL_BLK+pow(2,iNumberOfGroups) && iCsReply <= 6999 ) {

		// This is the case where we got a reply for risk management we cannot handle. More than 10 groups.
		qsRiskMessage = QString("%1: %2").arg ( ErrorHandling::getRxPathError(ImtsRxErrors::RX_CS_UNKNOWN_REPLY) ).arg (iCsReply);
	}

	return qsRiskMessage;
}


/**
 * @sa getEan13Barcode
 * @param number of longs the s/w should expect. The default is 2. Just pass
 * the number your project is expecting and the method will calculate the correct one for you.
 * So, you don't really have to override the method if number of longs is not 2.
 * Ean number follows - Games 5000:After REPLY_100_1 - Games 2000:After TRNS_GM_2000 * groups - Game 7000:After RTRNS_GM_7000
 * @param bIsRaffle. usually these games belong to 2000 family games but have no groups. In that case we need to distinguish it
 * so that we cust the ean pointer to the right memory address.
 * @return the ean barcode as string
 */
QString GamesCommonRx::getEan13Barcode ( quint8 iNumberOfLongs, bool bIsRaffle )
{

	QString qsEanBarcode = QString ();
	qint32 iGameCode = getGameCode ();
	unsigned long* pEanData = nullptr;

	if (m_bIsTraining){

		qsEanBarcode = "5391518924700";
		return qsEanBarcode;
	}


	if ( (IS_PICK(iGameCode)) || (IS_RAFFLE (iGameCode)) ) {

		if ( !bIsRaffle ) {
			TRNS_GM_2000* pTrns_gm_2000 = (TRNS_GM_2000*) ( (const char*)(m_pReply_100_1) + sizeof(REPLY_100_1) );
			pEanData = (unsigned long*) ((const char*)(pTrns_gm_2000) + pTrns_gm_2000->grp*sizeof(TRNS_GM_2000) );
		} else {
			pEanData = (unsigned long*)( (const char*)(m_pReply_100_1) + sizeof(REPLY_100_1)); // raffle games usually have no number of groups so ean comes right after REPLY_100_1
		}

	} else if ( IS_LOTTO(iGameCode) ) {

		pEanData = (unsigned long*)( (const char*)(m_pReply_100_1) + sizeof(REPLY_100_1));

	} else if ( IS_PTVGAME(iGameCode ) ) {

		// The default does TellyBingo for PLI. You might have to override method.
		RTRNS_GM_7000* pRTrns_gm_7000 = (RTRNS_GM_7000*) ( (const char*)(m_pReply_100_1) + sizeof(REPLY_100_1) );
		pEanData = (unsigned long*) ((const char*)(pRTrns_gm_7000) + sizeof(RTRNS_GM_7000) );

	} else {

		qWarning() << "Please add your game familly to support ean";
	}

	if ( pEanData ) {

		for ( int i = 0; i < iNumberOfLongs; ++i ) {
			qsEanBarcode.append (QString::number (*pEanData));
			++pEanData;
		}
	}

	// You got to check that the number C/S sends is 12-digits + 1-digit the check digit,
	// that is total 13-digits. We request from HtmlParsing object to create and return
	// the ean13 barcode by using Star's library for that. The library will receive a 12-digit
	// number and generate the barGraph data for us and it will auto calculate the check digit.
	// That is it expects a 12-digit number otherwise it will throw an exception and it will
	// brutally exit and no ticket will be printed. We got to watch out. We return 13-digits
	// to our caller to include the check digit in barcode text, but when we request the graphical
	// barcode we chop the last digit.
	if ( qsEanBarcode.size () != 13 ) {
		qsEanBarcode.clear ();
	}

	return qsEanBarcode;

}

/**
  * @sa getTrnsHdrPtr
  * @return pointer to TRNS_HDR
  * @brief returns a pointer to TRNS_HDR
  */
TRNS_HDR* GamesCommonRx::getTrnsHdrPtr() const
{
	if ( !m_bIsTraining ) {
		return m_pTrns_Hdr;
	} else {
		return nullptr;
	}
}

/**
  * @sa getCssIt1Ptr
  * @return pointer to CSS_IT_1
  * @brief returns a pointer to CSS_IT_1
  */
CSS_IT_1* GamesCommonRx::getCssIt1Ptr() const
{
	if ( !m_bIsTraining ) {
		return m_pCss_It_1;
	} else {
		return nullptr;
	}
}

/**
  * @sa getReply100_1Ptr
  * @return pointer to REPLY_100_1
  * @brief returns a pointer to REPLY_100_1
  */
REPLY_100_1* GamesCommonRx::getReply100_1Ptr() const
{
	if ( !m_bIsTraining ) {
		return m_pReply_100_1;
	} else {
		return nullptr;
	}
}

/**
 * @brief getGameTxData
 * @return
 */
GameTxData* GamesCommonRx::getGameTxData () const
{
	return m_pcGameTxData;
}

/** @sa getEmail
 * @return the email we ought to send receipt to, if one exists
 * @brief returns email
 */
QString GamesCommonRx::getEmail () const
{
	return m_pcGameTxData->readEmail ();
}

/** @sa getEmailPassword
 * @return the email password we ought to encrypt data with
 * @brief returns email password
 */
QString GamesCommonRx::getEmailPassword () const
{
	return m_pcGameTxData->readEmailPassword ();
}

/**
 * @sa getOnTicketMessages
 * @return the list of messages to be printed on the ticket.
 */
QVariantList GamesCommonRx::getOnTicketMessages () const
{
	QVariantList qvlOnTicketMsgList = m_pcGameTxData->readOnTicketMessageList ();
	return qvlOnTicketMsgList;
}

/**
 * @sa getGameRuleMessageList
 * @return the list of messages to be printed on the ticket.
 */
QVariantList GamesCommonRx::getGameRuleMessageList () const
{
	QVariantList qvlGameRuleMessageList = m_pcGameTxData->readGameRuleMessageList ();
	return qvlGameRuleMessageList;
}

QByteArray GamesCommonRx::getGamePromotionData() const
{
	QByteArray promotionData = m_pcGameTxData->readPromotionData();
	return promotionData;
}

/**
 * @sa setSaveReceiptFileName
 */
void GamesCommonRx::setSaveReceiptFileName ( const QString& qsFileName )
{
	m_qsSaveReceiptFileName = qsFileName;
	m_qsSaveReceiptFileName.append (QStringLiteral(".html"));
}

/**
  * @sa addPlayTransactionToCustomerSession
  * @brief Populates the map addTransaction method expects and calls it to adds play transaction
  * to customer session.
  */
void GamesCommonRx::addPlayTransactionToCustomerSession ()
{
	int iSession = m_pcGameTxData->readSessionId ();
	QString qsGameName = getGameName ();

	CustomerSessionTrnsData customerSessionTrnsData;
	customerSessionTrnsData.setHandleId ( 0 ); // 0 because only one customer is currently supported. We could add more customers.
	customerSessionTrnsData.setSessionId ( iSession );

	if ( m_bIsTraining ) {
		customerSessionTrnsData.setTransactionDateTime ( QDateTime::currentDateTime ().toTime_t () );
	} else {
		customerSessionTrnsData.setTransactionDateTime ( m_pCss_It_1->sys_time );
	}
	customerSessionTrnsData.setTransactionDescription ( qsGameName );
	customerSessionTrnsData.setTransactionType (TransactionTypes::Play);
	customerSessionTrnsData.setTransactionNumber ( getTrnsNumber () );
	customerSessionTrnsData.setAmount ( getPlainCouponCost () );
	customerSessionTrnsData.setTimesPrinted (0);

	/*--- In case we have promotion discount amount --- */
	QString qsDiscountAmount = getPromotionDiscountAmount();
	if(qsDiscountAmount != QString::null){
		double dblDiscountAmount = qsDiscountAmount.toDouble();
		customerSessionTrnsData.setAuxAmount(dblDiscountAmount);
	}
	/*------------------------------------------------- */

	QString qsBarcode = getBarcode ()%QString("-")%getIsecurePrintable ();
	customerSessionTrnsData.setBarcode ( qsBarcode);
	customerSessionTrnsData.setLastPrintFileName (m_qsSaveReceiptFileName);


	QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&customerSessionTrnsData);

	PlaceServerManagerRequest placeServerManagerRequest;
	placeServerManagerRequest.aSyncRequest ( ClientServerDefinitions::CustomerSessionUpdate, qbaJsonData );

}

/**
 * @sa HandlePromotions
 * @param pReceivedData
 * @return
 */
bool GamesCommonRx::HandlePromotions (const char *pReceivedData)
{
	if(m_bIsTraining == true)
		return true;

	bool pendingPromotions;
	unsigned long m_InitialTriggerBarcode[3];
	memset ( m_InitialTriggerBarcode, 0x00, sizeof(m_InitialTriggerBarcode) );

	m_promotionsActionsDataList.clear();

	QVariantMap qvmDataForGui;

	REPLY_100_1* pReply100_1 = (REPLY_100_1*)&pReceivedData[sizeof(CSS_IT_1)];
	memcpy ( m_InitialTriggerBarcode, pReply100_1->cpn_id, sizeof(m_InitialTriggerBarcode) );

	bool res = GamesCommonRx::HandleTicketPromotions ( pReceivedData, m_promotionsActionsDataList, pendingPromotions );

	/**  TODO:: Here we might have to ask for further data from CS. So keep in mind that we might have to place transaction(s)
		 to get the data. What triggers us to ask for extra data is the pendingPromotion flag.
	**/
	//while(res==true && pendingPromotions==true){
		// Create new transaction to get the pending promotions
	//  res = GamesCommonRx::HandlePendingPromotions(pReceivedData,m_InitialTriggerBarcode,m_promotionsActionsDataList,pendingPromotions);
	//}

	if ( res == true ) {
		QByteArray qbaPromotionData;
		PromotionData promotionData;
		PromotionTypes::PromotionType ePromoType;

		//  Go through promotion action list, find the discount amount (if we have discount) ====
		//  and update the trigger ticket promotion data with the discount amount.
		bool bPromotionDiscountFound = false;
		QString qsPromotionAmount = QString::null;
		for ( QVariant outcome : m_promotionsActionsDataList ) {
			qbaPromotionData = outcome.toByteArray ();
			QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);

			ePromoType = PromotionTypes::PromotionType(promotionData.readPromotionType ());
			if(ePromoType == PromotionTypes::PromotionOutcomeDiscount){
				bPromotionDiscountFound = true;
				qsPromotionAmount = promotionData.readDiscountAmount();
				break;
			}
		}

		if(bPromotionDiscountFound == true ){
			for ( QVariant outcome : m_promotionsActionsDataList ) {
				qbaPromotionData = outcome.toByteArray ();
				QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);

				ePromoType = PromotionTypes::PromotionType(promotionData.readPromotionType ());
				if(ePromoType == PromotionTypes::PromotionTriggerTicket){
					// If we have discount amount, we remove the trigger ticket data node from the list (that is the first in the list)
					//we update it with the discount amount and we enter it again at the beginning of the list.
					m_promotionsActionsDataList.removeFirst();

					promotionData.setDiscountAmount(qsPromotionAmount);
					QByteArray qbaUpdatedPromotionData = QJson::JsonOperations::qObjectToJson(&promotionData);
					m_promotionsActionsDataList.prepend(qbaUpdatedPromotionData);
					break;
				}
			}
		}

		//=====================================================================

		// Go through promotion action list and call only the relative method
		// for trigger ticket

		for ( QVariant outcome : m_promotionsActionsDataList ) {
			qbaPromotionData = outcome.toByteArray ();
			QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);

			ePromoType = PromotionTypes::PromotionType(promotionData.readPromotionType ());
			qDebug () << "Do promotion type for: " << ePromoType;

			if(ePromoType == PromotionTypes::PromotionTriggerTicket ){
				if ( m_mHandlePromotionOutcomeMap.contains (ePromoType) ) {
					m_mHandlePromotionOutcomeMap.value (ePromoType)(*this, promotionData,qvmDataForGui );
				} else {
					qDebug () << "Add promotion type: " << ePromoType << " in handle HandleTicketPromotionOutocomeMap";
				}
			}
		}
	} else {
		return false;
	}
	return true;
}

/**
 * @sa HandleTicketPromotions
 * @param pReceivedData
 * @param promotionsActionsDataList
 * @param pendingPromotions
 * @return
 */
bool GamesCommonRx::HandleTicketPromotions ( const char* pReceivedData, QVariantList& promotionsActionsDataList, bool& pendingPromotions )
{
	PromotionManagerTicket promotionManagerTicket;
	promotionManagerTicket.setCsBuffer(pReceivedData);

	//==== Try to get the project name. e.g. For Montana is MT =========
	QSettings settings ( QStringLiteral ("Intralot"), QStringLiteral ("ImtsGlobalConfig") );
	QString projectNamePath = settings.value (QStringLiteral ("Global/CompletePath")).toString ();
	projectNamePath = projectNamePath.remove(-1,1); // Remove the last "/" symbol


	QFileInfo fi(projectNamePath);
	QString absolutePath = fi.symLinkTarget();
	QFileInfo fii(absolutePath);
	projectNamePath = fii.baseName();
	 LOG("HandleTicketPromotions set namePath:"+projectNamePath);
   //=================================================================
	promotionManagerTicket.setProjectName(projectNamePath);

	if ( promotionManagerTicket.detectPromotion() ){
		promotionManagerTicket.calculateTriggerBarcodeFromCsBuffer();

		if(promotionManagerTicket.constructPromotionEventList()){
			if(promotionManagerTicket.performPromotionActions()){
				promotionsActionsDataList = promotionManagerTicket.getPromotionsProcessedData();
				pendingPromotions = promotionManagerTicket.getMorePendingOutcomes();
			} else {
				return false;
			}
		} else {
			return false;
		}
	} else {
		return false;
	}
	return true;
}

/**
 * @sa HandlePendingPromotions
 * @param pReceivedData
 * @param barcode
 * @param promotionsActionsDataList
 * @param pendingPromotions
 * @return
 */
bool GamesCommonRx::HandlePendingPromotions ( const char *pReceivedData,const unsigned long *barcode,QVariantList &promotionsActionsDataList,bool &pendingPromotions )
{

	PromotionManagerCoupon promotionManagerCoupon;
	promotionManagerCoupon.setCsBuffer(pReceivedData);

	if ( promotionManagerCoupon.detectPromotion() ) {

		//==== Try to get the project name. =========
		QSettings settings ( QStringLiteral ("Intralot"), QStringLiteral ("ImtsGlobalConfig") );
		QString projectNamePath = settings.value (QStringLiteral ("Global/CompletePath")).toString ();
		projectNamePath = projectNamePath.remove(-1,1); // Remove the last "/" symbol

		QFileInfo fi(projectNamePath);
		QString absolutePath = fi.symLinkTarget();
		QFileInfo fii(absolutePath);
		projectNamePath = fii.baseName();
		 LOG("HandlePendingPromotions set namePath:"+projectNamePath);
	   //=================================================================

		promotionManagerCoupon.setProjectName(projectNamePath);
		promotionManagerCoupon.setTriggerBarcode(barcode);

		if ( promotionManagerCoupon.constructPromotionEventList() ) {
			if ( promotionManagerCoupon.performPromotionActions() ) {
				QVariantList pendingPromotionsDataList = promotionManagerCoupon.getPromotionsProcessedData();
				promotionsActionsDataList.append(pendingPromotionsDataList);
				pendingPromotions = promotionManagerCoupon.getMorePendingOutcomes();
			} else {
				return false;
			}
		} else {
			return false;
		}
	} else {
		return false;
	}
	return true;
}

/**
 * @sa ExecutePromotionsActions
 * @brief For all the promotions, besides the actions that have to be done at the promotion trigger ticket,
 * @brief execute the associated to each promotion actions (e.g. print receipt, play game, play sound etc)
 */
void GamesCommonRx::ExecutePromotionsActions()
{
	QVariantMap qvmDataForGui;
	QByteArray qbaPromotionData;
	PromotionData promotionData;
	PromotionTypes::PromotionType ePromoType;

	/// // Go through promotion action list and call relative method
	for ( QVariant outcome : m_promotionsActionsDataList ) {
		qbaPromotionData = outcome.toByteArray ();
		QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);

		ePromoType = PromotionTypes::PromotionType(promotionData.readPromotionType ());
		qDebug () << "Do promotion type for: " << ePromoType;

		// For the promotion trigger ticket node of the list, do not take it into account.
		// We had already done before.
		if(ePromoType == PromotionTypes::PromotionTriggerTicket)
			continue;

		if ( m_mHandlePromotionOutcomeMap.contains (ePromoType) ) {
			m_mHandlePromotionOutcomeMap.value (ePromoType)(*this, promotionData,qvmDataForGui );
		} else {
			qDebug () << "Add promotion type: " << ePromoType << " in handle HandleTicketPromotionOutocomeMap";
		}
	}
}

/**
 * @sa getDiscountAmount
 * @brief Find if the coupon has discount amount from promotion data
 * @return the discount amount
 */
QString GamesCommonRx::getPromotionDiscountAmount()
{
	QByteArray qbaPromotionData = getGamePromotionData();
	PromotionData promotionData;
	QJson::JsonOperations::JsonToqObject (qbaPromotionData,&promotionData);

	QString qsDiscountAmount = promotionData.readDiscountAmount();
	return(qsDiscountAmount);
}


