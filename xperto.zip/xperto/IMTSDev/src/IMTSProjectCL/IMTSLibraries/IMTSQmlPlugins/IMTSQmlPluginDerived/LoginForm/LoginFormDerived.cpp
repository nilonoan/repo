/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

/**
 * @file LoginFormDerived.cpp
 * @brief Handles WDC Login
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
#include "LoginFormDerived.h"
#include "Dialogs/QmlMessageBox.h"
#include "SystemWideConstValues.h"
#include <QtCore/QDebug>
#include "DbusWrapper.h"
#include "IMTSDbusArmInterfaces/DbusWrapperArm.h"
#include "Components/LineInput.h"
#include "LocalEventLoggerEvents.h"
#include "ImtsLotos5Enumerations.h"
#include "Nvram/Nvram.h"
#include "ProjectDependentConfig_interface.h"
/**
 * @sa LoginFormDerived
 * @param parent
 * @brief constructor
 */

LoginFormDerived::LoginFormDerived( QObject *parent )
	: LoginForm                   ( parent )
	, m_bChangePassDueToCsRequest ( false )
	, m_eLoginType                ( UserLoginType::InvalidIdentity )
{
}

/**
 * @sa ~LoginFormDerived
 * @brief destructor
 */
LoginFormDerived::~LoginFormDerived ()
{

}

bool LoginFormDerived::changePassDueToCsRequest () const
{
	return m_bChangePassDueToCsRequest;
}

void LoginFormDerived::setChangePassDueToCsRequest ( const bool& bNewVal )
{
	if ( m_bChangePassDueToCsRequest == bNewVal ) return;
	m_bChangePassDueToCsRequest = bNewVal;
	emit changePassDueToCsRequestChanged ();
}

/**
 * @sa updateDownloadListWithAdditionalFiles
 */
void LoginFormDerived::updateDownloadListWithAdditionalFiles (const QVariantMap&)
{
	QVariantList qvlFilesList = readDwloadFilesList ();

	qvlFilesList.append ("GamesConfig.json");
	qvlFilesList.append ("ScreenSaverMessages.json");

	QVariantList qvlGamesList = DbusWrapper::getConfigManagerInterface ()->getAvailableGameCodes ();
	for ( quint8 iGame = 0; iGame < qvlGamesList.size (); ++iGame ) {
		qvlFilesList.append (qvlGamesList.at (iGame).toString ().append (".json"));
	}

	setDwloadFilesList (qvlFilesList);
}

/**
 * @sa requestFtpDownload
 */
void LoginFormDerived::requestFtpDownload (const QVariantMap& qvmMessageReply)
{
	Q_UNUSED (qvmMessageReply)

	quint32 iFtpSessionId = QUuid::createUuid ().data1;
	bool bOK = DbusWrapper::getCommserverInterface ()->triggerDownloadFiles ( readDwloadFilesList (), false/*not SWDownload*/,iFtpSessionId );

	if (bOK) {

//		LOG (QStringLiteral("Download ended update gui with new values"));
//        projectDependentInterface.data ()->reloadGamesConfigSlot ();

		processFlexbet();

		QEventLoop loop;
		QPointer<QTimer> pDownloadWatcherTimer (new QTimer());

		QObject::connect(pDownloadWatcherTimer.data (), &QTimer::timeout, this, [&loop] {
			LOG (QStringLiteral("LoginFormDerived FTP download early break after 3mins"));
			loop.exit ();
		});

		pDownloadWatcherTimer->start(140000); // In 140seconds if we haven't got the downloadEnded signal from commserver we'll proceed

		QObject::connect ( DbusWrapper::getCommserverInterface (), &DbusWrapper::CommserverInterface::downloadEnded, this, [=,&loop] (const QVariantList& qvlFilesToDownload , quint32 sessionid) {

			if ( iFtpSessionId == sessionid ) {

				LOG (QStringLiteral("LoginForm catched commserver's downloadEnded signal"));

				for ( auto failedFile : qvlFilesToDownload ){
					LOG(QString("Failed to download file: %1").arg (failedFile.toString ()));
				}

				loop.exit ();
			}
		});

		loop.exec ();

		if ( !pDownloadWatcherTimer.isNull ()) {

			if ( pDownloadWatcherTimer->isActive () ) {
				pDownloadWatcherTimer->stop ();
			}
			pDownloadWatcherTimer->deleteLater ();
		}
	}
}

/**
 * @sa processFlexbet
 */
void LoginFormDerived::processFlexbet ()
{

	static const quint32 iFlexWaitPeriod = 301000; // 5minutes wait for time Like MAX_NSYNC_FTPTIME value
	static QScopedPointer<QDBusInterface> pFlexBetInterface (new QDBusInterface (QStringLiteral("com.intralot.IMTSFlexBet"), QStringLiteral("/FlexBetOperations"), QStringLiteral(""), QDBusConnection::sessionBus(), 0 ));

	QEventLoop loop;
	QPointer<QTimer> pTimer( new QTimer());

	QObject::connect (pTimer.data (),&QTimer::timeout,this,[&loop]{
		loop.quit ();
	});

	pTimer->start (iFlexWaitPeriod+1000);


	pFlexBetInterface.data ()->setTimeout (iFlexWaitPeriod);
	QDBusPendingCall pcall2 = pFlexBetInterface->asyncCall (QStringLiteral("DownloadTeams"));

	QDBusPendingCallWatcher *watcher2 = new QDBusPendingCallWatcher(pcall2, this);
	QObject::connect(watcher2, &QDBusPendingCallWatcher::finished, this, [&loop](QDBusPendingCallWatcher* call){

		QDBusPendingReply<void> reply = *call;

		if ( reply.isValid () ) {
			QString qsMsg = QString("FlexBet download finished downloading teams");
			LOG ( qsMsg);
			qDebug () << qsMsg;
		} else {
			QDBusError dbusError = reply.error();
			LOG ( dbusError.message () );
			LOG ( dbusError.errorString(dbusError.type()));
		}
		call->deleteLater();
		loop.exit ();
	});


	loop.exec ();


	if ( !pTimer.isNull ()) {

		if ( pTimer->isActive () ) {
			pTimer->stop ();
		}
		pTimer->deleteLater ();
	}
}

/**
 * @sa processChangePasswordReplySlot
 * @param qvmMessageReply data coming from Trss (C/S)
 * @brief processs return data for changed password request.
 */
void LoginFormDerived::processChangePasswordReplySlot ( const QVariantMap& qvmMessageReply )
{
	QString qsErrorMessage = QString();

	emit endPleaseWait ();

	if ( qvmMessageReply.isEmpty() ) {

		qsErrorMessage = tr("Remote proccess returned an empty reply");
		LOG(qsErrorMessage);

	} else {

		qsErrorMessage = qvmMessageReply.value(CS_ERROR_MSG).toString();

		if ( qsErrorMessage.isEmpty () ) {

			if ( changePassDueToCsRequest () ) {

				setChangePassDueToCsRequest (false);

				// m_eLoginType was stored locally when we detected a pass change request
				if ( m_eLoginType == UserLoginType::Retailer ||
					 m_eLoginType == UserLoginType::Employee ||
					 m_eLoginType == UserLoginType::ChainHead) {

					endRetailerPostLoginActionsSlot ( qvmMessageReply );

				} else {

					LOG(QStringLiteral("C/S pass request for unknown user login type "));
				}

				m_eLoginType = UserLoginType::InvalidIdentity;

			}

			showMessage( qvmMessageReply.value(MSGBOX_MSG).toString() );
			emit passwordChangedSuccessfully ();  // Depends on what you want to do: If password might not have been changed successfully let Gui think so, to exit the ChangePass dialoge. In that case move signal emitiion before exiting method.
		}
	}

	if ( !qsErrorMessage.isEmpty () ) {
		showMessage (qsErrorMessage);
	}
}

/**
 * @sa startRetailerPostLoginActionsSlot
 * @brief performs any post sign on operations. Project specific
 */
void LoginFormDerived::startRetailerPostLoginActionsSlot ( const QVariantMap& qvmMessageReply )
{
	bool bErrorsExist = errorsOccurred ( qvmMessageReply );

	if ( !bErrorsExist ) {

		int iGuiAction = qvmMessageReply.value (COMMAND_ACTION).toInt ();

		if ( iGuiAction == CommandGuiAction::ChangePassword ) {

			// We need to know the user type the change password was requested for when a passChange reply comes from C/S. It's only local.
			if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::NormalRetailer ) {
				m_eLoginType = UserLoginType::Retailer;
			} else if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::Employee ) {
				m_eLoginType = UserLoginType::Employee;
			} else if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::ChainHead ) {
				m_eLoginType = UserLoginType::ChainHead;
			}

			emit endPleaseWait ();
			emit changePassword (); // we got to raise dialog for changing password. Qml handles it.

		} else if ( iGuiAction == CommandGuiAction::NoAction ) { // second level check. c/s returns the type of user. If not the same as the gui value do not allow to login.

			if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::NormalRetailer ||
				 qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::Employee ||
				 qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::ChainHead ) {

				downloadLoginFiles (qvmMessageReply);

			} else {

				LOG(QString(QStringLiteral("Request for Normal Retailer Login but C/S returned a type of: %1")).arg (qvmMessageReply.value (CS_DATA).toInt ()));
				emit endPleaseWait ();
				showMessage( tr("Invalid user or password") );
			}

		} else {

			LOG( QString(QStringLiteral("Unknown Login type: %1")).arg (iGuiAction));
			emit endPleaseWait ();
			showMessage( tr("Sign On Failed") );
		}
	}
}

/**
 * @sa postDownloadLoginFilesSteps
 * @brief actions that have to be done after downloading the files from the ftp server
 */
void LoginFormDerived::postDownloadLoginFilesSteps (const QVariantMap& qvmMessageReply)
{
	Q_UNUSED (qvmMessageReply)
	// Ended with all downloads. Now see what do to with the files you've got.
	static QScopedPointer<com::intralot::IMTSMainDesktop::ProjectDependentConfig> projectDependentInterface (new com::intralot::IMTSMainDesktop::ProjectDependentConfig (QLatin1String("com.intralot.IMTSMainDesktop"), QLatin1String("/ProjectDependentConfig"), QDBusConnection::sessionBus(), 0 ));
	projectDependentInterface.data ()->reloadGamesConfigSlot ();

}


/**
 * @sa finalPostLoginActions
 */
void LoginFormDerived::finalPostLoginActions (const QVariantMap& qvmMessageReply)
{

	// all of them have retailerAccessRights on hardware. Change if appropriate
	// by overriding set....AccessRights ();

	if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::NormalRetailer ) {

		DbusWrapper::getConfigManagerInterface ()->setLoginIdentity (int(UserLoginType::Retailer));

	} else if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::Employee ) {

		DbusWrapper::getConfigManagerInterface ()->setLoginIdentity (int(UserLoginType::Employee));

	} else if ( qvmMessageReply.value (CS_DATA).toInt () == GenericTransactions::ChainHead ) {

		DbusWrapper::getConfigManagerInterface ()->setLoginIdentity (int(UserLoginType::ChainHead));
	}
}

