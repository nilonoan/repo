/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file GamesCenter.cpp
  * @class GamesCenter
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */

#include <QtCore/QtGlobal>
#include <QtWidgets/QApplication>
#include <QWindow>
#include <QVariant>
#include "DbusWrapper.h"

#include <QtQml/QQmlEngine>
#include <QtQuick/QQuickView>
#include <QtQml/QQmlContext>

#include <QtCore/QtDebug>
#include "GamesCenter.h"
#include "GetConfigValue.h"
#include "LocalEventLoggerEvents.h"
#include "JsonOperations.h"
#include "GameChip.h"
#include "QpGeneration/QpGeneration.h"
#include "CheckCoupon/CouponUtilities.h"
#include "GamesCore/CouponTransmissionManagerDerived.h"
#include "GamesCore/GamesLogicDerived.h"
#include "GamesCore/CouponProcessManagerDerived.h"
#include "GamesCore/CouponCollectorManager.h"
#include "GamesCore/GamesOperationsDerived.h"
#include "GamesUi.h"
#include "GamesCore/PollaGol.h"
#include "SystemWideConstValues.h" // aste: added on 21/6/2016

/**
	* @sa GamesCenter
	* @param parent
	* @brief GamesCenter constructor
	*/
GamesCenter::GamesCenter(QObject *parent )
	: QObject( parent )
	, m_pid                         ( 0 )
	, m_bShowGames                  ( false )
	, m_pcGamesUi                   ( nullptr )
	, m_pcCouponTransmissionManager ( nullptr )
	, m_pcGamesOperations           ( nullptr )
	, m_pcGamesLogic                ( nullptr )
	, m_pcCouponProcessManager      ( nullptr )
	, m_pcCouponCollectorManager    ( nullptr )
{
	m_lConnections.clear ();

	m_pcPollaGol = new PollaGol (this);

	m_pcGamesOperations = new GamesOperationsDerived ( this );

	if ( QQmlEngine::contextForObject ( this->parent ()) ) {
	QQmlEngine::setContextForObject ( this, QQmlEngine::contextForObject ( this->parent ()) );
		QQmlEngine::contextForObject ( this->parent () )->setContextProperty ("GamesCenterBackEnd", this); // expose this object to QML
		QQmlEngine::contextForObject ( this->parent () )->setContextProperty ("PollaGolBackEnd", m_pcPollaGol); // expose this object to QML
	}

	m_qGraphicsObject = qobject_cast<QQuickView*>(QGuiApplication::topLevelWindows ().at (0));
	m_pcPleaseWaitNew = dynamic_cast<PleaseWaitNew*>(m_qGraphicsObject->findChild<PleaseWaitNew*>("PleaseWaitNew"));

	// do metaType registrations needed due to being running on a separate thread, an Qt::QueueConnection is being used.
	qRegisterMetaType<ImtsGamesEnums::EditModesFlags>();

	initializeGamesComponents ();

	QpGeneration::getQpGenerationInstance ()->populatePool ();

}

GamesCenter::~GamesCenter ()
{
	if ( m_pcCouponProcessManager ) {
		delete m_pcCouponProcessManager;
	}
	m_pcCouponProcessManager = 0;

	for ( int iConnection = 0; iConnection < m_lConnections.size (); ++iConnection ) {
		disconnect (m_lConnections.at (iConnection));
	}
}


bool GamesCenter::showGames () const
{
	return m_bShowGames;
}


void GamesCenter::setShowGames ( const bool& bShowGames )
{
	if ( m_bShowGames == bShowGames ) return;
	m_bShowGames = bShowGames;
	emit showGamesChanged ();
}

/**
  * @sa getGameConfig
  * @param gameCode to get the config for.
  * @brief get game config dictated by the input parameter, and updates class's m_cGameConfig member.
  * Who ever choses to show games per gameCode, it adds a 100000 offset to game's gameCode iff the game supports customQp and
  * 300000 for customQpPromo. We find out and we get the real gameCode to get game's config
  */
bool GamesCenter::getGameConfig ( const int& iSelectGameCode )
{
	int iRealGameCode = 0;
	if ( iSelectGameCode>GamesUi::CUSTOM_QP_OFFSET ) {

		iRealGameCode = iSelectGameCode-GamesUi::CUSTOM_QP_OFFSET;

	} else {

		iRealGameCode = iSelectGameCode;
	}
	return CouponUtilities::getGameConfig ( CouponUtilities::eByGameCode, iRealGameCode, m_cGameConfig );
}

/**
  * @sa initializeGamesComponents
  * @brief Initializes essential objects for GamesCenter functionality
  */
void GamesCenter::initializeGamesComponents ()
{
	QMetaObject::Connection connection;

	m_pcGamesUi = new GamesUi ( this );
	initializeGamesUi ();
	m_pcCouponTransmissionManager = new CouponTransmissionManagerDerived ( this, false/*FiFo*/ );
	m_pcCouponProcessManager      = new CouponProcessManagerDerived;
	m_pcGamesLogic                = new GamesLogicDerived ( this );
	m_pcCouponCollectorManager    = new CouponCollectorManager ( this );

	// do all needed connections.

	QObject::connect ( m_pcGamesLogic, &GamesLogicDerived::handleCouponView,
					   m_pcGamesUi,    &GamesUi::handleCouponViewSlot );

	QObject::connect ( m_pcGamesLogic,                &GamesLogicDerived::suspendCouponTransmissionManager,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::suspendCouponsTransmissionSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcPollaGol,                  &PollaGol::suspendCouponTransmissionManager,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::suspendCouponsTransmissionSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcGamesLogic,             &GamesLogicDerived::processCouponsBatch,
					   m_pcCouponCollectorManager, &CouponCollectorManager::processCouponsBatchSlot );

	QObject::connect ( m_pcPollaGol,                &PollaGol::processCouponsBatch,
					   m_pcCouponCollectorManager, &CouponCollectorManager::processCouponsBatchSlot );

	connection = QObject::connect ( m_pcGamesLogic, &GamesLogic::hideGameCenter, [this](){



		setShowGames (false);
		DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked ( false );

	});
	m_lConnections.append (connection);


	QObject::connect ( m_pcCouponCollectorManager,    &CouponCollectorManager::suspendCouponTransmissionManager,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::suspendCouponsTransmissionSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcCouponTransmissionManager,  &CouponTransmissionManagerDerived::requestCouponDataEdit,
					   m_pcCouponCollectorManager,     &CouponCollectorManager::requestCouponDataEditSlot, Qt::QueuedConnection);

	QObject::connect ( m_pcCouponCollectorManager,    &CouponCollectorManager::resumeCouponProcess,
					   m_pcCouponProcessManager,      &CouponProcessManagerDerived::resumeCouponProcessSlot, Qt::QueuedConnection);


	QObject::connect ( m_pcCouponCollectorManager,    &CouponCollectorManager::deliverCouponDataForTransmission,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::deliverCouponDataForTransmissionSlot, Qt::QueuedConnection );


	QObject::connect ( m_pcCouponCollectorManager,    &CouponCollectorManager::abortTransmission,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::abortTransmissionSlot, Qt::QueuedConnection );


	connection = QObject::connect ( m_pcGamesOperations, &GamesOperations::hideGameCenter, [this](){
		setShowGames (false);
	});
	m_lConnections.append (connection);

	connection = QObject::connect ( m_pcPollaGol, &PollaGol::hideGameCenter, [this](){
		setShowGames (false);
	});
	m_lConnections.append (connection);


	QObject::connect ( m_pcGamesOperations,      &GamesOperations::addCouponForProcessing,
					   m_pcCouponProcessManager, &CouponProcessManager::addCouponForProcessingSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcGamesOperations, &GamesOperations::selectGame,
					   this,                &GamesCenter::selectGameSlot);


	QObject::connect ( m_pcGamesOperations,           &GamesOperations::paperChangeInProgress,
					   m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::setPrinterRollReplacementInProgressSlot );

	QObject::connect ( m_pcCouponCollectorManager, &CouponCollectorManager::requestCouponDataEdit,
					   this,                       &GamesCenter::requestCouponDataEditSlot);

	QObject::connect ( m_pcCouponProcessManager, &CouponProcessManager::requestCouponDataEdit,
					   this,                     &GamesCenter::requestCouponDataEditSlot, Qt::QueuedConnection );


	QObject::connect ( m_pcCouponProcessManager,   &CouponProcessManager::processCouponsBatch,
					   m_pcCouponCollectorManager, &CouponCollectorManager::processCouponsBatchSlot, Qt::QueuedConnection );

	QObject::connect ( m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::transmissionInProgressChanged,
					   m_pcCouponCollectorManager,    &CouponCollectorManager::transmissionInProgressChanged );

	QObject::connect ( m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::removeCollectorsCoupon,
					   m_pcCouponCollectorManager,    &CouponCollectorManager::removeCollectorsCouponSlot );


	connection = QObject::connect ( m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::startPleaseWait,
									[=](QString qsPleaseWaitText,
									int iStep,
									bool bShowProgressBar,
									int iMaximum,
									bool bShowCancelButton,
									QString qsSourceObject )
	{

		if ( dynamic_cast<QWindow*>(this->parent ())->isVisible () ) {

			if ( m_pcPleaseWaitNew->readState () == QStringLiteral("show") ) { // if already on screen just update step if requested

				if ( iStep > -1 ) {
					m_pcPleaseWaitNew->setStep (iStep);
				}

				if ( bShowProgressBar ) {
					if ( !m_pcPleaseWaitNew->readProgressBarEnabled () ) {
						m_pcPleaseWaitNew->initWithBarProgress ();
					}
					m_pcPleaseWaitNew->setMaximum (iMaximum);
				} else {
					m_pcPleaseWaitNew->setProgressBarEnabled (false);
				}

				m_pcPleaseWaitNew->setDisplayText (qsPleaseWaitText); // update display text while in view

			} else { // dialog not on screen

				if ( bShowProgressBar ) { // if we want progress bar initialize dialog appropriately

					m_pcPleaseWaitNew->initWithBarProgress ();
					m_pcPleaseWaitNew->setMaximum (iMaximum);

				} else {

					m_pcPleaseWaitNew->initForGeneralUse ();
				}

				m_pcPleaseWaitNew->setDisplayText (qsPleaseWaitText);
				m_pcPleaseWaitNew->setState (QStringLiteral("show"));
			}

			m_pcPleaseWaitNew->setCancelButtonEnabled (bShowCancelButton);

		} else {

			// 1st ask to see which window is active
			QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();
			if ( reply.isValid () ) {

				QStringList l = reply.value ();

				if ( !l.isEmpty () ) {
					// 2nd place startPleaseWait call to remote application. list contains service and path
					QDBusInterface remoteApp( l.at (0), l.at (1) );
					remoteApp.call( QDBus::NoBlock, "showPleaseWait",
									qsPleaseWaitText,
									iStep,
									bShowProgressBar,
									iMaximum,
									bShowCancelButton,
									qsSourceObject );
				}
			}
		}

	});
	m_lConnections.append (connection);


	connection = QObject::connect ( m_pcCouponTransmissionManager, &CouponTransmissionManagerDerived::endPleaseWait, [=](){

		if ( dynamic_cast<QWindow*>(this->parent ())->isVisible () ) {

			m_pcPleaseWaitNew->resetAndHide ();

		} else {

			// 1st ask to see which window is active
			QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();
			if ( reply.isValid () ) {

				QStringList l = reply.value ();

				if ( !l.isEmpty () ) {

					// 2nd place endPleaseWait call to remote application. list contains service and path
					QDBusInterface remoteApp( l.at (0), l.at (1) );
					remoteApp.call( QDBus::NoBlock, "hidePleaseWait");
				}
			}
		}

	});
	m_lConnections.append (connection);



	QObject::connect (m_pcGamesOperations, &GamesOperationsDerived::generateQpNumbers,
					  this,                &GamesCenter::generateQpNumbersSlot, Qt::QueuedConnection );

}

/**
 * @sa initializeGamesUi
 * @brief get games config and calls Ui initialization routine.
 */
void GamesCenter::initializeGamesUi ()
{

	QVariantMap qvmGameConfigMap = QVariantMap();

	DbusWrapper::getAllGamesConfig( qvmGameConfigMap );

	if ( !qvmGameConfigMap.isEmpty() ) {

		int iGameCode = 0;
		QMap<QString, QVariant>::const_iterator i = qvmGameConfigMap.constBegin();
		while ( i != qvmGameConfigMap.constEnd() ) {

			iGameCode = i.key().toInt();
			m_cGameConfig.clearConfig ();

			bool bOk =  QJson::JsonOperations::JsonToqObject( i.value().toByteArray(), &m_cGameConfig );

			if ( bOk ) {

				m_pcGamesUi->initializeGamesUiComponents ( &m_cGameConfig );

			} else {

				LOG ( QString(QStringLiteral("ERROR parsing config data for game %1")).arg (iGameCode));
			}
			++i;
		}
	} else {

		LOG ( QStringLiteral ("Games Config Map is empty"));
	}
}

/**
 * @sa selectGame
 * @param int iSelectGameCode: game's gamecode passed from qml
 * @param customQp view
 * @brief this slot is called from QML file GameButton.qml in response to selecting a Game from the list of
 * available games. First we update our local member m_iActiveGame to keep track which game is active. Then
 * we update the config data for this game by asking SystemConfigurationManager to provide us the data, then
 * we emit a signal to update the view of the selected game (logo), we change the state of GamesCenter.qml with the
 * name of the newly selected game and at last we instruct LottoGames.cpp to update the selected game's
 * view.
 * In addition, this slot is triggered with a signal selectGame by the LottoGames object in response of
 * editing a coupon.
 */
void GamesCenter::selectGameSlot ( const int& iSelectGameCode )
{

	DbusWrapper::getConfigManagerInterface ()->setBarcodeProcessingBlocked ( true );

	if ( getGameConfig ( iSelectGameCode ) ) {

		setShowGames ( true );

		if (iSelectGameCode != POLLAGOL_CL) {

		if ( m_pcGamesLogic->getEditMode () == ImtsGamesEnums::NoEdit ) {

			bool bCustomQp = iSelectGameCode>GamesUi::CUSTOM_QP_OFFSET?true:false;

			m_pcGamesLogic->initializeGamesLogic ( &m_cGameConfig, bCustomQp );  // Let game logic initialize
			m_pcGamesUi->changeGameView ( &m_cGameConfig, iSelectGameCode );     // Responsible to control game view.

			LOG( QString(QStringLiteral("Game:%1 selected")).arg(iSelectGameCode) );

		} else {

			QString qsMsg(QStringLiteral("Changing Games while in editing mode is not allowed"));
			LOG( qsMsg );
			qWarning () << qsMsg;
		}

		} else {
			m_pcGamesUi->setActiveGame (iSelectGameCode);
			emit m_pcPollaGol->initializeGamesLogic (ImtsGamesEnums::NoEdit);
		}


	} else {
		qWarning () << iSelectGameCode << " : not a valid game";
	}
}

/**
 * @sa requestCouponDataEditSlot
 * @param Coupon
 * @param who did the request
 * @brief This slot is executed due to a request to edit coupon data.
 */
void GamesCenter::requestCouponDataEditSlot ( const Coupon& couponData, const ImtsGamesEnums::EditModesFlags& editRequestFrom )
{

	int iGameCodeForEditing = couponData.getGameCode ();

	if ( getGameConfig ( iGameCodeForEditing ) ) {

		setShowGames (true);

		if (iGameCodeForEditing==POLLAGOL_CL) {

			m_pcPollaGol->initializeGamesLogic (&m_cGameConfig, couponData, editRequestFrom);
			m_pcGamesUi->setActiveGame (iGameCodeForEditing);

		} else {
			m_pcGamesLogic->initializeGamesLogic ( &m_cGameConfig, couponData, editRequestFrom );
			m_pcGamesUi->changeGameView ( &m_cGameConfig, iGameCodeForEditing );
		}

		LOG( QString(QStringLiteral("Game:%1 selected for editing")).arg(iGameCodeForEditing) );
	}
    else if ( iGameCodeForEditing == iFlex_CL ) {
        QDBusInterface betInterface ("com.intralot.IMTSFlexBet", "/FlexBetOperations");
//        betInterface.call ("Play", 0,0 );
        betInterface.call ( "couponEditRequestSlot", couponData.getAdditionalGameMap().value("ExternalTxData").toByteArray(), 0, 2 );
    }
}



/**
 * @sa generateQpNumbersSlot
 */
void GamesCenter::generateQpNumbersSlot ( const int iSamples, const QList<QVariant> lGames )
{
	Q_UNUSED ( iSamples )
	Q_UNUSED ( lGames )
	qWarning () << "Add your logic to generate qp numbers for randomness test. Check PLI";

	return;
}

