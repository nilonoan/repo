/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
/**
  * @file CouponProcessManagerDerived.cpp
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */
#include "CouponProcessManagerDerived.h"
#include "GamesCore/GamesUtilities.h"
#include "LocalEventLoggerEvents.h"
#include "QpGeneration/QpGeneration.h"
#include "JsonOperations.h"
#include "PlaySlipDataDerived.h"
#include "DbusWrapper.h"
#include "FormatAmount/FormatAmount.h"
#include "GamesCore/GamesOperations.h"
#include "Dialogs/QmlMessageBox.h"
#include "ProjectGameCodes.h"
#include "Plays/ExternalPlay.h"
#include "Transactions/100_149_DrawTransactions/FlexBetTxData.h"
#include "GetConfigValue.h"
#include <QDebug>
#include <QFile>
#include <QDataStream>
#include "SystemWideConstValues.h"
#include "GamesOperationsDerived.h"
#include "PollaGol.h"

static const QString POLLAGOL_EVENTS_FILE_TRAINING = GetConfigValue::getCsFiles ()%"PollaGolTraining.json";
static const QString POLLAGOL_EVENTS_FILE = GetConfigValue::getCsFiles ()%"PollaGol.json";


CouponProcessManagerDerived::CouponProcessManagerDerived (QObject* parent)
	: CouponProcessManager (parent)
	, m_pcCouponUtilitiesDerived (new CouponUtilitiesDerived)
	, m_pcPlaySlipProject        (new PDIPlayslipProject)
{
	setPopUpTimeout (15*1000); // 15seconds
	QObject::connect (DbusWrapper::getConfigManagerInterface (),&com::intralot::IMTSScm::ConfigManager::trainingChanged,this,[this](const bool& trainingStatus){
		m_bIsTraining = trainingStatus;
	});

	m_mLotoSlip     = QJson::JsonOperations::JsonObjectFromFile (GetConfigValue::getResourcesPath ()+ QStringLiteral("LinkToYourProject/Playslips/Camera/ChileCoupons/Loto/Loto.json"));
	m_mLoto4Slip    = QJson::JsonOperations::JsonObjectFromFile (GetConfigValue::getResourcesPath ()+ QStringLiteral("LinkToYourProject/Playslips/Camera/ChileCoupons/Loto4/Loto4.json"));
	m_mLoto3Slip    = QJson::JsonOperations::JsonObjectFromFile (GetConfigValue::getResourcesPath ()+ QStringLiteral("LinkToYourProject/Playslips/Camera/ChileCoupons/Loto3/Loto3.json"));
	m_mRachaSlip    = QJson::JsonOperations::JsonObjectFromFile (GetConfigValue::getResourcesPath ()+ QStringLiteral("LinkToYourProject/Playslips/Camera/ChileCoupons/Racha/Racha.json"));
	m_mPollaGolSlip = QJson::JsonOperations::JsonObjectFromFile (GetConfigValue::getResourcesPath ()+ QStringLiteral("LinkToYourProject/Playslips/Camera/ChileCoupons/PollaGol/PollaGol.json"));

	if (m_mLotoSlip.isEmpty()) {
		qDebug () << "Failed to load Loto definition file";
	} else {
		m_mSlips.insert (2400,m_mLotoSlip);
	}

	if (m_mLoto4Slip.isEmpty()) {
		qDebug () << "Failed to load Loto4 definition file";
	} else {
		m_mSlips.insert (2410,m_mLoto4Slip);
	}

	if (m_mLoto3Slip.isEmpty()) {
		qDebug () << "Failed to load Loto3 definition file";
	} else {
		m_mSlips.insert (2405,m_mLoto3Slip);
	}

	if (m_mRachaSlip.isEmpty()) {
		qDebug () << "Failed to load Racha definition file";
	} else {
		m_mSlips.insert (2415,m_mRachaSlip);
	}

	if (m_mPollaGolSlip.isEmpty()) {
		qDebug () << "Failed to load PollaGol definition file";
	} else {
		m_mSlips.insert (2420,m_mPollaGolSlip);
	}

	m_cCouponData = getCouponData (); // The object we are inhering from has done a required initialization on the coupon data. We don't have to re-do here.

	setAlwaysPromptOnSameCoupon (true);
}


/**
 * @sa makePollaGolQP
 * @return
 */
void CouponProcessManagerDerived::makePollaGolQP (QVariantMap& mMatches)
{
	static QMap<int,PrognosticsFlags> mSingleChance = {
		{0,HomeWin},
		{1,Draw},
		{2,VisitorWin}
	};

	static QMap<int,PrognosticsFlags> mDoubleChance = {
		{0,HomeDraw},
		{1,HomeVisitor},
		{2,DrawVisitor}
	};


	// Get a random number between 0 and 13. It will be used as an index to insert the double chance.
	auto iDoubleIndex = quint32(QUuid::createUuid ().data1)%(14);

	QVariantMap mMatch   = QVariantMap ();

	for (quint32 iEvent = 0; iEvent < 14; ++iEvent) {

		mMatch = mMatches.value (QString::number (iEvent)).toMap ();
		mMatch.insert (QStringLiteral("prognostics"),qint32(Invalid)); // reset any prev. value

		if (iDoubleIndex == iEvent) {
			mMatch.insert (QStringLiteral("prognostics"),qint32(mDoubleChance.value (quint32(QUuid::createUuid ().data1)%3)));
		} else {
			mMatch.insert (QStringLiteral("prognostics"),qint32(mSingleChance.value (quint32(QUuid::createUuid ().data1)%3)));
		}

		mMatches.insert (QString::number (iEvent),mMatch);
	}
}


/**
 * @sa initializePollaGolFromMarks
 * @param pCamMarks
 * @param iSize
 * @param iRiga
 */
QString CouponProcessManagerDerived::initializePollaGolFromMarks (const quint16* pCamMarks, quint16 iSize, qint32 iRiga)
{
	QVariantMap mCouponDefinitions = m_mSlips.value (iRiga);

	QVariantMap mChipValues = QVariantMap ();
	BoxType eBoxType        = BoxType::Invalid;
	QString qsValue         = QString ();
	QString qsErrorMessage  = QString ();

	QVariantMap mPollaGolData = QVariantMap ();
	QVariantMap mAreaData     = QVariantMap ();
	QVariantMap mMatch        = QVariantMap ();
	QVariantMap mMatches      = QVariantMap ();

	PrognosticsFlags ePrognostic = PrognosticsFlag::Invalid;
	auto iMatchIndex  = 0;
	auto iDoubles     = 0;
	auto iTriples     = 0;
	auto bErrorFree   = false;
	auto bMatchMarked = false;
	auto isQp         = false;


	// Get program
	QVariantList qvlMatches = QVariantList ();
	if (m_bIsTraining) {
		QVariantMap m = QJson::JsonOperations::JsonObjectFromFile (POLLAGOL_EVENTS_FILE_TRAINING);
		qvlMatches = m.value (QStringLiteral("information")).toList ();
	} else {
		QVariantMap m = QJson::JsonOperations::JsonObjectFromFile (POLLAGOL_EVENTS_FILE);
		qvlMatches = m.value (QStringLiteral("information")).toList ();
	}

	// Initialize data with matches. Later we'll fill prognostics based on camera data
	auto iEvent = 0;
	for (const auto event:qvlMatches) {

		mMatch.clear ();
		mMatch.insert (QStringLiteral("home")       , event.toMap ().value (QStringLiteral("homeDescription")).toString ());
		mMatch.insert (QStringLiteral("visitor")    , event.toMap ().value (QStringLiteral("awayDescription")).toString ());
		mMatch.insert (QStringLiteral("prognostics"), qint32(Invalid));

		mMatches.insert (QString::number (iEvent++),mMatch);
	}

	// Loop through camera marks and initialize prognostics.
	for (auto iMark=0; iMark<iSize; ++iMark) {

		// Each camera mark is devided by 5 to get the match index. That is, we got in each row in playslip
		// camera marks from 0-4, 5-9, 10-14, 15-19, 20-24, 25-29, .... ,65-69

		if (iMatchIndex < pCamMarks[iMark]/5) { // Change row detection.

			// Count doubles and triples from last pass. On exiting the for loop we'll count once more.
			if (ePrognostic.operator int () == PrognosticsFlag::HomeDraw ||
				ePrognostic.operator int () == PrognosticsFlag::HomeVisitor ||
				ePrognostic.operator int () == PrognosticsFlag::DrawVisitor) {
				++iDoubles;
			}

			if (ePrognostic.operator int () == PrognosticsFlag::HomeDrawVisitor) {
				++iTriples;
			}

			ePrognostic = PrognosticsFlag::Invalid;
		}

		iMatchIndex = pCamMarks[iMark]/5;
		mMatch = mMatches.value (QString::number (iMatchIndex)).toMap ();

		mChipValues = mCouponDefinitions.value (QString::number (pCamMarks[iMark])).toMap ();
		eBoxType = BoxType(mChipValues.value (QStringLiteral("boxType")).toString ().toUInt ());

		if (eBoxType == BoxType::Mark) {

			bMatchMarked = true;

			qsValue = mChipValues.value (QStringLiteral("value")).toString ();

			if (qsValue == QStringLiteral("H")) {
				ePrognostic = PrognosticsFlag::HomeWin;
			}

			if (qsValue == QStringLiteral("X")) {
				ePrognostic |= PrognosticsFlag::Draw;
			}

			if (qsValue == QStringLiteral("V")) {
				ePrognostic |= PrognosticsFlag::VisitorWin;
			}

			if (qsValue == QStringLiteral("D")) {

				if (ePrognostic.operator int () != PrognosticsFlag::HomeDraw ||
					ePrognostic.operator int () != PrognosticsFlag::HomeVisitor ||
					ePrognostic.operator int () != PrognosticsFlag::DrawVisitor) {

					qsErrorMessage += tr("Invalid double selection in match %1\n").arg (iMatchIndex+1);
				}
			}

			if (qsValue == QStringLiteral("T")) {

				if (ePrognostic.operator int () != PrognosticsFlag::HomeDrawVisitor) {
					qsErrorMessage += tr("Invalid triple selection in match %1\n").arg (iMatchIndex+1);
				}
			}

			if (ePrognostic!=PrognosticsFlag::Invalid) {
				mMatch.insert (QStringLiteral("prognostics"),qint32(ePrognostic));
				mMatches.insert (QString::number (iMatchIndex),mMatch);
			}


		} else if (eBoxType == BoxType::QP) {

			if (!bMatchMarked) {
				// all OK generate qp
				makePollaGolQP (mMatches);
				iDoubles = 1;
				iTriples = 0;
				isQp = true;
				mAreaData.insert (QStringLiteral("QP"),true);
			} else {
				qsErrorMessage += tr("Invalid QP selection. Some events are marked.\n");
			}
		}
	}

	// On exiting the for loop we got to see whether a double or triple was marked in the last match.
	if ((ePrognostic.operator int () == PrognosticsFlag::HomeDraw ||
		 ePrognostic.operator int () == PrognosticsFlag::HomeVisitor ||
		 ePrognostic.operator int () == PrognosticsFlag::DrawVisitor) &&
		isQp==false) {
		++iDoubles;
	}

	if (ePrognostic.operator int () == PrognosticsFlag::HomeDrawVisitor &&
		isQp==false) {
		++iTriples;
	}


	mAreaData.insert (QStringLiteral("matches"),mMatches);
	mPollaGolData.insert (QStringLiteral("Area0"),mAreaData); // one area at the moment

	if (mMatches.size () ==14 /*14: number of matches*/) {
		bErrorFree = CouponUtilitiesDerived::isPollaGolValid (iDoubles,iTriples);
		if (!bErrorFree) {
			qsErrorMessage += tr("Invalid number of doubles and/or triples");
		}
	} else {
		qsErrorMessage += tr("Some events are not marked");
	}


	auto iColumns = m_pcCouponUtilitiesDerived.data ()->getPollaGolColumns (iDoubles,iTriples);

	m_cCouponData.setCouponColumns (iColumns);
	m_cCouponData.setCouponCost (iColumns*m_cGamesConfig.readColumnPrice ());

	GameTxData gameTxData;
	gameTxData.setTxProduct        (m_cGamesConfig.readTxProduct ());
	gameTxData.setRxProduct        (m_cGamesConfig.readRxProduct ());
	gameTxData.setPriority         (HIGH_PRI);
	gameTxData.setProtocol         (LOTOS5);
	gameTxData.setIsCouponVoid     (false);
	gameTxData.setHeader           (tr("PollaGol Play"));

	gameTxData.setGameCode         (m_cGamesConfig.readGameCode ());
	gameTxData.setGameName         (m_cGamesConfig.readGameName ());
	gameTxData.setGameHtmlTemplate (m_cGamesConfig.readGameHtmlTemplate ());
	gameTxData.setNumberOfAreas    (m_cGamesConfig.readNumberOfAreas());
	gameTxData.setInputMethod      (ImtsGamesEnums::ECoupon);
	gameTxData.setIsCouponVoid     (false);
	gameTxData.setColumns          (iColumns);
	gameTxData.setCost             (iColumns*m_cGamesConfig.readColumnPrice ());
	gameTxData.setCouponOrigin     (ImtsGamesEnums::PropoBet);
	gameTxData.setMultidraws       (1);

	// Open relative xxxx.txt xxxx=gameCode and get game messages for receipt.
	QString qsOnReceiptGameMessageFile = GetConfigValue::getDownloadPath ();
	qsOnReceiptGameMessageFile.append (QString("%1.json").arg (m_cGamesConfig.readGameCode()));

	gameTxData.setOnTicketMessageList (QJson::JsonOperations::JsonObjectFromFile(qsOnReceiptGameMessageFile).value ("onTicketMessages").toList ());

	gameTxData.setCustomData (mPollaGolData);
	gameTxData.setIsCouponEmpty (false);

	m_cCouponData.setMiscellaneousData (QJson::JsonOperations::JsonObjectFromQObject (&gameTxData));



	return qsErrorMessage;
}

/**
 * @sa initializeCouponDataFromMarks
 * @param pointer to sSlipCoupon structure
 * @brief This routine initializes game coupon object from camera marks buffer
 * @note  open up game's json config file and use it as reference to help you do this easier.
 */
QString CouponProcessManagerDerived::initializeCouponDataFromMarks (const quint16* pCamMarks, quint16 iSize, qint32 iRiga)
{

	QVariantMap mChipValues = QVariantMap ();
	BoxType eBoxType = BoxType::Invalid;
	quint32 iArea = 0;
	quint32 iPanel = 0;
	quint32 iValue = 0;
	quint32 iPickPlayType = 0;
	QString qsErrorMessage = QString ();


	// PollaGol does own error checking and return message;
	// For all other games IMTS via CouponError check for errors
	if (iRiga==2420) {// pollaGol

		qsErrorMessage = initializePollaGolFromMarks (pCamMarks,iSize,iRiga);

	} else {

		QVariantMap mCouponDefinitions = m_mSlips.value (iRiga);

		for (auto iMark=0; iMark<iSize; ++iMark) {

			mChipValues   = mCouponDefinitions.value (QString::number (pCamMarks[iMark])).toMap ();
			eBoxType      = BoxType(mChipValues.value (QStringLiteral("boxType")).toString ().toUInt ());

			iArea         = mChipValues.value (QStringLiteral("area")).toString ().toUInt ();
			iPanel        = mChipValues.value (QStringLiteral("panel")).toString ().toUInt ();
			iValue        = mChipValues.value (QStringLiteral("value")).toString ().toUInt ();
			iPickPlayType = mChipValues.value (QStringLiteral("playType")).toUInt ();


			if (eBoxType == BoxType::Mark) {

				// For Pick game value 0 is assigned as valid. No need to subtract 1
				if (IS_PICK(m_cGamesConfig.readGameCode ())) {
					m_cCouponData.getArea(iArea)->addMarkPanelX (iPanel,iValue);
				} else {
					m_cCouponData.getArea(iArea)->addMarkPanelX (iPanel,iValue-1);
				}


			} else if (eBoxType == BoxType::QP) {

				QpGeneration::getQpGenerationInstance ()->updateCouponDataWithQpMarks (&m_cGamesConfig, m_cCouponData, iArea);

			} else if (eBoxType == BoxType::Void) {

				m_cCouponData.getArea(iArea)->setVoidArea (true);

			}  else if (eBoxType == BoxType::Multiplier) {



				if (IS_PICK(m_cGamesConfig.readGameCode ())) {

					static QMap<ImtsGamesEnums::PickXPlayTypeFlags,QString> typeToTypeString = {
						{ImtsGamesEnums::Straight       , QStringLiteral("Straight")},
						{ImtsGamesEnums::Combo          , QStringLiteral("Combo")},
						{ImtsGamesEnums::Box            , QStringLiteral("Box")},
						{ImtsGamesEnums::FrontBackPairs , QStringLiteral("Pairs")},
						{ImtsGamesEnums::LastDigit      , QStringLiteral("LastDigit")}
					};

					ImtsGamesEnums::PickXPlayTypeFlags ePlayTypeFlag        = ImtsGamesEnums::PickXPlayTypeFlags (iPickPlayType);
					ImtsGamesEnums::PickXPlayTypeFlags eCurrentPlayTypeFlag = ImtsGamesEnums::PickXPlayTypeFlags (m_cCouponData.getArea (iArea)->getPickXPlayType ());
					QString qsPlaytype = typeToTypeString.value (ePlayTypeFlag);

					eCurrentPlayTypeFlag.operator |= (ePlayTypeFlag); // set new
					eCurrentPlayTypeFlag.operator &= (~ImtsGamesEnums::NoPlayType); // remove no playtype
					m_cCouponData.getArea (iArea)->setPickXPlayType (eCurrentPlayTypeFlag); // set playtype to coupondata


					QVariantMap mMultipliers  = m_cCouponData.getArea (iArea)->getCustomData ();
					mMultipliers.insertMulti (qsPlaytype,iValue); // assign multiple multiplier for given playtype so that later we can display the right message.
					m_cCouponData.getArea (iArea)->setCustomData (mMultipliers);

				} else {
					m_cCouponData.getArea(iArea)->setMultiplierMulti (iValue);
				}

			}  else if (eBoxType == BoxType::AdditionalGamePerArea) {

				QVariantMap mAdditionalGamesPerArea  = m_cCouponData.getArea (iArea)->getAdditionalGamePerArea();

				if ( m_cGamesConfig.readGameCode() == RACHA_CL ) {

					static QMap<int,QString> intToTypeString = {
						{0, QStringLiteral("0")},
						{1, QStringLiteral("10")}
					};

					mAdditionalGamesPerArea.insert ( intToTypeString.value(iValue), 1 );

				} else if ( m_cGamesConfig.readGameCode() == LOTO_CL ) {

					static QMap<int,QString> intToTypeString = {
						{0, QStringLiteral("Revancha")},
						{1, QStringLiteral("Desquite")},
						{3, QStringLiteral("Multiplicador")},
						{2, QStringLiteral("Ahora si que si!")},
						{4, QStringLiteral("Jubilazo")}
					};

					mAdditionalGamesPerArea.insert ( intToTypeString.value(iValue), 1 );

				}

				m_cCouponData.getArea (iArea)->setAdditionalGamePerArea( mAdditionalGamesPerArea );

			}  else if (eBoxType == BoxType::Multidraw) {

				m_cCouponData.setMultiDrawMulti (iValue);
			}
		}

		// -------- Clear void areas -------
		for ( int area; area < m_cCouponData.getAreaListSize(); area++ ) {

			if ( m_cCouponData.getArea( area )->isVoidArea() ) {
				m_cCouponData.getArea( area )->clearArea();
			}
		}


		// -------- 2nd Phase ---------
		// Check values entered in couponData and mark for errors.

		if (m_cCouponData.getMultiDrawList().size() > 2) {
			m_cCouponData.setMultiDrawSingle (ImtsGamesEnums::TooManyDraws);
		}

		auto iNumberOfAreas = m_cGamesConfig.readNumberOfSlipAreas ();
		for (auto iArea=0; iArea<iNumberOfAreas; ++iArea) {

			if (m_cCouponData.getArea (iArea)->isVoidArea ()) {
				continue;
			}

			if (IS_PICK(m_cGamesConfig.readGameCode ())) {

				QVariantMap mMultipliers  = m_cCouponData.getArea (iArea)->getCustomData ();

				if (mMultipliers.isEmpty ()) {
					m_cCouponData.getArea (iArea)->setMultiplierSingle (ImtsGamesEnums::NoMultiplierSelected);
				}

				// Go through playTypes (keys) and detect whether a key has been assigned multiple values
				// In that case, we remove the key and tag for "too many multipliers"

				QMutableMapIterator<QString, QVariant> i(mMultipliers);
				auto bTooManyMultipliers = false;
				while (i.hasNext()) {
					i.next();
					if (mMultipliers.values (i.key ()).size () > 1) { // check whether playtype has assigned multiple multipliers.
						bTooManyMultipliers = true;
						i.remove ();
					}
				}
				if (bTooManyMultipliers) {
					m_cCouponData.getArea (iArea)->setMultiplierSingle (ImtsGamesEnums::TooManyMultipliers);
				}

				m_cCouponData.getArea (iArea)->setCustomData (mMultipliers);
			}
		}

		CouponError cCouponError = checkForCouponErrors ();

		if (!cCouponError.isEmpty ()) {

			qsErrorMessage += cCouponError.getCouponErrorsInArea(100);

			QString qsAreaError = QString ();

			for (int iArea = 0, iFirstAreaWithError = -1; iArea < m_cGamesConfig.readNumberOfAreas (); ++iArea) {

				qsAreaError = cCouponError.getCouponErrorsInArea(iArea);

				if (!qsAreaError.isEmpty ()) {

					qsErrorMessage += qsAreaError;

					if (IS_PICK(m_cGamesConfig.readGameCode ())) { // Loto3 does not have multiple areas. So remove label. Could have been done better, but I got not time for it.
						qsErrorMessage.remove ("Area[1]: ");
					}

					if (iFirstAreaWithError == -1) {

						m_cCouponData.setLastSelectedArea(iArea);
						iFirstAreaWithError = iArea;

					}
				}
			}
		}
	}

	m_cCouponData.setGameCode (m_cGamesConfig.readGameCode());
	m_cCouponData.setGameName (m_cGamesConfig.readGameName ());
	m_cCouponData.setInputMethod(int(ImtsGamesEnums::Scanned));
	m_cCouponData.setCouponOrigin (ImtsGamesEnums::Camera);

	return qsErrorMessage;
}


/**
 * @brief checkForCouponErrors
 * @param cGamesConfig
 * @param cCouponData
 * @return CouponError object
 */
CouponError CouponProcessManagerDerived::checkForCouponErrors ()
{
	CouponError cCouponError = m_pcCouponUtilitiesDerived->getCouponErrors (&m_cGamesConfig, m_cCouponData);

	return cCouponError;
}



/**
 * @sa promptForCost
 * @brief just before feeding CCM with data do a final check on cost.
 * In case a msg box is raised and the user answers +ve play data are fed in CCM via GamesCenter obj,
 * which handles the msg box.
 */
void CouponProcessManagerDerived::promptForCost ()
{

	QString qsDisplayText = QString ();

	double dCouponCost = m_cCouponData.getCouponCost ()*m_cCouponData.getNumberOfTickets ();

	qsDisplayText = m_pcCouponUtilitiesDerived->promptForCost (m_cGamesConfig.readGameCode (), dCouponCost);

	if (!qsDisplayText.isEmpty ()) {

		setScanningDeviceEnabled (false);

		QmlMessageBox::eeQmlMessageBoxResult eUsersChoice = GamesUtilities::displayLocalMessageBox (qsDisplayText,
																									tr("Yes"),
																									tr("Information"),
																									tr("Edit"),
																									tr("Exit"),
																									QString ());
		if (eUsersChoice == QmlMessageBox::eOK) { // Yes

			emit processCouponsBatch (&m_cGamesConfig, QList<Coupon> () << m_cCouponData, ImtsGamesEnums::Camera);
			emit resumeCouponProcess ();

		} else if (eUsersChoice == QmlMessageBox::eCANCEL ) { // Edit

			emit requestCouponDataEdit (m_cCouponData, ImtsGamesEnums::HwEditRequest|ImtsGamesEnums::CostEdit);

		} else if (eUsersChoice == QmlMessageBox::eCUSTOM1  || eUsersChoice == QmlMessageBox::eTIMEOUT) { // Drop

			emit resumeCouponProcess ();
		}
		m_cCouponData.clearCouponData ();
	}


	if (qsDisplayText.isEmpty ()) {
		emit processCouponsBatch (&m_cGamesConfig, QList<Coupon> () << m_cCouponData, ImtsGamesEnums::Camera);
		emit resumeCouponProcess ();
	}
}

/**
 * @sa promptForCouponErrors
 * @param qsDisplayText
 */
void CouponProcessManagerDerived::promptForCouponErrors (const QString& qsDisplayText)
{

	setScanningDeviceEnabled (false);

	QmlMessageBox::eeQmlMessageBoxResult eUsersChoice = GamesUtilities::displayLocalMessageBox (qsDisplayText,
																								tr("Edit"),
																								tr("Information"),
																								tr("Discard"),
																								QString (),
																								QString ());



	if (eUsersChoice == QmlMessageBox::eOK) { // Edit

		emit requestCouponDataEdit (m_cCouponData, ImtsGamesEnums::HwEditRequest);

	} else if (eUsersChoice == QmlMessageBox::eCANCEL || eUsersChoice == QmlMessageBox::eTIMEOUT ) { // Drop

		emit resumeCouponProcess ();
	}
	m_cCouponData.clearCouponData ();
}

/**
 * @sa promptForGeneralError
 * @param qsDisplayText
 * @param qsBtn1Text
 * @param qsMsgBoxTitle
 * @param iTimeOut
 */
void CouponProcessManagerDerived::promptForGeneralError ( const QString& qsDisplayText, const QString& qsBtn1Text, const QString& qsMsgBoxTitle, int )
{
	setScanningDeviceEnabled (false);

	GamesUtilities::displayLocalMessageBox (qsDisplayText,
											qsBtn1Text,
											qsMsgBoxTitle,
											QString (),
											QString (),
											QString ());


	m_cCouponData.clearCouponData ();
	emit resumeCouponProcess ();
}

/**
 * @sa procceedOnDuplicateDataSlot
 */
void CouponProcessManagerDerived::procceedOnDuplicateDataSlot ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData )
{

	setScanningDeviceEnabled (false);

	QString qsDisplayText = QString(tr("Current play is the same as last\nWould you like to proceed?"));

	QmlMessageBox::eeQmlMessageBoxResult eUsersChoice = GamesUtilities::displayLocalMessageBox (qsDisplayText,
																								tr("Yes"),
																								tr("Information"),
																								tr("No"),
																								QString (),
																								QString ());


	if ( eUsersChoice == QmlMessageBox::eOK ) { // Yes

		// Dont' resume CTM because
		acceptIncomingCouponData ( eCouponSource, qbaCouponData );

	} else if ( eUsersChoice == QmlMessageBox::eCANCEL || eUsersChoice == QmlMessageBox::eTIMEOUT ) { // No

		// just don't do anything. Ignore incoming data, but resume CTM.
	}
	setScanningDeviceEnabled (true);

}

/**
 * @sa processCameraCoupon
 * @param qbaCouponData
 */
#undef PRODUCTION
void CouponProcessManagerDerived::processCameraCoupon (const QByteArray &qbaCouponData)
{
	m_cCouponData.clearCouponData ();

#if 0
	static quint32 iCouponNo = 0;
	QFile cameraData (QString("/tmp/coupon%1.dat").arg (++iCouponNo));
	cameraData.open (QIODevice::WriteOnly);

	QDataStream stream;
	stream.setVersion (QDataStream::Qt_5_0);
	stream.setDevice (&cameraData);
	stream.setByteOrder (QDataStream::LittleEndian);
	stream.device ()->reset ();
	stream << qbaCouponData;
	cameraData.close ();
	return;
#else


#if defined PRODUCTION
	QVariantMap m = QJson::JsonOperations::JsonObjectFromData (qbaCouponData);

	SMiniLotCouponDatMarks* pMiniLotMarks = new SMiniLotCouponDatMarks;

	memset (&pMiniLotMarks->camMarks,0,NUMBER_OF_CAMERA_MARKS);

	pMiniLotMarks->iPrimaRiga = quint16(m.value ("primariga").toInt ());
	QVariantList lMarks = m.value ("marks").toList ();
	auto iMark = 0;
	for (const auto mark:lMarks){
		pMiniLotMarks->camMarks[iMark++] = mark.toInt ();
	}
	pMiniLotMarks->iNoOfMarks = iMark;
#else


	QByteArray qbaLittleEndianData = QByteArray ();
	QBuffer buffer(&qbaLittleEndianData);
	buffer.open(QIODevice::WriteOnly);
	QDataStream stream(&buffer);
	stream.setVersion (QDataStream::Qt_5_0);
	stream.setByteOrder (QDataStream::LittleEndian);
	stream << qbaCouponData;
	buffer.close ();

	SMiniLotCouponDatMarks* pMiniLotMarks = (SMiniLotCouponDatMarks*)((char *)qbaLittleEndianData.data());

	QString qsCamData = QString(qbaLittleEndianData.toHex ());
	LOG(qsCamData);

#endif

	qint32 iGameRiga = pMiniLotMarks->iPrimaRiga;

	// iFlex: custom play slip handling
	LOG( QString("R I G A: %1 * * * * *").arg ( iGameRiga ) );
	if( iGameRiga==2425 ) {

		static QScopedPointer<QDBusInterface> flexBetDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSFlexBet"), QLatin1String("/FlexBetOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
		flexBetDbusInterface.data ()->setTimeout (0);
		QDBusReply<void> reply = flexBetDbusInterface.data ()->call ("processCameraDataSlot", qbaLittleEndianData );

		if (!reply.isValid ()) {

			QDBusError dbusError = reply.error();
			LOG(dbusError.message());
			LOG(dbusError.errorString(dbusError.type()));
			LOG("Flex bet is down?");

		}

		emit resumeCouponProcess ();
		return;
	}
	// iFlex: end of custom handling


	quint16 iNumberOfMarks = pMiniLotMarks->iNoOfMarks;
	QString qsErrorMessage = QString ();


	LOG(QString("Coupon with riga: %1 received").arg (iGameRiga));

	if (!CouponUtilities::getGameConfig (CouponUtilities::eByGameRiga, iGameRiga, m_cGamesConfig)) {

		promptForGeneralError (tr("Invalid play slip"), tr("OK"), tr("Information"));

	} else {
		qsErrorMessage = initializeCouponDataFromMarks (pMiniLotMarks->camMarks, iNumberOfMarks,iGameRiga);

		if (m_cCouponData.isCouponEmpty() || m_cCouponData.isCouponVoid()) {

			promptForGeneralError (tr("Empty play slip") , tr("OK"), tr("Information"));

		} else {

			if (!qsErrorMessage.isEmpty ()) { // Message either for lotto games or pollagol

				promptForCouponErrors (qsErrorMessage);

			} else {

				if (iGameRiga!=2420) { // Not PollaGol. PollaGol does cost on its own.
					m_pcCouponUtilitiesDerived->updateCouponCost (&m_cGamesConfig, m_cCouponData);
				}

				emit processCouponsBatch (&m_cGamesConfig, QList<Coupon> () << m_cCouponData, ImtsGamesEnums::Camera);
				emit resumeCouponProcess ();

			}
		}
	}

#if defined PRODUCTION
	delete pMiniLotMarks;
#endif
#endif

}

/**
 * @sa processGuiFlexBetData
 * @param qbaCouponData
 */
void CouponProcessManagerDerived::processGuiFlexBetData (const QByteArray& qbaFlexBetData)
{

	m_cCouponData.clearCouponData();
	FlexBetTxData cFlexBetTxData;

	bool bOK = QJson::JsonOperations::JsonToqObject (qbaFlexBetData, &cFlexBetTxData);

	if (bOK) {

		ImtsGamesEnums::CouponSource eCouponSource = ImtsGamesEnums::CouponSource(cFlexBetTxData.readSource ());

		m_cCouponData.setGameCode          (cFlexBetTxData.readGameCode ());
		m_cCouponData.setGameName          (cFlexBetTxData.readGameName ());
		m_cCouponData.setCouponCost        (cFlexBetTxData.readCost ());
		m_cCouponData.setCouponColumns     (cFlexBetTxData.readColumns ());
		m_cCouponData.setInputMethod       (cFlexBetTxData.readInputMethod ());
		m_cCouponData.setCouponOrigin      (ImtsGamesEnums::FlexBet);
		m_cCouponData.setCouponId          (cFlexBetTxData.readImtsCouponId ());

		QVariantMap mFlexBet;
		mFlexBet.insert (QStringLiteral("ExternalTxData"), qbaFlexBetData);
		m_cCouponData.setAdditionalGameMap (mFlexBet);

		if (cFlexBetTxData.readPgm15000 ().isEmpty()) { //.value ("Marks").toByteArray ().isEmpty ()) {
			// In case data sent by Flexbet is the result of an edit action then, we got to check
			// whether flexbet actual data contained in "Marks" is empty or not. If empty then it
			// means that the user edited the data but cleared them and in that case we got to tag
			// coupon as void so that its entry is removed rom CCM.

			m_cCouponData.setCouponVoid (true);

		}

		emit processCouponsBatch (nullptr, QList<Coupon> () << m_cCouponData, eCouponSource);


	} else {

		LOG("Invalid flex bet data");
	}

	emit resumeCouponProcess ();
}

/**
 * @brief CouponProcessManagerDerived::updateCouponCost
 */
void CouponProcessManagerDerived::updateCouponCost (GamesConfig& cGamesConfig, const Coupon& cCouponData )
{
	m_pcCouponUtilitiesDerived->updateCouponCost (&cGamesConfig, cCouponData);
}

/**
 * @brief CouponProcessManagerDerived::createCouponDataFromGameTxData
 */
void CouponProcessManagerDerived::createCouponDataFromGameTxData (const QByteArray& qbaGameTxData, Coupon& couponData, GamesConfig *const pcGamesConfig)
{
	m_pcCouponUtilitiesDerived->createCouponDataFromGameTxData (qbaGameTxData, couponData, pcGamesConfig);
}


/**
 * @sa finalizeQpPlay
 * @param cGamesConfig
 * @param cCouponData
 * @return finalize qp play. Project depended
 */
void CouponProcessManagerDerived::finalizeQpPlay (GamesConfig& cGamesConfig, Coupon& cCouponData, ExternalPlay& cExternalPlay)
{
	if (cExternalPlay.readMultiplier() >= 100 && cGamesConfig.readGameCode() == LOTO3_CL) {

		QVariantMap qvmCustomData = QVariantMap();
		ImtsGamesEnums::PickXPlayTypeFlags playTypeFlag = ImtsGamesEnums::PickXPlayTypeFlags(2);

		qvmCustomData.insert(QStringLiteral("Straight"),cExternalPlay.readMultiplier());
		cCouponData.getArea(cCouponData.getLastSelectedArea())->setCustomData(qvmCustomData);
		cCouponData.getArea(cCouponData.getLastSelectedArea())->setPickXPlayType(playTypeFlag);

		cCouponData.getArea(cCouponData.getLastSelectedArea())->setMultiplierSingle(1);   // Due to the use of "Multiplier" attribute inside the configuration file.
	}

	if (cExternalPlay.readSystem() > 0 && cGamesConfig.readGameCode() == POLLAGOL_CL) {

		PollaGol fastPlayPollaGol;
		fastPlayPollaGol.selectQpMatches(cExternalPlay.readSystem()/10, cExternalPlay.readSystem()%10);
		//fastPlayPollaGol.performPlaySlot();
	}
}


