#include "dlgSystemsMults.h"
#include "FlexBet.h"
#include "CommonDefinitions.h"
#include "ProjectApp.h"

SystemsMultipliers::SystemsMultipliers(bool draw, QWidget *parent, const char *name):Screen(parent, name)
{
    OkPressed=false;
    indexP=0;
    memset(&betCoupon,0,sizeof(CouponRecord));
    for (int i=0; i<NUM_O_PERMS-1; i++)
        sysMultiplier[i]=1;

    sysNumAllowed = NUM_O_PERMS-2; // aste: Was NUM_O_PERMS-1, but in CH we don't have the 0-system either
    Draw = draw;

    SysLabel=NULL;
    SysText=NULL;
    MultLabel=NULL;
    MultText=NULL;
    TotalCpnsCostLabel=NULL;
    TotalCpnsCostText=NULL;
    DateTimeText=NULL;

    if (draw)
    {
        initGraph();
        initTouchAreas();
        initMark();
        initDialog();
    }
}

SystemsMultipliers::~SystemsMultipliers()
{
    if (Draw)
    {
        if (SysLabel)
            delete SysLabel;

        if (SysText)
            delete SysText;

        if (MultLabel)
            delete MultLabel;

        if (MultText)
            delete MultText;

        if (TotalCpnsCostLabel)
            delete TotalCpnsCostLabel;

        if (TotalCpnsCostText)
            delete TotalCpnsCostText;

        if (DateTimeText)
            delete DateTimeText;

        for (int i=0; i<NUM_O_STAKES_MULTS+NUM_O_SYSTEMMULTS+NUM_O_PERMS; i++)
            delete sysMultsTick[i];

        delete pixMarkSysMults;
        delete pixMarkStakes; // aste: added for CH
    }

}

void SystemsMultipliers::showDateTime()
{
    QDateTime qdtNow = QDateTime::currentDateTime();
    QString qsDate = qdtNow.date().toString(Qt::DefaultLocaleLongDate);

//    qdtNow.setTimeSpec(Qt::LocalTime);
//    DateTimeText->setText(QDateTime::currentDateTime().toString("dddd, MMMM d, yyyy hh:mm:ss"));
    DateTimeText->setText(qsDate.append (QString(" %1").arg (qdtNow.toString ("hh:mm:ss")) ));
}

void SystemsMultipliers::initDialog()
{

    char qname[1000]= {0};

    //set the cancel and ok buttons
    CancelBtn= new TouchButton(this,"NoName");
    CancelBtn->setGeometry(772, 698, 100, 55);
    CancelBtn->isCustomDraw=true;
    sprintf(qname,"%s",(m_pApp->getGamesBitmapsPath() + QString("buttons/msk100x55.png")).toAscii().data());
    CancelBtn->setMask(QBitmap(qname));
    sprintf(qname,"%s",(m_pApp->getGamesBitmapsPath() + QString("buttons/buttonsB/btnCancel")).toAscii().data());
    CancelBtn->SetPixmapText(qname);
    CancelBtn->setFocusPolicy(Qt::NoFocus);
    connect (CancelBtn, SIGNAL(pressed()), SLOT(CancelSgn()));

    //set the ok and cancel buttons
    ReturnBtn= new TouchButton(this,"NoName");
    ReturnBtn->setGeometry(891, 698, 100, 55);
    ReturnBtn->isCustomDraw=true;
    sprintf(qname,"%s",(m_pApp->getGamesBitmapsPath() + QString("buttons/msk100x55.png")).toAscii().data());
    ReturnBtn->setMask(QBitmap(qname));
    sprintf(qname,"%s",(m_pApp->getGamesBitmapsPath() + QString("buttons/buttonsB/btnOk")).toAscii().data());
    ReturnBtn->SetPixmapText(qname);
    ReturnBtn->setFocusPolicy(Qt::NoFocus);
    connect (ReturnBtn, SIGNAL(pressed()), SLOT(ExitSgn()));

    int offsetLabelX = 35, offsetTextX = 110, offsetY = 688;
    int textWidth = 120, textHeight = 15;

    QFont labelFont("Arial",10);

    // Label & text field for the Systems
    SysLabel = new QLabel(this,"sysLabel");
    SysLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
    SysLabel->setLineWidth(0);
    SysLabel->setIndent(4);
    SysLabel->setFont(labelFont);
    SysLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
    SysLabel->setAutoFillBackground( true );
    SysLabel->setBackgroundColor(QColor(255,255,255));
    SysLabel->setPaletteForegroundColor(Qt::black);
    SysLabel->setGeometry(offsetLabelX, offsetY, offsetTextX, 3 * textHeight);
    SysLabel->setText(QString("Systems"));

    SysText=new QLabel(this,"SysText");
    SysText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
    SysText->setLineWidth(0);
    SysText->setIndent(4);
    SysText->setFont(labelFont);
    //SysText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    SysText->setAlignment(Qt::AlignRight|Qt::AlignTop);
    SysText->setAutoFillBackground( true );
    SysText->setBackgroundColor(QColor(255,255,255));
    SysText->setPaletteForegroundColor(Qt::black);
//	SysText->move(150,678);
//	SysText->resize(135,51);
//    SysText->setGeometry(150, 678, 135, 51);
    SysText->setGeometry(offsetLabelX + offsetTextX, offsetY, textWidth, 3 * textHeight);
    SysText->setWordWrap(true);
    // Label & text field for the Systems

    // Label & text field for the Total Columns
    MultLabel = new QLabel(this,"multLabel");
    MultLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
    MultLabel->setLineWidth(0);
    MultLabel->setIndent(4);
    MultLabel->setFont(labelFont);
    MultLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
    MultLabel->setAutoFillBackground( true );
    MultLabel->setBackgroundColor(QColor(255,255,255));
    MultLabel->setPaletteForegroundColor(Qt::black);
    MultLabel->setGeometry(offsetLabelX, offsetY + 3 * textHeight, offsetTextX, textHeight);
    MultLabel->setText(QString("Total Columns"));

    MultText=new QLabel(this,"MultText");
    MultText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
    MultText->setLineWidth(0);
    MultText->setIndent(4);
    MultText->setFont(labelFont);
    MultText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    MultText->setAutoFillBackground( true );
    MultText->setBackgroundColor(QColor(255,255,255));
    MultText->setPaletteForegroundColor(Qt::black);
//    MultText->setGeometry(150,728,135,17);
    MultText->setGeometry(offsetLabelX + offsetTextX, offsetY + 3 * textHeight, textWidth, textHeight);
    // Label & text field for the Total Columns

    // Label & text field for the Total Cost
    TotalCpnsCostLabel = new QLabel(this,"totalCostLabel");
    TotalCpnsCostLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
    TotalCpnsCostLabel->setLineWidth(0);
    TotalCpnsCostLabel->setIndent(4);
    TotalCpnsCostLabel->setFont(labelFont);
    TotalCpnsCostLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
    TotalCpnsCostLabel->setAutoFillBackground( true );
    TotalCpnsCostLabel->setBackgroundColor(QColor(255,255,255));
    TotalCpnsCostLabel->setPaletteForegroundColor(Qt::black);
    TotalCpnsCostLabel->setGeometry(offsetLabelX, offsetY + 4 * textHeight, offsetTextX, textHeight);
    TotalCpnsCostLabel->setText(QString("Total Cost"));

    TotalCpnsCostText = new QLabel(this,"");
    TotalCpnsCostText->setFrameStyle( Q3Frame::Panel | Q3Frame::Sunken );
    TotalCpnsCostText->setLineWidth(0);
    TotalCpnsCostText->setIndent(4);
    TotalCpnsCostText->setFont(labelFont);
//    TotalCpnsCostText->setGeometry(150,746,135,16);
    TotalCpnsCostText->setGeometry(offsetLabelX + offsetTextX, offsetY + 4 * textHeight, textWidth, textHeight);
    TotalCpnsCostText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    TotalCpnsCostText->setText(QString("--"));
    TotalCpnsCostText->setAutoFillBackground( true );
    TotalCpnsCostText->setBackgroundColor(QColor(255,255,255));
    TotalCpnsCostText->setPaletteForegroundColor(Qt::black);
    TotalCpnsCostText->show();
    // Label & text field for the Total Cost

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(showDateTime()));
    timer->start(1000);

    DateTimeText = new QLabel(this,"dateTimeText");
//    DateTimeText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
//    DateTimeText->setLineWidth(0);
//    DateTimeText->setIndent(4);
    DateTimeText->setFont(QFont("Roboto",11));
    DateTimeText->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);
    DateTimeText->setAutoFillBackground( true );
    DateTimeText->setBackgroundColor(QColor(255, 140, 0));
    DateTimeText->setPaletteForegroundColor(Qt::white);
    DateTimeText->setGeometry(368, 1, 300, 32);
    showDateTime();
}

void SystemsMultipliers::initGraph()
{
    char fname[100];

    resize(1024,768);

    pixMarkSysMults=new Q3CanvasPixmapArray();
    pixMarkStakes=new Q3CanvasPixmapArray();

    mpCanvas=new Q3Canvas(this, "");
    mpCanvas->resize(1019,763);
    mpView= new screenView(mpCanvas,this);
    mpView->resize(1024,768);

    sprintf(fname,"%s",(m_pApp->getGamesBitmapsPath() + QString("screens/SnM_NGUI_E.png")).toAscii().data());

    screenSys.load(fname);
    mpCanvas->setBackgroundPixmap(screenSys);

    sprintf(fname,"%s",(m_pApp->getGamesBitmapsPath() + QString("selections/SystemsSelection.png")).toAscii().data());
    pixMarkSysMults->readPixmaps(fname,1);

    sprintf(fname,"%s",(m_pApp->getGamesBitmapsPath() + QString("selections/SystemsSelectionB.png")).toAscii().data());
    pixMarkStakes->readPixmaps(fname,1);

    for (int i=0; i<NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS; i++)
    {
        if (i < NUM_O_PERMS)
            sysMultsTick[i] = new Q3CanvasSprite(pixMarkSysMults,mpCanvas);
        else
            sysMultsTick[i] = new Q3CanvasSprite(pixMarkStakes,mpCanvas);
    }

    mpCanvas->setAdvancePeriod(10);
    mpCanvas->setDoubleBuffering(true);
}

void SystemsMultipliers::initMark()
{

    for (int i=0; i<NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS; i++)
        sysMultsTick[i]->move(PicArray[i].x,PicArray[i].y);

}

void SystemsMultipliers::initTouchAreas()
{
    int xpos,ypos;
    int dx;
    int dy;
    int sw;
    int sh;
    int ipos=0;
    int x0, y0;

    ///set touch areas for the systems
    x0 = 82;
    y0 = 144;
    dx=80;
    dy=73;
    sw=65;
    sh=65;
    xpos=x0;
    ypos=y0;//ypos=150;
    for (int i = 0; i < NUM_O_PERMS; i++)
    {
        if (i == 0 || i == NUM_O_PERMS - 1)
        {
            // Since CH does not support the 0-system or ALL-system buttons, make their PicArray entries invalid
            PicArray[ipos].x=-999;
            PicArray[ipos].y=-999;
            PicArray[ipos].w=0;
            PicArray[ipos].h=0;
        }
        else
        {
            PicArray[ipos].x=xpos;
            PicArray[ipos].y=ypos;
            PicArray[ipos].w=sw;
            PicArray[ipos].h=sh;
            xpos+=dx;
        }

        ipos++;

        if (i != 0 && i % 11 == 0) // 11 system buttons per row, starting from index 1
        {
            xpos=x0;
            ypos+=dy;
        }
    }

    /// 	for the system multiplier
    dx=24;//dx=14;
    xpos=85;//xpos=15;
    ypos=534;//ypos=570;
    for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
    {
#ifdef DISABLE_SYSMULTS
        PicArray[ipos].x=-999;
        PicArray[ipos].y=-999;
        PicArray[ipos].w=0;
        PicArray[ipos].h=0;
#else
        PicArray[ipos].x=xpos;
        PicArray[ipos].y=ypos;
        PicArray[ipos].w=sw;
        PicArray[ipos].h=sh;
#endif
        xpos+=dx+sw;
        ipos++;
    }

    /// 	for the coupon stake
    x0 = 87;
    y0 = 440;
    dx = 148;
    dy = 64;
    sw = 115;
    sh = 55;
    xpos = x0;
    ypos = y0;
    for (int i=0; i<NUM_O_STAKES; i++)
    {
        if (i % 6 == 0 && i != 0) // 6 stakes buttons per row
        {
            xpos = x0;
            ypos += dy;
        }

        PicArray[ipos].x = xpos;
        PicArray[ipos].y = ypos;
        PicArray[ipos].w = sw;
        PicArray[ipos].h = sh;
        xpos += dx;
        ipos++;
    }

    /// 	for the coupon multiplier
    dx=25;//dx=15;
    xpos=682;//376;//xpos=268;
    ypos=533;//ypos=570;
    for (int i=0; i<NUM_O_MULTS; i++)
    {
        if (i==2)
        {
            xpos=682;
            ypos=533+sh+18;
        }

        PicArray[ipos].x=xpos;
        PicArray[ipos].y=ypos;
        PicArray[ipos].w=sw;
        PicArray[ipos].h=sh;
        xpos+=dx+sw;
        ipos++;
    }
}

void SystemsMultipliers::CheckGUI()
{

    int sumSM=0;
    int sumCM=0;
    int sumMU=0;
    int count=0;

    /// check the system marks
    for (int i=0; i<NUM_O_PERMS-1; i++) ///don't count the ALL mark
        if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]==1)
            count++;

    for (int i=0; i<NUM_O_PERMS-1; i++)
    {
        if (count<sysNumAllowed)
        {
            if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]==3)
            {
                betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]=0;
                count--;

            }
            else if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]==2)
            {
                betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]=1;
                count++;
            }
            else if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]!=1)
                betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]=0;
        }
    }

    if (betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]==2)
        betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]=1;
    else if (betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]==3)
        betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]=0;

    /// check the system multiplier marks
    for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
        if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]==1)
            sumSM++; ///Find out how many choices aready exist

    for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
    {
        if (sumSM<NUM_O_SYSTEMMULTS)   ///if less than 4 choices
        {
            if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]==2)
            {
                betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]=1; ///make the choice valid
                sumSM++; ///choice increments (not really need to)
            }
            else if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]==3)
            {
                betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]=0;
                sumSM--; ///choices decrement
            }
        }
        else if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]!=1)
            betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)]=0; ///leave only the choices that already exist
    }

    /// check the coupon stake
    for (int i=0; i<NUM_O_STAKES; i++)
        if (betCoupon.Marks[OFFSET_OF_STAKE+ i]==1)
            sumCM++; ///Find out how many choices aready exist

    for (int i=0; i<NUM_O_STAKES; i++)
    {
        if (sumCM < MAXIMUM_SELECTED_STAKES)   ///if less than three choices
        {
            if (betCoupon.Marks[OFFSET_OF_STAKE+ i]==2)
            {
                betCoupon.Marks[OFFSET_OF_STAKE+ i]=1; ///make the choice valid
                sumCM++; ///choices increment
            }
            else if (betCoupon.Marks[OFFSET_OF_STAKE+ i]==3)
            {
                betCoupon.Marks[OFFSET_OF_STAKE+ i]=0;
                sumCM--; ///choices decrement
            }
        }
        else if (betCoupon.Marks[OFFSET_OF_STAKE+ i]!=1)
            betCoupon.Marks[OFFSET_OF_STAKE+ i]=0; ///leave only the choices that already exist

    }

    /// check the coupon multiplier
    for (int i=0; i<NUM_O_MULTS; i++)
        if (betCoupon.Marks[OFFSET_OF_MULT+ i]==1)
            sumMU++; ///Find out how many choices aready exist

    for (int i=0; i<NUM_O_MULTS; i++)
    {
        if (sumMU < MAXIMUM_SELECTED_MULTS)   ///if less than three choices
        {
            if (betCoupon.Marks[OFFSET_OF_MULT+ i]==2)
            {
                betCoupon.Marks[OFFSET_OF_MULT+ i]=1; ///make the choice valid
                sumMU++; ///choices increment
            }
            else if (betCoupon.Marks[OFFSET_OF_MULT+ i]==3)
            {
                betCoupon.Marks[OFFSET_OF_MULT+ i]=0;
                sumMU--; ///choices decrement
            }
        }
        else if (betCoupon.Marks[OFFSET_OF_MULT+ i]!=1)
            betCoupon.Marks[OFFSET_OF_MULT+ i]=0; ///leave only the choices that already exist

    }
}

void SystemsMultipliers::InformMousePressEvent(QMouseEvent *e)
{
    QRect r;
    QPoint p;

    p.setX(e->x());
    p.setY(e->y());

    /// get the event for the multiplier area
    for (int i=0; i<NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS; i++)
    {
        r.setRect(PicArray[i].x,PicArray[i].y,PicArray[i].w,PicArray[i].h);
        if (r.contains(p) && i<NUM_O_PERMS)
        {
            // A system button has been selected
            m_pApp->playSoundEffect();
            ///   0...30 Marks
            if (i<(NUM_O_PERMS-1))
            {
                if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)])
                    betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]=3; ///if mark is on set it off
                else
                    betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)]=2;  ///else set it on
            }
            ///	ALL mark
            if (i==(NUM_O_PERMS-1))
            {
                if (betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)])      ///Last mark of couponRec.Marks is for ALL
                    betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]=3;   ///if mark is on set it off
                else
                    betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)]=2;    ///else set it on
            }
        }
        else if (r.contains(p)&& i<NUM_O_SYSTEMMULTS+NUM_O_PERMS)
        {
            // A system multiplier button has been selected
            m_pApp->playSoundEffect();
            if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + ((i-NUM_O_PERMS)+1)])
                betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + ((i-NUM_O_PERMS)+1)]=3; ///if mark is on set it off
            else
                betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + ((i-NUM_O_PERMS)+1)]=2; ///else set it on
        }
        else if (r.contains(p) && i<NUM_O_SYSTEMMULTS+NUM_O_PERMS+NUM_O_STAKES)
        {
            // A stake button has been selected
            m_pApp->playSoundEffect();
            if (betCoupon.Marks[OFFSET_OF_STAKE+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))])
                betCoupon.Marks[OFFSET_OF_STAKE+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))]=3;
            else
                betCoupon.Marks[OFFSET_OF_STAKE+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))]=2;
        }
        else if (r.contains(p))
        {
            // A coupon multiplier button has been selected
            m_pApp->playSoundEffect();
            if (betCoupon.Marks[OFFSET_OF_MULT+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))])
                betCoupon.Marks[OFFSET_OF_MULT+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))]=3;
            else
                betCoupon.Marks[OFFSET_OF_MULT+ (i-(NUM_O_SYSTEMMULTS+NUM_O_PERMS))]=2;
        }
    }
    CheckGUI();
    calculateIt();
    UpdateArea();
}

void SystemsMultipliers::UpdateArea()
{
    ///Update system multiplier Sprites and buttons

//    char temp[10];
//    char filename[256];

    QString systems="";

    for (int i=0; i<NUM_O_PERMS+NUM_O_SYSTEMMULTS+NUM_O_STAKES_MULTS; i++)
    {
        if (i<NUM_O_PERMS)
        {
            if (i<(NUM_O_PERMS-1))
            {
                if (betCoupon.Marks[OFFSET_OF_SYS + i*(NUM_O_SYSTEMMULTS+1)]==1)
                {
//                    if (i==indexP)
//                    {
//                        sprintf(filename,"%s",(m_pApp->getGamesBitmapsPath() + QString("SYSTEMS/pmBtnToggle")).toAscii().data());
//                        SMButton[i]->SetPixmapText(filename);
//                    }
//                    else
//                    {
//                        sprintf(filename,"%s",(m_pApp->getGamesBitmapsPath() + QString("SYSTEMS/pmBtn")).toAscii().data());
//                        SMButton[i]->SetPixmapText(filename);
//                    }
//                    SMButton[i]->setEnabled(true);
//                    sprintf(temp,"%d",sysMultiplier[i]);
//                    SMButton[i]->SetText(temp);
//                    SMButton[i]->update();
                    sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI

                    if (systems.length())
                        systems.append(QString(", "));

                    systems=systems.append(QString::number(i)+QString("(%1)").arg(sysMultiplier[i]));
                }
                else
                {
//                    SMButton[i]->setEnabled(false);
//                    emptyMulti(i);
//                    SMButton[i]->SetText(" ");
//                    SMButton[i]->update();
                    sysMultsTick[i]->hide(); ///if it is off don`t
//                    sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI
                }
            }

            ///for ALL
            if (betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)])
            {
                sysMultsTick[NUM_O_PERMS-1]->show();

                systems=systems.append(qApp->translate("FlexBet",", ALL"));
            }
            else
                sysMultsTick[NUM_O_PERMS-1]->hide();
//                sysMultsTick[NUM_O_PERMS-1]->show();

        }
        else if (i<NUM_O_SYSTEMMULTS+NUM_O_PERMS)
        {
            if (betCoupon.Marks[OFFSET_OF_SYS + indexP*(NUM_O_SYSTEMMULTS+1) + (i-NUM_O_PERMS+1)])
            {
                sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI
            }
            else
                sysMultsTick[i]->hide(); ///if it is off don`t
//                sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI
        }
        else
        {
            if (betCoupon.Marks[OFFSET_OF_STAKE + (i-(NUM_O_PERMS+NUM_O_SYSTEMMULTS))])
            {
                sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI
            }
            else
                sysMultsTick[i]->hide(); ///if it is off don`t
//                sysMultsTick[i]->show(); ///if Mark is on show the tick mark on GUI
        }
    }

    int count=0;
    ReturnBtn->setEnabled(true);
    for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
        if (betCoupon.Marks[OFFSET_OF_SYS+ indexP*(NUM_O_SYSTEMMULTS+1) + (i+1)])
            count++;
    if (count>NUM_O_SYSTEMMULTS)
        ReturnBtn->setEnabled(false); ///if more than NUM_O_SYSTEMMULTS choices disable OK button

    count=0;
    for (int i=0; i<NUM_O_STAKES; i++)
        if (betCoupon.Marks[OFFSET_OF_STAKE+i])
            count++;
    if (count>MAXIMUM_SELECTED_STAKES)
        ReturnBtn->setEnabled(false); ///if more than MAXIMUM_SELECTED_STAKES choices disable OK button

    count=0;
    for (int i=0; i<NUM_O_MULTS; i++)
        if (betCoupon.Marks[OFFSET_OF_MULT+i])
            count++;
    if (count>MAXIMUM_SELECTED_MULTS)
        ReturnBtn->setEnabled(false); ///if more than MAXIMUM_SELECTED_MULTS choices disable OK button

    for (int i=0; i<NUM_O_PERMS-1; i++)
        if ((!betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)])&&(sysMultiplier[i]!=1))
            ReturnBtn->setEnabled(false); ///if the system is not selected but has a multiplier

    // Display the Systems text
    if (systems.length())
        SysText->setText(systems);
    else
        SysText->setText(QString("-"));

    unsigned long int iColumns = 0;

    // aste : Seems to be necessary to propagate the button just pressed to the FlexBet class
    getCouponMarks(m_FlexBet->getCouponRecord(0),NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));

    if (m_FlexBet->CheckCoupon(0,false) == 1)
        iColumns = m_FlexBet->getTotalColumns();

    // Display the Multiplier text
    MultText->setText(QString::number(iColumns * cpnMultiplier));

    // Display the Total Coupon Cost text
    TotalCpnsCostText->setText(QString("%L1").arg(iColumns * cpnMultiplier * DEFAULT_STAKE));
}

void SystemsMultipliers::calculateIt()
{
    //     calculate the multipliers
    for (int sys=0; sys<NUM_O_PERMS-1; sys++)
    {
        sysMultiplier[sys]=1;
        // aste: The next part is unnecessary for CH, as there are no system multipliers
//        if (betCoupon.Marks[OFFSET_OF_SYS + sys*(NUM_O_SYSTEMMULTS+1)])
//        {
//            for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
//                if (betCoupon.Marks[OFFSET_OF_SYS + sys*(NUM_O_SYSTEMMULTS+1) + (i+1)])
//                    sysMultiplier[sys] *= (i+2);
//        }
    }
    ///	calculate the coupon multiplier
//    int translateStake[NUM_O_STAKES]=  {5, 10, 20, 30, 40, 50, 60, 70, 100, 150, 200, 250, 300, 400, 500, 1000, 2000, 5000};
    int translateStake[NUM_O_STAKES]=  {500, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 10000, 15000, 20000, 25000, 30000, 40000, 50000, 100000, 200000, 500000};
    cpnStake=0;
    for (int i=0; i<NUM_O_STAKES; i++)
    {
        if (betCoupon.Marks[OFFSET_OF_STAKE + i])
        {
            cpnStake += translateStake[i];
        }
    }

    // aste : If no stake buttons have been selected, set the cpnStake to 1 to play the default stake
    if (cpnStake == 0)
        cpnStake = 1;

    cpnMultiplier = 1;

    // aste: The next part is unnecessary for CH, as there are no coupon multipliers
//    int translateMulti[NUM_O_MULTS]=  {2,3,4,5};
//    for (int i=0; i<NUM_O_MULTS; i++)
//        if (betCoupon.Marks[OFFSET_OF_MULT + i])
//            cpnMultiplier *= translateMulti[i];

    cpnMultiplier*=cpnStake;
}

void SystemsMultipliers::emptyMulti(int index)
{
    sysMultiplier[index]=1;
    for (int i=0; i<NUM_O_SYSTEMMULTS; i++)
        betCoupon.Marks[OFFSET_OF_SYS + index*(NUM_O_SYSTEMMULTS+1) + (i+1)]=0;
}

/// set the maximum system number that can be played (not used)
void SystemsMultipliers::setSysAllowed(int num)
{
    sysNumAllowed=num;
}

void SystemsMultipliers::getResults(int *sys, int *multArray, int &cpnMlt)
{
    /// give the results
    for (int i=0; i<NUM_O_PERMS-1; i++)
    {
        if (betCoupon.Marks[OFFSET_OF_SYS+ i*(NUM_O_SYSTEMMULTS+1)])
        {
            sys[i]=1;
            multArray[i]=sysMultiplier[i];
        }
        else
        {
            sys[i]=0;
            multArray[i]=1;
        }
    }

    // ALL-system button
    if (betCoupon.Marks[OFFSET_OF_SYS+(NUM_O_PERMS-1)*(NUM_O_SYSTEMMULTS+1)])
        sys[NUM_O_PERMS-1]=1;
    else
        sys[NUM_O_PERMS-1]=0;

    cpnMlt=cpnMultiplier;
}

void SystemsMultipliers::setCouponMarks(CouponRecord &rec,int length)
{
    /// sets the marks that will be processed in this class (systems, sys multipliers and cpn multilier)
    for (int i=0; i<length; i++)
        betCoupon.Marks[OFFSET_OF_STAKE + i]=rec.Marks[OFFSET_OF_STAKE + i];
}

void SystemsMultipliers::getCouponMarks(CouponRecord &rec, int length)
{
    /// the processed marks are returned to the FlexBet main dialog
    for (int i=0; i<length; i++)
        rec.Marks[OFFSET_OF_STAKE + i]=betCoupon.Marks[OFFSET_OF_STAKE + i];
}

void SystemsMultipliers::ExitSgn()
{
    OkPressed=true;
    close();
}

void SystemsMultipliers::CancelSgn()
{
    OkPressed=false;
    close();
}

void SystemsMultipliers::MultiSgn()
{
    CheckGUI();
    UpdateArea();
}
