//Marks[] is divided as follows:
// 0...3            4 places for event multipliers 1K, 2K, 3K, 4K
// 4...33           30 places for Event (0, 100, 200,..., 900, 0, 10,..., 90, 0, 1,..., 9)
// 34...71          38 places for Bets. The bets are read with the following sequence
//                  1-X-2-U-O-0,5-NG-G-1ST-OD-EV-2ND-H-N-V-(0-1),(2-3),(4+),0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5+,5+,HC,B,Switch
// 72    	    1   place for R group
// 73...76          4   places for ABCD group
// 77...80          4 unused positions
// the above repeats 30 times one for each area (81 places) then:
//

// 2430...2445           16  places for multiplier
// 2446,2451,2456...     31  places for permutations
// 2447...2450,
// 2452...2455,
// 2457...               31*4 places to hold each permutation's multiplier
// 2600...              1   place to hold the ALL permutations

#ifndef FLEXBET_H
#define FLEXBET_H

#include <qapplication.h>
#include <qbitmap.h>
#include <qlayout.h>
#include <CoronisMessagebox.h>
#include "ecoupon.h"
#include "CouponsTable.h"
#include "CalculatorWidget.h"
#include "FlexBetDefs.h"
#include <qdatetime.h>
#include <q3groupbox.h>
#include <q3canvas.h>
#include <QMouseEvent>
#include <qlabel.h>
#include "AmountFunctions.h"
#include <Q3ValueList>
#include "l5_rdef.h"
#include "l5_tmsg.h"
#include "l5_strc.h"
#include "l5_strc_gm_15000.h"

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************
#include "FlexBetXmlController.h"
#include "IMTS/FlexBetTxData.h"
#include <QProgressDialog>
#include <QtDBus>
#include "FlexBetXmlController.h"
//***************************************************************************************
//***************************************************************************************

#define FLEXBET_TEMPLATE "GameFlexBet.xml"
#define COLUMN_PRICES_FOLDER "/IMTSResources/LinkToYourProject/TextFiles/ColumnPrices/"
#define BET_MARKS  45 // aste : Was 38 in BG
#define GRP_MARKS  4
#define R_GRP_MARK 1
#define MAXIMUM_NBR_BETBUTTONS_COMBINATIONS 6
#define BET_STD_INDX 2 // aste: Was 36 in BG
#define DEFAULT_STAKE 1 //100 // aste: was 10 in BG

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************
#define BET_RIGA_PHOTON 1643
#define BET_PLP_SIZE_BUFFER 712 //We don't have Game struct to describe the playslip and get the size. So we define it and give the value according the one calculated by the plp file.
#define MAX_TEAM_DESC_LENGTH 8
//***************************************************************************************
//***************************************************************************************
#define TICKET_EVENTID_LEN 5//standard + 4 digit code
#define TICKET_EVENT_LEN 32//(including the 3 chars ' - ' for a normal event)
#define TICKET_BET_TYPE_SPECIAL_LEN 45
#define TICKET_BET_HANDICAP_LEN 13
#define TICKET_BET_ODD_LEN 10
#define TICKET_BET_OUTCOME_NORMAL_LEN 18
#define TICKET_BET_OUTCOME_SPECIAL_LEN 32
#define SPACE_REPLACE_STR "~"
#define SPACE_REPLACE_CHAR '~'
#define SPACE_HTML_STR "&nbsp;"

#define IFLEX_RIGA  0x979 // aste: was 0x1FB in BG
#define IFLEX_RIGA2 0x231
#define IFLEX_RIGA3 0x135
#define IFLEX_RIGA4 0x1AD
#define IFLEX_RIGA5 0x373

#define IFLEX_RIGA_AREAS  10 // aste: was 12 in BG
//#define IFLEX_RIGA2_AREAS 6
//#define IFLEX_RIGA3_AREAS 30
//#define IFLEX_RIGA4_AREAS 15
//#define IFLEX_RIGA5_AREAS 1

#define PLAYLSIP_0135_LENGTH 234
#define PLAYLSIP_01AD_LENGTH 67
#define PLAYLSIP_0373_LENGTH 99

#define MULTIPLE_MARK_HALF_FINAL 10000


//////////////////////////////////////////
// Message header in all messages
//////////////////////////////////////////

typedef struct {
	int  MessageLength;           // Message Length
	unsigned short MessageType;   // Message Type  PKAP a180
	unsigned char MessageSubtype; // Message Subtype
	int  MsgTrnsNum;              // Internal transaction number
	unsigned long Extra;          // I can't have thought of everything can I?
}
__attribute__((packed)) MSGHEAD;

typedef struct {
    int32_t unused1;
    int32_t unused2;
    int32_t uiRiga;
    uint16_t uiMarks;
}__attribute__((packed)) SScanHeader;

/////////////////////////////////////////////
// Generic Message to LOTOS
/////////////////////////////////////////////
#define MAXDATA     4096
#define MAXRECLEN   2048

//////////////////////////////////////////
// Play Coupon Message and Reply
//////////////////////////////////////////
typedef struct {
	MSGHEAD header;
	char        data[MAXRECLEN];
}
__attribute__((packed)) TRNS_MSG;

typedef struct {
	MSGHEAD header;
	int  ErrorCode;
	char Status;
	char    data[MAXDATA];
}
__attribute__((packed)) GENERAL_MSG_R;
//////////////////////////////////////////

class RequestDataFromCs;
class columnCalculator;
class FlexBetXmlController;
class AmountFunctions;

enum ECSDatamode {eeCSDataNone=0, eeCSDataNormal, eeCSDataApprovalRequired, eeCSDataApproved};

typedef Q3ValueList <int> TMarks;

enum { half1 = A1_BET_OFFSET+12, halfX=A1_BET_OFFSET+13, half2=A1_BET_OFFSET+14, final1=A1_BET_OFFSET, finalX=A1_BET_OFFSET+1, final2=A1_BET_OFFSET+2 };

class FlexBet :public ECoupon
{
	//********************************** IMTS - DBUS Stuff **********************************
	//***************************************************************************************
	Q_OBJECT
	Q_CLASSINFO("D-Bus Interface", "com.intralot.IMTSFlexBet.FlexBetOperations")
	//***************************************************************************************
	//***************************************************************************************

	// Enums stollen from IMTS project. Not the right way of doing it but....
//    enum CouponSource    { UndefinedSource,                /**< Source is undefined */
//                           Camera,                         /**< Source from Camera. */
//                           Scanner,                        /**< Source from Scanner */
//                           GuiQp,                          /**< Source from Gui QP. Fast QP play for example. */
//                           FastPlayGame,                   /**< Source fast play game. Usually the source is MainDesktop's Gui */
//                           QR,                             /**< Source is from QR */
//                           AdditionalGame,                 /**< Source is from Addional Game */
//                           Verbal,                         /**< Source Verbal */
//                           VerbalEdit,                     /**< Source edit request due to user's request by selecting a game in GameProgress list */
//                           VerbalEditDueToCs,              /**< Source edit request due to C/S */
//                           VerbalEditDueToCouponProcessing,/**< Source edit request coming from CPM due to CouponErrors or CostEdit */
//                           RegeneratedTicket,              /**< Source for ticket regeneration process, mostly for ticketRepeat */
//                           eFlexBet,                        /**< Source for ticket iFlex game */
//                           FlexBetCamera,                  /**< Source for ticket iFlex scanned game */
//                           eRaces,                          /**< Source for ticket races game */
//                           RacesCamera,                    /**< Source for ticket races sacenned game */
//                           eParoli,                          /**< Source for ticket paroli game */
//                           ParoliCamera,                    /**< Source for ticket paroli sacenned game */
//                           SportMax,                       /**< Source for ticket Virtual Football game */
//                           SportMaxCamera                  /**< Source for ticket Virtual Football scanned game */
//                         };
	enum CouponSource    { /*  0 */ UndefinedSource,                /**< Source is undefined */
						   /*  1 */ Camera,                         /**< Source from Camera. */
						   /*  2 */ Scanner,                        /**< Source from Scanner */
						   /*  3 */ GuiQp,                          /**< Source from Gui QP. Fast QP play for example. */
						   /*  4 */ FastPlayGame,                   /**< Source fast play game. Usually the source is MainDesktop's Gui */
						   /*  5 */ QR,                             /**< Source is from QR */
						   /*  6 */ AdditionalGame,                 /**< Source is from Addional Game */
						   /*  7 */ Verbal,                         /**< Source Verbal */
						   /*  8 */ VerbalEdit,                     /**< Source edit request due to user's request by selecting a game in GameProgress list */
						   /*  9 */ VerbalEditDueToCs,              /**< Source edit request due to C/S */
						   /* 10 */ VerbalEditDueToCouponProcessing,/**< Source edit request coming from CPM due to CouponErrors or CostEdit */
						   /* 11 */ RegeneratedTicket,              /**< Source for ticket regeneration process, mostly for ticketRepeat */
						   /* 12 */ MiscellaneousGame,              /**< Source Works games' batch */
						   /* 13 */ MiscellaneousGameModified,	    /**< Source Works games' batch modified*/
						   /* 14 */ PromotionTicket,             	/**< Source Promotion manager */
						   /* 15 */ eFlexBet,                        /**< Source for ticket iFlex game */
						   /* 16 */ FlexBetCamera,                  /**< Source for ticket iFlex scanned game */
						   /* 17 */ Races,                          /**< Source for ticket races game */
						   /* 18 */ RacesCamera,                    /**< Source for ticket races sacenned game */
						   /* 19 */ GBIRaces,                       /**< Source for ticket races game */
						   /* 20 */ GBIRacesCamera                  /**< Source for ticket races sacenned game */


						   /*Do not change the order*/
						 };

	enum class EditModesFlag   { NoEdit           = 1 << 0,
								 GuiEditRequest   = 1 << 1,
								 HwEditRequest    = 1 << 2,
								 CSEditRequest    = 1 << 3,
								 OtherEditRequest = 1 << 4,
								 CostEdit         = 1 << 5,
								 AnyEditMode      = GuiEditRequest | HwEditRequest | CSEditRequest | OtherEditRequest | CostEdit
							   };

public:
	FlexBet( QWidget*parent, const char *name=0,CouponRecord *Area=NULL,const char *path=NULL );
	~FlexBet();

	int Action;
	int Stage;
	bool EditScanned;
	unsigned long UpperLimit;
	unsigned long LowerLimit;
	int ExistingCoupons;


	bool m_SessionIsStarted;
	long long m_SessionCardID;

	unsigned long int btotcol[MAX_COUPONS];
	unsigned long int getTotalColumns() { return btotcol[0]; }
	CouponRecord& getCouponRecord(int i) { return CouponRec[i]; }
	EventStruct event[TOT_CPN_AREAS];
	QString BetDescription[TOT_CPN_AREAS];
	int cpnPerm[NUM_O_PERMS];
	int cpnPermMult[NUM_O_PERMS-1];

	int cpnMultiply;
	int sjp_nr;
	int sjpMatches;
	columnCalculator *colCalc;

	void InitCoupon();
	void InitNumbering() ;
	void InitBar();
	int CheckCoupon(int cpn, bool bCheckAmount=false);

	TouchButton *Clear;
	TouchButton *Help; // aste : New button needed for CH
	TouchButton *Finish;
	TouchButton *Exit;

	TouchButton *btnSet;
	TouchButton *btnOther15;
	TouchButton *btnSystemsMultipliers;
//    TouchButton *SjpNums[6];
	TouchButton *btnBetTypeAccept;

	QLabel *IndexLabel[TOT_CPN_AREAS/2];
	QLabel *HeadingLabels[3];
	QLabel *SysLabel;
	QLabel *SysText;
	QLabel *MultLabel;
	QLabel *MultText;
	QLabel *TotalCpnsCostLabel;
	QLabel *TotalCpnsCostText;
	QLabel *DateTimeText;

	//********************************** IMTS - DBUS Stuff **********************************
	//***************************************************************************************
	int setGamesBitmapsPath(const char* path);
	QString homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType;
	FlexBetXmlController* getFlexBetXmlController(){return m_flexBetXmlController;}
	QLabel *CouponCostPerComb; //TOCHECK TO_CHECK TODO TO_DO
	int m_icpnCombinations;
	//***************************************************************************************
	//***************************************************************************************

	bool isWindowActive ();
	bool isDialogOnScreen ();
protected:
	virtual void InformMousePressEvent (QMouseEvent * e);
	bool invokePlayCpn();
	void Get_Updated_Revision ();
	unsigned long getFlexBetDelay(CouponRecord *couponRecord);
	bool prePlaySteps();
	int postPlaySteps(const QByteArray& qbaCsData);
	bool playCoupon();
	void Start();

	void setUpDBusInterface ();
	int nog;
	TRNS_MSG msg;
	GENERAL_MSG_R rep;
	unsigned long playCRC;
	//----
	QList< QByteArray> m_lCoupons;
	QThread processingThread;
	void SetDefaultStake();

private:
	uint m_NumOfTeams;
	unsigned short riga;
	QString m_GameName;
	enum KeyValues {CLEAR=10,DELETE=11};
	CouponsTableViewDialog *CouponsTable;
	CalculatorWidget *calcDial;
    AmountFunctions iFlexCost;
	double getColumnCost() { return iFlexCost.getColumnCost(); }
	unsigned int m_iColumns;
	unsigned int Choice;
	bool ScannedCoupon;
	QString m_EventText;
	CouponInfo coupon;
	bool Edit;
	int thisArea;
	bool first15;	///if true 1-15 screen if false 16-30
	int lastSection[MAX_VERBAL_COUPONS];

	void UpdateSjpNumSelections();
	void ClearSjpNumArray();
	void UpdateBetStruct(int cpn);
	void GroupingAdjustment(unsigned char *storage,unsigned char *std_tbl,unsigned char &count, unsigned char &std_count);
	void GroupingAdjustmentFromRec(TRNS_GM_15000 *trns_gm_15000,unsigned char *storage,unsigned char *std_tbl,unsigned char &count, unsigned char &std_count,int cpn,bool replay=false);
	unsigned int getSystemMultplier(unsigned long s_multiplier, unsigned int uiMultPos);
	unsigned long evaluateRequestRec(int cpn, unsigned char matches,unsigned char standards,long *s_multiplier) ;

	int IsEmptyCoupon(int cpn);
	bool IsStakeMultPos(unsigned int iPos);
	bool IsStakeMarked(int cpn, unsigned int iPos);
	bool IsMultsMarked(int cpn, unsigned int iPos);

	void SetButtonsState();
	bool PreviousCouponExists();
	bool NextCouponExists();
	void UpdateMoney();
	unsigned long CouponColumns(int cpn);
	void UpdateArea();
	int ApplyMarks(int cpn, const QByteArray& qbaCouponData, QString &strError);
	void CalculateLastSect(int coupon);
	void calculateEvent(int cpn);
	void UpdateBetStructM(int cpn);
	void CheckGUICoupon();
	void RecordCoupon(int cpn=0);
	unsigned long evaluateRecordVal(int area);
	unsigned char evaluateRecordFlags(int area);
	double CouponMoney(int cpn);

	inline bool isEmptyArea(int cpn, int area);
	inline int chkLimits(int cpn);
	inline int chkEmptyCpnLoc(int cpn);
	inline unsigned int checkForSameEvent(int cpn);
	inline int chkMultiAlone(int cpn);
	inline int chkPermMult(int cpn);
	inline int chkMoreStake(int cpn);
	inline int chkMoreMulti(int cpn);
	inline int chkEmptyWithStd(int cpn);
	inline int chkAllnSystems(int);
	inline int chkZeroNoStd(int cpn);
	inline int chkLessEvntMarks(int cpn);
	inline int chkMoreEvntMarks(int cpn);
	inline int chkEvntCodeGreater5000(int cpn);
	inline int chkStdNoBet(int cpn);
	inline int chkStdWithoutPerm(int cpn);
	inline int chkReqMore(int, int matches, int standards);
	inline int chkInvalidBet(int cpn);
	inline int chkInvalidEvent(int cpn);
	inline int chckTheGroups(int cpn);
	inline int chkGrpStd(int cpn);
	inline int chkGroupComplete(int cpn);
	int chkAllEventsInOneGroup(int cpn);
	inline int chkZeroSystemAlone(int matches, int standards);
	inline int chkSJPandMatches(int matches);
	inline int chkAmount(int cpn);
	inline int chkSJPandEvents(int cpn);
	inline int chkMorethanOneSJPselections(int cpn);
	inline int chkSJPInvalidBet(int cpn);
	inline int chkSJPandSTD(int cpn);
	inline bool IsEmpty(int cpn,int area);

	void UpdateGame(CouponRecord &CurrentCouponRecord,int cpn);
	int ConvertToPlayReply(CouponRecord &CurrentCouponRecord);
	void MoveLastGameHere(int cpn,int pos);

	bool isTeamCouponsPlay();
	unsigned long CalculateColumns(unsigned char played, unsigned char tot_std, unsigned char req,unsigned char *Dbls, unsigned char *std_tbl);

	/// =================Variables & Procedures for Bet Types and Groups Selection Area ==============================
	CouponRecord betCoupon;
	int recordCode;

	bool EnableInsertBetTypes;

	int betTypeMarksNum;
	int betTypeMarks[MAXIMUM_NBR_BETBUTTONS_COMBINATIONS];
	int betType;
	bool isSpcode;
	int eventCode;

	Q3CanvasPixmapArray *bet_group_pixMark,*Rgroup_pixMark;
	Q3CanvasSprite *tick       [BET_MARKS+R_GRP_MARK+GRP_MARKS]; //as many as the on screen choices
	GraphMarkRecord picBetArray[BET_MARKS+R_GRP_MARK+GRP_MARKS];

	void initTouchAreas();
	void initMark();
	int CountBetTypeMarks(CouponRecord &rec,int area);
	int CountBetTypeMarksSpCol1(CouponRecord &rec,int area);
	int CountBetTypeMarksSpCol2(CouponRecord &rec,int area);
	int CountBetTypeMarksSpCol3(CouponRecord &rec,int area);


	int getRecordCode();
	QString getBetTypeDescription();
	QString getBetTypeTxt();
	QString getBetDescriptionTxt();

	void CheckBetTypesGUI(CouponRecord &rec,int area);
	void UpdateBetTypesAndGroupsArea(CouponRecord &rec,int ValidEventCode,int area);

	int getBetType();
	int isStandard(CouponRecord &rec,int area);
	void calculateBet(CouponRecord &rec,int area);
	void getBetTypeMarks(int *bMarks,int length);
	void setEventCode(QString code);
	void setEventCode(int code);
	void getCouponMarks(CouponRecord &rec,int area,int length);
	void setCouponMarks(CouponRecord &rec,int area,int length);

	void GetEventGroupText(int evtGroup,QString &groupPrnt);
	void GetEventGroupText(int area,QString &groupPrnt,CouponRecord *rec);
	void findGroupText(int area,QString &out);
	void getGroupNumber(int area,bool &random,int &group,CouponRecord *rec);
	bool hasGroup(int area,CouponRecord *rec);
	int getEventID (QString qstrEvent);
	long cnvSysMultBitsToLong (char in_mults);
	bool IsSet(char *buf,int bitpos);
	void ResetBit(char *buf,int bitpos);
	void SetBit(char *buf,int bitpos);
	/// ===========================================================================

	//********************************** IMTS - DBUS Stuff **********************************
	//***************************************************************************************
	FlexBetXmlController* m_flexBetXmlController;
	QPixmap m_PFBet;
	void IMTSConnectionFunctions();
	QByteArray PrintHTMLCoupon (const QVariantMap &mReply,  const CouponRecord &PrintCouponRecord, int &result, const bool  bPendingApproval = false );
	QByteArray PreviewHTMLCoupon(const QByteArray &qbaCsData);
	void DisplayError(QString, QString msg);
	QString formatOdds(uint integral,uint fractional);
	int CombinationsOf( int n, int r);
	int Factorial(int number);
	double getTotalCost ();
	unsigned int getColumns() { return m_iColumns; }
	void setColumns(unsigned int Columns) { m_iColumns=Columns; }
	void LoadTxRxFromFiles();
	bool InsertHtmlFile(QString iFlexHtml, QString strHtml, QString strPosition, QString outputHtml);
	QString FillSpecial(unsigned int i,TRNS_GM_15000 *trns_gm_15000,SEL_DATA_EV_15000 *betData,RTRNS_CD_15000 *repData,QString strOutcomeBlock, bool bApprovalRequired=false);
	QString FillNormal(unsigned int i,TRNS_GM_15000 *trns_gm_15000,SEL_DATA_EV_15000 *betData,RTRNS_CD_15000 *repData,QString strOutcomeBlock, bool bApprovalRequired=false);
	QString getOddNormal(int codeR,RTRNS_CD_15000 *repData);
	QString getOddSpecial(RTRNS_CD_15000 *repData);
	QString getHandicapNormal(int codeR,RTRNS_CD_15000 *repData,bool bApprovalRequired=false);
	QString getGroupStr(unsigned long val_flg, bool bApprovalRequired=false);
	void FillSystems(QVariantMap &mPrintData,TRNS_GM_15000 *trns_gm_15000, ulong trns_cpn_hdr_data0, ulong reply_100_1_data1, bool bApprovalRequired=false);
	QString getGroupHtmlStr(QString strFile);
	void PrintApprovalNumber(QVariantMap &mPrintData,ulong css_it_1_res, ulong css_it_1_data, ulong trns_gm_15000_app, bool bPendingApproval);
	void ShowMarksTableMapping();
	void ShowFlexBetData();
	//***************************************************************************************
	//***************************************************************************************
	volatile bool m_bDelaying;
	void getMonth(QDateTime *CurDate,QString & month);
	void getDay(QDateTime *CurDate,QString & day);

public Q_SLOTS:

	/**
	 * @sa printerPaperRollReplacementInProgress
	 */
	Q_NOREPLY void printerPaperRollReplacementInProgress ( const bool );

	Q_NOREPLY void processCameraDataSlot(const QByteArray &qbaCameraData); //, const int iCouponId);

	QString consumeCsReplySlot ( const QByteArray qbaCouponData, const QVariantMap qvmGuiData );
	Q_NOREPLY void couponEditRequestSlot (const QByteArray qbaCouponData, const int iCouponId, const int iEditMode );

	Q_NOREPLY void exitService (const QString);
	Q_NOREPLY void wakeUpService (const QString);

	void DownloadTeams();

private slots:
	// needs to be updated. basically this will be executed when CouponProcess sends us data.
	void changeSelections ( int row,int col );
	void calcValueChanged(int keyPressed);
	void setCouponPressed();
	void SystemsMultsCouponPressed();
	void BetTypeAcceptPressed();
	void ClearPressed();
	void FinishPressed();
	void HelpPressed(); // aste : Handler method for when the Help button is pressed
	void OtherSgn();
	void showDateTime();

	void SwitchBetFiles(bool bIsTraining);
private:
	void timerEvent(QTimerEvent *event);
	bool initCsTxData (CouponRecord &CurrentCouponRecord, ECSDatamode ecsDataMode=eeCSDataNormal);
	void SendData(bool bIsHighStake  = false);
	void SendDataSim(bool bIsHighStake  = false);
	void SendDataOnline(bool bIsHighStake  = false);
	QString processCsData (const QVariantMap& qvmCsReply, const int& iReplyCode );
	//QEventLoop m_betDelayLoop;

	RequestDataFromCs* m_pcRequestDataFromCs;
	qint32 m_iTimerId;
	FlexBetTxData m_flexBetData;
	int m_iVoidAreas;
	QProgressDialog* m_pcProgressDialog;
	bool m_bPrinterRollReplacementInProgress;
	bool proceedDueToCouponCost(const double &dCouponCost);
	bool proceedWithEdit (const QString& qsMessage );
	void startPleaseWait ( const QString& qsPleaseWaitText );
	void endPleaseWait ();
	bool checkPrinter ();
	int CouponOriginFromScanner;
	void finalizeReceipt (const QVariantMap &mReply, CSS_IT_1 *css_it_1, REPLY_100_1 *reply_100_1, QVariantMap& mHtmlData, bool bApprovalRequired, bool bPendingApproval, bool bTraining = false );
	void addPlayTransactionToCustomerSession (const quint32& iTransactionNo, const QString& qsBarcode, const QString& qsIsecure, QString qsSavedPlayFile , const double dAmount);
	bool SjpNumSelected[6];
	//********************************** IMTS - DBUS Stuff **********************************
	//***************************************************************************************
	void ConvertDoubleToAMOUNTSTRC(double Input,AMOUNT_STRC *Output);
	void GuiTranslations();
	void LoadBetslip();
	QString getEventDescription(QString homeDescr, QString visitorDescr, unsigned char sjp_nr, int uiMaxLen=0);
	//***************************************************************************************
	//***************************************************************************************
	CouponSource m_eSource;
	unsigned int m_iCouponId;
	bool GetNextCoupon();
	QString getError2Display(const QVariantMap qvmCsReply, const QString strOther);
	void Show1stAreaPlayslipMapping();
	unsigned int CouponToMarks_c3[PLAYLSIP_0135_LENGTH];
	unsigned int CouponToMarks_c4[PLAYLSIP_01AD_LENGTH];
	unsigned int CouponToMarks_c5[PLAYLSIP_0373_LENGTH];
//    void PopulatePlayslipMapping0135();
//    void PopulatePlayslipMapping01AD();
//    void PopulatePlayslipMapping0373();
	bool ValidPlayslipSelections(unsigned int uiRiga, QString &strError);
	QMap<unsigned int, TMarks > m_MultipleMarks;
	void MapMultipleMarks();
	unsigned int getTriples();

	bool m_bIsWindowActive;
	bool m_bIsDialogActive;

public slots:
	int ShowForm();
	void HideForm();
	void ExitPressed();
	int Play(int stage,int action);
	void playHighStakeSlot(const QByteArray& qbaCsData, const uint ApprovalNbr);
	void hideWindowSlot ();
	QByteArray highStakePreviewSlot(const QByteArray& qbaCsData );
	bool CheckActiveDraw(bool asynchronous_mode,bool downloadActiveDrawFile,uint replyDraw=0,uint replyLiveRevision=0,uint replyPreGameRevision=0);
	void sendCameraDataSlot ( const QByteArray& qbaCameraData );
	void sjpnumPressed();

signals:
	void sgnFailure(int);
	void sgnSuccess(int);
	void sgnCheckActiveDraw(bool,bool,uint,uint,uint);
};

#endif
