#include "FlexBet.h"
#include <qeventloop.h>
#include <qdir.h>
#include <wait.h>
#include <math.h>
#include <iostream>
#include <qstring.h>
#if defined IMTS_ARM
#include "IMTS/libilotfb.h"
#endif

#include <Q3TextStream>
#include <Q3Frame>
#include <QMouseEvent>
#include "AmountFunctions.h"

using namespace std;
#include <wait.h>
#include "dlgSystemsMults.h"
#include "columnCalculator.h"
#include "BetReplyHandling.h"
#include "CommonDefinitions.h"

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************
#include "IMTS/FlexBetTxData.h"
#include "SystemWideConstValues.h"
#include "RequestDataFromCs.h"
#include "JsonOperations.h"
#include "IMTS/CustomerSessionTrnsData.h"
#include "PlaceServerManagerRequest.h"
#include "ClientServerDefinitions.h"
#include "BarcodeUtilities/BarcodeUtilities.h"
#include "LocalEventLoggerEvents.h"
#include "DbusWrapper.h"
#include "FlexBetOperations_adaptor.h"
#include "ProjectApp.h"
#include "GetConfigValue.h"
//#include <QElapsedTimer>
extern ProjectApp *m_pApp;
//***************************************************************************************
//***************************************************************************************

extern QPixmap m_PFBet;
extern char g_bet_err_txt[256];
extern int bet_error(int err_code, int hint);
extern long int CheckSystemValid(int);

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************

//***************************************************************************************
//***************************************************************************************
#ifdef IMTS_ARM
static char *  fg_fb =  "/dev/fb1";
#endif
FlexBet::FlexBet( QWidget *parent, const char *name,CouponRecord *Area,const char *path ):ECoupon ( parent,name,Area,path )
{
	m_GameName = qApp->translate("FlexBet","BET");

	UpperLimit=ULONG_MAX;
	LowerLimit = 0;

	thisArea=0;
	CurrentCoupon=0;
	memset(&betCoupon,0,sizeof(CouponRecord));
	memset(Area,0,sizeof(CouponRecord));
	memset(&CouponRec[CurrentCoupon],0,sizeof(CouponRecord));
	setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

	first15=true;
	memset(&cpnPerm[0],0,sizeof(cpnPerm));
	cpnMultiply=1;
	sjp_nr=0;
	sjpMatches=0;
	EnableInsertBetTypes=false;

	colCalc = new columnCalculator();

	iFlexCost.SetColumnCostsFolder(COLUMN_PRICES_FOLDER);
	iFlexCost.setColumnCost(DEFAULT_STAKE); //a default one
	//iFlexCost.GetFileColumnCost(IFLEX_GAMECODE);
	//qDebug("Working with columnCost = %0.2f",getColumnCost());

	ScannedCoupon=false;
	Edit=false;
	CouponsTable = new CouponsTableViewDialog(this);
	ClearSjpNumArray();
	//********************************** IMTS - DBUS Stuff **********************************
	//***************************************************************************************
	IMTSConnectionFunctions();
	//***************************************************************************************
	//***************************************************************************************
	Clear=NULL;
	Help = NULL;
	Finish=NULL;
	Exit=NULL;

	btnSet=NULL;
	btnOther15=NULL;
	btnSystemsMultipliers=NULL;
	btnBetTypeAccept=NULL;

	SysLabel=NULL;
	SysText=NULL;
	MultLabel=NULL;
	MultText=NULL;
	TotalCpnsCostLabel=NULL;
	TotalCpnsCostText=NULL;
    DateTimeText=NULL;

	for (int i=0; i<TOT_CPN_AREAS/2; i++)
		IndexLabel[i]=NULL;

	for (int i = 0; i < 3; i++)
		HeadingLabels[i] = NULL;

	p_canvas->setBackgroundPixmap(m_PFBet);
	InitCoupon();
	InitNumbering();
	initTouchAreas();
	initMark();
//    ShowMarksTableMapping();

	m_eSource = CouponSource::Verbal;
	m_iCouponId = 0;
	m_bDelaying = false;
//    if(!QDir("/root/IMTSDev/IMTSResources/LinkToYourProject").exists())
//    {
//        qDebug("WARINIG: /root/IMTSDev/IMTSResources/LinkToYourProject does not exist");
//    }
	//Show1stAreaPlayslipMapping();
//    PopulatePlayslipMapping0135();
//    PopulatePlayslipMapping01AD();
//    PopulatePlayslipMapping0373();
//    MapMultipleMarks();

	m_bIsDialogActive = false;
	HideForm ();

}

FlexBet::~FlexBet()
{
	if( colCalc )
	delete colCalc;

	if( CouponsTable )
		delete CouponsTable;

	for (int i=0; i<TOT_CPN_AREAS/2; i++)
	{
		if( IndexLabel[i] )
			delete  IndexLabel[i];
	}

	for (int i = 0; i < 3; i++)
	{
		if (HeadingLabels[i])
			delete HeadingLabels[i];
	}

	if (SysLabel)
		delete SysLabel;

	if (SysText)
		delete SysText;

	if (MultLabel)
		delete MultLabel;

	if (MultText)
		delete MultText;

	if (TotalCpnsCostLabel)
		delete TotalCpnsCostLabel;

	if (TotalCpnsCostText)
		delete TotalCpnsCostText;

    if (DateTimeText)
        delete DateTimeText;

	for (int i=0; i<BET_MARKS+R_GRP_MARK+GRP_MARKS; i++)
	{
		if (tick[i])
			delete tick[i];
	}
	if (bet_group_pixMark)
		delete bet_group_pixMark;

	if (Rgroup_pixMark)
		delete Rgroup_pixMark;
}

/**
   This procedure updates the events' table with the up-to-date information of the selected events
**/
void  FlexBet::CheckGUICoupon()
{
	for (int i=0; i<MAX_VERBAL_COUPONS; i++)
		CouponsTable->CouponsList[i].clear();

	CalculateLastSect(CurrentCoupon);

	for (int i=0; i<lastSection[CurrentCoupon]+1; i++)
	{
		if(sjp_nr)
			coupon.event=QString("%1%2").arg(tr("SJP")).arg(sjp_nr);
		else if (event[i].choice>=0)
		{
			QString group = QString("");
			if (event[i].random || event[i].group)
			{
				findGroupText(i,group);
			}
			coupon.group=group;
			coupon.std=QString("");
			if (event[i].standard)
			{
				coupon.std=QString("#");
			}

		coupon.event=coupon.std + coupon.group + QString("%1").arg(event[i].choice);
		}
		else
		{
			coupon.event=QString("--");
		}
		coupon.bet=QString("%1").arg(BetDescription[i]);
		CouponsTable->CouponsList[CurrentCoupon].append(coupon);
	}

	int allRows = CouponsTable->CouponsList[CurrentCoupon].count();
	if (allRows)
		CouponsTable->DisplayCouponsData(CurrentCoupon);

	if (allRows<TOT_CPN_AREAS)
	{
		CouponsTable->m_CouponsTable->setCurrentCell(CouponsTable->CouponsList[CurrentCoupon].count(),0);
		CouponsTable->m_CouponsTable->drawRow(CouponsTable->CouponsList[CurrentCoupon].count(),QColor ( "white" ),QColor ( "blue" ));
	}
	//======================
	first15=true;
	btnOther15->SetPixmapText(m_pApp->getGamesBitmapsPath()+"buttons/buttonsB/btnCodes1630");
	btnOther15->update();
	for (int i=0; i<TOT_CPN_AREAS/2; i++)
		IndexLabel[i]->setText(QString("%1").arg(i+1));

	CouponsTable->m_CouponsTable->setPage(0);
	btnOther15->setEnabled(((CouponsTable->CouponsList[CurrentCoupon].count())>=ROWS_PER_PAGE)?true:false);

	//======================
}

void FlexBet::HideForm()
{
	DbusWrapper::getWindowManagerInterface ()->unregisterWindowApplicationSlot (   "com.intralot.IMTSFlexBet",
																				   "/FlexBetOperations" );
	ClearPressed();
#ifdef IMTS_LINUX
	hide();
#else
	// hide /dev/fb/1
	m_bIsWindowActive = false;
	static QScopedPointer<QDBusInterface> mainDesktopDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSMainDesktop"), QLatin1String("/DesktopOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
	mainDesktopDbusInterface.data ()->setProperty ("windowActive",true);
	switch_fbs(fg_fb,1);
#endif
}


int FlexBet::ShowForm()
{
	DbusWrapper::getWindowManagerInterface ()->registerWindowApplicationSlot (   "com.intralot.IMTSFlexBet", "/FlexBetOperations" );

	p_canvas->setBackgroundPixmap(m_PFBet);

	//LoadBetslip(); //load prestored betslip ///tmp/coupon.dat

	if (EditScanned){

		UpdateGame(CouponRec[0],CurrentCoupon);
		CheckGUICoupon();
	}
	else {
		m_eSource = CouponSource::eFlexBet;
		m_iCouponId = 0;
		ClearPressed();
	}

	SetDefaultStake();
	UpdateArea();
	UpdateMoney();
	SetButtonsState();
	UpdateSjpNumSelections();

	setAttribute (Qt::WA_AcceptTouchEvents);
	setFocus ();
	showNormal ();
	activateWindow ();

#ifdef IMTS_ARM
	QByteArray qbaTest = qgetenv("DBUS_SESSION_BUS_ADDRESS");
	printf("DBUS_SESSION_BUS_ADDRESS = %s\n", qbaTest.data());
	static QScopedPointer<QDBusInterface> mainDesktopDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSMainDesktop"), QLatin1String("/DesktopOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
	bool result = mainDesktopDbusInterface.data ()->setProperty ("windowActive",false);
	printf("Setting windowActive to false %s!\n", result?"successful":"failed");
	switch_fbs(fg_fb, 0); // show /dev/fb/1
	qApp->processEvents(); // consume the event has mouse pressed may arrive after the dbus message
	m_bIsWindowActive = true;
#endif

	return 1;
}

void FlexBet::InitCoupon()
{
	char fname[1024]= {0};
	char fname1[1024]= {0};

	this->resize(1024,768);
	this->setMinimumSize(0,0);


	CouponsTable->setBackgroundPixmap(m_PFBet);
	CouponsTable->setGeometry ( QRect( 32, 101, 402, 359 ));
	CouponsTable->setBackgroundOrigin(QFrame::ParentOrigin);
	connect (CouponsTable,SIGNAL(rowPressed(int,int)),this,SLOT (changeSelections(int,int)));
	CouponsTable->m_CouponsTable->drawRow(CouponsTable->CouponsList[CurrentCoupon].count(),QColor ( "white" ),QColor ( "blue" ));

	calcDial=new CalculatorWidget(this);
	calcDial->move(711,68);
	calcDial->setBackgroundPixmap(m_PFBet);
	calcDial->setBackgroundOrigin(QFrame::ParentOrigin);
	connect(calcDial,SIGNAL(CalcChanged(int)),this,SLOT(calcValueChanged(int)));

	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk110x50.png");
	QBitmap ButtonMaskDraws(fname);
	btnSet= new TouchButton ( this,"NoName" );
	btnSet->setGeometry ( 809, 400, 110, 50 );
	btnSet->setMinimumSize ( 0,0 );
	btnSet->SetPixmapText (m_pApp->getGamesBitmapsPath() + "buttons/buttonsB/btnSet");
	btnSet->isCustomDraw=true;
	btnSet->setMask ( ButtonMaskDraws );
	connect(btnSet,SIGNAL(pressed()),SLOT(setCouponPressed()));
	btnSet->setEnabled(false);

	sprintf(fname1,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk110x70.png");
	QBitmap ButtonMask1(fname1);
	btnOther15 = new TouchButton(this,"NoName");
	btnOther15->setGeometry(518, 111, 110, 70);
	btnOther15->setMinimumSize(0, 0);
	btnOther15->setFocusPolicy(Qt::NoFocus);
	btnOther15->isCustomDraw = true;
	btnOther15->SetPixmapText(m_pApp->getGamesBitmapsPath() +"buttons/buttonsB/btnCodes1630" );
	btnOther15->setEnabled(false);
	btnOther15->setMask ( ButtonMask1 );
	connect(btnOther15, SIGNAL(pressed()),SLOT(OtherSgn()));

	btnSystemsMultipliers= new TouchButton ( this,"NoName" );
	btnSystemsMultipliers->setGeometry ( 518, 205, 110, 70 );
	btnSystemsMultipliers->setMinimumSize ( 0, 0 );
	btnSystemsMultipliers->SetPixmapText (m_pApp->getGamesBitmapsPath() + "buttons/buttonsB/btnSystems");
	btnSystemsMultipliers->isCustomDraw=true;
	btnSystemsMultipliers->setMask ( ButtonMask1 );
	connect(btnSystemsMultipliers,SIGNAL(pressed()),SLOT(SystemsMultsCouponPressed()));

	sprintf(fname1,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"Masks/mask66x135.png");
	QBitmap ButtonMask2(fname1);
	btnBetTypeAccept= new TouchButton ( this,"NoName" );
	btnBetTypeAccept->setGeometry ( 468, 394, 207, 64 );
	btnBetTypeAccept->setMinimumSize ( 0,0 );
	btnBetTypeAccept->SetPixmapText (m_pApp->getGamesBitmapsPath() + "buttons/buttonsB/btnAcceptBetB");
	btnBetTypeAccept->isCustomDraw=true;
	btnBetTypeAccept->setMask ( ButtonMask2 );
	btnBetTypeAccept->setEnabled(false);
	connect(btnBetTypeAccept,SIGNAL(pressed()),SLOT(BetTypeAcceptPressed()));

	//=========SJP============================
	QBitmap bmpMask(m_pApp->getGamesBitmapsPath()+QString("Masks/mask66x65.png"));
//    int x,y,dx,dy;
//    int StartX=441;
//    int StartY=115;
//    dx = 74;
//    dy = 70;
//    x = StartX;
//    y = StartY;

//    for (int i = 0; i < 6; i++)
//    {
//        SjpNums[i] = new TouchButton(this,"");

//        SjpNums[i]->setGeometry(x,y,66,65);

//        SjpNums[i]->setFocusPolicy(Qt::NoFocus);
//        SjpNums[i]->setMask(bmpMask);
//        connect(SjpNums[i],SIGNAL(pressed()),SLOT(sjpnumPressed()));

//        if(i==2)
//        {
//            x = StartX;
//            y+=dy;
//        }
//        else
//        {
//            x+=dx;
//        }

//        //SjpNums[i-1]->hide(); //DISABLE
//    }

	UpdateSjpNumSelections();
   //==========================================

	InitBar();

	bet_group_pixMark = NULL;
	bet_group_pixMark=new Q3CanvasPixmapArray();
//	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"tick.png");
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"selections/Selection.png");
	bet_group_pixMark->readPixmaps(fname,1);

	Rgroup_pixMark = NULL;
	Rgroup_pixMark=new Q3CanvasPixmapArray();
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"TickR.png");
	Rgroup_pixMark->readPixmaps(fname,1);

	for (int i=0; i<BET_MARKS; i++)
	{
		tick[i] = NULL;
		tick[i]=new Q3CanvasSprite(bet_group_pixMark,p_canvas);
	}

	for (int i=BET_MARKS; i<BET_MARKS+R_GRP_MARK; i++)
	{
		tick[i] = NULL;
		tick[i]=new Q3CanvasSprite(Rgroup_pixMark,p_canvas);
	}

	for (int i=BET_MARKS+R_GRP_MARK; i<BET_MARKS+R_GRP_MARK+GRP_MARKS; i++)
	{
		tick[i] = NULL;
		tick[i]=new Q3CanvasSprite(bet_group_pixMark,p_canvas);
	}

	ScannedCoupon=false;
}

void FlexBet::sjpnumPressed(){
//int i,matchesNum=0;

////if (IsEmptyCoupon(CurrentCoupon)!=1)
////	return;

//CouponsTable->CouponsList[CurrentCoupon].clear();
//QString SJPLabel="";
//    for (i = 0; i < 6; i++)
//            if (((TouchButton*)sender()) == SjpNums[i])
//        {
//            SjpNumSelected[i]=SjpNumSelected[i]?false:true;
//            if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]==1)
//            {
//                for(int j=0;j<NUM_O_SJP;j++)
//                    CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+j]=0;
//                CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]=0;
//            }
//            else
//            {
//                for(int j=0;j<NUM_O_SJP;j++)
//                    CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+j]=0;
//                CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]=1;
//            }

//            if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]==1)
//            {
//                SJPLabel=QString("%1%2").arg(tr("SJP")).arg(i+1);
//                matchesNum=15;//matchesNum=i+10;
//            }
//            else
//            {
//                matchesNum=0;

//            }
//                    break;
//        }

//    for (i = 0; i < matchesNum; i++)
//    {
//        coupon.event=SJPLabel;
//        coupon.bet="";
//        CouponsTable->CouponsList[CurrentCoupon].append(coupon);

//    }


//        CouponsTable->DisplayCouponsData(CurrentCoupon);
//    if(matchesNum==0)
//            CouponsTable->m_CouponsTable->drawRow(0,QColor ( "white" ),QColor ( "blue" ));
//    UpdateSjpNumSelections();
//    ScannedCoupon=false;
//    SetButtonsState();
//    UpdateArea();
//    UpdateMoney();

}

void FlexBet::UpdateSjpNumSelections()
{
//    for (int i = 0; i < 6; i++)
//    {
//        if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]==1)
//            SjpNums[i]->SetPixmapText(m_pApp->getGamesBitmapsPath()+QString("SjpNums/%1Btnm").arg(i+1));
//        else
//            SjpNums[i]->SetPixmapText(m_pApp->getGamesBitmapsPath()+QString("SjpNums/%1Btn").arg(i+1));

//        SjpNums[i]->update();
//    }
}

void FlexBet::ClearSjpNumArray()
{
	for(int i=0; i<NUM_O_SJP;i++)
	{
			SjpNumSelected[i]=false;
		//CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]=0;
	}

}

/**
	This procedure displays the numbering of the events' table
**/
void FlexBet::InitNumbering()
{
	QFont h("Arial",12,QFont::Bold);
	QPalette lblPal;
	lblPal.setColor (QColorGroup::Foreground, QColor (Qt::black));

	int dy=24;

	// Create the text labels for the heading
	// 1st column (#)
	HeadingLabels[0] = new QLabel(this,"Index");
	HeadingLabels[0]->setGeometry(7, 75 /*99 - 24*/, 24, dy);
	HeadingLabels[0]->setBackgroundOrigin(ParentOrigin);
	HeadingLabels[0]->setBackgroundPixmap(QPixmap(m_PFBet));
	HeadingLabels[0]->setPalette(lblPal);
	HeadingLabels[0]->setFont(h);
	HeadingLabels[0]->setText(QString("#"));
	HeadingLabels[0]->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);
	// 2nd column (Event)
	HeadingLabels[1] = new QLabel(this,"Index");
	HeadingLabels[1]->setGeometry(31 /*7 + 24*/, 75 /*99 - 24*/, 200, dy);
	HeadingLabels[1]->setBackgroundOrigin(ParentOrigin);
	HeadingLabels[1]->setBackgroundPixmap(QPixmap(m_PFBet));
	HeadingLabels[1]->setPalette(lblPal);
	HeadingLabels[1]->setFont(h);
	HeadingLabels[1]->setText(QString("Event")); // TO DO: Invoke translator ?
	HeadingLabels[1]->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);
	// 3rd column (Bet)
	HeadingLabels[2] = new QLabel(this,"Index");
	HeadingLabels[2]->setGeometry(231 /* 31 + 200*/, 75 /*99 - 24*/, 202, dy);
	HeadingLabels[2]->setBackgroundOrigin(ParentOrigin);
	HeadingLabels[2]->setBackgroundPixmap(QPixmap(m_PFBet));
	HeadingLabels[2]->setPalette(lblPal);
	HeadingLabels[2]->setFont(h);
	HeadingLabels[2]->setText(QString("Bet")); // TO DO: Invoke translator ?
	HeadingLabels[2]->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);

	for (int i=0; i<TOT_CPN_AREAS/2; i++)
	{
		IndexLabel[i]=new QLabel(this,"Index");
		IndexLabel[i]->setGeometry(7,99+i*dy,24,dy);
		IndexLabel[i]->setBackgroundOrigin(ParentOrigin);
		IndexLabel[i]->setBackgroundPixmap(QPixmap(m_PFBet));
		IndexLabel[i]->setPalette(lblPal);
		IndexLabel[i]->setFont(h);
		IndexLabel[i]->setText(QString("%1").arg(i+1).rightJustify(2,' '));
		IndexLabel[i]->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);
	}
}

/**
	When the button 0->15 or 16->30 is pressed
**/
void FlexBet::OtherSgn()
{
	if (first15)
	{
		first15=false;
		memset(&betCoupon,0,sizeof(CouponRecord));
		setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

		btnOther15->SetPixmapText(m_pApp->getGamesBitmapsPath()+"buttons/buttonsB/btnCodes0115");
		btnOther15->update();
		for (int i=0; i<TOT_CPN_AREAS/2; i++)
			IndexLabel[i]->setText(QString("%1").arg(i+16).rightJustify(2,' '));
		CouponsTable->m_CouponsTable->setPage(1);
	}
	else
	{
		first15=true;
		memset(&betCoupon,0,sizeof(CouponRecord));
		setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

		btnOther15->SetPixmapText(m_pApp->getGamesBitmapsPath()+"buttons/buttonsB/btnCodes1630");
		btnOther15->update();
		for (int i=0; i<TOT_CPN_AREAS/2; i++)
			IndexLabel[i]->setText(QString("%1").arg(i+1).rightJustify(2,' '));

		CouponsTable->m_CouponsTable->setPage(0);
	}
}

void FlexBet::showDateTime()
{
    QDateTime qdtNow = QDateTime::currentDateTime();
    QString qsDate = qdtNow.date().toString(Qt::DefaultLocaleLongDate);

//    qdtNow.setTimeSpec(Qt::LocalTime);
//    DateTimeText->setText(QDateTime::currentDateTime().toString("dddd, MMMM d, yyyy hh:mm:ss"));
    DateTimeText->setText(qsDate.append (QString(" %1").arg (qdtNow.toString ("hh:mm:ss")) ));
}

void FlexBet::InitBar()
{
	char fname[1024];

	QFont labelFont("Arial",10);

//	QFont h("Arial",12);

	// Buttons
	Clear=new TouchButton(this,"Clear");
	Clear->setGeometry(534,698,100,55);
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk100x55.png");
	Clear->setMask(QBitmap(fname));
	Clear->isCustomDraw=true;
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/buttonsB/btnClear");
	Clear->SetPixmapText(fname);
	Clear->show();

	Help=new TouchButton(this,"Help");
	Help->setGeometry(653,698,100,55);
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk100x55.png");
	Help->setMask(QBitmap(fname));
	Help->isCustomDraw=true;
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/buttonsB/btnHelp");
	Help->SetPixmapText(fname);
	Help->show();

	Exit=new TouchButton(this,"Exit");
	Exit->setGeometry(772,698,100,55);
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk100x55.png");
	Exit->setMask(QBitmap(fname));
	Exit->isCustomDraw=true;
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/buttonsB/btnExit");
	Exit->SetPixmapText(fname);
	Exit->show();

	Finish=new TouchButton(this,"");
	Finish->setGeometry(891,698,100,55);
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/msk100x55.png");
	Finish->setMask(QBitmap(fname));
	Finish->isCustomDraw=true;
	sprintf(fname,"%s%s",m_pApp->getGamesBitmapsPath().ascii(),"buttons/buttonsB/btnSend");
	Finish->SetPixmapText(fname);
	Finish->show();
	// Buttons

	int offsetLabelX = 35, offsetTextX = 110, offsetY = 688;
	int textWidth = 120, textHeight = 15;

	// Label & text field for the Systems
	SysLabel = new QLabel(this,"sysLabel");
	SysLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
	SysLabel->setLineWidth(0);
	SysLabel->setIndent(4);
	SysLabel->setFont(labelFont);
	SysLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
	SysLabel->setAutoFillBackground( true );
	SysLabel->setBackgroundColor(QColor(255,255,255));
	SysLabel->setPaletteForegroundColor(Qt::black);
	SysLabel->setGeometry(offsetLabelX, offsetY, offsetTextX, 3 * textHeight);
	SysLabel->setText(QString("Systems"));

	SysText=new QLabel(this,"SysText");
	SysText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
	SysText->setLineWidth(0);
	SysText->setIndent(4);
	SysText->setFont(labelFont);
	//SysText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
	SysText->setAlignment(Qt::AlignRight|Qt::AlignTop);
	SysText->setAutoFillBackground( true );
	SysText->setBackgroundColor(QColor(255,255,255));
	SysText->setPaletteForegroundColor(Qt::black);
//	SysText->move(150,678);
//	SysText->resize(135,51);
//    SysText->setGeometry(150, 678, 135, 51);
	SysText->setGeometry(offsetLabelX + offsetTextX, offsetY, textWidth, 3 * textHeight);
	SysText->setWordWrap(true);
	// Label & text field for the Systems

	// Label & text field for the Total Columns
	MultLabel = new QLabel(this,"multLabel");
	MultLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
	MultLabel->setLineWidth(0);
	MultLabel->setIndent(4);
	MultLabel->setFont(labelFont);
	MultLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
	MultLabel->setAutoFillBackground( true );
	MultLabel->setBackgroundColor(QColor(255,255,255));
	MultLabel->setPaletteForegroundColor(Qt::black);
	MultLabel->setGeometry(offsetLabelX, offsetY + 3 * textHeight, offsetTextX, textHeight);
	MultLabel->setText(QString("Total Columns"));

	MultText=new QLabel(this,"MultText");
	MultText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
	MultText->setLineWidth(0);
	MultText->setIndent(4);
	MultText->setFont(labelFont);
	MultText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
	MultText->setAutoFillBackground( true );
	MultText->setBackgroundColor(QColor(255,255,255));
	MultText->setPaletteForegroundColor(Qt::black);
//    MultText->setGeometry(150,728,135,17);
	MultText->setGeometry(offsetLabelX + offsetTextX, offsetY + 3 * textHeight, textWidth, textHeight);
	// Label & text field for the Total Columns

	// Label & text field for the Total Cost
	TotalCpnsCostLabel = new QLabel(this,"totalCostLabel");
	TotalCpnsCostLabel->setFrameStyle( QFrame::Panel | QFrame::Sunken );
	TotalCpnsCostLabel->setLineWidth(0);
	TotalCpnsCostLabel->setIndent(4);
	TotalCpnsCostLabel->setFont(labelFont);
	TotalCpnsCostLabel->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
	TotalCpnsCostLabel->setAutoFillBackground( true );
	TotalCpnsCostLabel->setBackgroundColor(QColor(255,255,255));
	TotalCpnsCostLabel->setPaletteForegroundColor(Qt::black);
	TotalCpnsCostLabel->setGeometry(offsetLabelX, offsetY + 4 * textHeight, offsetTextX, textHeight);
	TotalCpnsCostLabel->setText(QString("Total Cost"));

	TotalCpnsCostText = new QLabel(this,"");
	TotalCpnsCostText->setFrameStyle( Q3Frame::Panel | Q3Frame::Sunken );
	TotalCpnsCostText->setLineWidth(0);
	TotalCpnsCostText->setIndent(4);
	TotalCpnsCostText->setFont(labelFont);
//    TotalCpnsCostText->setGeometry(150,746,135,16);
	TotalCpnsCostText->setGeometry(offsetLabelX + offsetTextX, offsetY + 4 * textHeight, textWidth, textHeight);
	TotalCpnsCostText->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
	TotalCpnsCostText->setText(QString("--"));
	TotalCpnsCostText->setAutoFillBackground( true );
	TotalCpnsCostText->setBackgroundColor(QColor(255,255,255));
	TotalCpnsCostText->setPaletteForegroundColor(Qt::black);
	TotalCpnsCostText->show();
	// Label & text field for the Total Cost

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(showDateTime()));
    timer->start(1000);

    DateTimeText = new QLabel(this,"dateTimeText");
//    DateTimeText->setFrameStyle( QFrame::Panel | QFrame::Sunken );
//    DateTimeText->setLineWidth(0);
//    DateTimeText->setIndent(4);
    DateTimeText->setFont(QFont("Roboto",11));
    DateTimeText->setAlignment(Qt::AlignCenter|Qt::AlignVCenter);
    DateTimeText->setAutoFillBackground( true );
    DateTimeText->setBackgroundColor(QColor(255, 140, 0));
    DateTimeText->setPaletteForegroundColor(Qt::white);
    DateTimeText->setGeometry(368, 1, 300, 32);
    showDateTime();

	connect(Exit,SIGNAL(pressed()),SLOT(ExitPressed()));
	connect(Help,SIGNAL(pressed()),SLOT(HelpPressed()));
	connect(Clear,SIGNAL(pressed()),SLOT(ClearPressed()));
	connect(Finish,SIGNAL(pressed()),SLOT(FinishPressed()));
}

/**
	Clears the current coupon
**/
void FlexBet::ClearPressed()
{
	/*When clear is pressed the current coupon should be deleted*/
	memset(&CouponRec[CurrentCoupon],0x00,sizeof(CouponRecord));

	CouponsTable->CouponsList[CurrentCoupon].clear();
	CouponsTable->RemoveCouponsData(CurrentCoupon);
	RemoveCoupon(CurrentCoupon);

	/*The current working area is set to 0*/
	thisArea=0;
	memset(&betCoupon,0,sizeof(CouponRecord));
	setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);


	CouponsTable->DisplayCouponsData(CurrentCoupon);
	CouponsTable->m_CouponsTable->drawRow(CouponsTable->CouponsList[CurrentCoupon].count(),QColor ( "white" ),QColor ( "blue" ));
	coupon.event="";
	coupon.bet="";
	Edit=false;
	m_EventText="";
	//==============
	first15=true;
	btnOther15->SetPixmapText(m_pApp->getGamesBitmapsPath()+"buttons/buttonsB/btnCodes1630");
	btnOther15->update();
	for (int i=0; i<TOT_CPN_AREAS/2; i++)
	{
		if( IndexLabel[i] )
			IndexLabel[i]->setText(QString("%1").arg(i+1).rightJustify(2,' '));
	}
	CouponsTable->m_CouponsTable->setPage(0);
	btnOther15->setEnabled(false);
	//================
	UpdateBetTypesAndGroupsArea(betCoupon,0,thisArea);
	EnableInsertBetTypes = false;

	UpdateBetStruct(CurrentCoupon);
	UpdateArea();
	UpdateMoney();
	SetButtonsState();
	EditScanned=false;
	UpdateSjpNumSelections();
}

/**
	This procedure is called when the finish button is pressed. It checks the coupon
	and creates the record with the coupon's info in order to send it to the CSS
**/
void FlexBet::FinishPressed()
{
//    for (int i = 0; i < CompletedCoupons+1; i++)
//    {
		if (IsEmptyCoupon(0))
		{
			ClearPressed();
			ExitPressed();
			return;
		}
//    }

	SendData();
	processingThread.exit();
}

void FlexBet::ExitPressed()
{
	bool dontAsk = true;
	for (int i = 0; i < CompletedCoupons+1; i++)
		if (!IsEmptyCoupon(i))
			dontAsk = false;

	CoronisMessageBox msb(this);
	msb.SetButtons(true,true,false);
	msb.SetTitle(tr("Warning"));
	msb.SetContents(tr("Exiting\n will clear\nall coupons"));
	if (!dontAsk)
		msb.Exec();

	initCsTxData ( CouponRec[0], eeCSDataNone);

	if (msb.GetResult() || dontAsk) {

		memset(CouponRec,0,sizeof(CouponRecord));
		CouponsTable->CouponsList[0].clear();

		CompletedCoupons=0;

		  static QScopedPointer<QDBusInterface> mainDesktopDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSMainDesktop"), QLatin1String("/GamesOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
		  mainDesktopDbusInterface.data()->call("fillCouponFromFlexBetDataSlot",QJson::JsonOperations::qObjectToJson (&m_flexBetData));

		 //DbusWrapper::getGameOperationsInterface ()->fillCouponFromFlexBetDataSlot ( QJson::JsonOperations::qObjectToJson (&m_flexBetData) );

		HideForm ();
	}
#if defined IMTS_ARM
	repaint ();
#endif
	processingThread.exit();
	EditScanned = false;
}

// aste : Handler method for when the Help button is pressed
// Currently an empty placeholder until more info on what the button should do becomes available
void FlexBet::HelpPressed()
{
	qDebug("Help Button pressed!");
}

/**
 * If a row is selected at the events' table.
 * @param row The row which pressed by the user
 * @param column The column which pressed by the user
 */
void FlexBet::changeSelections ( int row,int col )
{
	Q_UNUSED(col);

	int LastRow=CouponsTable->CouponsList[CurrentCoupon].count()-1;

	if (row > LastRow)
	{
		if (row>=ROWS_PER_PAGE && LastRow<ROWS_PER_PAGE)
		{
			CouponsTable->m_CouponsTable->setPage(0);
			emit(OtherSgn() );
		}
		row=LastRow;
	}

	if (row<0)
	{
		row=0;
	}

	if (CouponsTable->CouponsList[CurrentCoupon].count())
		CouponsTable->DisplayCouponsData(CurrentCoupon);

	if ( row < CouponsTable->CouponsList[CurrentCoupon].count() )
	{

		if (!CouponsTable->m_CouponsTable->MultipleSelections.isEmpty())
			CouponsTable->m_CouponsTable->diselectRow (  );


		Q3ValueList<CouponInfo>::iterator cpnIt = CouponsTable->CouponsList[CurrentCoupon].at ( row );
		CouponsTable->m_CouponsTable->selectRow ( row );

		coupon.event=(*cpnIt).event;
		CouponsTable->m_CouponsTable->setCurrentCell(row,0);
		EnableInsertBetTypes = true;
		btnSet->setEnabled(true);
		thisArea = row;
		memset(&betCoupon,0,sizeof(CouponRecord));
		setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

		Edit=true;
		SetButtonsState();
		UpdateBetTypesAndGroupsArea(betCoupon,1,thisArea);

	}
	else
		return;
}

/**
	Is called when a calculator's button is pressed
**/
void FlexBet::calcValueChanged(int keyPressed)
{
	int LastRow = CouponsTable->CouponsList[CurrentCoupon].count();

	if ((LastRow>=TOT_CPN_AREAS) && !Edit)
		return;

	Q3ValueList<CouponInfo>::iterator cpnIt;

	if (LastRow)
		cpnIt= CouponsTable->CouponsList[CurrentCoupon].at ( LastRow-1);


	if (LastRow && ((*cpnIt).bet=="" && !Edit) )
		return;

	if (Edit)
		cpnIt = CouponsTable->CouponsList[CurrentCoupon].at ( thisArea );


	if (keyPressed == DELETE)
	{
		if (!m_EventText.isEmpty())
			m_EventText = m_EventText.remove(m_EventText.length()-1,1);
	}
	else if (keyPressed == CLEAR)
	{
		coupon.event=coupon.bet="";
		m_EventText="";

		if ( CouponsTable->CouponsList[CurrentCoupon].count())
		{
			CouponsTable->CouponsList[CurrentCoupon].remove(cpnIt);
		}

		CouponsTable->DisplayCouponsData(CurrentCoupon);
		btnOther15->setEnabled((CouponsTable->CouponsList[CurrentCoupon].count()>=ROWS_PER_PAGE)?true:false);
		EnableInsertBetTypes = false;
		btnSet->setEnabled(false);
		Edit=false;
		for (int i = 0; i < NUM_O_BETS; i++)
			if (CouponRec[CurrentCoupon].Marks[thisArea*AREA_MARKS+OFFSET_OF_BET+i] && i!=BET_STD_INDX) /// The BET_STD_INDX position is for the standard
				CouponRec[CurrentCoupon].Marks[thisArea*AREA_MARKS+OFFSET_OF_BET+i]=0;

		for (int l=thisArea; l<CouponsTable->CouponsList[CurrentCoupon].count(); l++)
			memcpy(&CouponRec[CurrentCoupon].Marks[l*AREA_MARKS],&CouponRec[CurrentCoupon].Marks[(l+1)*AREA_MARKS],AREA_MARKS);
		memset(&CouponRec[CurrentCoupon].Marks[CouponsTable->CouponsList[CurrentCoupon].count()*AREA_MARKS],0,AREA_MARKS);

		thisArea = CouponsTable->CouponsList[CurrentCoupon].count();
		memset(&betCoupon,0,sizeof(CouponRecord));
		setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);
		UpdateBetTypesAndGroupsArea(betCoupon,0,thisArea);

		CouponsTable->m_CouponsTable->drawRow(CouponsTable->CouponsList[CurrentCoupon].count(),QColor ( "white" ),QColor ( "blue" ));
		ScannedCoupon=false;
		UpdateArea();
		UpdateMoney();
		SetButtonsState();
		return;
	}
	else
		m_EventText.append(QString::number(keyPressed));

	if (Edit)
	{
		coupon.event=m_EventText;
		coupon.bet=(*cpnIt).bet;
		CouponsTable->displayCouponData ( coupon,thisArea,0,1);
	}
	else
	{
		coupon.event=m_EventText;
		coupon.bet="";

		CouponsTable->displayCouponData ( coupon,LastRow,0,1);
	}

	//    if(coupon.event.toInt()>=0 && coupon.event.toInt()<5000)
	int res = getEventID (coupon.event);
	if (res>=0 && res<5000)
		btnSet->setEnabled(true);
	else
		btnSet->setEnabled(false);


	return;
}


/**
	Is called when the SET button is pressed
**/
void FlexBet::setCouponPressed()
{
	int row;

	int allRows = CouponsTable->CouponsList[CurrentCoupon].count();

	if (!Edit)
	{

		if ( (coupon.event.length()!=0) &&
				(CouponsTable->CouponsList[CurrentCoupon].count()<TOT_CPN_AREAS) )
			CouponsTable->CouponsList[CurrentCoupon].append(coupon);
		else
			return;
	}
	else
	{
		Q3ValueList<CouponInfo>::iterator cpnIt=CouponsTable->CouponsList[CurrentCoupon].at (thisArea);
		(*cpnIt).event=coupon.event;


		UpdateBetStruct(CurrentCoupon);

		if (isStandard(CouponRec[CurrentCoupon],thisArea) && !(*cpnIt).event.contains("#"))
			(*cpnIt).event=QString("#")+(*cpnIt).event;

		if (!isStandard(CouponRec[CurrentCoupon],thisArea) && (*cpnIt).event.contains("#"))
			(*cpnIt).event.remove(0,1);

		coupon.event=(*cpnIt).event;
		CouponsTable->displayCouponData ( coupon,thisArea,0,1);

		(*cpnIt).bet=coupon.bet=BetDescription[thisArea];
		CouponsTable->displayCouponData ( coupon,thisArea,1,1);


		CouponsTable->m_CouponsTable->drawRow((thisArea),QColor ( "black" ),QColor ( "white" ));
		if (allRows<TOT_CPN_AREAS)
			CouponsTable->m_CouponsTable->drawRow((allRows),QColor ( "white" ),QColor ( "blue" ));

	}

	allRows = CouponsTable->CouponsList[CurrentCoupon].count();
	if (Edit)
		row=thisArea;
	else
	{
		row=allRows-1;
		thisArea = row;
		memset(&betCoupon,0,sizeof(CouponRecord));
		setCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

	}

	m_EventText="";
	coupon.event="";
	coupon.bet="";

	btnSet->setEnabled(false);
	//================================================================================

	Q3ValueList<CouponInfo>::iterator cpnIt = CouponsTable->CouponsList[CurrentCoupon].at ( row );
	QString evnt=(*cpnIt).event;
	if (evnt.contains("#"))
		evnt.remove(0,1);
	setEventCode(evnt);

	if (Edit)
	{
		EnableInsertBetTypes=false;
		if (allRows<TOT_CPN_AREAS)
			UpdateBetTypesAndGroupsArea(CouponRec[CurrentCoupon],0,allRows);
		else
		{
			memset(&betCoupon,0,sizeof(CouponRecord));
			UpdateBetTypesAndGroupsArea(betCoupon,0,thisArea);
		}
		Edit=false;
	}
	else
	{
		EnableInsertBetTypes = true;
		int event;
		if (evnt=="")
			event=EMPTY_AREA;
		else
			event= getEventID (evnt);  //=evnt.toInt();
		if ((event>=0 && event<5000) )
			UpdateBetTypesAndGroupsArea(betCoupon,1,thisArea);
		else
			UpdateBetTypesAndGroupsArea(betCoupon,0,thisArea);
	}


	ScannedCoupon=false;
	UpdateArea();
	UpdateMoney();
	SetButtonsState();
}

/**
	Is called when the ACCEPT BET TYPE button is pressed
**/
void FlexBet::BetTypeAcceptPressed()
{
	int row;
	int allRows = CouponsTable->CouponsList[CurrentCoupon].count();
	if (Edit)
		row=thisArea;
	else
		row=allRows-1;

	UpdateBetTypesAndGroupsArea(betCoupon,1,thisArea);

	Q3ValueList<CouponInfo>::iterator cpnIt = CouponsTable->CouponsList[CurrentCoupon].at ( row );

	if (betTypeMarksNum!=0 && (getRecordCode()==-1 || getBetTypeTxt()=="-" || getBetDescriptionTxt()=="-"))
	{
		DisplayError(qApp->translate("FlexBet","Error"), qApp->translate("FlexBet","Invalid bet selection"));
		EnableInsertBetTypes=true;

		(*cpnIt).bet=getBetTypeDescription();
		coupon.bet=(*cpnIt).bet;

		QString eventStr = (*cpnIt).event;
		if (eventStr.contains("#"))	/// For standard
			eventStr.remove(0,1);
		if (eventStr.contains("(") && eventStr.contains(")") ) 	/// For groups
		{
			int i = eventStr.find( ")", 0,false );
			eventStr = eventStr.replace(0,i+1,"");
		}

		QString StdGrpStr = QString::null;
		if (isStandard(betCoupon,thisArea))
			StdGrpStr = QString("#");

		eventStr = StdGrpStr + eventStr;
		(*cpnIt).event = eventStr;

		coupon.event=(*cpnIt).event;
		CouponsTable->displayCouponData ( coupon,row,0,1);
		CouponsTable->displayCouponData ( coupon,row,1,1);

		CouponsTable->m_CouponsTable->drawRow(row,QColor ( "black" ),QColor ( "white" ));

		if (!Edit)
		{
			if (row+1<TOT_CPN_AREAS)
				CouponsTable->m_CouponsTable->drawRow((row+1),QColor ( "white" ),QColor ( "blue" ));
		}
		else
		{
			if (allRows<TOT_CPN_AREAS)
				CouponsTable->m_CouponsTable->drawRow(allRows,QColor ( "white" ),QColor ( "blue" ));
		}
	}
	else
	{

		EnableInsertBetTypes=false;

		(*cpnIt).bet=getBetTypeDescription();
		coupon.bet=(*cpnIt).bet;

		QString eventStr = (*cpnIt).event;
		if (eventStr.contains("#"))
			eventStr.remove(0,1);
		if (eventStr.contains("(") && eventStr.contains(")") ) 	/// For groups
		{
			int i = eventStr.find( ")", 0,false );
			eventStr = eventStr.replace(0,i+1,"");
		}

		QString StdGrpStr = QString::null;
		if (isStandard(betCoupon,thisArea))
			StdGrpStr = QString("#");

		if (hasGroup(thisArea,&betCoupon))
		{
			QString groupPrnt;
			GetEventGroupText(thisArea,groupPrnt,&betCoupon);
			StdGrpStr = StdGrpStr + groupPrnt;
		}

		eventStr = StdGrpStr + eventStr;
		(*cpnIt).event = eventStr;

		coupon.event=(*cpnIt).event;
		CouponsTable->displayCouponData ( coupon,row,0,1);
		CouponsTable->displayCouponData ( coupon,row,1,1);


		CouponsTable->m_CouponsTable->drawRow(row,QColor ( "black" ),QColor ( "white" ));

		if (!Edit)
		{
			if (row+1<TOT_CPN_AREAS)
				CouponsTable->m_CouponsTable->drawRow((row+1),QColor ( "white" ),QColor ( "blue" ));
		}
		else
		{
			if (allRows<TOT_CPN_AREAS)
				CouponsTable->m_CouponsTable->drawRow(allRows,QColor ( "white" ),QColor ( "blue" ));
		}

		btnOther15->setEnabled((allRows>=ROWS_PER_PAGE)?true:false);
		btnSet->setEnabled(false);
	}
	getCouponMarks(CouponRec[CurrentCoupon],thisArea,NUM_O_BETS+NUM_O_RGROUP+NUM_O_GROUPS);

	if (allRows<TOT_CPN_AREAS)
		UpdateBetTypesAndGroupsArea(CouponRec[CurrentCoupon],0,allRows);
	else
	{
		memset(&betCoupon,0,sizeof(CouponRecord));
		UpdateBetTypesAndGroupsArea(betCoupon,0,thisArea);
	}

	m_EventText="";
	Edit=false;

	ScannedCoupon=false;
	UpdateArea();
	UpdateMoney();
	SetButtonsState();
}

/**
	 Is called when the systems and multipliers button is pressed
**/
void FlexBet::SystemsMultsCouponPressed()
{
	CouponRecord MarksBefore;
	memset(&MarksBefore,0,sizeof(MarksBefore));
	memcpy(&MarksBefore,&CouponRec[CurrentCoupon],sizeof(MarksBefore));
	m_bIsDialogActive = true;
	SystemsMultipliers *BetMultiplierFrm = new SystemsMultipliers(true, this);
	BetMultiplierFrm->setFlexBet(this);
	BetMultiplierFrm->setCouponMarks(CouponRec[CurrentCoupon],NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));

	BetMultiplierFrm->calculateIt();
	BetMultiplierFrm->UpdateArea();
	BetMultiplierFrm->move(0,1);
	BetMultiplierFrm->exec();

	if (BetMultiplierFrm->OkPressed)
	{
		BetMultiplierFrm->getCouponMarks(CouponRec[CurrentCoupon],NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
		BetMultiplierFrm->getResults(cpnPerm, cpnPermMult,cpnMultiply);
		MultText->setText(QString::number(cpnMultiply));

		QString sys="";

		for (int i=0; i<NUM_O_PERMS; i++)
		{
			if (cpnPerm[i]>0)
			{
				if (sys.length())
					sys.append(QString(", "));

				sys=sys.append(QString::number(i)+QString("(%1)").arg(cpnPermMult[i]));
			}
		}
		if (cpnPerm[NUM_O_PERMS-1]>0)
			sys=sys.append(qApp->translate("FlexBet",", ALL"));

		if (sys.length())
			SysText->setText(sys);
		else
			SysText->setText(QString("-"));
	}
	else
	{
		memcpy(&CouponRec[CurrentCoupon],&MarksBefore,sizeof(MarksBefore));
		BetMultiplierFrm->setCouponMarks(CouponRec[CurrentCoupon],NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
	}
	delete BetMultiplierFrm;

	m_bIsDialogActive = false;

	UpdateMoney();
	SetButtonsState();
	return;
}

/**
   Procedure for calculating the number of standards, which bets are double, etc.
**/
void FlexBet::GroupingAdjustment(unsigned char *storage,unsigned char *std_tbl,
								 unsigned char &count, unsigned char &std_count)
{
	count=std_count=0;
	bool wait=true;

	memset(storage,1,TOT_CPN_AREAS);
	memset(std_tbl,0,TOT_CPN_AREAS);

	for (int i=0; i<TOT_CPN_AREAS; i++) {
		if (event[i].group>0 && !event[i].random) {
			//if it belongs to a group then don't increase index as
			//we consider them as one event
			wait=false;
			for (int j=i+1; j<TOT_CPN_AREAS; j++)
				if (event[i].group==event[j].group && !event[j].random)
					wait=true;
			if (!wait) {
				for (int j=0; j<i; j++) {
					if (event[i].group==event[j].group && !event[j].random) {
						if ((event[j].betType>=FINAL_1X && event[j].betType<=FINAL_X2 )|| (event[j].betType>=FstHALF_1X && event[j].betType<=FstHALF_X2) || (event[j].betType>=SndHALF_1X && event[j].betType<=SndHALF_X2) ||
			(event[j].betType>=FINALHC_1X && event[j].betType<=FINALHC_X2))
							// if not 1 or X or 2 is played alone then double final result selection
							// meaning one more game played
						//if (event[j].betCode2!=1 && event[j].betCode2!=10 &&event[j].betCode2!=100)
								storage[count] *= 2;
					}
				}
				if ((event[i].betType>=FINAL_1X && event[i].betType<=FINAL_X2 )|| (event[i].betType>=FstHALF_1X && event[i].betType<=FstHALF_X2) || (event[i].betType>=SndHALF_1X && event[i].betType<=SndHALF_X2) ||
			(event[i].betType>=FINALHC_1X && event[i].betType<=FINALHC_X2))
					//if (event[i].betCode2!=1 && event[i].betCode2!=10 &&event[i].betCode2!=100)
						storage[count] *= 2;
		if (event[i].betType==FINAL_1X2 || event[i].betType==FstHALF_1X2 || event[i].betType==SndHALF_1X2 || event[i].betType==FINALHC_1X2 )
			 storage[count] *= 3;

				if (event[i].standard) {
					std_tbl[count]=1;
					std_count++;
				}
				// if reached the last grouped game then increase index
				count++;
			}
		} else if (event[i].group>0 && event[i].random) {
			// just as above we consider only one
			wait=false;
			for (int j=i+1; j<TOT_CPN_AREAS; j++)
				if (event[i].group==event[j].group && event[j].random)
					wait=true;
			if (!wait) {
				// if reached the last grouped event
				for (int j=0; j<i; j++) {
					if (event[i].group==event[j].group && event[j].random) {
						// count how many events belong to the same group
						// and increase the number of different codes
						// this group participates
						storage[count]++;
						if ((event[j].betType>=FINAL_1X && event[j].betType<=FINAL_X2 )|| (event[j].betType>=FstHALF_1X && event[j].betType<=FstHALF_X2) || (event[j].betType>=SndHALF_1X && event[j].betType<=SndHALF_X2) ||
			(event[j].betType>=FINALHC_1X && event[j].betType<=FINALHC_X2))
							// if not 1 or X or 2 is played alone then
							// double final result selection
							// meaning one more game played
						   // if (event[j].betCode2!=1 && event[j].betCode2!=10&& event[j].betCode2!=100)
								storage[count]++;
					}
				}
				if ((event[i].betType>=FINAL_1X && event[i].betType<=FINAL_X2 )|| (event[i].betType>=FstHALF_1X && event[i].betType<=FstHALF_X2) || (event[i].betType>=SndHALF_1X && event[i].betType<=SndHALF_X2) ||
			(event[i].betType>=FINALHC_1X && event[i].betType<=FINALHC_X2))
				   // if (event[i].betCode2!=1 && event[i].betCode2!=10&& event[i].betCode2!=100)
						storage[count]++;
				// and of course increase the index
				if (event[i].standard) {
					std_tbl[count]=1;
					std_count++;
				}
				count++;
			}
		} else if (!event[i].group && event[i].choice>=0 && sjp_nr==0) {

			if (event[i].betType==FINAL_1X2 || event[i].betType==FstHALF_1X2 || event[i].betType==SndHALF_1X2 || event[i].betType==FINALHC_1X2 )
				 storage[count] *= 3;
			else
			{
				// if the event is not grouped then it participates with one game
			  if ((event[i].betType>=FINAL_1X && event[i].betType<=FINAL_X2 )|| (event[i].betType>=FstHALF_1X && event[i].betType<=FstHALF_X2) || (event[i].betType>=SndHALF_1X && event[i].betType<=SndHALF_X2) ||
				(event[i].betType>=FINALHC_1X && event[i].betType<=FINALHC_X2))
					// if not 1 or X or 2 is played alone then double final result selection
					// meaning one more game played
				   // if (event[i].betCode2!=1 && event[i].betCode2!=10 && event[i].betCode2!=100)
						storage[count]++;
			}

			if (event[i].standard) {
				std_tbl[count]=1;
				std_count++;
			}
			count++;
		}else if (!event[i].group && event[i].betType!=-1 && sjp_nr) {
			// if the event is not grouped then it participates with one game
		  if ((event[i].betType>=FINAL_1X && event[i].betType<=FINAL_X2 )|| (event[i].betType>=FstHALF_1X && event[i].betType<=FstHALF_X2) || (event[i].betType>=SndHALF_1X && event[i].betType<=SndHALF_X2) ||
			(event[i].betType>=FINALHC_1X && event[i].betType<=FINALHC_X2))
				// if not 1 or X or 2 is played alone then double final result selection
				// meaning one more game played
			   // if (event[i].betCode2!=1 && event[i].betCode2!=10 && event[i].betCode2!=100)
					storage[count]++;
			if (event[i].standard) {
				std_tbl[count]=1;
				std_count++;
			}
			count++;
		}
	}
}

unsigned int FlexBet::getSystemMultplier(unsigned long s_multiplier, unsigned int uiMultPos)
{
//    unsigned int uiMults[NUM_O_SYSTEMMULTS]={2,3,4,5};

//    if( uiMultPos>(NUM_O_SYSTEMMULTS-1) )
//        return 0;

//    if( !s_multiplier )
//        return uiMults[uiMultPos];
//    else
//        return s_multiplier*uiMults[uiMultPos];

	Q_UNUSED(s_multiplier);
	Q_UNUSED(uiMultPos);

	return 1; // CH has no system multipliers, so return 1 no matter what
}


/**
	This procedure evaluates the permutations and their corresponding multipliers
**/
unsigned long FlexBet::evaluateRequestRec(int cpn, unsigned char matches, unsigned char standards, long *s_multiplier)
{
	unsigned char count=0,first=0;
	unsigned long requests=0;
	int i,j;

	if (0==standards)   //without standards
	{
		for (i=1; i<NUM_O_PERMS-1; i++)   //not counting the 0 mark...
		{
			if (cpnPerm[i])   //if set in requested systems location on the coupon
			{
				//set the request bit
				requests |= (1 << (i-1));
				//set the multiplier bits for the given request
				s_multiplier[i-1]=1;//initialize
				for (j=0; j<NUM_O_SYSTEMMULTS; j++)
					if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
						s_multiplier[i-1] = getSystemMultplier(s_multiplier[i-1],j); //s_multiplier[i-1] |= (1<<(j+1));
				count++;
				first=i+1;
			}
		}

		if (cpnPerm[0])
			return bet_error(416,0); //request 0 without stadard

		if (cpnPerm[NUM_O_PERMS-1])   //ALL marked
		{
			if (count>1)
				return(bet_error(415,0)); //'ALL' plus 2 or more systems
			if (first)
			{
				for (i=first; i<=matches; i++)
				{
					requests |= (1 << (i-1));
					s_multiplier[i-1]=1;//initialize
					for (j=0; j<NUM_O_SYSTEMMULTS; j++)
						if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
							s_multiplier[i-1] = getSystemMultplier(s_multiplier[i-1],j); //s_multiplier[i-1] |= (1<<(j+1));
				}
			}
			else
			{
				for (i=0; i<matches; i++)
				{
					requests |= (1 << i);
					s_multiplier[i]=1;//initialize
					for (j=0; j<NUM_O_SYSTEMMULTS; j++)
						if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
							s_multiplier[i] = getSystemMultplier(s_multiplier[i],j); //s_multiplier[i] |= (1<<(j+1));
				}
			}
		}
		if (!count && !cpnPerm[NUM_O_PERMS-1])   //no system marked
		{
			requests |= (1 << (matches-1));
			s_multiplier[matches-1]=1;//initialize
			// no system multiplier since no system...
		}

	}
	else   //with standards case
	{
		for (i=0; i<NUM_O_PERMS-1; i++)
		{
			if (cpnPerm[i])
			{
				if ((i+standards)>matches)
					return bet_error(508, 0); //requested more than played
				requests |= (1 <<(i+standards-1));
				s_multiplier[i+standards-1]=1;//initialize
				for (j=0; j<NUM_O_SYSTEMMULTS; j++)
					if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
						s_multiplier[i+standards-1] = getSystemMultplier(s_multiplier[i+standards-1],j); //s_multiplier[i+standards-1] |= (1<<(j+1));
				count++;
				first=i+standards;
			}
		}

		if (cpnPerm[NUM_O_PERMS-1])   //if ALL marked
		{
			if (count>1)
				return(bet_error(415,0)); //'ALL' plus 2 or more systems
			if (first)
			{
				for (i=first; i<=matches; i++)
				{
					requests|=(1<<(i-1));
					s_multiplier[i-1]=1;//initialize
					for (j=0; j<NUM_O_SYSTEMMULTS; j++)
						if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
							s_multiplier[i-1] = getSystemMultplier(s_multiplier[i-1],j); //s_multiplier[i-1] |= (1<<(j+1));
				}
			}
			else
			{
				for (i=standards-1; i<matches; i++)
				{
					requests|=(1<<i);
					s_multiplier[i]=1;//initialize
					for (j=0; j<NUM_O_SYSTEMMULTS; j++)
						if (CouponRec[cpn].Marks[OFFSET_OF_SYS + i*5 + (j+1)])
							s_multiplier[i] = getSystemMultplier(s_multiplier[i],j); //s_multiplier[i] |= (1<<(j+1));
				}
			}
		}

		if (!count && cpnPerm[NUM_O_PERMS-1])   //if no systems marked
		{
			requests|= (1<<(matches-1));
			s_multiplier[matches-1]=1;//initialize
			// no system multiplier since no system...
		}
	}//end if with standard case

	return requests;
}

/**
	This procedure updates the struct that holds the information of the bets.
**/
void FlexBet::UpdateBetStruct(int cpn)
{
	int i=0;
//    bool isSJP=false;
	sjp_nr=0;
	sjpMatches=0;

	CalculateLastSect(cpn);

//    for(int i=0;i<NUM_O_SJP;i++)
//    {
//     if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]==1)
//     {
//         isSJP=true;
//         sjp_nr=i+1;//sjp_nr=i+10;
//         break;
//     }
//    }

	memset(event,0,sizeof(event));
	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		event[i].choice=EMPTY_AREA;
		event[i].betType=-1;
		event[i].random=false;
		event[i].group=0;
		event[i].standard=false;
		BetDescription[i]="";
	}

	Q3ValueList<CouponInfo>::iterator couponIt;
	for ( couponIt=CouponsTable->CouponsList[cpn].begin(); couponIt!=CouponsTable->CouponsList[cpn].end(); couponIt++ )
	{
		if (( *couponIt ).event=="")
			event[i].choice=EMPTY_AREA;
		else
		{
			QString evnt=(*couponIt ).event;
			if (evnt.contains("#"))	/// For standard
				evnt.remove(0,1);
			if (evnt.contains("(") && evnt.contains(")") ) 	/// For groups
			{
				int i = evnt.find( ")", 0,false );
				evnt = evnt.replace(0,i+1,"");
			}
			event[i].choice= getEventID (evnt); //evnt.toInt();
		}


		setEventCode(event[i].choice);

		if ((event[i].choice>=0 && event[i].choice<MAX_EVENT_CODE) )
		{
			calculateBet(CouponRec[cpn],i);
			event[i].betType=getRecordCode();

			if (event[i].betType>=0)
			{
				BetDescription[i]=getBetTypeDescription();
				if (BetDescription[i]=="- -")
				{
					event[i].betType=-1;
				}
			}
			else
				BetDescription[i]="-";
		}
		else
		{
			if( sjp_nr )
			{
				calculateBet(CouponRec[cpn],i);
				event[i].betType=getRecordCode();
			}
			else
			{
				BetDescription[i]="- -";
				event[i].betType=-1;
			}
		}

		event[i].standard=isStandard(CouponRec[cpn],i);
		getGroupNumber(i,event[i].random,event[i].group,&CouponRec[cpn]);

		i++;
	}

	SystemsMultipliers *temp2 = new SystemsMultipliers(false, this);
	temp2->setFlexBet(this);
	temp2->setCouponMarks(CouponRec[cpn], NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
	temp2->calculateIt();
	temp2->getResults(cpnPerm, cpnPermMult, cpnMultiply);
	delete temp2;

	return;
}


///checks for an empty area in coupon
inline int FlexBet::chkEmptyCpnLoc(int cpn)
{
	bool found;
	bool flag=false;
	int ret=0;
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		found=false;
		for (int j=0; j<AREA_MARKS; j++)
		{
			if (CouponRec[cpn].Marks[i*AREA_MARKS+j])
				found = true;
		}
		if (!found)
		{
			flag=true;//found an empty area
			ret=i+1;
		}
		if (flag&&found)//some previous area was empty and found a non empty one
			return ret;//return that empty area
	}
	return 0;
}

///check if the same event is twice chosen
inline unsigned int FlexBet::checkForSameEvent(int cpn)
{

	/* If a system is selected then let the
	central system do the check */
	for (int i=0; i<NUM_O_PERMS; i++)
	{
		if (cpnPerm[i]>0)
		{
			return 0;
		}
	}

	/* In the most simple case of same events maenaing no R group and
	not special event report error*/
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		for (int j=0; j<lastSection[cpn]+1 && j<TOT_CPN_AREAS; j++)
		{
			if (event[i].choice>=0 && event[i].choice==event[j].choice && i!=j)
			{
				Choice=event[i].choice;
				if (event[i].random && event[j].random && event[i].group == event[j].group)
					//if in same random group OK...
					continue;
				if ((event[i].betType>=0 && event[i].betType<NORMAL_BETTYPES_STARTINGCODE) || (event[j].betType>=0 && event[j].betType<NORMAL_BETTYPES_STARTINGCODE))
					continue;
				return Choice;
			}
		}
	}
	return 0;
}

///check if a multiplier in an empty coupon exists
inline int FlexBet::chkMultiAlone(int cpn)
{
	if (lastSection[cpn]==-1)
		for (int i=0 ; i<NUM_O_MULTS; i++)
			if (CouponRec[cpn].Marks[OFFSET_OF_MULT+i])
				return 1;
	return 0;
}

///check if a mult for a perm is marked without the perm
inline int FlexBet::chkPermMult(int cpn)
{
	for (int i=0; i<NUM_O_PERMS-1; i++)
		for (int j=0; j<NUM_O_SYSTEMMULTS; j++)
			if (!cpnPerm[i])
				if (CouponRec[cpn].Marks[OFFSET_OF_SYS+i*(NUM_O_SYSTEMMULTS+1)+j])
					return i+1;
	return 0;
}

///check if more than allowed marks in stake
inline int FlexBet::chkMoreStake(int cpn)
{
	int count=0;
	for (int i=0; i<NUM_O_STAKES; i++)
		if (CouponRec[cpn].Marks[OFFSET_OF_STAKE+i])
			count++;

	if (count>MAXIMUM_SELECTED_STAKES)
		return 1;
	else
		return 0;
}

///check if more than allowed marks in multiplier
inline int FlexBet::chkMoreMulti(int cpn)
{
	int count=0;
	for (int i=0; i<NUM_O_MULTS; i++)
		if (CouponRec[cpn].Marks[OFFSET_OF_MULT+i])
			count++;

	if (count>MAXIMUM_SELECTED_MULTS)
		return 1;
	else
		return 0;
}

///check if an empty event is marked as standard
inline int FlexBet::chkEmptyWithStd(int cpn)
{
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
		if (event[i].choice<0 && event[i].standard)
			return i+1;
	return 0;
}

///check if "all" perm is marked and more than two perms marked
inline int FlexBet::chkAllnSystems(int)
{
	int count=0;
	if (cpnPerm[NUM_O_PERMS-1]>0)      /// For ALL
	{
		for (int j=0; j<NUM_O_PERMS-1; j++)
			if (cpnPerm[j]>0)
				count++;
		if (count>1)
			return 1;
	}
	return 0;
}

///check if zero system and no standards marked
inline int FlexBet::chkZeroNoStd(int cpn)
{

	if (cpnPerm[0]>0)
	{
		for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
			if (event[i].standard)
				return 0;//no error
		return 1;//error no standard found
	}
	return 0;//if 0 system not marked bypass check
}

/// check if less than 3 marks in the event choice
inline int FlexBet::chkLessEvntMarks(int cpn)
{
	int count;
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		count=0;
		for (int j=0; j<NUM_O_PLAYSLIP_EVENT_MARKS; j++)
		{
			if (CouponRec[cpn].Marks[i*AREA_MARKS+NUM_O_PLAYSLIP_EVENT_MULT+j])
				count++;
		}
		if  (count<3  && sjp_nr==0)
			return i+1;
	}
	return 0;

}

/// check if more than 3 marks in the event choice
inline int FlexBet::chkMoreEvntMarks(int cpn)
{
	int tempMarks[NUM_O_PLAYSLIP_EVENT_MARKS],countTotal=0, countOne=0;
	// chkEmptyCpnLoc(cpn);

	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		for (int j=0; j<NUM_O_PLAYSLIP_EVENT_MARKS; j++)
			tempMarks[j]=CouponRec[cpn].Marks[i*AREA_MARKS+NUM_O_PLAYSLIP_EVENT_MULT+j];

		countTotal=0;
		//countOne=1;//Passes the first time
		for (int j=0; j<NUM_O_PLAYSLIP_EVENT_MARKS; j++)
		{
			if (!(j%10))
				countOne = 0;//Inititalizes every time

			if (tempMarks[j])
			{
				countTotal++;
				countOne++;
			}
		}
		if (countOne>1 || countTotal>3)
			return i+1;
	}
	return 0;
}

/// check if event code is greater than maximum allowed code (5000)
inline int FlexBet::chkEvntCodeGreater5000(int cpn)
{
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
		if (event[i].choice>MAX_EVENT_CODE)
			return i+1;
	return 0;

}

/// check if standard with no bet type selected
inline int FlexBet::chkStdNoBet(int cpn)
{
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
		if (event[i].standard && event[i].betType<0)
			return i+1;
	return 0;
}

///checks if standard with no permutations is marked
inline int FlexBet::chkStdWithoutPerm(int cpn)
{
	bool found=false;
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
		if (event[i].standard)
		{
			found=true;
			break;
		}
	if (found)
	{
		for (int i=0; i<NUM_O_PERMS; i++)
			if (cpnPerm[i]>0)
				return 0;
		return 1;
	}
	return 0;
}

inline int FlexBet::chkReqMore(int cpn, int matches, int standards)  //check if req>played
{
	Q_UNUSED(cpn);
	//checks if selections are less than permutations
	for (int i=0; i<NUM_O_PERMS-1; i++)
	{
		if (cpnPerm[i]>0)
		{
			if ((i+standards)>matches)
				return 1;
		}
	}
	return 0;
}

///checks if for an event no bet is played
inline int FlexBet::chkInvalidBet(int cpn)
{
	for (int i=0; i<lastSection[cpn]+1; i++)
	{
		if (event[i].choice>=0 && event[i].betType<0)
		{
			return i+1;
		}
	}
	return 0;
}

///checks if no event is played
inline int FlexBet::chkInvalidEvent(int cpn)
{
	for (int i=0; i<lastSection[cpn]+1; i++)
	{
		if (event[i].choice<0)
		{
			return i+1;
		}
	}
	return 0;
}

///check for correct grouping of events
inline int FlexBet::chckTheGroups(int cpn)
{
	for (int i=0; i<=lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		if (event[i].choice<0 && (event[i].group || event[i].random))
			return i+1;
	}
	return 0;
}


///check if only some events from a group are played as stds
inline int FlexBet::chkGrpStd(int cpn)
{
	for (int i=0; i<=lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		if (event[i].group && event[i].standard)
			for (int j=0; j<=lastSection[cpn]+1 && i<TOT_CPN_AREAS; j++)
				if (event[j].group==event[i].group && event[i].random==event[j].random && !event[j].standard)
					return 1;
	}
	return 0;
}

///check if only the R switch is marked without group
inline int FlexBet::chkGroupComplete(int cpn)
{
	for (int i=0; i<=lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
		if (event[i].random && !event[i].group)
			return i+1;
	return 0;
}

///Checks if all the played events are in the same group or if there is a group with only one event
///In this case the coupon is not accepted
int FlexBet::chkAllEventsInOneGroup(int cpn)
{
	QMap< QPair<bool,int> ,uint >  Groups;
	Groups.clear();

	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++)
	{
		QPair<bool,int>current(event[i].random, event[i].group);

		if (Groups.keys().contains(current))
		{
			uint temp = Groups[current];
			temp++;
			Groups.insert(current,temp);
		}
		else
		{
			Groups.insert(current,1);
		}
	}

	QMap< QPair<bool,int> ,uint >::Iterator groupIt;
	for ( groupIt = Groups.begin(); groupIt != Groups.end(); ++groupIt)
	{
		QPair<bool,int> group = groupIt.key();
		if (group.first == false && group.second == 0)
		{
			continue;
		}
		if (groupIt.data()==(uint)lastSection[cpn]+1)
			return 312;
		if (groupIt.data()==1)
			return 313;
	}
	return 0;
}

inline int FlexBet::chkAmount(int cpn)
{
	//Stake
	for(unsigned int i=0; i<NUM_O_STAKES; i++) //12 stake values
	{
		if( CouponRec[cpn].Marks[OFFSET_OF_STAKE+i] )
			return 0;
	}
	return 1;
}

///check for a lonely '0' permutation
inline int FlexBet::chkZeroSystemAlone(int matches, int standards)
{

	int i;
	if (matches>standards && cpnPerm[0]==1)
	{
		i=0;
		for (int j=0; j<NUM_O_PERMS; j++)
		{
			if (cpnPerm[j]>0)
				i++;
		}
		if (i==1)  //just '0' system marked
			return 1;
	}
	return 0;
}

inline int FlexBet::chkSJPandMatches(int matches)
{
	if(sjp_nr && (matches<10 || matches>15))
		return 1;
	return 0;
}

inline int FlexBet::chkSJPandEvents(int cpn)
{

	int count;
	for (int i=0; i<lastSection[cpn]+1 && i<TOT_CPN_AREAS; i++) {
		count=0;
		for (int j=0; j<33; j++)
	{
			if (CouponRec[cpn].Marks[i*AREA_MARKS+j])
				count++;
	}
		if  (count>0 && sjp_nr) //(event[i].choice<0 && count<3)
			return i+1;
	}
/*
	for (int i=0; i<lastSection[cpn]+1; i++) {
		if (event[i].choice>0 && sjp_nr) {

			return i+1;
		}
	}
*/
	return 0;
}

inline int FlexBet::chkSJPInvalidBet(int cpn) {//checks if for an event no bet is played
	for (int i=0; i<lastSection[cpn]+1; i++) {
		if (sjp_nr && ( (event[i].betType!=FINAL_1 && event[i].betType!=FINAL_X && event[i].betType!=FINAL_2 && event[i].betType!=FINAL_1X && event[i].betType!=FINAL_12 && event[i].betType!=FINAL_X2 && event[i].betType!=FINAL_1X2) /* || event[i].standard*/ ) ) {
			//if the error is in a special bet delete all the bet marks because it can't
			//be displayed on screen...
		  //  if (CouponRec[cpn].Marks[i*AREA_MARKS+OFFSET_OF_BET+ 8])
		  //      for (int j=0; j<NUM_O_BETS; j++)
		  //          CouponRec[cpn].Marks[i*AREA_MARKS+OFFSET_OF_BET+j]=0;
			return i+1;
		}
	}
	return 0;
}

inline int FlexBet::chkSJPandSTD(int cpn) {
	for (int i=0; i<lastSection[cpn]+1; i++) {
		if (sjp_nr &&  event[i].standard  ) {
			//if the error is in a special bet delete all the bet marks because it can't
			//be displayed on screen...
		  //  if (CouponRec[cpn].Marks[i*AREA_MARKS+OFFSET_OF_BET+ 8])
		  //      for (int j=0; j<NUM_O_BETS; j++)
		  //          CouponRec[cpn].Marks[i*AREA_MARKS+OFFSET_OF_BET+j]=0;
			return i+1;
		}
	}
	return 0;
}

inline int FlexBet::chkMorethanOneSJPselections(int cpn)
{
	int count=0;

		for (int j=0; j<NUM_O_SJP; j++)
	{
			if (CouponRec[cpn].Marks[OFFSET_OF_SJP+j])
				count++;
	}
		if  (count>1)
			return 1;


	return 0;
}

///check if above or below the given column limits for the coupon
inline int FlexBet::chkLimits(int cpn)
{
	if ( btotcol[cpn] >= UpperLimit)
		return 1;
	if ((double)btotcol[cpn] * getColumnCost() > LONG_MAX)
		return 1;
	if (IsEmptyCoupon(cpn))
		return 0;
	if ( btotcol[cpn] < LowerLimit)
		return 1;
	return 0;
}

bool FlexBet::IsStakeMarked(int cpn, unsigned int iPos)
{
	Q_UNUSED(iPos);

	for(unsigned int i=0; i<NUM_O_STAKES; i++)
	{
		if( CouponRec[cpn].Marks[ OFFSET_OF_STAKE+i ] )
			return true;
	}

	return false;
}

bool FlexBet::IsMultsMarked(int cpn, unsigned int iPos)
{
	Q_UNUSED(iPos);

	for(unsigned int i=0; i<NUM_O_MULTS; i++)
	{
		if( CouponRec[cpn].Marks[ OFFSET_OF_MULT+i ] )
			return true;
	}

	return false;
}

bool FlexBet::IsStakeMultPos(unsigned int iPos)
{
	for(unsigned int i=0; i<NUM_O_STAKES; i++)
	{
		if(iPos == OFFSET_OF_STAKE+i)
			return true;
	}

	for(unsigned int i=0; i<NUM_O_MULTS; i++)
	{
		if(iPos == OFFSET_OF_MULT+i )
			return true;
	}

	return false;
}

/// Check if the coupon is empty
int FlexBet::IsEmptyCoupon(int cpn)
{

	if (!ScannedCoupon)
	{
		if (CouponsTable->CouponsList[cpn].count() )
			return 0;
	}
	else
	{
		for (int i=0; i<AREA_MARKS*TOT_CPN_AREAS; i++)
			if (CouponRec[cpn].Marks[i])
				return 0;
	}

	for (int i=AREA_MARKS*TOT_CPN_AREAS; i<TOTAL_ECPN_MARKS; i++)
		if (CouponRec[cpn].Marks[i] && !IsStakeMultPos(i) )
			return 0;

	return 1;
}

/// Check if a given area of the coupon is empty
inline bool FlexBet::IsEmpty(int cpn,int area)
{
	/*just chek if the given area is empty*/
	for (int i=0; i<AREA_MARKS; i++)
		if (CouponRec[cpn].Marks[area*AREA_MARKS+i])
			return false;
	return true;
}

/**
	1. Check the coupon for error
		2. Calculate the coupon's columns
		3. Update the struct the holds the coupon's bets information.
**/
int FlexBet::CheckCoupon(int cpn, bool bCheckAmount)
{

	unsigned long totalc=0;
	unsigned char Dbls[TOT_CPN_AREAS];
	unsigned char std_tbl[TOT_CPN_AREAS];
	long req_mult[TOT_CPN_AREAS];

	int errHint=0;
	unsigned char matches=0;
	unsigned char standards=0;
	unsigned long req;

	//int predMatches=0,predRequested=0,predColumns=0;


	memset(Dbls,1,sizeof(Dbls));
	memset(std_tbl,0,sizeof(std_tbl));
	memset(req_mult,0,sizeof(req_mult));



	//timeval tvs, tve;
	//gettimeofday(&tvs, NULL );

	if (ScannedCoupon)
		UpdateBetStructM(cpn);
	else
		UpdateBetStruct(cpn);



	GroupingAdjustment(Dbls,std_tbl,matches,standards);
	req = evaluateRequestRec(cpn,matches,standards,req_mult);

	//if(predLine(cpn,predMatches,predRequested,predColumns,Dbls)<0)
	//return -1

	if (ScannedCoupon)
	{
		if ((errHint=chkEmptyCpnLoc(cpn)))
			return bet_error(511,errHint);
		else if ((errHint=chkLessEvntMarks(cpn)) && (sjp_nr==0))
			return bet_error(501,errHint);
		else if ((errHint=chkMoreEvntMarks(cpn)))
			return bet_error(502,errHint);
		else if ((errHint=chkEvntCodeGreater5000(cpn)))
			return bet_error(910,errHint);
	}

	if ((checkForSameEvent(cpn)))
		return bet_error(605,Choice);
	else if (chkSJPandMatches(matches))
		return bet_error(913,0);
	else if (chkMultiAlone(cpn))
		return bet_error(304,0);
	else if (chkMoreStake(cpn))
		return bet_error(106,0);
	else if (chkMoreMulti(cpn))
		return bet_error(107,0);
	else if ((errHint=chkPermMult(cpn)))
		return bet_error(305,errHint-1);
	else if ((errHint=chkEmptyWithStd(cpn)))
		return bet_error(407, errHint);
	else if ((errHint=chkStdNoBet(cpn)))
		return bet_error(503,errHint);
	else if (chkAllnSystems(cpn))
		return bet_error(415,0);
	else if (chkZeroNoStd(cpn))
		return bet_error(416,0);
	else if (chkStdWithoutPerm(cpn))
		return bet_error(506,0);
	else if (chkReqMore(cpn,matches,standards))
		return bet_error(508,0);
	else if ( (errHint=chkInvalidBet(cpn) ) && (sjp_nr==0) )
		return bet_error(512,errHint);
	else if ((errHint=chkInvalidBet(cpn)) && (sjp_nr && sjpMatches<10) )
	   return bet_error(512,errHint);
	else if ((errHint=chckTheGroups(cpn)))
		return bet_error(303,errHint);
	else if (chkGrpStd(cpn))
		return bet_error(306,0);
	else if ((chkGroupComplete(cpn)))
		return bet_error(307,errHint);
	else if ((errHint=chkAllEventsInOneGroup(cpn)))
		return bet_error(errHint,0);
	else if (IsEmptyCoupon(cpn))
		return bet_error(600,0);
	else if ((errHint=chkInvalidEvent(cpn)) && (sjp_nr==0) )
		return bet_error(501,errHint);
	else if (chkZeroSystemAlone(matches,standards))
		return bet_error(515,0);
	else if (chkAmount(cpn) && bCheckAmount)
		return bet_error(914,0);

	unsigned long temp=0;
	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		temp=0;

		if (req & (1<<i))
		{
			temp=CalculateColumns(matches, standards, i+1, Dbls, std_tbl);

			temp *= req_mult[i];

			if (temp >= UpperLimit)
				return bet_error(309,0);
		}

		totalc+=temp;
		if (totalc>=unsigned(UpperLimit))
		{
			return bet_error(309,0);
		}
		if (totalc * getColumnCost() > LONG_MAX)
		{
			return bet_error(309,0);
		}
	}

	totalc*=getTriples();

	btotcol[cpn] = totalc;


	if (chkLimits(cpn))
		return bet_error(309,0);
	if (cpn!=CurrentCoupon)
		UpdateBetStruct(CurrentCoupon);

	return 1;

}

/// Update the state of the Add, Previous, Finish buttons
void FlexBet::SetButtonsState()
{
	bool CouponIsOk;
//	char fname[1024];

	//WaitForm wait;
	CouponIsOk=CheckCoupon(CurrentCoupon)==1;
	bool FinishState=CouponIsOk||IsEmptyCoupon(CurrentCoupon);

	if (FinishState)
	{
		if (EditScanned)
		{
			//EditScanned=false;
			UpdateArea();
		}

		QString strTotalCost = TotalCpnsCostText->text();
		strTotalCost.remove(".");
		strTotalCost.remove(",");
		strTotalCost.remove("0");
		Finish->setEnabled( strTotalCost.length() );
		sprintf(g_bet_err_txt,"%s", qApp->translate("FlexBet","NO ERRORS\nPress Finish to Send").utf8().data());
		if (IsEmptyCoupon(CurrentCoupon))
			sprintf(g_bet_err_txt,"%s", qApp->translate("FlexBet","Empty Coupon\nPress Finish to Exit").utf8().data());

	}
	else
		Finish->setEnabled(false);

	if (EnableInsertBetTypes==true)
		btnBetTypeAccept->setEnabled(true);
	else
		btnBetTypeAccept->setEnabled(false);
}

/// Check if the current coupon is the first one or not.
bool FlexBet::PreviousCouponExists()
{
	if (CurrentCoupon>0)
		return true;
	return false;
}

/// Check if the current coupon is the last or not.
bool FlexBet::NextCouponExists()
{
	if (CurrentCoupon<CompletedCoupons)
		return true;
	return false;
}


/// Returns the coupon's cost
double FlexBet::CouponMoney(int cpn)
{

	btotcol[cpn]=0;
	//WaitForm wait;
	if (CheckCoupon(cpn)!=1)
		return 0;

	return btotcol[cpn]*getColumnCost();
}

void FlexBet::SetDefaultStake()
{
    return; //no preselected amount

	bool StakeMarked = false;
	for (int i=0; i<NUM_O_STAKES; i++)
	{
		if( CouponRec[0].Marks[OFFSET_OF_STAKE+i] )
		{
			StakeMarked = true;
			break;
		}
	}
	if( !StakeMarked )
	{
		CouponRec[0].Marks[OFFSET_OF_STAKE] = 1;
		cpnMultiply = DEFAULT_STAKE;
	}
}

/**
	Updates the information fot the columns, coupon's cost etc.
**/
void FlexBet::UpdateMoney()
{
	unsigned long totalcolumns=CouponColumns(CurrentCoupon);
	double couponCost = getColumnCost() * totalcolumns;

	MultText->setText(QString::number(totalcolumns*cpnMultiply));

	double TotalCpnsCost=0.0;
	for (int i=0; i<CompletedCoupons+1; i++)
	{
		totalcolumns=CouponColumns(i);
		couponCost = getColumnCost() * totalcolumns;
		TotalCpnsCost+=couponCost;
	}

//    TotalCpnsCostText->setText(QString("%L1").arg( AmountFunctions::getAmountStr(TotalCpnsCost*cpnMultiply) ) ); //(TotalCpnsCost*cpnMultiply,0,'f',2).ascii());
	TotalCpnsCostText->setText(QString("%L1").arg( (int)TotalCpnsCost*cpnMultiply ) ); // aste : No need for 2 decimal sigits in CH
//    TotalCpnsCostText->update();
}

/// Returns the coupon's columns
unsigned long FlexBet::CouponColumns(int cpn)
{
	btotcol[cpn]=0;
	//WaitForm wait;
	if (CheckCoupon(cpn)!=1)
		return 0;

	/*btotcol[cpn] already calculated by check coupon*/
	return btotcol[cpn];//CouponRec[0].Info.TotalColumns;
}

/**
	Calculates which permutations and their corresponding multipliers are selected.
**/
void FlexBet::UpdateArea()
{
	char temp[256];
	bool exists=false;

	SystemsMultipliers *temp3 = new SystemsMultipliers(false, this);
	temp3->setFlexBet(this);
	temp3->setCouponMarks(CouponRec[CurrentCoupon], NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
	temp3->calculateIt();
	temp3->getResults(cpnPerm, cpnPermMult, cpnMultiply);
	delete temp3;

	sprintf(temp,"%d",cpnMultiply);
	MultText->setText(temp);

	QString sys="";

	for (int i=0; i<NUM_O_PERMS-1; i++)
	{
		if (cpnPerm[i]>0)
		{
			if (sys.length())
				sys.append(QString(", "));

			sys=sys.append(QString::number(i)+QString("(%1)").arg(cpnPermMult[i]));
			exists=true;
		}
	}
	if (cpnPerm[NUM_O_PERMS-1]>0)
	{
		sys=sys.append(qApp->translate("FlexBet"," ALL"));
		exists=true;
	}

	if (exists)
	{
		SysText->setText(sys);//(temp);
	}
	else
		SysText->setText("-");
}

///  Assumes CouponRec[0].Reply.Reply contains Approved data returned from the host
///  Fills new coupon record for host
int FlexBet::ConvertToPlayReply(CouponRecord &CurrentCouponRecord)
{
//	int cpn=CurrentCoupon=0;

	char HostReplySim[MAXRECORDLEN];
	char *HostReply = &CurrentCouponRecord.HostReply[0];
	char *Record = &CurrentCouponRecord.Record[0];
	REPLY_50_5 reply_50_5_sim;
	TRNS_GM_15000 trns_gm_15000_sim;

	//--------------- real reply --------------------------
	REPLY_50_5 *reply_50_5 = (REPLY_50_5 *) &HostReply[sizeof(CSS_IT_1)];
	TRNS_GM_15000 *trns_gm_15000 = (TRNS_GM_15000 *) &HostReply[sizeof(CSS_IT_1)+sizeof(REPLY_50_5)];
	RTRNS_GM_15000 *rtrns_gm_15000 = (RTRNS_GM_15000 *) &HostReply[sizeof(CSS_IT_1)+sizeof(REPLY_50_5)+sizeof(TRNS_GM_15000)];
	RTRNS_CD_15000 *repData = (RTRNS_CD_15000 *) (&HostReply[sizeof(CSS_IT_1)+sizeof(REPLY_50_5)+sizeof(TRNS_GM_15000)+sizeof(RTRNS_GM_15000)]);
	memcpy(&reply_50_5_sim,reply_50_5,sizeof(REPLY_50_5));
	memcpy(&trns_gm_15000_sim,trns_gm_15000,sizeof(TRNS_GM_15000));


	//--------------- simulated reply ---------------------
	//css_it_1
	CSS_IT_1 *css_it_1 = (CSS_IT_1 *) &HostReplySim[0];
	memcpy( css_it_1, HostReply, sizeof ( CSS_IT_1 ) );
	//reply_100_1
	REPLY_100_1 *reply_100_1 = ( REPLY_100_1 * ) &HostReplySim[sizeof ( CSS_IT_1 ) ];
	memset(reply_100_1,0x00,sizeof(REPLY_100_1));
	reply_100_1->game = reply_50_5->game;
	reply_100_1->data[0] = reply_50_5->draw;
	reply_100_1->data[1] = reply_50_5->clms;
	reply_100_1->data[3] = reply_50_5->draw;
	reply_100_1->data[4]=reply_50_5->ddln;
	double dAmount = reply_50_5->clms * getColumnCost();
	ConvertDoubleToAMOUNTSTRC ( dAmount,(AMOUNT_STRC*)&reply_100_1->amount);
	//RTRNS_GM_15000
	RTRNS_GM_15000 *rtrns_gm_15000_sim = (RTRNS_GM_15000 *) &HostReplySim[sizeof(CSS_IT_1)+sizeof(REPLY_100_1)];
	memcpy(rtrns_gm_15000_sim,rtrns_gm_15000,sizeof(RTRNS_GM_15000));
	//RTRNS_CD_15000
	RTRNS_CD_15000 *repData_sim = (RTRNS_CD_15000 *) &HostReplySim[sizeof ( CSS_IT_1 ) +sizeof ( REPLY_100_1 ) +sizeof ( RTRNS_GM_15000 ) ];
	memcpy(repData_sim,repData,(sizeof(RTRNS_CD_15000)*rtrns_gm_15000_sim->recs));
	//LAST CALL FOR SIMULATION
	memcpy(HostReply,HostReplySim,sizeof ( CSS_IT_1 ) +sizeof ( REPLY_100_1 ) +sizeof ( RTRNS_GM_15000 )+(sizeof(RTRNS_CD_15000)*rtrns_gm_15000_sim->recs));

	//--------------- simulated record ---------------------
	memset(&CurrentCouponRecord.Record[0],0x00,sizeof(CurrentCouponRecord.Record));
	IT_CSS_4 *header = (IT_CSS_4 *)(&CurrentCouponRecord.Record[0]);

	//IT_CSS_4
	header->data[0]= IFLEX_GAMECODE;
	header->data[1]=1;
	header->data[2]=1;

	//TRNS_CPN_HDR
	TRNS_CPN_HDR *trns_cpn_hdr = (TRNS_CPN_HDR *) &Record[sizeof(IT_CSS_4)]; //there is not actually a record!
	memcpy( trns_cpn_hdr, &reply_50_5_sim.hdr, sizeof ( TRNS_CPN_HDR ) );

	//trns_gm
	trns_gm_15000 = (TRNS_GM_15000 *) ( &CurrentCouponRecord.Record[sizeof ( IT_CSS_4 ) +sizeof ( TRNS_CPN_HDR ) ] );
	memcpy(trns_gm_15000,&trns_gm_15000_sim,sizeof(TRNS_GM_15000));

	//--------------- info coupon ------------------------
	//CurrentCouponRecord.Info.RecordLen=sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)+sizeof(TRNS_GM_15000);
	//header->hdr.size=CurrentCouponRecord.Info.RecordLen; //+sizeof(COMM_MSG)

	//--------------- end of conversion ------------------------
	return 1;
}

/// Calculate the number of standards, which bets are double, etc. from the coupon's record
void FlexBet::GroupingAdjustmentFromRec(TRNS_GM_15000 *trns_gm_15000, unsigned char *storage,unsigned char *std_tbl,
										unsigned char &count, unsigned char &std_count,int cpn,bool replay)
{
	Q_UNUSED(cpn);

	bool wait=true;

	memset(storage,1,TOT_CPN_AREAS); //sizeof(storage)); //TOCHECK TO_CHECK TODO TO_DO
	memset(std_tbl,0,TOT_CPN_AREAS); //sizeof(std_tbl));
	count=std_count=0;

	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		if (replay && trns_gm_15000->data.ev_bet.data[i].val==99000)
		{
			continue;
		}
		if (trns_gm_15000->data.ev_bet.data[i].val_flg%100 > 0
				&& trns_gm_15000->data.ev_bet.data[i].val_flg%100 <= 10)
		{
			//if it belongs to a group then don't increase index as
			//we consider them as one event
			wait=false;
			for (int j=i+1; j<TOT_CPN_AREAS; j++)
				if (trns_gm_15000->data.ev_bet.data[i].val_flg==trns_gm_15000->data.ev_bet.data[j].val_flg)
					wait=true;
			if (!wait)
			{
				for (int j=0; j<i; j++)
				{
					if (trns_gm_15000->data.ev_bet.data[i].val_flg==trns_gm_15000->data.ev_bet.data[j].val_flg
							&& trns_gm_15000->data.ev_bet.data[j].val_flg%100 <= 10)
					{

						if ( ( (trns_gm_15000->data.ev_bet.data[j].val%1000>=FINAL_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FINAL_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=FstHALF_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FstHALF_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=SndHALF_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=SndHALF_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=FINALHC_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FINALHC_X2 )) )
							// if not 1 or X or 2 is played alone then
							// double final result selection
							// meaning one more game played
							storage[count] *= 2;
					}
				}

				if ( ( (trns_gm_15000->data.ev_bet.data[i].val%1000>=FINAL_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINAL_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=FstHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FstHALF_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=SndHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=SndHALF_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=FINALHC_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINALHC_X2 )) )
					storage[count] *= 2;
				if (trns_gm_15000->data.ev_bet.data[i].val_flg>=100)
				{
					std_tbl[count]=1;
					std_count++;
				}
				// if reached the last grouped game then increase index
				count++;
			}
		}
		else if (trns_gm_15000->data.ev_bet.data[i].val_flg%100 > 10)
		{
			// just as above we consider only one
			wait=false;
			for (int j=i+1; j<TOT_CPN_AREAS; j++)
				if (trns_gm_15000->data.ev_bet.data[i].val_flg==trns_gm_15000->data.ev_bet.data[j].val_flg)
					wait=true;
			if (!wait)
			{
				// if reached the last grouped event
				for (int j=0; j<i; j++)
				{
					if (trns_gm_15000->data.ev_bet.data[i].val_flg==trns_gm_15000->data.ev_bet.data[j].val_flg
							&& trns_gm_15000->data.ev_bet.data[j].val_flg%100 > 10)
					{
						// count how many events belong to the same group
						// and increase the number of different codes
						// this group participates
						storage[count]++;

						if ( ( (trns_gm_15000->data.ev_bet.data[j].val%1000>=FINAL_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FINAL_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=FstHALF_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FstHALF_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=SndHALF_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=SndHALF_X2 ) ||
								(trns_gm_15000->data.ev_bet.data[j].val%1000>=FINALHC_1X && trns_gm_15000->data.ev_bet.data[j].val%1000<=FINALHC_X2 )) && trns_gm_15000->data.ev_bet.data[j].val/100000 >= NORMAL_BETTYPES_STARTINGCODE )
							//if not 1 or X or 2 is played alone then
							//double final result selection
							//meaning one more game played
							storage[count]++;
					}
				}
				if ( ( (trns_gm_15000->data.ev_bet.data[i].val%1000>=FINAL_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINAL_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=FstHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FstHALF_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=SndHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=SndHALF_X2 ) ||
						(trns_gm_15000->data.ev_bet.data[i].val%1000>=FINALHC_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINALHC_X2 )) && trns_gm_15000->data.ev_bet.data[i].val/100000 >= NORMAL_BETTYPES_STARTINGCODE )
					storage[count]++;
				if (trns_gm_15000->data.ev_bet.data[i].val_flg >= 100)
				{
					std_tbl[count]=1;
					std_count++;
				}
				// and of course increase the index
				count++;
			}
		}
		else if (trns_gm_15000->data.ev_bet.data[i].val_flg%100==0
				 && trns_gm_15000->data.ev_bet.data[i].val>0)
		{
			// if the event is not grouped then it participates with one game

			if ( ( (trns_gm_15000->data.ev_bet.data[i].val%1000>=FINAL_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINAL_X2 ) ||
					(trns_gm_15000->data.ev_bet.data[i].val%1000>=FstHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FstHALF_X2 ) ||
					(trns_gm_15000->data.ev_bet.data[i].val%1000>=SndHALF_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=SndHALF_X2 ) ||
					(trns_gm_15000->data.ev_bet.data[i].val%1000>=FINALHC_1X && trns_gm_15000->data.ev_bet.data[i].val%1000<=FINALHC_X2 )) && trns_gm_15000->data.ev_bet.data[i].val/100000 >= NORMAL_BETTYPES_STARTINGCODE )
				// if not 1 or X or 2 is played alone then double final result selection
				// meaning one more game played
				storage[count]++;
			if (trns_gm_15000->data.ev_bet.data[i].val_flg>=100)
			{
				std_tbl[count]=1;
				std_count++;
			}
			count++;
		}
	}
}

int FlexBet::Play(int stage,int action) {
	int lerror=-1;
	Stage=stage;
	Action=action;

	ExistingCoupons=0;

	CouponOriginFromScanner=0;

	if (1!=(lerror=ShowForm()))
		return lerror;

	return CompletedCoupons;
}

/**
	It calculates all the events codes of the coupon.
**/
void FlexBet::calculateEvent(int cpn)
{
	int i,j,tempMarks[NUM_O_PLAYSLIP_EVENT_MULT+NUM_O_PLAYSLIP_EVENT_MARKS];
	int cnt,cntAll,cntTh,tempEvent,tempEvent1,tempEvent2;
	memset(tempMarks,0,sizeof(tempMarks));
	bool morePerLine;

	for (int area=0; area<lastSection[cpn]+1; area++)
	{
		tempEvent=tempEvent1=tempEvent2=0;
		cntAll=0;
		cntTh=0;
		morePerLine=false;

		for (i=0; i<NUM_O_PLAYSLIP_EVENT_MULT+NUM_O_PLAYSLIP_EVENT_MARKS; i++)
			tempMarks[i]=(CouponRec[cpn].Marks[area*AREA_MARKS+i]);

		for (i=0; i<NUM_O_PLAYSLIP_EVENT_MULT; i++)
		{
			if (tempMarks[i])
			{
				cntTh++;
				tempEvent1+=(i+1)*1000;
			}
		}

		for (i=0; i<3; i++)
		{
			cnt=0;
			for (j=0; j<10; j++)
			{
				if (tempMarks[NUM_O_PLAYSLIP_EVENT_MULT+j+i*10])
				{
					cnt++;
					cntAll++;
					tempEvent2+=j*(int)pow(10,(2-i));
				}
			}
			if (cnt>1)
				morePerLine=true;
		}

		tempEvent=tempEvent1+tempEvent2;
		if (morePerLine || cntAll!=3)
			tempEvent=EMPTY_AREA;
		if (!cntAll && !cntTh)
			tempEvent=EMPTY_AREA;


		event[area].choice=tempEvent;
	}
}

/**
	It finds the index of the coupon's last event
**/
void FlexBet::CalculateLastSect(int coupon)
{
	int i,j;
	lastSection[coupon]=-1;

	if (ScannedCoupon || EditScanned)
	{
		for (i=0; i<TOT_CPN_AREAS; i++)
		{
			for (j=0; j<AREA_MARKS; j++)
			{
				if (CouponRec[coupon].Marks[i*AREA_MARKS+j])
				{
					lastSection[coupon]=i;//even one Mark in an area sets it as last section
					break;
				}
			}
		}
	}
	else
		lastSection[coupon]= CouponsTable->CouponsList[coupon].count()-1;
}



/**
	This procedure updates the struct that holds the events information
	from the coupon's record
**/
void FlexBet::UpdateBetStructM(int cpn)
{
	bool isSJP=false;
	sjp_nr=0;
	sjpMatches=0;

	CalculateLastSect(cpn);

	for(int i=0;i<NUM_O_SJP;i++)
	{
		if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i]==1)
		{
			//SjpNumSelected[i]=true;
			isSJP=true;
			sjp_nr=i+1;//sjp_nr=i+10;
			sjpMatches=lastSection[cpn]+1;
			break;
		}
	}

	memset(event,0,sizeof(event));
	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		event[i].choice=EMPTY_AREA;
		event[i].betType=-1;
		event[i].random=false;
		event[i].group=0;
		event[i].standard=false;
		BetDescription[i]="";
	}

	if(isSJP)
	{
		for (int i=0; (i<lastSection[cpn]+1 && i<TOT_CPN_AREAS); i++)
			event[i].choice=0;
	}
	else
		calculateEvent(cpn);

	for (int i=0; (i<lastSection[cpn]+1 && i<TOT_CPN_AREAS); i++)
	{
		setEventCode(event[i].choice);

		if ((event[i].choice>=0 && event[i].choice<MAX_EVENT_CODE) )
		{
			calculateBet(CouponRec[cpn],i);
			event[i].betType=getRecordCode();
			event[i].standard=isStandard(CouponRec[cpn],i);
			getGroupNumber(i,event[i].random,event[i].group,&CouponRec[cpn]);
			if (event[i].betType>=0)
			{
				BetDescription[i]=getBetTypeDescription();
				if (BetDescription[i]==QString("- -"))
				{
					event[i].betType=-1;

				}
			}
			else
				BetDescription[i]="-";
		}
		else
		{
			if( sjp_nr )
			{
				calculateBet(CouponRec[cpn],i);
				event[i].betType=getRecordCode();
			}
			else
			{
				BetDescription[i]="- -";
				event[i].betType=-1;
			}
		}
	}
	SystemsMultipliers *temp3 = new SystemsMultipliers(false, this);
	temp3->setFlexBet(this);
	temp3->setCouponMarks(CouponRec[cpn], NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
	temp3->calculateIt();
	temp3->getResults(cpnPerm, cpnPermMult, cpnMultiply);
	delete temp3;


	return;
}

/// Calculates the event's value for the coupon record
unsigned long FlexBet::evaluateRecordVal(int area)
{
	unsigned long code=0;

	if(sjp_nr && event[area].betType==-1)
	{
		return code;
	}

	if( event[area].choice==EMPTY_AREA && sjp_nr )
		event[area].choice=0;

	if (event[area].choice!=EMPTY_AREA)
	{
		code = event[area].choice;  //set the choice
		code *= 100000;             //offset to the right place (eee99ccc)
		code += 99*1000;            //add the 99 to the middle places

		if (event[area].betType!=-1)
			code+=event[area].betType;
	}

	return code;
}

/// Calculates the value of the groups for the coupon record
unsigned char FlexBet::evaluateRecordFlags(int area)
{
	unsigned char flag=0;
	unsigned char choose[]={1,2,3,4};
	int remain;

	if ((remain=event[area].group))
	{
		for (int i=0; i<NUM_O_GROUPS; i++)
		{
			if (remain/((int)pow(10,3-i)))
			{
				remain=remain%((int)pow(10,3-i));
				if (!flag)
					flag = choose[i];
				else
				{
					flag = 2*flag + choose[i] + 1;
					if (flag>10)//because CD group evals to 11 so ...
						flag=10;
				}
			}
		}
		if (event[area].random)
			flag += 10;
	}

	if (event[area].standard)
		flag+=100;

	return flag;
}

/// copy the MARKS array from 'lastSection' to the one at 'pos'
/// shift all active games after current up one position
void FlexBet::MoveLastGameHere(int cpn,int pos)
{
	if ((lastSection[cpn]<0) || (lastSection[cpn]>(TOT_CPN_AREAS-1)) || (pos >= (TOT_CPN_AREAS - 1)) || (pos >= lastSection[cpn]))
		return;

	int index=pos+1;
	for (int i=pos; i<lastSection[cpn]; i++)
	{
		memset(&CouponRec[cpn].Marks[i*AREA_MARKS],0,AREA_MARKS);
		while (index<=lastSection[cpn])
		{
			if (!IsEmpty(cpn,index))
			{
				memcpy(&CouponRec[cpn].Marks[i*AREA_MARKS],&CouponRec[cpn].Marks[index*AREA_MARKS],AREA_MARKS);
				index++;
				break;
			}
			index++;
		}
	}

	int last_filled_area = lastSection[cpn];
	memset(&CouponRec[cpn].Marks[last_filled_area*AREA_MARKS],0,AREA_MARKS);
}

/**
	Updates the bets' struct from the record. Is called when we edit a ascanned coupon
**/
void FlexBet::UpdateGame(CouponRecord &CurrentCouponRecord, int cpn)
{

	TRNS_GM_15000 *trns_gm_15000 = (TRNS_GM_15000 *)(&CurrentCouponRecord.Record[sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)]);
	bool foundEmptyLoc=false;
	memset(event,0,sizeof(event));
	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		event[i].choice=EMPTY_AREA;
		event[i].betType=-1;
		event[i].random=false;
		event[i].group=0;
		BetDescription[i]="";
	}

//    sjp_nr=trns_gm_15000->sjp_nr;
	lastSection[cpn]=-1;

	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		if (trns_gm_15000->data.ev_bet.data[i].val)
			lastSection[cpn]=i;
	}

	for (int area=0; area<TOT_CPN_AREAS/2; area++)
	{
		if (lastSection[cpn]!=-1 && area<lastSection[cpn]
				&& (!IsEmpty(cpn,lastSection[cpn])) && (IsEmpty(cpn,area))/* && (!event[area].group && !event[area].random)*/)
		{
			MoveLastGameHere(cpn,area);
			foundEmptyLoc=true;
		}
	}

	int k=0;
	int pos;
	for (int i=0; i<(lastSection[cpn]+1); i++)
	{
		if((trns_gm_15000->data.ev_bet.data[i].val) || (trns_gm_15000->data.ev_bet.data[i].val==0 && sjp_nr && i<lastSection[cpn]+1))
		{
			pos=foundEmptyLoc?k:i;
			event[pos].choice= trns_gm_15000->data.ev_bet.data[i].val/100000;

			setEventCode(event[pos].choice);


			if ((event[pos].choice>=0 && event[pos].choice<MAX_EVENT_CODE))
			{
				calculateBet(CurrentCouponRecord,pos);
				event[pos].betType=getRecordCode();
				if (event[pos].betType>=0)
				{
					BetDescription[pos]=getBetTypeDescription();
					if (BetDescription[pos]=="- -")
					{
						event[pos].betType=-1;
						//BetDescription[i]="";
					}
				}
				else
					BetDescription[pos]="- -";
			}
			else
			{
				BetDescription[pos]="- -";
				event[pos].betType=-1;
			}

			event[pos].standard=isStandard(CurrentCouponRecord,pos);
			getGroupNumber(pos,event[pos].random,event[pos].group,&CurrentCouponRecord);
			k++;
		}
	}

	SystemsMultipliers *temp2 = new SystemsMultipliers(false, this);
	temp2->setFlexBet(this);
	temp2->setCouponMarks(CurrentCouponRecord, NUM_O_PERMS+NUM_O_STAKES_MULTS+(NUM_O_SYSTEMMULTS*(NUM_O_PERMS-1)));
	temp2->calculateIt();
	temp2->getResults(cpnPerm, cpnPermMult, cpnMultiply);
	delete temp2;

	return;

}

/// Create the record buffer
void FlexBet::RecordCoupon(int cpn)
{
	unsigned char codes_count=0;
	unsigned char std_count=0;
	unsigned char Dbls[TOT_CPN_AREAS];
	unsigned char std_tbl[TOT_CPN_AREAS];

	IT_CSS_4 *header = reinterpret_cast<IT_CSS_4 *>(&CouponRec[cpn].Record[0]);
	TRNS_CPN_HDR *trns_cpn_hdr = reinterpret_cast<TRNS_CPN_HDR *>(&CouponRec[cpn].Record[sizeof(IT_CSS_4)]);
	TRNS_GM_15000 *trns_gm_15000 = reinterpret_cast<TRNS_GM_15000 *>(&CouponRec[cpn].Record[sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)]);
	memset(trns_gm_15000,0x00,sizeof(TRNS_GM_15000));

	memset(Dbls,1,sizeof(Dbls));
	memset(std_tbl,0,sizeof(std_tbl));

	memset(CouponRec[cpn].Record,0,sizeof(CouponRec[cpn].Record));

	if (ScannedCoupon)
		UpdateBetStructM(cpn);
	else
		UpdateBetStruct(cpn);

	header->data[0]= IFLEX_GAMECODE;
	header->data[1]= (Stage == MOD_STAGE_RECORD && Action == MOD_ACTION_CHECK_CPN) ? 0 : 1;

	//  Type: Coupon Type
	header->data[2]=1;
	trns_cpn_hdr->flags=0; //No proto or qpick or other strange playing method
	trns_cpn_hdr->data[0] = cpnMultiply; //multiplier;
	//Multiple DRAWS
	trns_cpn_hdr->data[1] = 1; // Only idiots play multidraws in betting games!
	//groups
	trns_cpn_hdr->grps=1; //Always one played area in bet

	trns_gm_15000->sgm = 0;// FlexBet has not a subgame
	//    trns_gm_15000->odds_rev = 0; //if needed this will be filled by the central system
	trns_gm_15000->app = 0;//The approved coupon record is not handled here
//    trns_gm_15000->sjp_nr=sjp_nr; //SJP

	for (int i=0; i<TOT_CPN_AREAS; i++)
	{
		//record the vals needed in grp102_bet1 part of the record
		//record the codes in the form eee99ccc (eee the Event, ccc the prediction code)
		//using the evnt/code - coupon marks correlation table (lotos mesages doc)
		trns_gm_15000->data.ev_bet.data[i].val = evaluateRecordVal(i);
		//record the value flags (specific for each code)
		//this sets if and in which group the code belongs and if it is standard
		trns_gm_15000->data.ev_bet.data[i].val_flg = evaluateRecordFlags(i);
	}

	GroupingAdjustment(Dbls,std_tbl,codes_count,std_count);
	//=====================
	trns_gm_15000->req = evaluateRequestRec(cpn,codes_count,std_count, trns_gm_15000->data.ev_bet.req_mult);
//    //=====================
//    int eventCodes[30];
//    memset(eventCodes,EMPTY_AREA,sizeof(eventCodes));
//    for (int i=0; i<codes_count; i++)
//        eventCodes[i]=event[i].choice;
//    trns_gm_15000->delay=m_pApp->getMaximumDelay(eventCodes,codes_count);
}

bool FlexBet::isTeamCouponsPlay()
{
	REPLY_100_1 *reply_100_1=(REPLY_100_1 *)(&CouponRec[0].HostReply[sizeof(CSS_IT_1)]);

	if (reply_100_1->data[8])
	{
		m_NumOfTeams = reply_100_1->data[8];
		return true;
	}
	else
	{
		m_NumOfTeams=0;
		return false;
	}
}

unsigned long FlexBet::CalculateColumns(unsigned char played, unsigned char tot_std, unsigned char req,
										unsigned char *Dbls, unsigned char *std_tbl)
{
	unsigned long tot_cmbs_nr=0;
	unsigned char c0 ,c1 ,c2 ,c3 ,c4 ,c5 ,c6 ,c7 ,c8 ,c9 ,c10,c11,c12,c13,c14;
	unsigned char c15,c16,c17,c18,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29;
	unsigned char clm_std;

	for (c0 = 0; c0 < played - req + 1 && (req - 1) >= 0; c0++)   // loop 1
	{
		if (req - 1 == 0)
		{
			if (tot_std)
			{
				clm_std = std_tbl[c0];
				if (clm_std != tot_std)
					continue;
			}
			tot_cmbs_nr += Dbls[c0];
		}
		for (c1 = c0 + 1; c1 < played - req + 2 && (req - 2) >= 0; c1++)   // loop 2
		{
			if (req - 2 == 0)
			{
				if (tot_std)
				{
					clm_std = std_tbl[c0] + std_tbl[c1];
					if (clm_std != tot_std)
						continue;
				}
				tot_cmbs_nr += Dbls[c0]*Dbls[c1];
			}
			for (c2 = c1 + 1; c2 < played - req + 3 && (req - 3) >= 0;  c2++)   // loop 3
			{
				if (req - 3 == 0)
				{
					if (tot_std)
					{
						clm_std = std_tbl[c0] + std_tbl[c1] + std_tbl[c2];
						if (clm_std != tot_std)
							continue;
					}
					tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2];
				}
				for (c3 = c2 + 1; c3 < played - req + 4 && (req - 4) >= 0; c3++)   // loop 4
				{
					if (req - 4 == 0)
					{
						if (tot_std)
						{
							clm_std = std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3];
							if (clm_std != tot_std)
								continue;
						}
						tot_cmbs_nr +=Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3];
					}
					for (c4 = c3 + 1; c4 < played - req + 5 && (req - 5) >= 0; c4++)   // loop 5
					{
						if (req - 5 == 0)
						{
							if (tot_std)
							{
								clm_std = std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4];
								if (clm_std != tot_std)
									continue;
							}
							tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4];
						}
						for (c5 = c4 + 1; c5 < played - req + 6 && (req - 6) >= 0; c5++)   // loop 6
						{
							if (req - 6 == 0)
							{
								if (tot_std)
								{
									clm_std = std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5];
									if (clm_std != tot_std)
										continue;
								}
								tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5];
							}
							for (c6 = c5 + 1; c6 < played - req + 7 && (req - 7) >= 0; c6++)   // loop 7
							{
								if (req - 7 == 0)
								{
									if (tot_std)
									{
										clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4] + std_tbl[c5] + std_tbl[c6];
										if (clm_std != tot_std)
											continue;
									}
									tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6];
								}
								for (c7 = c6 + 1; c7 < played - req + 8 && (req - 8) >= 0; c7++)   // loop 8
								{
									if (req - 8 == 0)
									{
										if (tot_std)
										{
											clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7];
											if (clm_std != tot_std)
												continue;
										}
										tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7];
									}
									for (c8 = c7 + 1; c8 < played - req + 9 && (req - 9) >= 0; c8++)   // loop 9
									{
										if (req - 9 == 0)
										{
											if (tot_std)
											{
												clm_std = std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8];
												if (clm_std != tot_std)
													continue;
											}
											tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8];
										}
										for (c9 = c8 + 1; c9 < played - req + 10 && (req - 10) >= 0; c9++)   // loop 10
										{
											if (req - 10 == 0)
											{
												if (tot_std)
												{
													clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9];
													if (clm_std != tot_std)
														continue;
												}
												tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9];
											}

											for (c10 = c9 + 1; c10 < played - req + 11 && (req - 11) >= 0; c10++)   // loop 11
											{
												if (req - 11 == 0)
												{
													if (tot_std)
													{
														clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10];
														if (clm_std != tot_std)
															continue;
													}
													tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10];
												}
												for (c11 = c10 + 1; c11 < played - req + 12 && (req - 12) >= 0; c11++)   // loop 12
												{
													if (req - 12 == 0)
													{
														if (tot_std)
														{
															clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11];
															if (clm_std != tot_std)
																continue;
														}
														tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11];
													}
													for (c12 = c11 + 1; c12 < played - req + 13 && (req - 13) >= 0; c12++)   // loop 13
													{
														if (req - 13 == 0)
														{
															if (tot_std)
															{
																clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12];
																if (clm_std != tot_std)
																	continue;
															}
															tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12];
														}
														for (c13 = c12 + 1; c13 < played - req + 14 && (req - 14) >= 0; c13++)   // loop 14
														{
															if (req - 14 == 0)
															{
																if (tot_std)
																{
																	clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13];
																	if (clm_std != tot_std)
																		continue;
																}
																tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12]*Dbls[c13];
															}
															for (c14 = c13 + 1; c14 < played - req + 15 && (req - 15) >= 0; c14++)   // loop 15
															{
																if (req - 15 == 0)
																{
																	if (tot_std)
																	{
																		clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14];
																		if (clm_std != tot_std)
																			continue;
																	}
																	tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12]*Dbls[c13]*Dbls[c14];
																}
																for (c15 = c14 + 1; c15 < played - req + 16 && (req - 16) >= 0; c15++)   // loop 16
																{
																	if (req - 16 == 0)
																	{
																		if (tot_std)
																		{
																			clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15];
																			if (clm_std != tot_std)
																				continue;
																		}
																		tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12]*Dbls[c13]*Dbls[c14]*Dbls[c15];
																	}
																	for (c16 = c15 + 1; c16 < played - req + 17 && (req - 17) >= 0; c16++)   // loop 17
																	{
																		if (req - 17 == 0)
																		{
																			if (tot_std)
																			{
																				clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+std_tbl[c16];
																				if (clm_std != tot_std)
																					continue;
																			}
																			tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12]*Dbls[c13]*Dbls[c14]*Dbls[c15]*Dbls[c16];
																		}
																		for (c17 = c16 + 1; c17 < played - req + 18 && (req - 18) >= 0; c17++)   // loop 18
																		{
																			if (req - 18 == 0)
																			{
																				if (tot_std)
																				{
																					clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+std_tbl[c16]+std_tbl[c17];
																					if (clm_std != tot_std)
																						continue;
																				}
																				tot_cmbs_nr += Dbls[c0]*Dbls[c1]*Dbls[c2]*Dbls[c3]*Dbls[c4]*Dbls[c5]*Dbls[c6]*Dbls[c7]*Dbls[c8]*Dbls[c9]*Dbls[c10]*Dbls[c11]*Dbls[c12]*Dbls[c13]*Dbls[c14]*Dbls[c15]*Dbls[c16]*Dbls[c17];
																			}
																			for (c18 = c17 + 1; c18 < played - req + 19 && (req - 19) >= 0; c18++)   // loop 19
																			{
																				if (req - 19 == 0)
																				{
																					if (tot_std)
																					{
																						clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18];
																						if (clm_std != tot_std)
																							continue;
																					}
																					tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18];
																				}
																				for (c19 = c18 + 1; c19 < played - req + 20 && (req - 20) >= 0; c19++)   // loop 20
																				{
																					if (req - 20 == 0)
																					{
																						if (tot_std)
																						{
																							clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19];
																							if (clm_std != tot_std)
																								continue;
																						}
																						tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19];
																					}
																					for (c20 = c19 + 1; c20 < played - req + 21 && (req - 21) >= 0; c20++)   // loop 21
																					{
																						if (req - 21 == 0)
																						{
																							if (tot_std)
																							{
																								clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20];
																								if (clm_std != tot_std)
																									continue;
																							}
																							tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20];
																						}
																						for (c21 = c20 + 1; c21 < played - req + 22 && (req - 22) >= 0; c21++)   // loop 22
																						{
																							if (req - 22 == 0)
																							{
																								if (tot_std)
																								{
																									clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21];
																									if (clm_std != tot_std)
																										continue;
																								}
																								tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21];
																							}
																							for (c22 = c21 + 1; c22 < played - req + 23 && (req - 23) >= 0; c22++)   // loop 23
																							{
																								if (req - 23 == 0)
																								{
																									if (tot_std)
																									{
																										clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22];
																										if (clm_std != tot_std)
																											continue;
																									}
																									tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22];
																								}
																								for (c23 = c22 + 1; c23 < played - req + 24 && (req - 24) >= 0; c23++)   // loop 24
																								{
																									if (req - 24 == 0)
																									{
																										if (tot_std)
																										{
																											clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23];
																											if (clm_std != tot_std)
																												continue;
																										}
																										tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23];
																									}
																									for (c24 = c23 + 1; c24 < played - req + 25 && (req - 25) >= 0; c24++)   // loop 25
																									{
																										if (req - 25 == 0)
																										{
																											if (tot_std)
																											{
																												clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24];
																												if (clm_std != tot_std)
																													continue;
																											}
																											tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24];
																										}
																										for (c25 = c24 + 1; c25 < played - req + 26 && (req - 26) >= 0; c25++)   // loop 26
																										{
																											if (req - 26 == 0)
																											{
																												if (tot_std)
																												{
																													clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24] +std_tbl[c25];
																													if (clm_std != tot_std)
																														continue;
																												}
																												tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24] * Dbls[c25];
																											}
																											for (c26 = c25 + 1; c26 < played - req + 27 && (req - 27) >= 0; c26++)   // loop 27
																											{
																												if (req - 27 == 0)
																												{
																													if (tot_std)
																													{
																														clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24] +std_tbl[c25] +std_tbl[c26];
																														if (clm_std != tot_std)
																															continue;
																													}
																													tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24] * Dbls[c25] * Dbls[c26];
																												}
																												for (c27 = c26 + 1; c27 < played - req + 28 && (req - 28) >= 0; c27++)   // loop 28
																												{
																													if (req - 28 == 0)
																													{
																														if (tot_std)
																														{
																															clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24] +std_tbl[c25] +std_tbl[c26] +std_tbl[c27];
																															if (clm_std != tot_std)
																																continue;
																														}
																														tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24] * Dbls[c25] * Dbls[c26] * Dbls[c27];
																													}
																													for (c28 = c27 + 1; c28 < played - req + 29 && (req - 29) >= 0; c28++)   // loop 29
																													{
																														if (req - 29 == 0)
																														{
																															if (tot_std)
																															{
																																clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24] +std_tbl[c25] +std_tbl[c26] +std_tbl[c27] +std_tbl[c28];
																																if (clm_std != tot_std)
																																	continue;
																															}
																															tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24] * Dbls[c25] * Dbls[c26] * Dbls[c27] * Dbls[c28];
																														}
																														for (c29 = c28 + 1; c29 < played - req + 30 && (req - 30) >= 0; c29++)   // loop 30
																														{
																															if (req - 30 == 0)
																															{
																																if (tot_std)
																																{
																																	clm_std =  std_tbl[c0] + std_tbl[c1] + std_tbl[c2] + std_tbl[c3]+ std_tbl[c4]+ std_tbl[c5]+ std_tbl[c6]+ std_tbl[c7]+ std_tbl[c8]+ std_tbl[c9]+ std_tbl[c10]+ std_tbl[c11]+ std_tbl[c12]+ std_tbl[c13]+ std_tbl[c14]+ std_tbl[c15]+ std_tbl[c16]+ std_tbl[c17]+ std_tbl[c18] +std_tbl[c19] +std_tbl[c20] +std_tbl[c21] +std_tbl[c22] +std_tbl[c23] +std_tbl[c24] +std_tbl[c25] +std_tbl[c26] +std_tbl[c27] +std_tbl[c28] +std_tbl[c28];
																																	if (clm_std != tot_std)
																																		continue;
																																}
																																tot_cmbs_nr += Dbls[c0] * Dbls[c1] * Dbls[c2] * Dbls[c3] * Dbls[c4] * Dbls[c5] * Dbls[c6] * Dbls[c7] * Dbls[c8] * Dbls[c9] * Dbls[c10] * Dbls[c11] * Dbls[c12] * Dbls[c13] * Dbls[c14] * Dbls[c15] * Dbls[c16] * Dbls[c17] * Dbls[c18] * Dbls[c19] * Dbls[c20] * Dbls[c21] * Dbls[c22] * Dbls[c23] * Dbls[c24] * Dbls[c25] * Dbls[c26] * Dbls[c27] * Dbls[c28] * Dbls[c29];
																															}

																														} // end loop 30
																													} // end loop 29
																												} // end loop 28
																											} // end loop 27
																										} // end loop 26
																									} // end loop 25
																								} // end loop 24
																							} // end loop 23
																						} // end loop 22
																					} // end loop 21
																				} // end loop 20
																			} // end loop 19
																		} // end loop 18
																	} // end loop 17
																} // end loop 16
															} // end loop 15
														} // end loop 14
													} // end loop 13
												} // end loop 12
											} // end loop 11
										} // end loop 10
									} // end loop 9
								} // end loop 8
							} // end loop 7
						} // ens loop 6
					} // end loop 5
				} // end loop 4
			} // end loop 3
		} // end loop 2
	} // end loop 1

	return tot_cmbs_nr;
}



///========== Procedures for BET Types and Groups=====================================

/// Sets the marks positions for bet types and groups
void FlexBet::initTouchAreas()
{
	int startx,starty;
	int xpos,ypos;
	int dx,dy;
	int ipos=0;
	int sw;
	int sh;

////    BG values
//    startx=97;
//    starty=467;
//    dx=5;
//    dy=5;
//    sw=66;
//    sh=65;
//    CH values
	startx=11;
	starty=472;
	dx=2;
	dy=5;
	sw=65;
	sh=65;

	xpos=startx;
	ypos=starty;

	const uint GUIMARKS_C = BET_MARKS+R_GRP_MARK+GRP_MARKS;

	for (uint i = 0; i<GUIMARKS_C; i++)
	{
		picBetArray[ipos].x=-9999;
		picBetArray[ipos].y=-9999;
		picBetArray[ipos].w=sw;
		picBetArray[ipos].h=sh;
		ipos++;
	}
	ipos=0;
	for (int i = 0; i<BET_MARKS; i++)
	{
//		if(i<(BET_MARKS-1)){
			if (i%3==0 && i!=0)
			{
				xpos+=dx+sw;
				ypos=starty;
			}
			picBetArray[ipos].x=xpos;
			picBetArray[ipos].y=ypos;
			picBetArray[ipos].w=sw;
			picBetArray[ipos].h=sh;
			ypos+=dy+sh;
			ipos++;
//        }else{ /// For the switch button
//            xpos = 26;
//            ypos = 607;
//            picBetArray[ipos].x=xpos;
//            picBetArray[ipos].y=ypos;
//            picBetArray[ipos].w=sw;
//            picBetArray[ipos].h=sh;
//            ipos++;
//        }
	}
	/// For the standard
//    xpos = 943;
//    ypos = 461;
//    picBetArray[ipos].x=xpos;
//    picBetArray[ipos].y=ypos;
//    picBetArray[ipos].w=sw;
//    picBetArray[ipos].h=sh;
//    ipos++;

	/// For the R GROUP mark
	xpos = 511;
	ypos = 302;
	picBetArray[ipos].x=-999; //xpos;
	picBetArray[ipos].y=-999; //ypos;
	picBetArray[ipos].w=sw;
	picBetArray[ipos].h=sh;
	ipos++;

	/// For the A GROUP mark
	xpos = 448;
	ypos = 387;
	picBetArray[ipos].x=-999; //xpos;
	picBetArray[ipos].y=-999; //ypos;
	picBetArray[ipos].w=sw;
	picBetArray[ipos].h=sh;
	ipos++;

	/// For the B GROUP mark
	xpos += (sw+5);
	picBetArray[ipos].x=-999; //xpos;
	picBetArray[ipos].y=-999; //ypos;
	picBetArray[ipos].w=sw;
	picBetArray[ipos].h=sh;
	ipos++;

	/// For the C GROUP mark
	xpos += (sw+5);
	picBetArray[ipos].x=-999; //xpos;
	picBetArray[ipos].y=-999; //ypos;
	picBetArray[ipos].w=sw;
	picBetArray[ipos].h=sh;
}


void FlexBet::initMark()
{
	int i;
	if( !tick[0] )
	{
		qDebug("Sprite is not set");
		return;
	}

	for (i=0; i<BET_MARKS+R_GRP_MARK+GRP_MARKS; i++)
		tick[i]->move(picBetArray[i].x,picBetArray[i].y);
}

void FlexBet::InformMousePressEvent(QMouseEvent *e)   //change for new screen
{
	if (!isActiveWindow () && !isDialogOnScreen ()) {
		return;
	}

	if (EnableInsertBetTypes == false)
		return;

	QRect r;
	QPoint p;

	p.setX(e->x());
	p.setY(e->y());

	for (int i=0; i<BET_MARKS+GRP_MARKS+R_GRP_MARK; i++)
	{

		r.setRect(picBetArray[i].x,picBetArray[i].y,picBetArray[i].w,picBetArray[i].h);

		if (r.contains(p))
		{
			m_pApp->playSoundEffect();
			if (i<BET_MARKS)
			{
				if (betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_BET+ i])
				{
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_BET+ i] = 3;
				}
				else
				{
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_BET+ i] = 2;
				}
			}
			else if (i<BET_MARKS+R_GRP_MARK)
			{
				/// For the R-Group
				if (betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS])
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS] = 3;
				else
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS] = 2;
			}
			else if (i < BET_MARKS+R_GRP_MARK+GRP_MARKS)
			{
				/// For the groups A,B,C,D
				if (betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+(i-BET_MARKS-R_GRP_MARK)])
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+(i-BET_MARKS-R_GRP_MARK)] = 3;
				else
					betCoupon.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+(i-BET_MARKS-R_GRP_MARK)] = 2;
			}
		}
	}

	CheckBetTypesGUI(betCoupon,thisArea);
	UpdateBetTypesAndGroupsArea(betCoupon,1,thisArea);

}

/// Chexk if a bet is standard
int FlexBet::isStandard(CouponRecord &rec,int area)
{

	int isStd=0;

	if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+BET_STD_INDX])
		isStd=1;

	return isStd;
}

/// Counts the number of marks that are selected for creating a bet
int FlexBet::CountBetTypeMarks(CouponRecord &rec,int area)
{
	int i, marked = 0;
	for (i = 0; i < NUM_O_BETS; i++)
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+i] && i!=BET_STD_INDX) /// The BET_STD_INDX position is for the standard
			marked++;

	return marked;
}



void FlexBet::CheckBetTypesGUI(CouponRecord &rec,int area)
{

//	int num1[NUM_O_SPECIALCOLUMN1]={18,21,24,27,30}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Campeon/Especiales region of the playslip, excluding the 0.5 option)
	int num1[NUM_O_SPECIALCOLUMN1]={6,7,8,9,33};

//	int num2[NUM_O_SPECIALCOLUMN2]={19,22,25,28,31,34}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Resultado Exacto/Goles Locales region of the playslip)
	int num2[NUM_O_SPECIALCOLUMN2]={16,17,18,19,20,21};

//	int num3[NUM_O_SPECIALCOLUMN3]={20,23,26,29,32,35}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Resultado Exacto/Goles Locales region of the playslip)
	int num3[NUM_O_SPECIALCOLUMN3]={27,28,29,30,31,32};

	printf("In CHECKGUI");
	calculateBet(rec,area);//gets the bet data before the mouse event

	if (isSpcode)
	{
		for (int i=0; i<NUM_O_SPECIALCOLUMN1; i++)
		{
			if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num1[i] ]==2 )
			{
				for (int j=0; j<NUM_O_SPECIALCOLUMN1; j++)
					rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num1[j]]=0;

				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num1[i]]=1;
			}
			else if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num1[i]]== 3 )
				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num1[i]]=0;
		}

		for (int i=0; i<NUM_O_SPECIALCOLUMN2; i++)
		{
			if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num2[i] ]==2 )
			{
				if (CountBetTypeMarksSpCol2(rec,area)>2)
					rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num2[i]]=0;
				else
					rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num2[i]]=1;
			}
			else if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num2[i]]== 3 )
				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num2[i]]=0;
		}

		for (int i=0; i<NUM_O_SPECIALCOLUMN3; i++)
		{
			if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num3[i] ]==2 )
			{
				if (CountBetTypeMarksSpCol3(rec,area)>2)
					rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num3[i]]=0;
				else
					rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num3[i]]=1;
			}
			else if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ num3[i]]== 3 )
				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num3[i]]=0;
		}
	}

	for (int i=0; i<NUM_O_BETS; i++)
	{
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i]==2 )
		{
			if (CountBetTypeMarks(rec,area)>6)
				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+i]=0;
			else
				rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+i]=1;
		}
		else if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i]== 3 )
			rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+i]=0;
	}
	///set the R-group mark
	if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS]==2)
		rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS]=1;
	else if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS]==3)
		rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS]=0;

	/// for the A,B,C,D groups
	int count=0;
	for (int i=0; i<NUM_O_GROUPS; i++)
		if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i])
			count++;
	for (int i=0; i<NUM_O_GROUPS; i++)
	{
		if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]==2 && count<3)
		{
			rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]=1;
			count++;
		}
		else if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]==3)
		{
			rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]=0;
			count--;
		}
		else if (rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]==2 && count>=3)
			rec.Marks[thisArea*AREA_MARKS+OFFSET_OF_GROUPS+1+i]=0;
	}
}

/// Shows on GUI the selected bet marks and groups of an area
void FlexBet::UpdateBetTypesAndGroupsArea(CouponRecord &rec,int ValidEventCode,int area)
{
	//Update Sprites
	if( !tick[0] )
	{
		qDebug("Sprite is not set");
		return;
	}

	for (int i=0; i<BET_MARKS; i++)
	{
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i] )
		{
			tick[i]->show();//if Mark is on show the tick mark on GUI
		}
		else
		{
			tick[i]->hide();//if it is off don`t(also the last 6 marks)
//            tick[i]->show();//if it is off don`t(also the last 6 marks)
		}
	}

	for (int i=0; i<R_GRP_MARK+GRP_MARKS; i++) /// All groups (including the R-group)
	{
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_GROUPS+i] )
		{
			tick[BET_MARKS+i]->show();//if Mark is on show the tick mark on GUI
		}
		else
		{
			tick[BET_MARKS+i]->hide();//if it is off don`t(also the last 6 marks)
			//tick[BET_MARKS+i]->show();//if it is off don`t(also the last 6 marks)
		}
	}

	if (ValidEventCode)
		calculateBet(rec,area);//update the bet data
	else
	{
		QString(betTypeTxt)="-";
		QString(betDescr)="-";
		recordCode=-1;
	}
}

void FlexBet::calculateBet(CouponRecord &rec,int area)
{
	// BG (38 bets)
//	int numOfBets[NUM_O_BETS]={1,11,22,2,12,23,3,13,24,4,14,25,5,15,26,34,35,36,6,16,27,7,17,28,8,18,29,9,19,30,33,20,31,10,21,32,0,37};
	// CH (45 bets)
	int numOfBets[NUM_O_BETS]={37,38,0,1,11,22,10,24,25,39,40,41,42,43,44,45,46,47,34,35,36,2,3,4,12,13,14,23,7,9,6,8,33,16,18,20,17,19,21,27,29,31,28,30,32};

	betType=0;
	recordCode=-1;
	betTypeMarksNum=0;
	memset(betTypeMarks,0,sizeof(betTypeMarks));

	for (int i = 0; i < NUM_O_BETS; i++)
	{
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+i] && i!=BET_STD_INDX)  /// The BET_STD_INDX position is for the standard
		{
			if (betTypeMarksNum>=6)
			{
				recordCode=-1;
				return;
			}

			betTypeMarks[betTypeMarksNum]=numOfBets[i];
			betTypeMarksNum++;
		}
	}

	recordCode = m_pApp->getRecordCode(betTypeMarks);
	if( sjp_nr )
		event[area].betType = recordCode;

	m_pApp->getBetDescription(eventCode,betTypeMarks,homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr);
	//printf("In eventCode %d recordCode %d,betType %s betDescr %s betTypeMarksNum %d\n", eventCode,recordCode,QString(betTypeTxt).utf8().data(),QString(betDescr).utf8().data(),betTypeMarksNum);

	isSpcode=true;

//	int num[20]={1,2,3,4,5,34,10,11,12,13,14,15,35,22,23,24,25,26,36,37}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Campeon/Especiales region of the playslip, excluding the 0.5 option)
	// Array size should be (total_number_of_bets - number_of_special_bets_in_colmns_1_2_3 - 1); the -1 corresponds to the standard/banker ('F' in Xperto)
	int num[NUM_O_BETS - (NUM_O_SPECIALCOLUMN1 + NUM_O_SPECIALCOLUMN2 + NUM_O_SPECIALCOLUMN3 + 1)]={37,38,1,11,22,10,24,25,39,40,41,42,43,44,45,46,47,34,35,36,2,3,4,12,13,14,23};

	for (int n=0; n<MAX_COMBINATION_TOUCHES; n++)
	{
//		for (int i=0; i<20; i++)
		for (int i=0; i<NUM_O_BETS - (NUM_O_SPECIALCOLUMN1 + NUM_O_SPECIALCOLUMN2 + NUM_O_SPECIALCOLUMN3 + 1); i++)
		{
			if (betTypeMarks[n]== num[i])
			{
				isSpcode=false;
				break;
			}
		}
	}

	int num1=0,num2=0,num3=0;
	if (isSpcode)
	{
		if ( (CountBetTypeMarksSpCol1(rec,area)>1 || CountBetTypeMarksSpCol2(rec,area)>2 || CountBetTypeMarksSpCol3(rec,area)>2)
				|| (CountBetTypeMarksSpCol1(rec,area)>0 && (CountBetTypeMarksSpCol2(rec,area)==0 || CountBetTypeMarksSpCol3(rec,area)==0) )
				|| (CountBetTypeMarksSpCol2(rec,area)>0 && CountBetTypeMarksSpCol3(rec,area)==0) )
		{
			betType=-1;
			return;
		}

		for (int i=0; i<MAX_COMBINATION_TOUCHES; i++)
		{
			if (betTypeMarks[i]>=6 && betTypeMarks[i]<=9)
				num1+=betTypeMarks[i]-5;
			if (betTypeMarks[i]==33)
				num1+=5;
			if (betTypeMarks[i]>=16 && betTypeMarks[i]<=21)
				num2+=betTypeMarks[i]-16;
			if (betTypeMarks[i]>=27 && betTypeMarks[i]<=32)
				num3+=betTypeMarks[i]-27;

		}

		betType=num1*100+num2*10+num3;
	}
	return;
}


QString FlexBet::getBetTypeDescription()
{
	int iRecordCode  = getRecordCode();
	QString strSpCode = "";
	if( iRecordCode>-1 && iRecordCode < NORMAL_BETTYPES_STARTINGCODE )
		strSpCode = "(" + QString::number(iRecordCode+100) + ") ";

	if ( QString::fromUtf8(betTypeTxt).contains(qApp->translate("FlexBetXmlController","Special Bet"),TRUE) )
		return QString::fromUtf8(strSpCode + betTypeTxt);
	else
	{
		if( strSpCode.length() )
			return QString::fromUtf8(strSpCode + betDescr);
		else
			return QString::fromUtf8(betTypeTxt) + QString(" ") + QString::fromUtf8(betDescr);
	}
}

QString FlexBet::getBetTypeTxt()
{
	return QString::fromUtf8(betTypeTxt);
}

QString FlexBet::getBetDescriptionTxt()
{
	return QString::fromUtf8(betDescr);
}

int FlexBet::getRecordCode()
{
	return recordCode;
}

int FlexBet::getBetType()
{
	return betType;
}

void FlexBet::getBetTypeMarks(int *bMarks,int length)
{
	for (int i=0; i<length; i++)
		bMarks[i]=betTypeMarks[i];

}


void FlexBet::setEventCode(QString code)
{
	eventCode=getEventID (code); //code.toInt(); //TOCHECK TO_CHECK TODO TO_DO
}

void FlexBet::setEventCode(int code)
{
	eventCode=code;
}

void FlexBet::getCouponMarks(CouponRecord &rec,int area,int length)
{
	for (int i=0; i<length; i++)
		rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i]=betCoupon.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i];
}

void FlexBet::setCouponMarks(CouponRecord &rec,int area,int length)
{
	for (int i=0; i<length; i++)
		betCoupon.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i]=rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+ i];
}

/// Get the groups text based on the event code that we have created for the coupon's record
void FlexBet::GetEventGroupText(int evtGroup,QString &groupPrnt)
{
	if (evtGroup>10)
	{
		groupPrnt = qApp->translate("FlexBet","(R");
		evtGroup = evtGroup % 10;
	}
	else
	{
		groupPrnt = qApp->translate("FlexBet","(-");
	}
	switch (evtGroup)
	{
	case 1:
		groupPrnt.append(qApp->translate("FlexBet","A-)"));
		break;
	case 2:
		groupPrnt.append(qApp->translate("FlexBet","B-)"));
		break;
	case 3:
		groupPrnt.append(qApp->translate("FlexBet","C-)"));
		break;
	case 4:
		groupPrnt.append(qApp->translate("FlexBet","D-)"));
		break;
	case 5:
		groupPrnt.append(qApp->translate("FlexBet","AB)"));
		break;
	case 6:
		groupPrnt.append(qApp->translate("FlexBet","AC)"));
		break;
	case 7:
		groupPrnt.append(qApp->translate("FlexBet","AD)"));
		break;
	case 8:
		groupPrnt.append(qApp->translate("FlexBet","BC)"));
		break;
	case 9:
		groupPrnt.append(qApp->translate("FlexBet","BD)"));
		break;
	default:
		groupPrnt.append(qApp->translate("FlexBet","CD)"));
		break;
	}

}

/// Get the groups text based on the marks of the coupon record.
void FlexBet::GetEventGroupText(int area,QString &groupPrnt,CouponRecord *rec)
{
	if (rec == NULL)
		rec = &betCoupon;

	QString temp = QString::null;
	QString choose[] =
	{
		qApp->translate("FlexBet","A"),
		qApp->translate("FlexBet","B"),
		qApp->translate("FlexBet","C"),
	};

	if (rec->Marks[area*AREA_MARKS + OFFSET_OF_GROUPS])
		temp = qApp->translate("FlexBet","(R");

	for (int i=0; i<(NUM_O_GROUPS-1); i++)
	{
		if (rec->Marks[area*AREA_MARKS+OFFSET_OF_GROUPS+1+i])
		{
			if (temp.isEmpty())
				temp=QString("(%1").arg(choose[i]);
			else
				temp=temp.append(choose[i]);
		}
	}
	if (!temp.isEmpty())
		temp=temp.append(")");

	groupPrnt = temp;

}

/// Create the groups text based on the information of the bets' structure
void FlexBet::findGroupText(int area,QString &out)
{
	/*Using the format introduced (A=1, B=10 etc...)
	the literal describing the group that the given
	area participates in is written to the out array*/
	QString temp=QString::null;
	out = QString::null;
	QString choose[] =
	{
		qApp->translate("FlexBet","A"),
		qApp->translate("FlexBet","B"),
		qApp->translate("FlexBet","C"),
		qApp->translate("FlexBet","D")
	};
	int remain=event[area].group;

	if (event[area].random)
		temp=QString(qApp->translate("FlexBet","R"));
	for (int i=0; i<NUM_O_GROUPS; i++)
	{
		if (remain/((int)pow(10,3-i)))
		{
			remain=remain%((int)pow(10,3-i));
			if (temp.isEmpty())
				temp=QString("%1").arg(choose[i]);
			else
				temp=temp.append(choose[i]);
		}
	}
	out=temp.utf8().data();
	if (out!=QString::null)
		out = QString("(") + out + QString(")");
	return;
}

/// Create the groups code based on the marks of the coupon's record so as to update the bet's struct
void FlexBet::getGroupNumber(int area,bool &random,int &group,CouponRecord *rec)
{

	if (rec == NULL)
		rec = &betCoupon;

	//Find group
	group=0;
	for (int i=0; i<NUM_O_GROUPS; i++)
		if (rec->Marks[area*AREA_MARKS+OFFSET_OF_GROUPS+1+i])
			group+=(int)pow(10,3-i);

	//Find if R group
	if (rec->Marks[area*AREA_MARKS + OFFSET_OF_GROUPS])
		random=true;
	else
		random=false;
}

/// Check if a selected area-bet has groups.
bool FlexBet::hasGroup(int area,CouponRecord *rec)
{
	if (rec == NULL)
		rec = &betCoupon;

	for (int i=0; i<NUM_O_GROUPS+1; i++)
		if (rec->Marks[area*AREA_MARKS+OFFSET_OF_GROUPS+i])
			return true;

	return false;
}


/**
	This procedure is for the scanned coupon. It converts the scanner's information to
	table's marks
**/
int FlexBet::ApplyMarks(int cpn, const QByteArray& qbaCouponData, QString &strError)
{
	char ScanBuf[MAXSCANBUF];       // The scanner buffer
	memcpy ( ScanBuf,(char *)qbaCouponData.data(), qbaCouponData.size() );

	ScannedCoupon = true;

    SScanHeader *sScanHeader = (SScanHeader*) &ScanBuf[0];
    unsigned int MarkLen = sScanHeader->uiMarks;
    short *ptrMark = (short*)(&ScanBuf[sizeof(SScanHeader)]);

	/// Initialize "CouponRec"
	memset ( CouponRec[cpn].Marks,0,sizeof ( CouponRec[cpn].Marks ) );

	int *MarkTable;
	unsigned int uiLength=0;
	int NumOfPlayslipAreas=0;

	char TempMarks[MAXMARKSLEN];
	memset ( TempMarks,0,sizeof ( TempMarks ) );

    if( sScanHeader->uiRiga != IFLEX_RIGA )
    {
        return 0;
    }

	MarkTable = (int*)&CouponToMarks_c[0];
	uiLength = TotalScanCouponMarks_c;
	NumOfPlayslipAreas = IFLEX_RIGA_AREAS;

	unsigned short MarkNo;
	for ( int i=0; i<MarkLen; i++ )
	{
		MarkNo = (*ptrMark);

		ptrMark++;

        if ( !MarkNo || MarkNo>uiLength ) // Camera marks start from 0 (local table from 0)
			continue;

        TempMarks[ MarkTable[MarkNo] ] = 1;
	}

	//compact non void areas
	int ValidAreas= 0;
	for ( int AreaNo=0; AreaNo<NumOfPlayslipAreas; AreaNo++ )
	{
		if ( TempMarks[TOTAL_ECPN_MARKS+AreaNo] != 1 )
		{
			memcpy(&CouponRec[cpn].Marks[ValidAreas*AREA_MARKS],&TempMarks[AreaNo*AREA_MARKS],AREA_MARKS);
			ValidAreas++;
		}
	}

	memcpy(&CouponRec[cpn].Marks[NumOfPlayslipAreas*AREA_MARKS],&TempMarks[NumOfPlayslipAreas*AREA_MARKS], (  MAXMARKSLEN-(NumOfPlayslipAreas*AREA_MARKS) ) );

    if(!ValidPlayslipSelections(sScanHeader->uiRiga,strError))
    {
        return 0;
    }

	SetDefaultStake();

	UpdateBetStructM(cpn);

	return 1;

}

bool FlexBet::ValidPlayslipSelections(unsigned int uiRiga, QString &strError)
{
    strError="";

    if( uiRiga==IFLEX_RIGA || uiRiga==IFLEX_RIGA2 || uiRiga==IFLEX_RIGA5)
        return true;

    unsigned char ucSJCount = 0;

    if( uiRiga==IFLEX_RIGA3 || uiRiga==IFLEX_RIGA4)
    {
        for(int i=0;i<NUM_O_SJP;i++)
        {
            if(CouponRec[CurrentCoupon].Marks[OFFSET_OF_SJP+i])
            {
                ucSJCount++;
            }
        }
    }

    if( ucSJCount==1 )
    {
        return true;
    }
    if( !ucSJCount )
    {
        strError = tr("SJP coupon without any sjp column");
        return false;
    }
    else if( ucSJCount>1 )
    {
        strError = tr("More than 1 SJP selections");
        return false;
    }

    return false;
}

int FlexBet::getEventID (QString qstrEvent)
{
	int EventID = -1;
	QString qstrTemp = qstrEvent.remove("#").remove("(").remove(")").remove("A").remove("B").remove("C").remove("R").stripWhiteSpace();
	bool ok =false;
	EventID = qstrTemp.toInt(&ok);
	if (!ok)
	{
		EventID = EMPTY_AREA;
	}
	return EventID;
}

long FlexBet::cnvSysMultBitsToLong (char in_mults)
{

	unsigned long out_mult = 1;

	if (IsSet(&in_mults,BIT_0_POS))
	{
		out_mult *= 1;
	}
	if (IsSet(&in_mults,BIT_1_POS))
	{
		out_mult *= 2;
	}
	if (IsSet(&in_mults,BIT_2_POS))
	{
		out_mult *= 3;
	}
	if (IsSet(&in_mults,BIT_3_POS))
	{
		out_mult *= 4;
	}
	if (IsSet(&in_mults,BIT_4_POS))
	{
		out_mult *= 5;
	}

	if (in_mults==0)
	{
		out_mult = 0;
	}

	return out_mult;
}
void FlexBet::SetBit(char *buf,int bitpos)
{
	int pos=bitpos/8;
	int sbit=bitpos%8;

	buf[pos]|=((0x80>>sbit));
}

void FlexBet::ResetBit(char *buf,int bitpos)
{
	int pos=bitpos/8;
	int sbit=bitpos%8;

	buf[pos]&=(~(0x80>>sbit));
}

bool FlexBet::IsSet(char *buf,int bitpos)
{
	int pos=bitpos/8;
	int sbit=bitpos%8;

	if (buf[pos]&(0x80>>sbit))
		return true;
	return false;
}

int FlexBet::CountBetTypeMarksSpCol1(CouponRecord &rec,int area)
{
	int i, marked = 0;
//	int num1[NUM_O_SPECIALCOLUMN1]={18,21,24,27,30}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Campeon/Especiales region of the playslip, excluding the 0.5 option)
	int num1[NUM_O_SPECIALCOLUMN1]={6,7,8,9,33};

	for (i = 0; i < NUM_O_SPECIALCOLUMN1; i++)
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num1[i]])
			marked++;

	return marked;
}

int FlexBet::CountBetTypeMarksSpCol2(CouponRecord &rec,int area)
{
	int i, marked = 0;
//	int num2[NUM_O_SPECIALCOLUMN2]={19,22,25,28,31,34}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Resultado Exacto/Goles Locales region of the playslip)
	int num2[NUM_O_SPECIALCOLUMN2]={16,17,18,19,20,21};

	for (i = 0; i < NUM_O_SPECIALCOLUMN2; i++)
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num2[i]])
			marked++;

	return marked;
}

int FlexBet::CountBetTypeMarksSpCol3(CouponRecord &rec,int area)
{
	int i, marked = 0;
//	int num3[NUM_O_SPECIALCOLUMN3]={20,23,26,29,32,35}; // BG
	// aste : CH (check with Nikos Bafaloukos that I got this right - they should be the indices of cells in the Resultado Exacto/Goles Locales region of the playslip)
	int num3[NUM_O_SPECIALCOLUMN3]={27,28,29,30,31,32};

	for (i = 0; i < NUM_O_SPECIALCOLUMN3; i++)
		if (rec.Marks[area*AREA_MARKS+OFFSET_OF_BET+num3[i]])
			marked++;

	return marked;
}

//********************************** IMTS - DBUS Stuff **********************************
//***************************************************************************************
int FlexBet::setGamesBitmapsPath(const char* path) {

	char fname[200];
//    sprintf(fname,"%s%s",path,"FlexBet.png");
//    sprintf(fname,"%s%s",path,"screens/xPerto_NGUI_G2.png");
//    sprintf(fname,"%s%s",path,"screens/xPerto_NGUI_G3.png");
	sprintf(fname,"%s%s",path,"screens/xPerto.png");

	if( !m_PFBet.load(fname) )
	{
		qDebug("ERROR: %s was not loaded: ",fname);
		qApp->exit();
	}
	if( m_PFBet.isNull () )
	{
		qDebug () << "m_PFBet Is null";
		qApp->exit();
	}
	return 1;
}

void FlexBet::IMTSConnectionFunctions()
{
	m_pcProgressDialog = NULL;

	m_iTimerId = 0;
	m_pcRequestDataFromCs = new RequestDataFromCs (this);

	setUpDBusInterface ();

	QObject::connect (this,SIGNAL(sgnCheckActiveDraw(bool,bool,uint,uint,uint)),this, SLOT (CheckActiveDraw(bool,bool,uint,uint,uint)));

	m_flexBetXmlController = new FlexBetXmlController;
//    CheckActiveDraw(false, true); //No need to download files here. This happens after sign on via login procedure.

	bool bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();
	SwitchBetFiles(bIsTraining);

	QObject::connect(DbusWrapper::getConfigManagerInterface (),SIGNAL(trainingChanged(bool)),this,SLOT(SwitchBetFiles(bool)));
}


//==================================================================================================================
//==================================================================================================================
//==================================================================================================================
//==================================================================================================================
//==================================================================================================================
//==================================================================================================================
//==================================================================================================================
//TEST - TEST- TEST- TEST- TEST- TEST- TEST- TEST
//    if(QFile("/home/A_TX.dat").exists())
//    {
//        int iRet = 0;
//        PrintHTMLCoupon ( mReply, iRet );
//        return;
//    }
//TEST - TEST- TEST- TEST- TEST- TEST- TEST- TEST

QString FlexBet::processCsData ( const QVariantMap& qvmCsReply, const int& iReplyCode )
{
	QString qsErrorMessage = QString ();
	CouponRecord PrintCouponRecord;

	QByteArray qbaCsData = QByteArray::fromBase64( qvmCsReply.value (BINARY_DATA).toByteArray());
	memcpy ( &PrintCouponRecord.HostReply[0], qbaCsData, qbaCsData.size() );

	QByteArray qbaMarks = QByteArray::fromBase64 (m_flexBetData.readPgm15000 ().value ("Marks").toByteArray ()); // Marks are stored in the map inside initCsData method.
	memcpy ( &PrintCouponRecord.Marks[0], qbaMarks, qbaMarks.size () );

	QByteArray qbaRecord = QByteArray::fromBase64 (m_flexBetData.readPgm15000 ().value ("Record").toByteArray ()); // Record
	memcpy ( &PrintCouponRecord.Record[0], qbaRecord, qbaRecord.size () );

	auto printCoupon = [this, qvmCsReply, PrintCouponRecord, &qsErrorMessage] () -> int {

		int iRet = 0;

		PrintHTMLCoupon ( qvmCsReply, PrintCouponRecord, iRet );

		if ( iRet != 0 && iRet!=9) {

			qsErrorMessage = tr("Error Printing Play Receipt");
		}
		return iRet;

	};

	if ( iReplyCode == RD_OK ) { // error free

		if ( !qbaCsData.isEmpty () ) {

			postPlaySteps( qbaCsData );

			if ( printCoupon () == 0 ) {

				LOG("IFLEX: receipt printed correctly");
				ClearPressed();
			}

		} else {

			qsErrorMessage = tr("Transaction with C/S failed");
		}


	}else if ( qvmCsReply.value ("RD_DIF_DRW_REV").toBool () ) {

		Get_Updated_Revision ();

	} else if ( iReplyCode == RD_BET_SPEC_REPLIES ) {

		DisplayError( tr("Information").utf8().data(), tr ("HIGH STAKE BET\nPLAY NEEDS APPROVAL").utf8().data() );
		qsErrorMessage = QString();//tr ("HIGH STAKE BET\nPLAY NEEDS APPROVAL").utf8().data();
		printCoupon ();

	} else if ( !qsErrorMessage.isEmpty () &&
				iReplyCode != RD_BET_SPEC_REPLIES &&
				iReplyCode != RD_WRONG_DELAY &&
				iReplyCode != RD_DRW_REV_NEW) {


		bool bProceed = proceedWithEdit ( QString () );

		if ( bProceed ) {

			this->Play(MOD_STAGE_RECORD,MOD_ACTION_EDIT_CPN);

		} else{

			ClearPressed();
		}
	}

	return qsErrorMessage;
}

QString FlexBet::getError2Display(const QVariantMap qvmCsReply, const QString strOther)
{
	QString strError="";

	if( !qvmCsReply.value(MSGBOX_MSG).isNull() )
	{
		strError = qvmCsReply.value(MSGBOX_MSG).toString();
	}
	else if( !qvmCsReply.value(CS_ERROR_MSG).isNull() )
	{
		strError = qvmCsReply.value(CS_ERROR_MSG).toString();
	}
	else
	{
		strError = strOther;
	}

	DisplayError( tr("Information").utf8().data(), strError.utf8().data() );
	return strError;
}

/**
 * @sa consumeCsReplySlot
 * @param qbaCouponData
 * @param qvmCsReply
 * @return
 */
QString FlexBet::consumeCsReplySlot ( const QByteArray qbaCouponData, const QVariantMap qvmCsReply )
{
	m_bDelaying = false;
	QString qsErrorMessage = QString ();

	if ( qvmCsReply.isEmpty () ) {

		LOG("Error Printing Play Receipt due to an invalid reply");
		return qsErrorMessage = tr("Error Printing Play Receipt due to an invalid reply");

	} else {

		if(qvmCsReply.count()==1)
		{
			return getError2Display(qvmCsReply,tr("Uknown Error"));
		}

		QJson::JsonOperations::JsonToqObject ( qbaCouponData, &m_flexBetData );

		quint32 iReplyCode   = qvmCsReply.value (CS_REPLY_CODE).toUInt ();
		qint32 iDelay        = qvmCsReply.value ("WRONG_DELAY").toUInt ();

		//----test ----
//        iReplyCode=RD_WRONG_DELAY;
//        iDelay = 4;
		//----test ----

		if( iReplyCode==RD_WRONG_DELAY ) {

			m_flexBetData.setDelay(iDelay);
			m_flexBetData.setCurrentDelay(iDelay);
			m_bDelaying = true;

			//QElapsedTimer timer;
			//timer.start();
			QEventLoop loop;
			QTimer::singleShot(iDelay*1000,&loop,SLOT(quit()));
			loop.exec();
			//qDebug () << "Delay of: " << timer.elapsed() << " ms";
			prePlaySteps();

			QVariantMap mCsReply = m_pcRequestDataFromCs->getCsDataSync( QJson::JsonOperations::qObjectToJson (&m_flexBetData) );
			iReplyCode           = mCsReply.value (CS_REPLY_CODE).toUInt ();

			m_bDelaying = false;
			/// ...blocking call with c/s, wait for an answer

			if ( iReplyCode==RD_WRONG_DELAY ) {

				qsErrorMessage = tr("Live event cannot be processed. Please try again.");
				LOG("Live event cannot be processed. Please try again.");

			} else if ( iReplyCode != RD_OK ) {

				qsErrorMessage = mCsReply.value(CS_ERROR_MSG).toString();

			}

			if ( qsErrorMessage.isEmpty() ) {
				qsErrorMessage = processCsData ( mCsReply, iReplyCode );
			}

		} else {
			qsErrorMessage = processCsData ( qvmCsReply, iReplyCode );
		}
	}

	return qsErrorMessage;
}

/**
 * @sa FlexBet::itRequestSlot
 * @param qbaCouponData
 * @param editMode
 */
void FlexBet::couponEditRequestSlot ( const QByteArray qbaCouponData, const int iCouponId, const int iEditMode )
{
	//	EditScanned = true;
	// Here you got to show game

	QJson::JsonOperations::JsonToqObject ( qbaCouponData, &m_flexBetData );

	m_eSource = CouponSource::Verbal;
	m_iCouponId = iCouponId;

	EditModesFlag eEditMode = EditModesFlag(iEditMode);

	if ( eEditMode == EditModesFlag::GuiEditRequest ) {

		//m_flexBetData.setSource ( int(CouponSource::VerbalEdit) );
		m_eSource = CouponSource::VerbalEdit;

	} else if ( eEditMode == EditModesFlag::CSEditRequest ) {

		//m_flexBetData.setSource ( int(CouponSource::VerbalEditDueToCs) );
		m_eSource = CouponSource::VerbalEditDueToCs;
	}

	//qDebug () << "Edit request: " << iEditMode <<  " on Flexbet";

	QByteArray qbaMarks = QByteArray::fromBase64 (m_flexBetData.readPgm15000 ().value ("Marks").toByteArray ()); // Marks are stored in the map inside initCsData method.
	memcpy ( CouponRec[CurrentCoupon].Marks, qbaMarks, qbaMarks.size () );

	QByteArray qbaRecord = QByteArray::fromBase64 (m_flexBetData.readPgm15000 ().value ("Record").toByteArray ()); // Marks are stored in the map inside initCsData method.
	memcpy ( CouponRec[CurrentCoupon].Record, qbaRecord, qbaRecord.size () );

	//UpdateBetStructM(cpn);
	EditScanned = true;

	ShowForm();


	// When you press finish you got to make the same call for adding it into IMTS GameProgress,

}

void FlexBet::timerEvent(QTimerEvent *event)
{
	Q_UNUSED ( event )

	m_pcRequestDataFromCs->getCsDataAsync  ( QJson::JsonOperations::qObjectToJson (&m_flexBetData));

	if ( m_iTimerId != 0 ) {
		killTimer (m_iTimerId);
		m_iTimerId = 0;
	}

}

bool FlexBet::initCsTxData (CouponRecord &CurrentCouponRecord, ECSDatamode ecsDataMode)
{
	//ECSDatamode {eeCSDataNone=0, eeCSDataNormal, eeCSDataApprovalRequired, eeCSDataApproved};

	FlexBetTxData::eeInputMethod method = (CouponOriginFromScanner ? FlexBetTxData::eScanned : FlexBetTxData::eCoupon);
	m_flexBetData.setInputMethod(method);
	m_flexBetData.setTxProduct ("Game15000Tx");
	m_flexBetData.setRxProduct ("Game15112Rx");
	m_flexBetData.setPriority (HIGH_PRI);
	m_flexBetData.setProtocol (LOTOS5);
	m_flexBetData.setIsCouponEmpty (false);
	m_flexBetData.setIsCouponVoid (false);
	m_flexBetData.setHeader (tr("Bet Play"));

	m_flexBetData.setGameCode (IFLEX_GAMECODE);
	m_flexBetData.setGameName (tr("XPerto"));
	m_flexBetData.setSource   (int(m_eSource));//int(CouponSource::eFlexBet));
	m_flexBetData.setImtsCouponId(m_iCouponId);
	m_flexBetData.setSubGame (0);
	m_flexBetData.setDelay (0);
	m_flexBetData.setCurrentDelay(0);
	m_flexBetData.setDistrictId (0);

	if( ecsDataMode==eeCSDataNone )
	{
		m_flexBetData.setIsCouponEmpty (true);
		m_flexBetData.setIsCouponVoid (true);

		QVariantMap mPgm15000;
		mPgm15000.clear();
		m_flexBetData.setPgm15000(mPgm15000);
		EditScanned=false;
		return true;
	}


	TRNS_CPN_HDR *trns_cpn_hdr = (TRNS_CPN_HDR *)(&CurrentCouponRecord.Record[sizeof(IT_CSS_4)]);
	TRNS_GM_15000 *trns_gm_15000 = (TRNS_GM_15000 *)(&CurrentCouponRecord.Record[sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)]);

	if( ecsDataMode==eeCSDataNormal )
	{
		m_flexBetData.setApproval (0);
		m_flexBetData.setMultiplier (cpnMultiply);
		m_flexBetData.setCost ( getTotalCost ());
		m_flexBetData.setColumns ((quint32)getColumns() );
		if( method==FlexBetTxData::eScanned && !EditScanned)
		{
			m_eSource = CouponSource::FlexBetCamera;
			m_flexBetData.setSource   (int(m_eSource));
		}
		else
		{
			if(EditScanned && ( m_eSource != CouponSource::VerbalEditDueToCs && m_eSource != CouponSource::VerbalEdit) )
			{
				m_eSource = CouponSource::eFlexBet;
			}
			m_flexBetData.setSource   (int(m_eSource));
		}
	}
	else
	{
		m_flexBetData.setApproval (trns_gm_15000->app);
		m_flexBetData.setMultiplier (trns_cpn_hdr->data[0]);
		m_flexBetData.setHighStakeAmount(trns_cpn_hdr->data[8]);
		m_flexBetData.setCost (getColumnCost()  * trns_cpn_hdr->data[0]);
		m_flexBetData.setColumns ((quint32)trns_cpn_hdr->data[0] );
		m_flexBetData.setSource   (int(CouponSource::eFlexBet));
	}

	quint32 iReq;

	if( ecsDataMode==eeCSDataNormal )
	{
		unsigned char codes_count=0;
		unsigned char std_count=0;
		unsigned char Dbls[TOT_CPN_AREAS];
		unsigned char std_tbl[TOT_CPN_AREAS];

		memset(Dbls,1,sizeof(Dbls));
		memset(std_tbl,0,sizeof(std_tbl));

		GroupingAdjustment(Dbls,std_tbl,codes_count,std_count);

		memset(trns_gm_15000->data.ev_bet.req_mult, 0, MAX_SEL_EV_15000);
		iReq = evaluateRequestRec(0,codes_count,std_count, trns_gm_15000->data.ev_bet.req_mult);
	}
	else
	{
		iReq = trns_gm_15000->req;
	}

	m_flexBetData.setRequestSelection (iReq);

	QVariantMap mPgm15000;

	QVariantList lReqMult;
	for ( quint8 iReqIndex = 0; iReqIndex < MAX_SEL_EV_15000; iReqIndex++ ) {

		lReqMult << quint8(trns_gm_15000->data.ev_bet.req_mult[iReqIndex]);
	}

	QVariantList lData;
	QVariantMap mSelDataEv;


	quint32 iValValue = 0;
	quint8 iValFlag = 0;
	int codeR;
	uint eventR;
	QString homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType="";

	for (int i=0; i<TOT_CPN_AREAS; i++) {

		if ( ecsDataMode==eeCSDataNormal )
		{
			if ( !isEmptyArea(0,i) )
			{
				//record the vals needed in grp102_bet1 part of the record
				//record the codes in the form eee99ccc (eee the Event, ccc the prediction code)
				//using the evnt/code - coupon marks correlation table (lotos mesages doc)


				iValValue = evaluateRecordVal(i);
				mSelDataEv.insertMulti ("val", iValValue );

				iValFlag = evaluateRecordFlags(i);
				mSelDataEv.insertMulti ("val_flag", iValFlag );

				//-------------- bet-market-description-for-extended-error --------------------
				eventR = iValValue/100000;// the first 3 digits
				codeR = iValValue % 1000; // the last 3 digits
				if( !sjp_nr )
					m_pApp->getBetDescription(eventR,codeR,homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType);
				mSelDataEv.insertMulti ( "Outcome", QString::number(eventR) + "||" +  QString::number(codeR) + "||" +  QString::fromUtf8(betTypeTxt) + "||" + QString::fromUtf8(betDescr) );
				//-------------- bet-market-description-for-extended-error --------------------

				lData.append (mSelDataEv);
				mSelDataEv.clear ();
			}
		}
		else
		{
			if( !trns_gm_15000->data.ev_bet.data[i].val )
				break;

			iValValue = trns_gm_15000->data.ev_bet.data[i].val;
			iValFlag = trns_gm_15000->data.ev_bet.data[i].val_flg;
			if ( iValValue ){
				mSelDataEv.insertMulti ("val",iValValue );
				mSelDataEv.insertMulti ("val_flag", iValFlag );

				//-------------- bet-market-description-for-extended-error --------------------
				eventR = iValValue/100000;// the first 3 digits
				codeR = iValValue % 1000; // the last 3 digits
				if( !sjp_nr )
					m_pApp->getBetDescription(eventR,codeR,homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType);
				mSelDataEv.insertMulti ( "Outcome", QString::number(eventR) + "||" +  QString::number(codeR) + "||" +  QString::fromUtf8(betTypeTxt) + "||" + QString::fromUtf8(betDescr) );
				//-------------- bet-market-description-for-extended-error --------------------

				lData.append (mSelDataEv);
				mSelDataEv.clear ();
			}
		}
	}

	QVariantList qSjNr;
	qSjNr << quint8(sjp_nr);
	m_flexBetData.setSjpNr(sjp_nr);

	mPgm15000.insert ("Data", lData );
	mPgm15000.insert ("ReqMult", lReqMult );
	mPgm15000.insert ("Marks", QByteArray(CurrentCouponRecord.Marks,MAXMARKSLEN).toBase64 () );
	if( ecsDataMode==eeCSDataNormal )
	{
		RecordCoupon(0); //it processes class member CouponRec[0]
		memcpy(CurrentCouponRecord.Record,CouponRec[0].Record,sizeof(CurrentCouponRecord.Record));
	}
	mPgm15000.insert ("Record", QByteArray(CurrentCouponRecord.Record,MAXRECORDLEN).toBase64 () );

	m_flexBetData.setPgm15000(mPgm15000);

	EditScanned=false;

//	int eventCodes[30];
//	memset(eventCodes,EMPTY_AREA,sizeof(eventCodes));
//	for(int i=0;i<codes_count;i++)
//		eventCodes[i]=event[i].choice;

	return true;
}

void FlexBet::ShowFlexBetData()
{
	qDebug("m_flexBetData.readInputMethod()=%d",(int)m_flexBetData.readInputMethod());
	qDebug("m_flexBetData.readTxProduct=%s",(char*)m_flexBetData.readTxProduct().ascii());
	qDebug("m_flexBetData.readRxProduct=%s",(char*)m_flexBetData.readRxProduct().ascii());
	qDebug("m_flexBetData.readPriority()=%s",(char*)m_flexBetData.readPriority().ascii());
	qDebug("m_flexBetData.readProtocol()=%s",(char*)m_flexBetData.readProtocol().ascii());
	qDebug("m_flexBetData.readIsCouponEmpty()=%d",m_flexBetData.readIsCouponEmpty());
	qDebug("m_flexBetData.readIsCouponVoid()=%d",m_flexBetData.readIsCouponVoid());
	qDebug("m_flexBetData.readHeader()=%s",(char*)m_flexBetData.readHeader().ascii());
	qDebug("m_flexBetData.readGameCode()=%d",m_flexBetData.readGameCode());
	qDebug("m_flexBetData.readGameName()=%s",(char*)m_flexBetData.readGameName().ascii());
	qDebug("m_flexBetData.readSource()=%d",(int)m_flexBetData.readSource());
	qDebug("m_flexBetData.readImtsCouponId()=%d",m_flexBetData.readImtsCouponId());
	qDebug("m_flexBetData.readSubGame()==%d",m_flexBetData.readSubGame());
	qDebug("m_flexBetData.readDelay()=%d",m_flexBetData.readDelay());
	qDebug("m_flexBetData.readCurrentDelay()=%d",m_flexBetData.readCurrentDelay());
	qDebug("m_flexBetData.readDistrictId()=%d",m_flexBetData.readDistrictId());

	QVariantMap mPgm15000 = m_flexBetData.readPgm15000 ();

	QVariantList lData    = mPgm15000.value (QString("Data")).toList ();

	QVariantMap mSelDataEv15000 = QVariantMap ();

	for ( quint8 iIndex = 0; iIndex < lData.size (); ++iIndex ) {

		mSelDataEv15000 = lData.at (iIndex).toMap ();

		qDebug("val=%d" , mSelDataEv15000.value (QString("val")).toUInt () );
		qDebug("val_flag=%d" ,  quint8(mSelDataEv15000.value (QString("val_flag")).toUInt ()) );
	}

	QVariantList lReqMult = mPgm15000.value (QString("ReqMult")).toList ();

	for ( quint8 iReqMul = 0; iReqMul < lReqMult.size (); ++ iReqMul ) {
		qDebug("reqmult=%d" , lReqMult.at (iReqMul).toUInt () );
	}
}

/**
 * @sa startPleaseWait
 */
void FlexBet::startPleaseWait ( const QString& qsPleaseWaitText )
{
	if ( !this->isVisible () ) {

		QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();
		if ( reply.isValid () ) {

			QStringList l = reply.value ();

			if ( !l.isEmpty () ) {
				QDBusInterface remoteApp( l.at (0), l.at (1) );
				remoteApp.call( QDBus::NoBlock, "showPleaseWait", qsPleaseWaitText );
			}
		}
	} else {

		if ( ! m_pcProgressDialog ) {
			 m_pcProgressDialog = new QProgressDialog ( this );
			 m_pcProgressDialog->setRange (0,0);
			 m_pcProgressDialog->setModal (true);
			 m_pcProgressDialog->setCancelButton (0);
			 m_pcProgressDialog->setLabelText (qsPleaseWaitText );
			m_pcProgressDialog->show ();
		 }

	}
}

/**
 * @sa FlexBet::endPleaseWait
 */
void FlexBet::endPleaseWait ()
{
	if ( !this->isVisible () ) {

		QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();
		if ( reply.isValid () ) {

			QStringList l = reply.value ();

			if ( !l.isEmpty () ) {

				// 2nd place endPleaseWait call to remote application. list contains service and path
				QDBusInterface remoteApp( l.at (0), l.at (1) );
				remoteApp.call( QDBus::NoBlock, "hidePleaseWait");
	}
		}
	} else {

		if (  m_pcProgressDialog ) {
			 delete m_pcProgressDialog;
			m_pcProgressDialog = NULL;
		}

	}
}

void FlexBet::SendDataSim( bool bIsHighStake)
{
	Q_UNUSED(bIsHighStake);
	static qint32 iProcessCoupon = 0;
	qDebug() << "Tx simulation is active. Coupon sent reply received in 2secs.";
	startPleaseWait (tr("Please Wait..."));
	QEventLoop createLocalLoop;
	QTimer::singleShot ( 5000, &createLocalLoop, SLOT(quit()) );
	createLocalLoop.exec();
	qDebug () << "Processed coupon: " << ++iProcessCoupon;
	this->Finish->setEnabled(true);
}

/**
 * @sa FlexBet::SendData
 * @param bIsHighStake
 */
void FlexBet::SendData( bool bIsHighStake)
{
#if defined(SIMULATE_TRANSACTION)
	SendDataSim(bIsHighStake)
#else
	SendDataOnline(bIsHighStake);
#endif
}

void FlexBet::SendDataOnline( bool bIsHighStake)
{
	bool FinishState = false;
	bool CouponIsOk = false;

	//---------------------------------------------------

	CouponIsOk=CheckCoupon(CurrentCoupon)==1;
	FinishState=CouponIsOk||IsEmptyCoupon(CurrentCoupon);

	if (FinishState)
	{
		if (EditScanned)
		{
			//EditScanned=false;
			UpdateArea();
		}
		sprintf(g_bet_err_txt,"%s", qApp->translate("FlexBet","NO ERRORS\nPress Finish to Send").utf8().data());
		if (IsEmptyCoupon(CurrentCoupon))
			sprintf(g_bet_err_txt,"%s", qApp->translate("FlexBet","Empty Coupon\nPress Finish to Exit").utf8().data());

	}
	else
	{
		DisplayError(qApp->translate("FlexBet","Coupon Error").utf8().data(),QString(g_bet_err_txt));
		return;
	}

	this->Finish->setEnabled(false);

	m_iVoidAreas = 0;
	//---------------------------------------------------

	double dTotalCost = getTotalCost();
	bool bProceed = proceedDueToCouponCost ( dTotalCost );

	if( !bProceed )
	{
		this->Finish->setEnabled(true);
		return;
	}

	initCsTxData ( CouponRec[0], bIsHighStake ? eeCSDataApprovalRequired : eeCSDataNormal );

	prePlaySteps();

	static QScopedPointer<QDBusInterface> mainDesktopDbusInterface (new QDBusInterface (QLatin1String("com.intralot.IMTSMainDesktop"), QLatin1String("/GamesOperations"), QLatin1String(""), QDBusConnection::sessionBus(), 0 ));
	mainDesktopDbusInterface.data()->call("fillCouponFromFlexBetDataSlot",QJson::JsonOperations::qObjectToJson (&m_flexBetData));

	// DbusWrapper::getGameOperationsInterface ()->fillCouponFromFlexBetDataSlot ( QJson::JsonOperations::qObjectToJson (&m_flexBetData) );
	// m_pcRequestDataFromCs->getCsDataAsync  ( QJson::JsonOperations::qObjectToJson (&m_flexBetData));

	m_eSource = CouponSource::eFlexBet;
	m_iCouponId = 0;
	EditScanned = false;

	HideForm();
}

/**
 * @sa printerPaperRollReplacementInProgress
 */
void FlexBet::printerPaperRollReplacementInProgress ( const bool bInProgress )
{
	m_bPrinterRollReplacementInProgress = bInProgress;
}

/**
 * @sa FlexBet::DisplayError
 * @param title
 * @param msg
 */
void FlexBet::DisplayError ( QString title, QString msg )
{
	if ( this->isVisible () ) {

		//No suspend of accepting coupon data when the game is visible. Is has been suspended already when the form was shown.
		CoronisMessageBox msgbox(NULL,"");
		msgbox.SetTitle(title);
		msgbox.SetContents(msg);
		msgbox.SetButtons(true,false,false);
		msgbox.Exec();
		//No resuming of accepting coupon data because we want to keep the suspension made when the form was shown
#if defined IMTS_ARM
		repaint ();
#endif

	} else {

		QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();

		if ( reply.isValid () ) {

			QStringList l = reply.value ();

			if ( !l.isEmpty () ) {

				QDBusInterface remoteApp( l.at (0), l.at (1) );
				QDBusReply<int> reply = remoteApp.call( QDBus::BlockWithGui,"displayMessageBox", QString::fromUtf8(msg), tr("OK"), QString::fromUtf8(title), QString(), QString (), QString(), 10000 /*iTimeOut*/ );

				if ( !reply.isValid() ) {

					QDBusError dbusError = reply.error();
					LOG ( dbusError.message () );
					LOG ( dbusError.errorString(dbusError.type()));

				} else {

					// OK or TimedOut. No need to do anything just return handle to caller
				}
			}

		} else {

			QDBusError dbusError = reply.error();
			LOG ( dbusError.message () );
			LOG ( dbusError.errorString(dbusError.type()));

			qWarning () << "Error in FlexBet: "  << dbusError.message ();
			qWarning () << "Error in FlexBet: "  << dbusError.errorString(dbusError.type());
		}
	}
}


/**
 * @sa proceedDueToCouponCost
 * @return true for proceeding with play false for discarding
 */
bool FlexBet::proceedDueToCouponCost ( const double& dCouponCost )
{
	bool bProceed = true;

	if ( dCouponCost > 300.0 ) {

//        QString qsTotalAmount = QString( QObject::tr("YOU ARE ABOUT\nTO VALIDATE A COUPON\nOF %1 BGN COST")).arg( AmountFunctions::getAmountStr(dCouponCost) ); //(dCouponCost,0,'f',2);
		QString qsTotalAmount = QString( QObject::tr("YOU ARE ABOUT\nTO VALIDATE A COUPON\nOF COST $%1")).arg( dCouponCost );

		if ( this->isVisible () ) {

			CoronisMessageBox msb(this,"MsgBox Edit Coupon");
			msb.SetTitle(tr("WARNING"));
			msb.SetContents (qsTotalAmount);
			msb.SetButtons(true, true, false);
			msb.Exec();

			bProceed = bool(msb.GetResult () ); // 0: Cancel, 1: OK
#if defined IMTS_ARM
			repaint ();
#endif

		} else {

			QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();

	if ( reply.isValid () ) {

		QStringList l = reply.value ();

		if ( !l.isEmpty () ) {

			QDBusInterface remoteApp( l.at (0), l.at (1) );
					QDBusReply<int> reply = remoteApp.call( QDBus::BlockWithGui,"displayMessageBox", qsTotalAmount, tr("Yes"), tr("WARNING"), tr("No"), QString (), QString(), 10000 /*iTimeOut*/ );

					if ( !reply.isValid() ) {

						QDBusError dbusError = reply.error();
						LOG ( dbusError.message () );
						LOG ( dbusError.errorString(dbusError.type()));
						bProceed = false;

					} else {

						int iUsersChoice = reply.value ();

						if ( iUsersChoice == 2 ) { // YES

							bProceed = true;

						} else { // NO or TIMEOUT

							bProceed = false;
						}
					}
				}

			} else {

				QDBusError dbusError = reply.error();
				LOG ( dbusError.message () );
				LOG ( dbusError.errorString(dbusError.type()));
				bProceed = false;

				qWarning () << "Error in FlexBet: "  << dbusError.message ();
				qWarning () << "Error in FlexBet: "  << dbusError.errorString(dbusError.type());
			}

		}

	}

	return bProceed;
}


/**
 * @sa proceedWithEdit
 * @return true for proceeding with edit false for discarding
 */
bool FlexBet::proceedWithEdit ( const QString& qsMessage )
{
	bool bProceed = true;

	QString qsMessageText = QString ("%1 %2").arg(qsMessage).arg(tr("WOULD YOU LIKE TO EDIT COUPON?"));

	if ( this->isVisible () ) {

		CoronisMessageBox msb(this,"MsgBox Edit Coupon");
		msb.SetTitle(tr("INFORMATION"));
		msb.SetContents(qsMessageText);
		msb.SetOkText("EDIT");
		msb.SetCancelText("DROP");
		msb.SetButtons(true, true, false);
		msb.Exec();

		bProceed = bool(msb.GetResult () ); // 0: Drop, 1: Edit
#if defined IMTS_ARM
		repaint ();
#endif

	} else {

		QDBusReply<QStringList> reply = DbusWrapper::getWindowManagerInterface ()->getActiveWindow ();

		if ( reply.isValid () ) {

			QStringList l = reply.value ();

			if ( !l.isEmpty () ) {

				QDBusInterface remoteApp( l.at (0), l.at (1) );
				QDBusReply<int> reply = remoteApp.call( QDBus::BlockWithGui, "displayMessageBox", qsMessageText, tr("EDIT"), tr("INFORMATION"), tr("DROP"), QString (), QString(), 10000 /*iTimeOut*/ );

				if ( !reply.isValid() ) {

					QDBusError dbusError = reply.error();
					LOG ( dbusError.message () );
					LOG ( dbusError.errorString(dbusError.type()));
					bProceed = false;

				} else {

					int iUsersChoice = reply.value ();

					if ( iUsersChoice == 2 ) { // EDIT

						bProceed = true;

					} else { // DROP or TIMEOUT

						bProceed = false;
					}
				}
			}

		} else {

			QDBusError dbusError = reply.error();
			LOG ( dbusError.message () );
			LOG ( dbusError.errorString(dbusError.type()));
			bProceed = false;

//            qWarning () << "Error in FlexBet: "  << dbusError.message ();
//            qWarning () << "Error in FlexBet: "  << dbusError.errorString(dbusError.type());
		}
	}

	return bProceed;
}

/**
 * @sa checkPrinter
 * @return bool
 */
bool FlexBet::checkPrinter ( )
{

	bool bOK = false;
	QString qsErrorMessage = QString ();

	// I don't think we need to poll for printer. It's all dynamic. But just in case, I'll leave the
	// printer checking code, in case we need it. We'll see.
	//
#ifndef CHECK_FOR_PRINTER

	QDBusReply<QStringList> reply = DbusWrapper::getPrintingServiceInterface ()->getPrinterStringError (PrinterTypes::Chief);

	if ( reply.isValid () ) {

		QStringList lPrinterErrors = reply.value ();

		if ( !lPrinterErrors.isEmpty () ) {
			//            qDebug () << "printer errors: " << lPrinterErrors;
			qsErrorMessage = lPrinterErrors.join (QChar('\n'));
			//            qDebug () << "printer errors: " << qsErrorMessage;
		} else {
			//            qDebug () << "No printer errors";
			bOK = true;
		}

	} else {

		QDBusError dbusError = reply.error();
		qDebug () << "CouponTransmissionManager Printer Error: " << dbusError.message ();
		qDebug () << "CouponTransmissionManager Printer Error: " << dbusError.errorString(dbusError.type());

		qsErrorMessage = QString(tr("Printing Service is down"));

		LOG (qsErrorMessage);
		LOG (dbusError.message ());
		LOG (dbusError.errorString(dbusError.type()));

	}


	if ( !bOK ) {
		DisplayError( tr("WARNING").utf8().data(), qsErrorMessage.utf8().data() );
	}

	return bOK;
#else
	Q_UNUSED ( cGamesConfig )
	Q_UNUSED ( qsErrorMessage )
#endif
}

/**
 * @sa processCameraDataSlot
 * @param qbaCameraData
 */
void FlexBet::processCameraDataSlot ( const QByteArray& qbaCameraData ) //, const int iCouponId
{
	if( m_bDelaying )
	{
		LOG("In Live event delay. Coupon will not be processed.")
		return;
	}

	m_lCoupons.append(qbaCameraData);

	GetNextCoupon();
}

bool FlexBet::GetNextCoupon()
{
	bool bCouponsInQueue = false;

	processingThread.exit();

	bCouponsInQueue = m_lCoupons.size();

	if( bCouponsInQueue )
	{
		emit sendCameraDataSlot(m_lCoupons.takeAt(0));
	}

	return bCouponsInQueue;
}

void FlexBet::sendCameraDataSlot ( const QByteArray& qbaCameraData ) //, const int iCouponId
{
	if( processingThread.isRunning() )
		return;

	processingThread.start();

	m_iCouponId = 0;

	QString strError="";
	qint8 iRet = ApplyMarks(0, qbaCameraData,strError);

	//- - - - simulation - - - -
//    qDebug("wait_1");
//    QEventLoop createLocalLoop;
//    QTimer::singleShot ( 2000, &createLocalLoop, SLOT(quit()) );
//    createLocalLoop.exec();
//    qDebug("wait_2");
	//- - - - simulation - - - -

	if ( !iRet ) {

		if( strError.length() )
			DisplayError(tr("Coupon Error").utf8().data(),strError.utf8().data());
		else
			DisplayError(tr("Coupon Error").utf8().data(),tr("Failed reading\nscanned coupon").utf8().data());

		GetNextCoupon();

		return;
	}
	//--------------------------------------------------------------

	CouponOriginFromScanner=1;
	RecordCoupon();

	qint8 iError = CheckCoupon (0, true);

    // aste: For CL, we want to show the form regardless of whether there are syntax errors in the coupon or not
    EditScanned = true;
    ShowForm();

	if ( iError != 1 ) {

		if(GetNextCoupon()) //do not edit form when there are coupons for transmition in queque
		{
			return;
		}

//		EditScanned = true;

		QString qsDisplayText = QString::fromUtf8(g_bet_err_txt);
		qsDisplayText += QString("\n");
		bool bProceed = proceedWithEdit ( qsDisplayText );

		if ( bProceed ) {
			CouponOriginFromScanner=0;
//			ShowForm ();
		} else {
			EditScanned = false;
			HideForm ();
		}

		GetNextCoupon();

		return;
	}

	//--------------------------------------------------------------
    // aste: We also do not want to send the data immediately to CS, so this is commented out
    // The user should press the send button themselves
//	SendData(false);

	GetNextCoupon();
}

//WE should probably need the iSecure number and the barcode. Thus, the argument may change to QVariantMap
void FlexBet::playHighStakeSlot(const QByteArray& qbaCsData, const uint ApprovalNbr )
{
	CouponRecord PrintCouponRecord;
	memcpy (PrintCouponRecord.HostReply,qbaCsData,qbaCsData.size());

	ConvertToPlayReply(PrintCouponRecord);

	UpdateGame(PrintCouponRecord, 0);

	//SendData( true ); //old: writes data in GP
	//------ or -----
	//new: send data directly to CS

	initCsTxData ( PrintCouponRecord, eeCSDataApproved );
	m_flexBetData.setApproval(ApprovalNbr);

	prePlaySteps();

	QVariantMap mCsReply = m_pcRequestDataFromCs->getCsDataSync( QJson::JsonOperations::qObjectToJson (&m_flexBetData) );
	unsigned int iReplyCode           = mCsReply.value (CS_REPLY_CODE).toUInt ();
	if ( iReplyCode == RD_OK )
	{
		QString qsErrorMessage = processCsData ( mCsReply, iReplyCode );
	}
	else
	{
		getError2Display(mCsReply,tr("Error on processing high stake ticket"));
	}
}


/**
  * @sa hideWindowSlot
  * @brief hides FlexBet
  */
void FlexBet::hideWindowSlot()
{
	HideForm();
}

QByteArray FlexBet::highStakePreviewSlot(const QByteArray &qbaCsData)
{

	return PreviewHTMLCoupon(qbaCsData);

}

void FlexBet::DownloadTeams()
{
	CheckActiveDraw(false,true);
}

bool FlexBet::CheckActiveDraw(bool asynchronous_mode, bool downloadActiveDrawFile, uint replyDraw, uint replyLiveRevision, uint replyPreGameRevision)
{

#if defined(SIMULATE_TRANSACTION)
	QElapsedTimer timer;
	timer.start();
	qDebug() << "Check active draw simulation started";

	QEventLoop createLocalLoop;
	QTimer::singleShot ( 80000, &createLocalLoop, SLOT(quit()) );
	createLocalLoop.exec();
	qDebug() << "Check active draw simulation finished in: " << timer.elapsed();
	return false;
#else


	bool bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();

	if(!bIsTraining){
		return m_flexBetXmlController->CheckActiveDraw(asynchronous_mode,downloadActiveDrawFile,replyDraw,replyLiveRevision,replyPreGameRevision);
	}else{
		return true;
	}
#endif
}

QString FlexBet::formatOdds(uint integral,uint fractional) {
	// This one "hides" the problem of the odds printout
	// when the central system sends the odds as i.(f-1)4999
	// example: 2.59999 instead of 1.6. It also takes care of the
	// formating of the odds (maximum 5 digits printout etc.)
	if (integral>=10000)
		integral%=10000;
	if (fractional>=10000)
		fractional%=10000;
	int places=4;
	if (fractional&1)
		fractional++;
	for (int i=1;i<10000;i*=10) {
		if (!(integral/i))
			break;
		places--;
	}
	if (places==3&&!(fractional%100))
		places=2;
	if (places==4)
	{
		if (!(fractional%100))
			places=2;
		else if (!(fractional%10))
			places=3;
	}

	char s[128];
	memset(s,0,sizeof(s));
	sprintf(s,"%.*f",places,integral+(fractional/10000.0));

	return QString(s);
}


/**
  * @sa addPlayTransactionToCustomerSession
  * @brief Populates the map addTransaction method expects and calls it to adds play transaction
  * to customer session.
  */
void FlexBet::addPlayTransactionToCustomerSession ( const quint32& iTransactionNo, const QString& qsBarcode, const QString& qsIsecure, QString qsSavedPlayFile, const double dAmount )
{
	QDateTime dateTime = QDateTime::currentDateTime ();

	QString qsCompleteBarcode = qsBarcode;
	qsCompleteBarcode.append (QString("-"));
	qsCompleteBarcode.append (qsIsecure);

	CustomerSessionTrnsData customerSessionTrnsData;
	customerSessionTrnsData.setHandleId ( 0 ); // 0 because only one customer is currently supported. We could add more customers.
	customerSessionTrnsData.setSessionId ( 0 );
	customerSessionTrnsData.setTransactionDateTime ( dateTime.toTime_t () );
	customerSessionTrnsData.setTransactionDescription ( tr("Sports Betting") );
	customerSessionTrnsData.setTransactionType (TransactionTypes::Play);
	customerSessionTrnsData.setTransactionNumber ( QString::number( iTransactionNo ).rightJustified (10,'0') );
	customerSessionTrnsData.setAmount ( dAmount );
	customerSessionTrnsData.setTimesPrinted (0);

	customerSessionTrnsData.setBarcode ( qsCompleteBarcode );
	customerSessionTrnsData.setTransactionTypeLastPrint ( qsSavedPlayFile.append (".html") );


	QByteArray qbaJsonData = QJson::JsonOperations::qObjectToJson (&customerSessionTrnsData);

	PlaceServerManagerRequest placeServerManagerRequest;
	placeServerManagerRequest.aSyncRequest ( ClientServerDefinitions::CustomerSessionUpdate, qbaJsonData );

}

/**
 * @sa finalizeReceipt
 * @param mReply the reply returned by Trss object
 * @param mPrintData data for html to fill the template with
 * @param bTraining true or false(default)
 */
void FlexBet::finalizeReceipt ( const QVariantMap& mReply, CSS_IT_1 *css_it_1, REPLY_100_1 *reply_100_1, QVariantMap& mPrintData, bool bApprovalRequired, bool bPendingApproval, bool bTraining )
{
	quint32 iTrnsNumber = 0;
	QString qsSaveReceivedFileName = QString ();
	QString qsBarcode = QString ();
	QString qsIsecure = QString ();
	static quint32 iAgencyNumber = 0;
	static quint32 iTerminalNumber = 0;
	Q_UNUSED(iTerminalNumber);

	static bool bCommonInitialized = false;
	bool bWithBarcode = !( bPendingApproval || bApprovalRequired );

	if ( !bCommonInitialized ) {

		QVariantList receiptValuesList = QVariantList ();


		// Get from SCM the values we need to complete Lotos5 tx packet header initialization.
		QDBusReply<QVariantList> reply = DbusWrapper::getNvramManagerInterface () ->getTerminalIdentification ();

		if (reply.isValid()) { // SUCCESS

			receiptValuesList = reply.value(); /* [0]: it, [1]: agn, [2]: trm */

			if ( receiptValuesList.isEmpty () ) {
				qWarning("Scm send an empty value list for filling in tx header");
			} else {
				//iItNumber       = receiptValuesList.at (0).toUInt ();
				iAgencyNumber   = receiptValuesList.at (1).toUInt();
				iTerminalNumber = receiptValuesList.at (2).toUInt();
				bCommonInitialized = true;
			}

		} else { // FAIL

			QDBusError dbusError = reply.error();

			qWarning () << dbusError.message();
			qWarning () << dbusError.errorString(dbusError.type());
			qWarning () << "Scm Service is down?";
		}
	}

	if ( bTraining ) {
		QSettings settings (QLatin1String("Intralot"), QLatin1String("Scm"));
		settings.sync ();
		iTrnsNumber = settings.value (QLatin1String("TransactionNumberTraining"), QVariant(0)).toInt ();

		qsSaveReceivedFileName = QString("Game_%1_Play_%2_Training").arg (IFLEX_GAMECODE).arg (iTrnsNumber);

	} else {
		CSS_IT_1 *css_it_1 = (CSS_IT_1 *) (betCoupon.HostReply);
		iTrnsNumber =  css_it_1->hdr.trns;

		qsSaveReceivedFileName = QString("Game_%1_Play_%2").arg (IFLEX_GAMECODE).arg (iTrnsNumber);
	}


	mPrintData.insert (QLatin1String("SAVE_AS"), qsSaveReceivedFileName );

	if ( bWithBarcode ) {
		qsBarcode = mReply.value ("barcode").toString ();
		qsIsecure = mReply.value ("iSecurePrintable").toString ();
		QString qs30digitBarcode = qsBarcode.left(35);
		QString qsCrc            = qsBarcode.right(5);
		mPrintData.insert (QString("barcodeText"),        qs30digitBarcode);
		QString qsDummyISecure = qsCrc+qsIsecure; //QString ().fill (QChar('0'),20);
		qsDummyISecure.insert (5,QChar(' '));
		qsDummyISecure.insert (11,QChar(' '));
		qsDummyISecure.insert (17,QChar(' '));
		qsDummyISecure.insert (23,QChar(' '));
		mPrintData.insert (QString("iSecure"),            QString("%1").arg ( qsDummyISecure ) );
		QString qsGraphicalBarcode = qsBarcode+qsIsecure;
		qsGraphicalBarcode.remove (QRegExp(" "));
		mPrintData.insert (QString("graphical_barcode"),  qsGraphicalBarcode.remove (QRegExp("\\D")));
		mPrintData.insertMulti (QString("CLEAR_CONTENT_AFTER_PRINT"), QString("GraphicalBarcodeContainer") ); // Print, Clear, Save
		mPrintData.insertMulti (QString("CLEAR_CONTENT_AFTER_PRINT"), QString("barcodeText") );       // Print, Clear, Save
		mPrintData.insertMulti (QString("CLEAR_CONTENT_AFTER_PRINT"), QString("iSecure") );           // Print, Clear, Save
		mPrintData.insertMulti (QString("CLEAR_CONTENT_AFTER_PRINT"), QString("graphical_barcode") ); // Print, Clear, Save
		mPrintData.insertMulti (QString("CLEAR_CONTENT_AFTER_PRINT"), QString("ean13BarcodeText") );  // Print, Clear, Save
	} else {
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "graphical_barcode");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "barcodeText");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "barcodeTable");
	}

	//header --------------------------------------------
	//mPrintData.insert ( QLatin1String("gameNameCode") ,   "(" + QString::number(IFLEX_GAMECODE ) + ")" ); //FROM_AZ

//    QString qsCombinedAgentUserTerminal =
//            QString ("%1").arg(iAgencyNumber).rightJustified(7,'0',true) +
//            QString ("-") +
//            QString ("%1").arg(css_it_1->hdr.usr).rightJustified(6,'0',true) +
//            QString (" ") +
//            QString ("%1").arg(iTerminalNumber).rightJustified(3,'0',true);
	QString qsAgent = QString ("%1").arg(iAgencyNumber).rightJustified(8,'0',true);
	QString qsTerminal = QString ("%1").arg(iTerminalNumber);

	QString qsTransactionNumber = QString ("%1").arg(css_it_1->hdr.trns).rightJustified(10,'0',true);

	uint uiVal;

	uiVal = bApprovalRequired ? 0 : reply_100_1->data[3];
	QString qsDraw;
	qsDraw.sprintf("%06d",uiVal);

	uiVal = bApprovalRequired ? 0 : reply_100_1->cpn;
	QString qsCouponNumber = QString ("%1").arg(uiVal).rightJustified(10,'0',true);

	uiVal = bApprovalRequired ? 0 : reply_100_1->data[1];
	QString qsColoumns = QString ("%1").arg(uiVal);

//    mPrintData.insert ( QLatin1String("cmbAgUsTerm")  ,   qsCombinedAgentUserTerminal);
	mPrintData.insert ( QLatin1String("terminal")         ,   QString(QString("%1").arg(qsTerminal)));
	mPrintData.insert ( QLatin1String("agent")         ,   QString(QString("%1").arg(qsAgent)));
	mPrintData.insert ( QLatin1String("draw")         ,   QString(QString("%1").arg(qsDraw)));
	mPrintData.insert ( QLatin1String("trns")         ,   QString(QString("%1").arg(qsTransactionNumber)));
	mPrintData.insert ( QLatin1String("cpn")          ,   QString(QString("%1").arg(qsCouponNumber)));
	mPrintData.insert ( QLatin1String("cols")         ,   QString(QString("%1").arg(qsColoumns)));
	if( bApprovalRequired || bPendingApproval )
	{
		mPrintData.insert("crcnum", QString("--------"));

		if( bApprovalRequired )
		{
			mPrintData.insert ( QLatin1String("drawDate") ,   QString("(--/--/-- --:--)"));
		}
		else
		{
			QDateTime dateTime;
			dateTime.setTime_t(reply_100_1->data[4]);
			mPrintData.insert ( QLatin1String("drawDate")   ,   QString(QString("%1").arg(dateTime.toString("(dd/MM/yy HH:mm)"))));
		}

		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "accDaySt"); //mPrintData.insert ("accDaySt", QString("---"));
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "accDayNum"); //mPrintData.insert ("accDayNum", QString(" -- "));
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "accMonth"); //mPrintData.insert ("accMonth", QString("----"));
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "accYear"); //mPrintData.insert ("accYear", QString(" ---- "));
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "accDateTime"); //mPrintData.insert ("accDateTime", QString("(--/--/---- --:--:--)") );
	}
	else
	{
		QString strHex;
//        strHex.sprintf("%08x",(uint)css_it_1->hdr.crc); //old
		QByteArray qbaCsTxData = QByteArray::fromBase64( mReply.value ("CS_TX_MSG").toByteArray());
		IT_CSS_3 *it_css_3 = (IT_CSS_3 *)qbaCsTxData.data();
		strHex.sprintf("%08x",(uint)it_css_3->hdr.crc);
		mPrintData.insert("crcnum", strHex.upper());

		QDateTime dateTime;

		dateTime.setTime_t(reply_100_1->data[4]);
		mPrintData.insert ( QLatin1String("drawDate")   ,   QString(QString("%1").arg(dateTime.toString("(dd/MM/yy HH:mm)"))));

////////////////////////////////////
		QDateTime acceptanceTime;
		acceptanceTime.setTime_t(reply_100_1->data[0]);
		QString accDay="";
		getDay ( &acceptanceTime,accDay );

		mPrintData.insert ("accDaySt", accDay);
		mPrintData.insert ("accDayNum", acceptanceTime.toString(" dd "));


		QString accMonth="";
		getMonth ( &acceptanceTime,accMonth );
		accMonth = accMonth.mid ( 0,4 );


		mPrintData.insert ("accMonth", accMonth);


		QString accYear="";

		accYear.append(acceptanceTime.toString ( " yyyy" ));
		mPrintData.insert ("accYear", accYear);

		mPrintData.insert ("accDateTime", acceptanceTime.toString("(dd/MM/yyyy hh:mm:ss)") );
 /////////////////////////////////////////////////////
	}

	//header --------------------------------------------

	// The following will clear html's content after printing is done. We don't want those when re-print is printed.
	mPrintData.insertMulti (QLatin1String("CLEAR_CONTENT_AFTER_PRINT"), QLatin1String("barcodeText") );       // Print, Clear, Save
  //  mPrintData.insertMulti (QLatin1String("CLEAR_CONTENT_AFTER_PRINT"), QLatin1String("GRAPHICAL_BARCODE") ); // Print, Clear, Save


	//************************************* TOTAL COST ******************************************
	double dAmount = 0;
	if( bApprovalRequired )
	{
		mPrintData.insert ("amount", "-,--");

	}
	else
	{
        dAmount = AmountFunctions::getAmount((AMOUNT_STRC *)&reply_100_1->amount);
//        dAmount = FormatAmount::getFormatedAmount((AMOUNT_STRC *)&reply_100_1->amount);
//        dAmount = FormatAmount::convert_AMOUNTSTRC_db((AMOUNT_STRC *)&reply_100_1->amount);
//        mPrintData.insert ("amount", FormatAmount::convert_AMOUNTSTRC_db((AMOUNT_STRC *)&reply_100_1->amount) ); //totalMoney.toQString());
        mPrintData.insert ("amount", AmountFunctions::getAmountStr((AMOUNT_STRC *)&reply_100_1->amount) ); //totalMoney.toQString());
//        mPrintData.insert ("amount", QString(QString("%1").arg(dAmount) )); //totalMoney.toQString());
	}
	//*******************************************************************************************

	if ( bWithBarcode ) { // means that the retailer was charged for this play so add to customer session.
		addPlayTransactionToCustomerSession ( iTrnsNumber, qsBarcode, qsIsecure, qsSaveReceivedFileName, dAmount );
	}

}

QString FlexBet::getGroupHtmlStr(QString strFile)
{
	QFile qFile;
	char cBuf[8192];

	//group file
	qFile.setName(strFile);

	if(!qFile.exists())
		return "";

	memset(cBuf,0x00,sizeof(cBuf));
	if(!qFile.open(IO_ReadOnly))
		return "";

	if (qFile.readBlock(cBuf,qFile.size()) != qFile.size() )
	{
		qFile.close();
		return "";
	}
	qFile.close();
	return QString(cBuf);
}

bool FlexBet::InsertHtmlFile(QString iFlexHtml, QString strHtml, QString strPosition, QString outputHtml)
{
	//parent file
	QFile qFile;
	qFile.setName(iFlexHtml);

	if(!qFile.exists())
		return false;

	char cBuf[16384];
	memset(cBuf,0x00,sizeof(cBuf));
	if(!qFile.open(IO_ReadOnly | IO_WriteOnly))
		return false;

	if (qFile.readBlock(cBuf,qFile.size()) != qFile.size() )
	{
		qFile.close();
		return false;
	}
	qFile.close();
	//relpace
	QString strGroup = QString(cBuf);
	strGroup.replace(strPosition,strHtml);


	//output
	qFile.setName(outputHtml);
	qFile.remove();

	if(!qFile.open(IO_WriteOnly))
		return false;

	if (qFile.writeBlock(strGroup,strGroup.length()) != strGroup.length() )
	{
		qFile.close();
		return false;
	}
	qFile.close();

	return true;
}


typedef struct {
	unsigned char   reply;          // Servers reply to the inc msg
	long            trns_nr;        // Cookie from the incoming msg
	int             length;         // Length of data to follow typicaly what received
} __attribute__ ((packed)) COMM_REPLY;

void FlexBet::LoadTxRxFromFiles()
{
	QFile qFile;
	qFile.setName("/home/A_TX.dat");
	if(qFile.exists())
	{
		char cBuf[512];
		memset(cBuf,0x00,sizeof(cBuf));
		if(qFile.open(IO_ReadOnly))
		{
			if( qFile.readBlock(cBuf,qFile.size()) != qFile.size() )
				qDebug("readBlock A failed");
			qFile.close();

			memcpy (&CouponRec[CurrentCoupon].Record[0],&cBuf[ sizeof(COMM_REPLY) ], qFile.size()-sizeof(COMM_REPLY) );
		}
	}
	qFile.setName("/home/B_RX.dat");
	if(qFile.exists())
	{
		char cBuf[512];
		memset(cBuf,0x00,sizeof(cBuf));
		if(qFile.open(IO_ReadOnly))
		{
			if( qFile.readBlock(cBuf,qFile.size()) != qFile.size() )
				qDebug("readBlock B failed");
			qFile.close();

			memcpy (betCoupon.HostReply,&cBuf [ sizeof(COMM_REPLY) ], qFile.size()-sizeof(COMM_REPLY) );
			memcpy (&CouponRec[CurrentCoupon].HostReply[0],&cBuf[ sizeof(COMM_REPLY) ], qFile.size()-sizeof(COMM_REPLY) );
		}
	}
}

QString FlexBet::getGroupStr(unsigned long val_flg, bool bApprovalRequired )
{
	QString groupPrnt="";

	if ( bApprovalRequired )
		return " ";

	val_flg = ( val_flg % 100 );

	if ( !val_flg )
		return groupPrnt;

	if ( val_flg>10 )
	{
		groupPrnt = qApp->translate ( "FlexBet","(R" );
		val_flg = val_flg % 10;
	}
	else
	{
		groupPrnt = qApp->translate ( "FlexBet","(-" );
	}
	switch ( val_flg )
	{
		case 1:
			groupPrnt.append ( qApp->translate ( "FlexBet","A-)" ) );
			break;
		case 2:
			groupPrnt.append ( qApp->translate ( "FlexBet","B-)" ) );
			break;
		case 3:
			groupPrnt.append ( qApp->translate ( "FlexBet","C-)" ) );
			break;
		case 4:
			groupPrnt.append ( qApp->translate ( "FlexBet","D-)" ) );
			break;
		case 5:
			groupPrnt.append ( qApp->translate ( "FlexBet","AB)" ) );
			break;
		case 6:
			groupPrnt.append ( qApp->translate ( "FlexBet","AC)" ) );
			break;
		case 7:
			groupPrnt.append ( qApp->translate ( "FlexBet","AD)" ) );
			break;
		case 8:
			groupPrnt.append ( qApp->translate ( "FlexBet","BC)" ) );
			break;
		case 9:
			groupPrnt.append ( qApp->translate ( "FlexBet","BD)" ) );
			break;
		default:
			groupPrnt.append ( qApp->translate ( "FlexBet","CD)" ) );
			break;
	}
	return groupPrnt;
}

QString FlexBet::getHandicapNormal(int codeR,RTRNS_CD_15000 *repData,bool bApprovalRequired)
{
	QString handicapStr;
		short handcp1, handcp2;
	if (bApprovalRequired) //css_it_1->res == 100000
	{
		if (codeR>=NORMAL_BETTYPES_STARTINGCODE)
		{
			if (codeR>=UNDER_OVER_STARTING_CODE && codeR<=UNDER_OVER_ENDING_CODE)
			{
//                if (repData->var[0] != 0) //not accesible
//                {
//                    handicapStr=(QString(qApp->translate("FlexBet","LIM:"))+QString::number(repData->var[0]/2.0,'f',1));//format as [-]9.9, 1 digit precision

//                }
//                else
				{
					handicapStr=QString(qApp->translate("FlexBet","HND:"))+QString("---- ----");
				}
			}else if(codeR>=WHO_WILL_WIN_THE_REST_OF_THE_GAME_STARTING_CODE &&
	 codeR<=WHO_WILL_WIN_THE_REST_OF_THE_GAME_ENDING_CODE){
	handicapStr=QString(qApp->translate("FlexBet","HND:"))+QString("---- ----");
	}
			else
				handicapStr=QString(qApp->translate("FlexBet","HND:"))+QString("---- ----");
		}
	}
	else
	{
		if (codeR>=UNDER_OVER_STARTING_CODE && codeR<=UNDER_OVER_ENDING_CODE)
		{

			if (repData->var[0] != 0) // if (repData->codds[1].ipart != 0) {
			{
				handicapStr=(QString(qApp->translate("FlexBet","LIM:"))+QString::number(repData->var[0]/2.0,'f',1));//format as [-]9.9, 1 digit precision
			}
			else
			{
				handicapStr=QString(qApp->translate("FlexBet","HND:"))+QString("---- ----");
			}
		}else if(codeR>=WHO_WILL_WIN_THE_REST_OF_THE_GAME_STARTING_CODE &&
	 codeR<=WHO_WILL_WIN_THE_REST_OF_THE_GAME_ENDING_CODE){
	handicapStr=QString(qApp->translate("FlexBet","HND:"))+QString("---- ----");
	}
		else
		{
			handcp1=repData->var[0];//fst_handicap;
			handcp2=repData->var[1];//sec_handicap;

			handicapStr=QString(qApp->translate("FlexBet","HND:"));
			if (handcp1 == 0)
			{
				handicapStr.append("----");
			}
			else if (handcp1 > 0)
			{
				handicapStr.append(qApp->translate("FlexBet","H"));
				handicapStr.append(QString::number(handcp1/2.0,'f',1));
			}
			else if (handcp1 < 0)
			{
				handicapStr.append(qApp->translate("FlexBet","A"));
				handicapStr.append(QString::number(-handcp1/2.0,'f',1));
			}
			handicapStr+=" ";
			if (handcp2 == 0)
			{
				handicapStr.append("----");
			}
			else if (handcp2 > 0)
			{
				handicapStr.append(qApp->translate("FlexBet","H"));
				handicapStr.append(QString::number(handcp2/2.0,'f',1));
			}
			else if (handcp2 < 0)
			{
				handicapStr.append(qApp->translate("FlexBet","A"));
				handicapStr.append(QString::number(-handcp2/2.0,'f',1));
			}
		}
	}

	if( handicapStr.contains(".") )
		handicapStr.replace(".",",");

//    if ( handicapStr == QString(qApp->translate("FlexBet","HND:"))+QString("---- ----") )
//		handicapStr=" "; //no need for empty handicap appearance

	return handicapStr;
}

QString FlexBet::getOddSpecial(RTRNS_CD_15000 *repData)
{
	QString oddStr="";

	if (repData->codds[0].ipart || repData->codds[0].fpart)
	{
		oddStr.sprintf("%d,%02d", repData->codds[0].ipart, repData->codds[0].fpart);
	}
	else
		oddStr="----";

	return oddStr;
}

QString FlexBet::getOddNormal(int codeR,RTRNS_CD_15000 *repData)
{
	QString oddStr;
	QString oddStr1,oddStr2;

	if (repData->codds[0].ipart || repData->codds[0].fpart)
	{
		oddStr.sprintf("%d,%02d", repData->codds[0].ipart, repData->codds[0].fpart);
	}
	if ((codeR<UNDER_OVER_STARTING_CODE || codeR>UNDER_OVER_ENDING_CODE) && repData->codds[1].ipart)
	{
		if (repData->codds[0].ipart)
		{
			oddStr.append(" ");
			oddStr1.sprintf("%d,%02d", repData->codds[1].ipart, repData->codds[1].fpart);
			oddStr.append(oddStr1);
		}
		else
			oddStr="----";
	}

	if ((codeR<UNDER_OVER_STARTING_CODE || codeR>UNDER_OVER_ENDING_CODE) && repData->codds[2].ipart)
	{
		if (repData->codds[1].ipart)
		{
			oddStr.append(" ");
			oddStr2.sprintf("%d,%02d", repData->codds[2].ipart, repData->codds[2].fpart);
			oddStr.append(oddStr2);
		}
		else
			oddStr="----";
	}

	if (oddStr.isEmpty())
		oddStr="----";

	return oddStr;
}

QString FlexBet::FillNormal(unsigned int i,TRNS_GM_15000 *trns_gm_15000,SEL_DATA_EV_15000 *betData,RTRNS_CD_15000 *repData, QString strOutcomeBlock, bool bApprovalRequired)
{
	QString betStr;
	QString oddStr;
	QString handicapStr;
	QString groupStr;

	QString strID="";
	strID.sprintf("%02d.",i+1);
	strOutcomeBlock.replace("event_id_value",strID);

	uint eventR = betData->val/100000;// the first 3 digits
	int codeR = betData->val % 1000; // the last 3 digits

	QString event_code = SPACE_REPLACE_STR;
	if (betData->val_flg>=100)
		event_code="#";
	event_code+=QString::number(eventR);
	event_code = event_code.rightJustify(TICKET_EVENTID_LEN,SPACE_REPLACE_CHAR);
	event_code = event_code.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	QString homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType="";

//    if( trns_gm_15000->sjp_nr )
//        m_pApp->getJackpotBetDescription(codeR,betTypeTxt,betDescr);
//    else
		m_pApp->getBetDescription(eventR,codeR,homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType);

	//event
//    if( trns_gm_15000->sjp_nr )
//        strOutcomeBlock.replace("event_code_value"," ");
//    else
		strOutcomeBlock.replace("event_code_value",event_code);
//    strOutcomeBlock.replace("event_descr_value",getEventDescription(homeDescr,visitorDescr,trns_gm_15000->sjp_nr,TICKET_EVENT_LEN));
		strOutcomeBlock.replace("event_descr_value",getEventDescription(homeDescr,visitorDescr,0,TICKET_EVENT_LEN));
	strOutcomeBlock.leftJustified(TICKET_EVENT_LEN,SPACE_REPLACE_CHAR);
	strOutcomeBlock = strOutcomeBlock.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	//outcome
	if (bApprovalRequired)
		betStr = ( betTypeTxt+QString(" ")+betDescr );
	else if (repData->imrkt_apos<0)
		betStr = ( betTypeTxt+QString(" ")+betDescr );
	else
	{
		QString market = QString::null;
		if(codeR>=WHO_WILL_WIN_THE_REST_OF_THE_GAME_STARTING_CODE && codeR<=WHO_WILL_WIN_THE_REST_OF_THE_GAME_ENDING_CODE)
		{
			QString homeScore = QString("%1").arg((int)repData->imrkt_apos);
			QString visitorScore = QString("%1").arg(((int)repData->imrkt_apos)+((int)(repData->var[0]/2.0)));
			market+= QString(":") + homeScore + QString("-") + visitorScore;
			betStr = betTypeTxt + QString(" ") + betDescr + market;
		}else
		{
			market+=QString(":%1").arg(repData->imrkt_apos+1);
			betStr = ( betTypeTxt + QString(market) + QString(" ") + betDescr );//PrintBet(codeR);
		}
	}
	betStr = QString::fromUtf8(betStr);
	betStr.truncate(TICKET_BET_OUTCOME_NORMAL_LEN);
	if( codeR==FstHALF_1X2 || codeR==SndHALF_1X2 || codeR==FINALHC_1X2 || codeR==FINAL_1X2 )
		betStr = betStr.leftJustify(TICKET_BET_OUTCOME_NORMAL_LEN-7,SPACE_REPLACE_CHAR); //den xoraei as is
	else
		betStr = betStr.leftJustify(TICKET_BET_OUTCOME_NORMAL_LEN,SPACE_REPLACE_CHAR);
	betStr = betStr.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	strOutcomeBlock.replace("outcome_descr_value",betStr.utf8());

	//odd
	if( bApprovalRequired)
		oddStr="----";
	else
		oddStr = getOddNormal(codeR,repData);

	oddStr = oddStr.leftJustify(TICKET_BET_ODD_LEN,SPACE_REPLACE_CHAR);
	oddStr = oddStr.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	strOutcomeBlock.replace("outcome_odds_value",oddStr);

	//handicap
	handicapStr=getHandicapNormal(codeR,repData,bApprovalRequired);
	handicapStr = handicapStr.rightJustify(TICKET_BET_HANDICAP_LEN,SPACE_REPLACE_CHAR);
	handicapStr = handicapStr.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	strOutcomeBlock.replace("outcome_hnd_value",handicapStr.utf8());


	return strOutcomeBlock;
}

QString FlexBet::FillSpecial(unsigned int i,TRNS_GM_15000 *trns_gm_15000,SEL_DATA_EV_15000 *betData,RTRNS_CD_15000 *repData,QString strOutcomeBlock, bool bApprovalRequired)
{
	QString specialEvtDesc;
	QString betStr;
	QString oddStr;
	QString handicapStr;
	QString groupStr;

	QString strID="";
	strID.sprintf("%02d.",i+1);
	strOutcomeBlock.replace("event_id_value",strID);

	uint eventR = betData->val/100000;// the first 3 digits
	int codeR = betData->val % 1000; // the last 3 digits

	QString event_code = SPACE_REPLACE_STR;
	if (betData->val_flg>=100)
		event_code="#";
	event_code+=QString::number(eventR);
	event_code = event_code.rightJustify(TICKET_EVENTID_LEN,SPACE_REPLACE_CHAR);
	event_code = event_code.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	QString homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType="";

	m_pApp->getBetDescription(eventR,codeR,homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType);

	//event
//    if( trns_gm_15000->sjp_nr )
//        strOutcomeBlock.replace("event_code_value"," ");
//    else
		strOutcomeBlock.replace("event_code_value",event_code);

//    if( homeDescr.length() && homeDescr!=tr("HOME TEAM"))
//        strOutcomeBlock.replace("event_descr_value",getEventDescription(homeDescr,visitorDescr,trns_gm_15000->sjp_nr,TICKET_EVENT_LEN));
//    else
//        strOutcomeBlock.replace("event_descr_value",getEventDescription(otherDescr,"",trns_gm_15000->sjp_nr,TICKET_EVENT_LEN));
	strOutcomeBlock.leftJustified(TICKET_EVENT_LEN,SPACE_REPLACE_CHAR);
	strOutcomeBlock = strOutcomeBlock.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);

	//outcomes
	betStr=(QString::number(codeR+SPECIALBETTYPE_CODE_OFFSET).rightJustify(3,' '));

	betTypeTxt = QString::fromUtf8(betTypeTxt);
	betTypeTxt.truncate(TICKET_BET_TYPE_SPECIAL_LEN);
	strOutcomeBlock.replace("outcome_descrtype_value",betTypeTxt.utf8());

	specialEvtDesc = betDescr;
	specialEvtDesc=specialEvtDesc.stripWhiteSpace();
	if (specialEvtDesc.length()>21)
		specialEvtDesc.setLength(21);
	betStr+=(QString(SPACE_REPLACE_CHAR) + /*betTypeTxt + " " + */specialEvtDesc); //uncomment to show outcome-event descr
	betStr = QString::fromUtf8(betStr);
	betStr.truncate(TICKET_BET_OUTCOME_SPECIAL_LEN);
	betStr = betStr.leftJustify(TICKET_BET_OUTCOME_SPECIAL_LEN,SPACE_REPLACE_CHAR);
	betStr = betStr.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);
	strOutcomeBlock.replace("outcome_descr_value",betStr.utf8());

	//odd
	if( bApprovalRequired)
		oddStr="----";
	else
		oddStr = getOddNormal(codeR,repData);

	oddStr = oddStr.leftJustify(TICKET_BET_ODD_LEN,SPACE_REPLACE_CHAR);
	oddStr = oddStr.replace(SPACE_REPLACE_STR,SPACE_HTML_STR);
	qDebug() << "oddStr=" << oddStr;
	strOutcomeBlock.replace("outcome_odds_value",oddStr);

	return strOutcomeBlock;
}

void FlexBet::FillSystems(QVariantMap &mPrintData,TRNS_GM_15000 *trns_gm_15000, ulong trns_cpn_hdr_data0, ulong reply_100_1_data1, bool bApprovalRequired)
{
	unsigned char codes_count=0;
	unsigned char std_count=0;
	unsigned char Dbls[TOT_CPN_AREAS];
	unsigned char std_tbl[TOT_CPN_AREAS];
	int tmplines, tmpmult,system;
	QString systemStr="-";
	unsigned long totalCpnClms=0;
	unsigned long multmp= 1;

	///========================END OF PRINT COUPON'S AREAS========================
	///================================PRINT SYSTEMS==============================
	/* Here the part of the receipt that the systems appear is procesedcp
	The columns from each system played must appear and followed by their
	specific multiplier the total column for the given systam are calculated
	and printed
	The overal coupon multiplier * the sum of the columns of each system is
	the final total columns number fot the coupon*/
	memset(Dbls,1,sizeof(Dbls));
	memset(std_tbl,0,sizeof(std_tbl));

	int cpn=0;
	GroupingAdjustmentFromRec(trns_gm_15000,Dbls,std_tbl,codes_count,std_count,cpn);

	unsigned long tmpClms=0;
	unsigned long totalCpnLines=0;
	int systemCount=0;
	unsigned int SysColumns=0;
	for (int i=0; i<NUM_O_PERMS-2; i++)
	{
		/*if a system is selected*/
		if (getbit(trns_gm_15000->req,i))
		{
			if( systemStr=="-")
				systemStr="";

			systemCount++;
			//mPrintData.insertMulti ("perms_det_tag", "CLONE_ONLY");

			/*print which system it is*/
			system=(i-std_count+1);
			/*for the given system calculate the columns*/
			tmplines=CalculateColumns(codes_count, std_count, i+1, Dbls, std_tbl);
			SysColumns+=tmplines;
			tmpmult=1;
			/* for the given system evaluate the multiplier
			and the total columns deriving*/
			tmpClms *= trns_gm_15000->data.ev_bet.req_mult[i];
			tmpmult *= trns_gm_15000->data.ev_bet.req_mult[i];

			tmpClms=tmplines*tmpmult;
			totalCpnLines+=tmpClms;

			//sprintf(XMLTmp,FormStr,system,tmplines,tmpmult,tmpClms);
			//mPrintData.insertMulti("perms_value_tag",system);
			if( systemStr.length() )
				systemStr.append(", ");
			systemStr+=QString::number(system);

			//mPrintData.insertMulti("lines_value_tag",QString::number(tmplines)); //Azerbaijan issues
			//mPrintData.insertMulti("perms_multi_value_tag",QString::number(tmpmult));
			//mPrintData.insertMulti("lines_total_value_tag",QString::number(tmpClms));

		}
	}
	mPrintData.insertMulti("perms_value_tag",systemStr);

	///========================================END OF PRINTING SYSTEMS=================================================
	//mPrintData.insertMulti("lines_alltotal_value_tag",QString::number(totalCpnLines)); //Azerbaijan issues

	if (bApprovalRequired)
	{
		totalCpnClms=0; //CouponRec[cpn].Info.BasicCol;
	}
	else
	{
		totalCpnClms=reply_100_1_data1;
	}
	multmp=trns_cpn_hdr_data0;

//    mPrintData.insertMulti("mults_value_tag",FormatAmount::getFormatedAmount(multmp * DEFAULT_STAKE));
	mPrintData.insertMulti("mults_value_tag",AmountFunctions::getAmountStr(multmp * DEFAULT_STAKE)); //Azerbaijan issues
	if( bApprovalRequired )
		mPrintData.insertMulti("cols_value_tag",QString::number(0)); //Azerbaijan issues
	else
        mPrintData.insertMulti("cols_value_tag",QString::number(totalCpnClms/multmp)); //Azerbaijan issues
}

void FlexBet::PrintApprovalNumber(QVariantMap &mPrintData,ulong css_it_1_res, ulong css_it_1_data, ulong trns_gm_15000_app, bool bPendingApproval)
{
	///========================PRINT APPROVAL NUMBER========================

	if (css_it_1_res == 100000)
	{
		// receipt without barcode providing the approval request number to the player
		mPrintData.insertMulti("approval_nr",QString::number(css_it_1_data));
		//qDebug("APPROVAL NUMBER: css_it_1_data = %d",css_it_1_data);
	}
	else if (trns_gm_15000_app)
	{
		// if an approved coupon is processed then the approval nnumber appears in the receipt
		mPrintData.insertMulti("approval_nr",QString::number(trns_gm_15000_app));
		if( !bPendingApproval )
			mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "Void");
	}
	else
	{
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "approvalNumberLine");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "approval_nr");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "HighStakeText");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "Void");
	}
	///========END OF PRINTING APPROVAL NUMBER=================
}

QString FlexBet::getEventDescription(QString homeDescr, QString visitorDescr, unsigned char sjp_nr, int uiMaxLen)
{
	if( sjp_nr )
		return QString( tr("SUPER JACKPOT") + QString::number(sjp_nr) ).utf8();

	QString strEvent="";
	QString strHome = QString::fromUtf8(homeDescr);
	QString strVisitor = QString::fromUtf8(visitorDescr);
	unsigned int uiParts=0;
	QString strSeparator = ( QString(SPACE_REPLACE_CHAR) + "-" + QString(SPACE_REPLACE_CHAR) );

	if(strHome.length())
	{
		strEvent+=strHome;
		uiParts++;
	}

	if(strVisitor.length())
	{
		if( strEvent.length() )
		{
			strEvent+=strSeparator;
		}

		strEvent+=strVisitor;
		uiParts++;
	}

	if( !uiMaxLen )
		return strEvent.toUtf8();

	if( strEvent.length()<=uiMaxLen )
		return strEvent.toUtf8();

	if( uiParts>1 )
	{
		unsigned int toCut = (strEvent.length()-uiMaxLen);
		if( toCut>1 )
			toCut/=2;

		strHome.truncate(strHome.length()-toCut);
		strVisitor.truncate(strVisitor.length()-toCut);
		strEvent = (strHome + strSeparator + strVisitor);
		//strEvent.truncate(uiMaxLen);
	}
	else
	{
		strEvent.truncate(uiMaxLen);
	}
	return strEvent.toUtf8();
}

QByteArray FlexBet::PrintHTMLCoupon (const QVariantMap &mReply,  const CouponRecord &PrintCouponRecord, int &result, const bool  bPendingApproval)
{
	//------------------------------------------------------------
	if ( m_bPrinterRollReplacementInProgress ) { // If we are changing paper don't handle incoming data.
		return "m_bPrinterRollReplacementInProgress";
	}

//	if ( !checkPrinter ( ) ) {
//		return "!checkPrinter ( )";
	//}
	//------------------------------------------------------------

	unsigned long totalCpnClms=0;
	QDateTime date(QDateTime::currentDateTime());
	QByteArray qbaHtml;
	qbaHtml.clear();
	Q_UNUSED(totalCpnClms);
	QVariantMap mPrintData;
	QString homeDescr,visitorDescr,otherDescr,betTypeTxt,betDescr,betEventType="";
	QString specialEvtDesc1;
	QString specialEvtDesc2;
	QString specialEvtDesc3;
	QString pitcherDescHome;
	QString pitcherDescVisitor;

	QString betStr;
	QString oddStr;
	QString oddStr1,oddStr2;
	QString handicapStr;
	QString handicapStrHome="";
	QString handicapStrVisitor="";
	QString strTemp="";
	QMap <int, QString> qEventTypes;
	REPLY_100_1 *reply_100_1=NULL;
	RTRNS_GM_15000 *numOfData=NULL;
	RTRNS_CD_15000 *repData=NULL;
	int codeR=0;
	ulong trns_cpn_hdr_data0=0;
	ulong reply_100_1_data1=0;
	Q_UNUSED(reply_100_1);
	Q_UNUSED(numOfData);

	//LoadTxRxFromFiles();
	bool bIsTraining = DbusWrapper::getConfigManagerInterface ()->training ();   //TOCHECK TO_CHECK TODO TO_DO

	TRNS_CPN_HDR *trns_cpn_hdr = (TRNS_CPN_HDR *) (&PrintCouponRecord.Record[sizeof(IT_CSS_4)]);
	TRNS_GM_15000 *trns_gm_15000 = (TRNS_GM_15000 *) (&PrintCouponRecord.Record[sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)]);
	SEL_DATA_EV_15000 *betData  = (SEL_DATA_EV_15000 *) (&PrintCouponRecord.Record[sizeof(IT_CSS_4)+sizeof(TRNS_CPN_HDR)+sizeof(TRNS_GM_15000)]);
	CSS_IT_1 *css_it_1 = (CSS_IT_1 *) PrintCouponRecord.HostReply;

	bool bApprovalRequired = (css_it_1->res == 100000);
	trns_cpn_hdr_data0=trns_cpn_hdr->data[0];

	if( !bApprovalRequired )
	{
		// From the relpy
		reply_100_1=(REPLY_100_1 *) (&PrintCouponRecord.HostReply[sizeof(CSS_IT_1)]);
		numOfData = (RTRNS_GM_15000 *) (&PrintCouponRecord.HostReply[sizeof(CSS_IT_1)+sizeof(REPLY_100_1)]);
		repData = (RTRNS_CD_15000 *) (&PrintCouponRecord.HostReply[sizeof(CSS_IT_1)+sizeof(REPLY_100_1)]+sizeof(RTRNS_GM_15000));
		reply_100_1_data1=reply_100_1->data[1];
	}

	if (!( css_it_1->flags & FlgPILOTPROG )){
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "PilotOperNotForSale");
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "PilotOperNotForSale");
	}

	if(!bIsTraining){
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING", "TrainingNotForSale");
	}

//	if( !bIsTraining && !bApprovalRequired && !bPendingApproval)
//	{
//		if( iFlexCost.UpdateFileColumnCost(css_it_1,reply_100_1) )
//		{
//			QString strLog;
//			strLog.sprintf("IFLEX: Column cost has been changed to %0.2f (TRNS=%ld)",getColumnCost(),css_it_1->hdr.trns);
//			LOG(strLog);
//		}
//	}

	//************************************* DATE & CRC_NUM **************************************
	QString strHex;
	if( !bPendingApproval)
	{
		if (bApprovalRequired)
		{
			date=QDateTime::currentDateTime();
		}
		else
		{
			date.setTime_t(reply_100_1->data[0]);
		}

		mPrintData.insert ("salesDate", date.toString("dd/MM/yyyy hh:mm:ss") );
	}else{
		mPrintData.insertMulti ("REMOVE_LINES_BEFORE_PROCESSING","salesDate");
	}
	//*******************************************************************************************

	//************************************* APROVAL *********************************************
	PrintApprovalNumber(mPrintData,css_it_1->res, css_it_1->data, trns_gm_15000->app,bPendingApproval);
	//*******************************************************************************************


	//************************************* EVENTS **********************************************
	betData = trns_gm_15000->data.ev_bet.data;
	int i=0;
	QString strHtmlPath = GetConfigValue::getHtmlTemplatesPath();
	//qDebug("strHtmlPath=%s",strHtmlPath.ascii()); //=/IMTSResources/LinkToYourProject/HtmlTemplates/en-us/
	if(!QDir(strHtmlPath).exists())
	{
		DisplayError(tr("ERROR"),"Folder " + strHtmlPath + "does not exist");
	}
	QString strNormalBlock=getGroupHtmlStr(strHtmlPath + "Games/iFlexGroup.html");
	QString strSpecialBlock=getGroupHtmlStr(strHtmlPath + "Games/iFlexGroupS.html");
	QString strBlocks="";
	while (betData->val && i<TOT_CPN_AREAS)
	{
		codeR = betData->val % 1000; // the last 3 digits

		if (codeR<NORMAL_BETTYPES_STARTINGCODE){
			strBlocks+=FillSpecial(i,trns_gm_15000,betData,repData,strSpecialBlock,bApprovalRequired);
		}
		else{
			strBlocks+=FillNormal(i,trns_gm_15000,betData,repData,strNormalBlock,bApprovalRequired);
		}

		i++;
		betData++;
		repData++;
	}

	QString outputHtml = strHtmlPath+ "tmp/iFlex.html";
	if( !InsertHtmlFile(strHtmlPath + "Games/iFlex.html",strBlocks, "EVENTS_HERE", outputHtml) )
	{
		DisplayError(tr("ERROR"),"File " + outputHtml + "does not exist");
		return qbaHtml;
	}
	//*******************************************************************************************


	//************************************* SYSTEMS *********************************************
	FillSystems(mPrintData, trns_gm_15000, trns_cpn_hdr_data0, reply_100_1_data1, bApprovalRequired);
	//*******************************************************************************************

	//************************************* TICKET - CPN ****************************************
	if( bApprovalRequired )
		mPrintData.insert("ticket_value_tag", "---");
	else
		mPrintData.insert("ticket_value_tag", QString::number(reply_100_1->cpn));
	//*******************************************************************************************

	//************************************* MAX_WIN **********************************************
	if( bApprovalRequired )
	{
		mPrintData.insert("potentialWin", "-,--");
	}
	else
	{
        AMOUNT_STRC amount_strc;
        amount_strc.i=numOfData->f_max_pay_amn;
        amount_strc.f=numOfData->i_max_pay_amn;
        mPrintData.insert("potentialWin", AmountFunctions::getAmountStr(&amount_strc));
//        mPrintData.insert ("potentialWin", AmountFunctions::getAmountStr((AMOUNT_STRC *)&numOfData->i_max_pay_amn) );
	}

	//*******************************************************************************************

	finalizeReceipt ( mReply, css_it_1, reply_100_1, mPrintData, bApprovalRequired, bPendingApproval);

	ImtsRxErrors::eeRxStatus eRxStatus;
	if( bPendingApproval) {
		eRxStatus = DbusWrapper::makeGuiData ( "/tmp/iFlex.html", mPrintData, qbaHtml ); //"Games/FlexBet.html"
	}else{
		eRxStatus = DbusWrapper::makeGuiDataAndPrint ( "/tmp/iFlex.html", mPrintData, PrinterTypes::Chief ); //"Games/FlexBet.html"
	}
	//qDebug ( "%s: %d, %s, eRxStatus=%d",__FILE__,__LINE__,__FUNCTION__,eRxStatus);
	result = int(eRxStatus);
	return qbaHtml;
}

QByteArray FlexBet::PreviewHTMLCoupon(const QByteArray &qbaCsData)
{
	QVariantMap qvmReply;
	QByteArray qbaResult;
	int result = 0;
	qbaResult.clear();
	qvmReply.insert( BINARY_DATA, QByteArray(qbaCsData).toBase64());

	CouponRecord PrintCouponRecord;
	memcpy (PrintCouponRecord.HostReply,qbaCsData,qbaCsData.size());

	ConvertToPlayReply(PrintCouponRecord);

	qbaResult =  PrintHTMLCoupon( qvmReply, PrintCouponRecord, result, true );

	return qbaResult;
}

int FlexBet::CombinationsOf( int n, int r)
{
//    qDebug() << QString ("n === %1").arg(n);
//    qDebug() << QString ("r === %1").arg(r);

	int factorialOfn =  Factorial(n);
	//qDebug ()<< QString("Factorial of n == %1").arg(factorialOfn);
	int factorialOfr = Factorial(r);
	//qDebug ()<< QString("Factorial of r == %1").arg(factorialOfr);
	int factorialOfn_r = Factorial(n-r);
	//qDebug ()<< QString("Factorial of n-r == %1").arg(factorialOfn_r);

	return factorialOfn/(factorialOfr*factorialOfn_r);
}

int FlexBet::Factorial(int number)
{
	int factorial;

	if(number < 0)
		number = 0;

	for (int i = 0; i <= number; i++)
	{
		if (i == 0)
			factorial = 1;
		else
			factorial = factorial * i;
	}
	return factorial;
}

void FlexBet::Get_Updated_Revision ()
{

	uint previousDraw = m_flexBetXmlController->getDraw();
	if(m_flexBetXmlController->LiveFtpRequestInProgress()){
		int requested_drawNbr = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
		int requested_LiveRev = m_flexBetXmlController->getLiveFtpRequestRevisionNumber();
		qDebug ( "%s: %d, %s  Ftp request for Live_%d.xml file in progress Rev=%d. Try terminate request",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_LiveRev);
		m_flexBetXmlController->terminateLiveFtpRequest();
#if NSYNC_FTPDOWNLOAD==1
		m_flexBetXmlController->RemoveLiveFileFromWorkingAndBackUpDirectory(previousDraw);
#endif

	}

	if(m_flexBetXmlController->PregameFtpRequestInProgress()){
		int requested_drawNbr = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
		int requested_PregameRev = m_flexBetXmlController->getPregameFtpRequestRevisionNumber();
		qDebug ( "%s: %d, %s  Ftp request for Pregame_%d.xml file in progress Rev.=%d. Try terminate request.",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_PregameRev);

		m_flexBetXmlController->terminatePregameFtpRequest();

#if NSYNC_FTPDOWNLOAD==1
		m_flexBetXmlController->RemovePregameFileFromWorkingAndBackUpDirectory(previousDraw);
#endif
	}

	qDebug ( "%s: %d, %s Downloading from Ftp FlexBet Xml Files. (css_it_1->res==RD_DIF_DRW_REV)",__FILE__,__LINE__,__FUNCTION__);
	m_flexBetXmlController->CheckActiveDraw(false,true);
	return;

}

unsigned long FlexBet::getFlexBetDelay(CouponRecord *couponRecord){
	unsigned long liveBetDelay=0;
	int eventCodes[30];
	memset(eventCodes,0,sizeof(eventCodes));


	TRNS_GM_15000 *trns_gm_15000 = (TRNS_GM_15000 *) ( &couponRecord->Record[sizeof ( IT_CSS_4 ) +sizeof ( TRNS_CPN_HDR ) ] );
	SEL_DATA_EV_15000 *betData  = (SEL_DATA_EV_15000 *) ( &couponRecord->Record[sizeof ( IT_CSS_4 ) +sizeof ( TRNS_CPN_HDR ) +sizeof ( TRNS_GM_15000 ) ] );

	betData = trns_gm_15000->data.ev_bet.data;
	int i=0;
	while ( betData->val && i<30 )      //TOT_CPN_AREAS=30
	{
		uint eventR = betData->val/100000;// the first 3 digits
		eventCodes[i]=eventR;
		i++;
		betData++;
	}

	if(m_flexBetXmlController!=NULL)
		liveBetDelay = m_flexBetXmlController->getMaximumDelay(eventCodes,i);//getDelay ( Selected_Games );

	return liveBetDelay;
}

bool FlexBet::prePlaySteps()
{
	memset(&msg,0,sizeof(TRNS_MSG));
	memset(&rep,0,sizeof(GENERAL_MSG_R));

	msg.header.MessageSubtype=0;        // Tell CSS to close channel

	///======================= For FlexBet Parsing xml files ==================================
#if WGET_FTPDOWNLOAD==1
	int requestedDraw;
	requestedDraw = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
	m_flexBetXmlController->CheckPregameFileExistsAndParse(requestedDraw);

	requestedDraw = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
	m_flexBetXmlController->CheckLiveFileExistsAndParse(requestedDraw);

#elif NSYNC_FTPDOWNLOAD==1
	int requestedDraw;
	requestedDraw = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
	if (!(m_flexBetXmlController->PregameFtpRequestInProgress()) &&
			QFile::exists(QString("/IMTSResources/LinkToYourProject/Downloads/HIM/Pregame_%1.xml.gz").arg(requestedDraw))){
		QString lastParsedPregameFile_Md5sum = m_flexBetXmlController->getLastParsedPregameFile_Md5sum();
		QString PregameFileInHIM_Md5sum = m_flexBetXmlController->getPregameFileMd5sum(requestedDraw);

		if(lastParsedPregameFile_Md5sum != PregameFileInHIM_Md5sum){
			m_flexBetXmlController->CheckPregameFileExistsAndParse(requestedDraw);

			int i = lastParsedPregameFile_Md5sum.find(" ");
			lastParsedPregameFile_Md5sum.truncate(i);

			i = PregameFileInHIM_Md5sum.find(" ");
			PregameFileInHIM_Md5sum.truncate(i);

//			qDebug ("%s: %d, %s Start parsing Pregame_%d.xml.gz ",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
//			qDebug ("%s: %d, %s lastParsedPregame_Md5sum=%s PregameHIM_Md5sum=%s ",__FILE__,__LINE__,__FUNCTION__,lastParsedPregameFile_Md5sum.utf8().data(),PregameFileInHIM_Md5sum.utf8().data());
		}else{

			int i = lastParsedPregameFile_Md5sum.find(" ");
			lastParsedPregameFile_Md5sum.truncate(i);

			i = PregameFileInHIM_Md5sum.find(" ");
			PregameFileInHIM_Md5sum.truncate(i);

//			qDebug ("%s: %d, %s Skip parsing Pregame_%d.xml.gz",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
//			qDebug ("%s: %d, %s lastParsedPregame_Md5sum=%s PregameHIM_Md5sum=%s ",__FILE__,__LINE__,__FUNCTION__,lastParsedPregameFile_Md5sum.utf8().data(),PregameFileInHIM_Md5sum.utf8().data());
		}
	}else if(m_flexBetXmlController->PregameFtpRequestInProgress()){
//		qDebug ("%s: %d, %s Skip parsing Pregame_%d.xml.gz. Pregame Ftp Request In Progress",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
	}


	requestedDraw = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
	if (!(m_flexBetXmlController->LiveFtpRequestInProgress()) &&
			QFile::exists(QString("/IMTSResources/LinkToYourProject/Downloads/HIM/Live_%1.xml.gz").arg(requestedDraw))){
		QString lastParsedLiveFile_Md5sum = m_flexBetXmlController->getLastParsedLiveFile_Md5sum();
		QString LiveFileInHIM_Md5sum = m_flexBetXmlController->getLiveFileMd5sum(requestedDraw);

		if(lastParsedLiveFile_Md5sum != LiveFileInHIM_Md5sum){
			m_flexBetXmlController->CheckLiveFileExistsAndParse(requestedDraw);

			int i = lastParsedLiveFile_Md5sum.find(" ");
			lastParsedLiveFile_Md5sum.truncate(i);

			i = LiveFileInHIM_Md5sum.find(" ");
			LiveFileInHIM_Md5sum.truncate(i);

//			qDebug ("%s: %d, %s Start parsing Live_%d.xml.gz ",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
//			qDebug ("%s: %d, %s lastParsedLive_Md5sum=%s LiveInHIM_Md5sum=%s ",__FILE__,__LINE__,__FUNCTION__,lastParsedLiveFile_Md5sum.utf8().data(),LiveFileInHIM_Md5sum.utf8().data());
		}else{
			int i = lastParsedLiveFile_Md5sum.find(" ");
			lastParsedLiveFile_Md5sum.truncate(i);

			i = LiveFileInHIM_Md5sum.find(" ");
			LiveFileInHIM_Md5sum.truncate(i);

//			qDebug ("%s: %d, %s Skip parsing Live_%d.xml.gz",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
//			qDebug ("%s: %d, %s lastParsedLive_Md5sum=%s LiveInHIM_Md5sum=%s ",__FILE__,__LINE__,__FUNCTION__,lastParsedLiveFile_Md5sum.utf8().data(),LiveFileInHIM_Md5sum.utf8().data());
		}
	}else if(m_flexBetXmlController->LiveFtpRequestInProgress()){
//		qDebug ("%s: %d, %s Skip parsing Live_%d.xml.gz. Live Ftp Request In Progress",__FILE__,__LINE__,__FUNCTION__,requestedDraw);
	}
#endif

	return true;
}


int FlexBet::postPlaySteps ( const QByteArray& qbaCsData )
{

	memset( betCoupon.HostReply,'0', MAXRECORDLEN);
	memcpy (betCoupon.HostReply,qbaCsData,qbaCsData.size());
	//    memset(CouponArray[cpnpos].HostReply,'0', MAXRECORDLEN);

#if defined(SIMULATE_TRANSACTION)
	QElapsedTimer timer;
	timer.start();
	//LOG("IFLEX: postPlaySteps simulation started");
	qDebug() << "postPlaySteps simulation started";

	QEventLoop createLocalLoop;
	QTimer::singleShot ( 5000, &createLocalLoop, SLOT(quit()) );
	createLocalLoop.exec();
	LOG(QString("postPlaySteps simulation finished in: %1").arg(timer.elapsed()));
	qDebug() << "postPlaySteps simulation finished in: " << timer.elapsed();
	return false;
#else

	// For FlexBet in case we have different Draw/Revision
	CSS_IT_1 *css_it_1 = (CSS_IT_1*)(betCoupon.HostReply);
	if ( css_it_1->res== RD_DRW_REV_NEW ){
		uint previousDraw = m_flexBetXmlController->getDraw();
		if(m_flexBetXmlController->LiveFtpRequestInProgress()){
//			int requested_drawNbr = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
//			int requested_LiveRev = m_flexBetXmlController->getLiveFtpRequestRevisionNumber();
//			qDebug ( "%s: %d, %s  Ftp request for Live_%d.xml file in progress Rev=%d. Try terminate request",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_LiveRev);
			m_flexBetXmlController->terminateLiveFtpRequest();
#if NSYNC_FTPDOWNLOAD==1
			m_flexBetXmlController->RemoveLiveFileFromWorkingAndBackUpDirectory(previousDraw);
#endif

		}

		if(m_flexBetXmlController->PregameFtpRequestInProgress()){
//			int requested_drawNbr = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
//			int requested_PregameRev = m_flexBetXmlController->getPregameFtpRequestRevisionNumber();
//			qDebug ( "%s: %d, %s  Ftp request for Pregame_%d.xml file in progress Rev.=%d. Try terminate request.",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_PregameRev);

			m_flexBetXmlController->terminatePregameFtpRequest();

#if NSYNC_FTPDOWNLOAD==1
			m_flexBetXmlController->RemovePregameFileFromWorkingAndBackUpDirectory(previousDraw);
#endif
		}

//		qDebug ( "%s: %d, %s Downloading from Ftp FlexBet Xml Files. (css_it_1->res==RD_DIF_DRW_REV)",__FILE__,__LINE__,__FUNCTION__);
		m_flexBetXmlController->CheckActiveDraw(false,true);
	}

	//qDebug ( "%s: %d, %s(lotos.PlayCoupon=success)",__FILE__,__LINE__,__FUNCTION__ );

	//NOTE(gpag) We inject the OUTGOING transaction CRC to the INCOMING
	//transaction CRC in order to print it to the play receipt. From now
	//on the css_it_1->hdr.crc does NOT contain the correct transaction
	//CRC so do not assume (as you have every right to) that it does!
	//        CSS_IT_1 *css_it_1 = (CSS_IT_1*)(CouponArray[cpnpos].HostReply);
	css_it_1->hdr.crc = playCRC;

	if ( css_it_1->res==RD_OK ) {

		REPLY_100_1 *reply_100_1;
		reply_100_1= ( REPLY_100_1 * ) ( &betCoupon.HostReply[0]+sizeof ( CSS_IT_1 ) );


		unsigned int currentDraw = reply_100_1->data[3];
		//            RTRNS_GM_15000 *numOfData = ( RTRNS_GM_15000 * ) ( &CouponArray[cpnpos].HostReply[sizeof ( CSS_IT_1 ) + sizeof ( REPLY_100_1 ) ] );

		///The reply_100_1->data[7] contains both Pregame revision and Live Revision. It has the form
		/// reply_100_1->data[7] = 100000*PreGameRevision + LiveRevision
		unsigned int currentPregameRevision = reply_100_1->data[7]/100000;
		unsigned int currentLiveRevision=reply_100_1->data[7]%100000;

		/// get the local stored active Draw, Pregame and Live revision
		uint previousDraw = m_flexBetXmlController->getDraw();
		uint previousPregameRevision = m_flexBetXmlController->getPregameRevision();
		uint previousLiveRevision = m_flexBetXmlController->getLiveRevision();

		if ( previousDraw != currentDraw ){
			LOG("IFLEX: Current draw changed. we download  new files");
			LOG(QString( "%1: %2, %3 Downloading from Ftp FlexBet Xml Files. LocalStored_Draw=%4 Reply_Draw=%5").arg(__FILE__).arg(__LINE__).arg(__FUNCTION__).arg(previousDraw).arg(currentDraw));
			//qDebug ( "%s: %d, %s Downloading from Ftp FlexBet Xml Files. LocalStored_Draw=%u Reply_Draw=%u",__FILE__,__LINE__,__FUNCTION__,previousDraw,currentDraw);

			if((m_flexBetXmlController->LiveFtpRequestInProgress() &&
				m_flexBetXmlController->getLiveFtpRequestDrawNumber()!=static_cast<int>(currentDraw)) ||
					(!(m_flexBetXmlController->LiveFtpRequestInProgress())) ){
				if(m_flexBetXmlController->LiveFtpRequestInProgress()){
					int requested_drawNbr = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
					int requested_LiveRev = m_flexBetXmlController->getLiveFtpRequestRevisionNumber();
					qDebug ( "%s: %d, %s  Ftp request for Live_%d.xml file in progress Rev=%d. Try terminate request",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_LiveRev);
					m_flexBetXmlController->terminateLiveFtpRequest();
				}
#if NSYNC_FTPDOWNLOAD==1
				m_flexBetXmlController->RemoveLiveFileFromWorkingAndBackUpDirectory(previousDraw);
#endif
			}

			if((m_flexBetXmlController->PregameFtpRequestInProgress() &&
				m_flexBetXmlController->getPregameFtpRequestDrawNumber()!=static_cast<int>(currentDraw)) || (!(m_flexBetXmlController->PregameFtpRequestInProgress())) ){
				if(m_flexBetXmlController->PregameFtpRequestInProgress()){
//					int requested_drawNbr = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
//					int requested_PregameRev = m_flexBetXmlController->getPregameFtpRequestRevisionNumber();
//                    qDebug ( "%s: %d, %s  Ftp request for Pregame_%d.xml file in progress Rev.=%d. Try terminate request.",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_PregameRev);

					m_flexBetXmlController->terminatePregameFtpRequest();
				}
#if NSYNC_FTPDOWNLOAD==1
				m_flexBetXmlController->RemovePregameFileFromWorkingAndBackUpDirectory(previousDraw);
#endif

			}
			m_flexBetXmlController->CheckActiveDraw(false,false,currentDraw,currentLiveRevision,currentPregameRevision);

		}else{

			if(previousPregameRevision!=currentPregameRevision){

				if(m_flexBetXmlController->PregameFtpRequestInProgress() &&
						m_flexBetXmlController->getPregameFtpRequestRevisionNumber()!=static_cast<int>(currentPregameRevision )){
//					int requested_drawNbr = m_flexBetXmlController->getPregameFtpRequestDrawNumber();
//					int requested_PregameRev = m_flexBetXmlController->getPregameFtpRequestRevisionNumber();
//                    qDebug ( "%s: %d, %s  Ftp request for Pregame_%d.xml file in progress Rev.=%d. Try terminate request.",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_PregameRev);

					m_flexBetXmlController->terminatePregameFtpRequest();
#if NSYNC_FTPDOWNLOAD==1
					m_flexBetXmlController->CopyPregameFileFromBackUpToWorkingDirectory(currentDraw);
#endif
					//qDebug ( "%s: %d, %s Downloading from Ftp Pregame Xml File. LocalStored_PregameRev.=%d Reply_PregameRev.=%d",__FILE__,__LINE__,__FUNCTION__,previousPregameRevision,currentPregameRevision);
					m_flexBetXmlController->GetPreGameXmlFileFromFtp(true,currentDraw,currentPregameRevision);
				}else if(!(m_flexBetXmlController->PregameFtpRequestInProgress())){
					//qDebug ( "%s: %d, %s Downloading from Ftp Pregame Xml File. LocalStored_PregameRev.=%d Reply_PregameRev.=%d",__FILE__,__LINE__,__FUNCTION__,previousPregameRevision,currentPregameRevision);
					m_flexBetXmlController->GetPreGameXmlFileFromFtp(true,currentDraw,currentPregameRevision);

				}


			}

			if(previousLiveRevision!=currentLiveRevision){
				if(m_flexBetXmlController->LiveFtpRequestInProgress() &&
						m_flexBetXmlController->getLiveFtpRequestRevisionNumber()!=static_cast<int>(currentLiveRevision )){
//					int requested_drawNbr = m_flexBetXmlController->getLiveFtpRequestDrawNumber();
//					int requested_LiveRev = m_flexBetXmlController->getLiveFtpRequestRevisionNumber();
					//qDebug ( "%s: %d, %s  Ftp request for Live_%d.xml file in progress Rev=%d. Try terminate request",__FILE__,__LINE__,__FUNCTION__,requested_drawNbr,requested_LiveRev);

					m_flexBetXmlController->terminateLiveFtpRequest();
#if NSYNC_FTPDOWNLOAD==1
					m_flexBetXmlController->CopyLiveFileFromBackUpToWorkingDirectory(currentDraw);
#endif
					//qDebug ( "%s: %d, %s Downloading from Ftp Live Xml File. Local_LiveRev.=%d  Reply_LiveRev.=%d ",__FILE__,__LINE__,__FUNCTION__,previousLiveRevision,currentLiveRevision );
					m_flexBetXmlController->GetLiveXmlFileFromFtp(true,currentDraw,currentLiveRevision);
				}else if(!(m_flexBetXmlController->LiveFtpRequestInProgress())){
					//qDebug ( "%s: %d, %s Downloading from Ftp Live Xml File. Local_LiveRev.=%d  Reply_LiveRev.=%d ",__FILE__,__LINE__,__FUNCTION__,previousLiveRevision,currentLiveRevision );
					m_flexBetXmlController->GetLiveXmlFileFromFtp(true,currentDraw,currentLiveRevision);
				}
			}
		}

	}

	return 0;
#endif
}

void FlexBet::SwitchBetFiles(bool bIsTraining)
{
	QString command;
	if(bIsTraining){
		command = QString("cp /IMTSResources/LinkToYourProject/Ftp/*.xml  /IMTSResources/LinkToYourProject/Ftp/OnlineBetFilesBackup/ ") ;
		system(command);
		command = QString("cp /IMTSResources/LinkToYourProject/TrainingData/TrainingBetFiles/*.xml /IMTSResources/LinkToYourProject/Ftp/ ") ;
		system(command);
	}
	else{
		command = QString("rm /IMTSResources/LinkToYourProject/Ftp/Active_Draw.xml /IMTSResources/LinkToYourProject/Ftp/Live.xml /IMTSResources/LinkToYourProject/Ftp/Pregame.xml");
		system(command);
		command = QString("cp  /IMTSResources/LinkToYourProject/Ftp/OnlineBetFilesBackup/*xml /IMTSResources/LinkToYourProject/Ftp/") ;
		system(command);
	}

	m_flexBetXmlController->ForceParseFlexBetLivePregameXmlFiles();
}

/**
 * @sa setUpDBusInterface
 * @brief This method sets up dbus interface for games application
 */
void FlexBet::setUpDBusInterface()
{
	// D-Bus stuff. Create the D-Bus adaptor for Game5xxx
	new FlexBetOperationsAdaptor(this);
	QDBusConnection dBusConnection = QDBusConnection::sessionBus();


	if (!dBusConnection.registerService("com.intralot.IMTSFlexBet") ) {
		LOG ( "Another FlexBet Center is already running");
		exit(0); // goodbye cruel world
	}

	QString qsQDbusConnection = "Connection name for games " + dBusConnection.baseService();
	LOG(qsQDbusConnection);

	bool bWasRegistrationSuccessfull = dBusConnection.registerObject("/FlexBetOperations", this);
	if (!bWasRegistrationSuccessfull) {
		LOG ("!!! ERROR !!! /FlexBetOperations could not register to D-Bus");
	}

	qint64 m_pid = QCoreApplication::applicationPid();
	QString qsMsg = QString("Application: %1 with pid: %2 started").arg (qAppName ()).arg(m_pid);
	LOG (qsMsg);
	// TODO:   We need to emit this signal when we are up and running. Leave for l8r
	//emit imtsServiceUp ( qAppName (), m_pid );

}

inline bool FlexBet::isEmptyArea(int cpn, int area)
{
	bool isEmpty = true;
	for (int j=0; j<AREA_MARKS; j++) {
		if (CouponRec[cpn].Marks[area*AREA_MARKS+j])
			isEmpty = false;
	}
	return isEmpty;
}

double FlexBet::getTotalCost () {

	unsigned long totalcolumns=CouponColumns(CurrentCoupon);
	setColumns(totalcolumns * cpnMultiply);
	double couponCost = getColumnCost() * getColumns();

	return couponCost; //TotalCpnsCost;
}

void FlexBet::ConvertDoubleToAMOUNTSTRC(double Input,AMOUNT_STRC *Output)
{
	if(Input<0)
		Output->i=static_cast<long>(ceil(Input));
	else
		Output->i=static_cast<long>(floor(Input));

	Output->f=static_cast<long>((Input - Output->i)*pow(10.0,FRACTIONAL_SIZE));

	if(Output->i != 0)
		Output->f = labs(Output->f);
}


void FlexBet::getMonth(QDateTime *CurDate,QString & month)
{
	const QString months[] = {
		tr("JANUARY" ),
		tr("FEBRUARY"),
		tr("MARCH"),
		tr("APRIL"),
		tr("MAY"),
		tr("JUNE"),
		tr("JULY"),
		tr("AUGUST" ),
		tr("SEPTEMBER"),
		tr("OCTOBER"),
		tr("NOVEMBER"),
		tr("DECEMBER"),
		NULL
	};

	month = months[CurDate->date().month()-1];
}

void FlexBet::getDay(QDateTime *CurDate,QString & day)
{
	const QString days[] = {
		tr("MON" ),
		tr("TUE"),
		tr("WED"),
		tr("THU"),
		tr("FRI"),
		tr("SAT"),
		tr("SUN"),
		NULL
	};

	day = days[CurDate->date().dayOfWeek()-1];
}

void FlexBet::ShowMarksTableMapping()
{
	QString strMarks="";
	int idx=0;

	for(unsigned int i=0; i<13; i++)
	{
		if( strMarks.length() )
			strMarks+=" ";
		strMarks+=QString::number(CouponToMarks_c[i]);
	}
	qDebug("%s",strMarks.toLatin1().data());

	strMarks="";
	idx=0;
	for(unsigned int i=13; i<TotalScanCouponMarks_c; i++)
	{
		if( strMarks.length() )
			strMarks+=" ";
		//strMarks+=(QString::number(CouponToMarks_c[i])+"(" + QString::number(i) + ")");
		strMarks+=(QString::number(CouponToMarks_c[i])); //+"(" + QString::number(i) + ")");
		idx++;
		if(idx==81)
		{
			qDebug("%s",strMarks.toLatin1().data());
			strMarks="";
			idx=0;
		}
	}
	if( strMarks.length() )
		qDebug("%s",strMarks.toLatin1().data());
}

void FlexBet::GuiTranslations()
{
	tr("EVENT");
	tr("BET");
	tr("Codes");
	tr("System & Multipliers");
	tr("SET");
	tr("ACCEPT BET");
	tr("SYSTEMS");
	tr("MULTIPLIERS");
	tr("COUPON COST");
	tr("EXIT");
	tr("CLEAR");
	tr("FINISH");
	tr("System Multiplier");
	tr("ALL");
	tr("CANCEL");
	tr("OK");
	tr("PILOT OPERATION - NOT FOR SALE");
	tr("HIGH STAKE");
	tr("PERMS");
	tr("LINES");
	tr("PERM MULTIPLIER");
	tr("TOTAL LINES");
	tr("MULTIPLIER");
	tr("TOTAL COLUMNS");
	tr("Total");
	tr("APPROVAL NUMBER:");
	tr("Maximum Winning Amount:");
	tr("Agent:");
	tr("TRNS:");
	tr("Ticket:");
	tr("Columns:");
}

void FlexBet::LoadBetslip()
{
	QFile qFile;
	qFile.setName("/tmp/coupon.dat");

	if(!qFile.exists())
		return;

	char ScanBuf[MAXSCANBUF];       // The scanner buffer
	if(!qFile.open(IO_ReadOnly))
		return;

	int iBytesRead = qFile.readBlock(ScanBuf,qFile.size());
	qDebug("%d have been read from %s",iBytesRead,qFile.name().ascii());
	qFile.close();

	QByteArray qbaCouponData;
	qbaCouponData = ScanBuf;

	if(iBytesRead)
	{
		QString strError="";
		ApplyMarks(0,qbaCouponData,strError);
		CalculateLastSect(0);
		UpdateBetStructM(0);
		CheckGUICoupon();
		EditScanned = false;
	}
}

void FlexBet::Show1stAreaPlayslipMapping()
{
	int id=14; //the systems are 13

	qDebug("index matches the camera marks (that is actuall id +1 )");
	qDebug("1st index = %d, the system marks",id);

	qDebug("id: %d, A1+0 = %d",id++,A1+0);
	qDebug("id: %d, A1+4 = %d",id++,A1+4);
	qDebug("id: %d, A1+5 = %d",id++,A1+5);
	qDebug("id: %d, A1+6 = %d",id++,A1+6);
	qDebug("id: %d, A1+7 = %d",id++,A1+7);
	qDebug("id: %d, A1+8 = %d",id++,A1+8);
	qDebug("id: %d, A1+9 = %d",id++,A1+9);
	qDebug("id: %d, A1+10 = %d",id++,A1+10);
	qDebug("id: %d, A1+11 = %d",id++,A1+11);
	qDebug("id: %d, A1+12 = %d",id++,A1+12);
	qDebug("id: %d, A1+13 = %d",id++,A1+13);

	qDebug("id: %d, A1_BET_OFFSET+18 = %d",id++,A1_BET_OFFSET+18);
	qDebug("id: %d, A1_BET_OFFSET+21 = %d",id++,A1_BET_OFFSET+21);
	qDebug("id: %d, A1_BET_OFFSET+24 = %d",id++,A1_BET_OFFSET+24);
	qDebug("id: %d, A1_BET_OFFSET+27 = %d",id++,A1_BET_OFFSET+27);
	qDebug("id: %d, A1_BET_OFFSET+30 = %d",id++,A1_BET_OFFSET+30);
	qDebug("id: %d, A1_VOID = %d",id++,A1_VOID);

	qDebug("id: %d, A1+1 = %d",id++,A1+1);
	qDebug("id: %d, A1+14 = %d",id++,A1+14);
	qDebug("id: %d, A1+15 = %d",id++,A1+15);
	qDebug("id: %d, A1+16 = %d",id++,A1+16);
	qDebug("id: %d, A1+17 = %d",id++,A1+17);
	qDebug("id: %d, A1+18 = %d",id++,A1+18);
	qDebug("id: %d, A1+19 = %d",id++,A1+19);
	qDebug("id: %d, A1+20 = %d",id++,A1+20);
	qDebug("id: %d, A1+21 = %d",id++,A1+21);
	qDebug("id: %d, A1+22 = %d",id++,A1+22);
	qDebug("id: %d, A1+23 = %d",id++,A1+23);

	qDebug("id: %d, A1_BET_OFFSET+19 = %d",id++,A1_BET_OFFSET+19);
	qDebug("id: %d, A1_BET_OFFSET+22 = %d",id++,A1_BET_OFFSET+22);
	qDebug("id: %d, A1_BET_OFFSET+25 = %d",id++,A1_BET_OFFSET+25);
	qDebug("id: %d, A1_BET_OFFSET+28 = %d",id++,A1_BET_OFFSET+28);
	qDebug("id: %d, A1_BET_OFFSET+31 = %d",id++,A1_BET_OFFSET+31);
	qDebug("id: %d, A1_BET_OFFSET+34 = %d",id++,A1_BET_OFFSET+34);

	qDebug("id: %d, A1+2 = %d",id++,A1+2);
	qDebug("id: %d, A1+24 = %d",id++,A1+24);
	qDebug("id: %d, A1+25 = %d",id++,A1+25);
	qDebug("id: %d, A1+26 = %d",id++,A1+26);
	qDebug("id: %d, A1+27 = %d",id++,A1+27);
	qDebug("id: %d, A1+28 = %d",id++,A1+28);
	qDebug("id: %d, A1+29 = %d",id++,A1+29);
	qDebug("id: %d, A1+30 = %d",id++,A1+30);
	qDebug("id: %d, A1+31 = %d",id++,A1+31);
	qDebug("id: %d, A1+32 = %d",id++,A1+32);
	qDebug("id: %d, A1+33 = %d",id++,A1+33);

	qDebug("id: %d, A1_BET_OFFSET+20 = %d",id++,A1_BET_OFFSET+20);
	qDebug("id: %d, A1_BET_OFFSET+23 = %d",id++,A1_BET_OFFSET+23);
	qDebug("id: %d, A1_BET_OFFSET+26 = %d",id++,A1_BET_OFFSET+26);
	qDebug("id: %d, A1_BET_OFFSET+29 = %d",id++,A1_BET_OFFSET+29);
	qDebug("id: %d, A1_BET_OFFSET+32 = %d",id++,A1_BET_OFFSET+32);
	qDebug("id: %d, A1_BET_OFFSET+35 = %d",id++,A1_BET_OFFSET+35);

	qDebug("id: %d, A1_BET_OFFSET+SWITCH = %d",id++,A1_BET_OFFSET+SWITCH);
	qDebug("id: %d, A1_BET_OFFSET = %d",id++,A1_BET_OFFSET);
	qDebug("id: %d, A1_BET_OFFSET+1 = %d",id++,A1_BET_OFFSET+1);
	qDebug("id: %d, A1_BET_OFFSET+2 = %d",id++,A1_BET_OFFSET+2);
	qDebug("id: %d, A1_BET_OFFSET+33 = %d",id++,A1_BET_OFFSET+33);
	qDebug("id: %d, A1_BET_OFFSET+3 = %d",id++,A1_BET_OFFSET+3);
	qDebug("id: %d, A1_BET_OFFSET+4 = %d",id++,A1_BET_OFFSET+4);
	qDebug("id: %d, A1_BET_OFFSET+6 = %d",id++,A1_BET_OFFSET+6);
	qDebug("id: %d, A1_BET_OFFSET+7 = %d",id++,A1_BET_OFFSET+7);
	qDebug("id: %d, A1_BET_OFFSET+9 = %d",id++,A1_BET_OFFSET+9);
	qDebug("id: %d, A1_BET_OFFSET+10 = %d",id++,A1_BET_OFFSET+10);
	qDebug("id: %d, A1_BET_OFFSET+8 = %d",id++,A1_BET_OFFSET+8);
	qDebug("id: %d, A1_BET_OFFSET+11 = %d",id++,A1_BET_OFFSET+11);
	qDebug("id: %d, A1_BET_OFFSET+12 = %d",id++,A1_BET_OFFSET+12);
	qDebug("id: %d, A1_BET_OFFSET+13 = %d",id++,A1_BET_OFFSET+13);
	qDebug("id: %d, A1_BET_OFFSET+14 = %d",id++,A1_BET_OFFSET+14);
	qDebug("id: %d, A1_BET_OFFSET+36 = %d",id++,A1_BET_OFFSET+36);
}

//void FlexBet::PopulatePlayslipMapping0135()
//{
//    unsigned int PL = 0;
//    unsigned int PL_BET_OFFSET = OFFSET_OF_BET;
//    unsigned int PL_VOID = TOTAL_ECPN_MARKS;

//    memset(CouponToMarks_c3,0x00,sizeof(CouponToMarks_c3));

//    unsigned int id=0;
//    for(unsigned int i=0; i<30; i++) //30 areas
//    {
//        CouponToMarks_c3[id++] = PL_BET_OFFSET+36;
//        CouponToMarks_c3[id++] = PL_BET_OFFSET;
//        CouponToMarks_c3[id++] = PL_BET_OFFSET+1;
//        CouponToMarks_c3[id++] = PL_BET_OFFSET+2;
//        CouponToMarks_c3[id++] = PL_BET_OFFSET+SWITCH;
//        CouponToMarks_c3[id++] = PL_VOID;

//        PL_BET_OFFSET += AREA_MARKS;
//        PL_VOID ++;
//    }

//    //Systems
//    PL = OFFSET_OF_SYS;
//    for(unsigned int i=0; i<31; i++) //30 areas + 0
//    {
//        CouponToMarks_c3[id++]= PL;
//        PL += 5;
//    }

//    //System - ALL
//    CouponToMarks_c3[id++]= OFFSET_OF_SYS_ALL;

//    //Super Jackpot
//    PL = OFFSET_OF_SJP;
//    for(unsigned int i=0; i<NUM_O_SJP; i++) //6 SS selections
//    {
//        CouponToMarks_c3[id++]= PL;
//        PL ++;
//    }

//    //Stake
//    PL = OFFSET_OF_STAKE;
//    for(unsigned int i=0; i<NUM_O_STAKES; i++) //12 stake values
//    {
//        CouponToMarks_c3[id++]= PL;
//        PL ++;
//    }

//    //Stake
//    PL = OFFSET_OF_MULT;
//    for(unsigned int i=0; i<NUM_O_MULTS; i++) //4 multipliers
//    {
//        CouponToMarks_c3[id++]= PL;
//        PL ++;
//    }

////    qDebug("Total marks: %d",id);
////    for(unsigned int i=0; i<PLAYLSIP_0135_LENGTH; i++)
////    {
////        qDebug("id: %d, OFFSET = %d",i,CouponToMarks_c3[i]);
////    }
////    qDebug("id: %d, OFFSET = %d",id,CouponToMarks_c3[id-1]);
////    qDebug("OFFSET_OF_MULT+3 = %d",OFFSET_OF_MULT+3);
//}


//void FlexBet::PopulatePlayslipMapping01AD()
//{
//    unsigned int PL = 0;
//    unsigned int PL_BET_OFFSET = OFFSET_OF_BET;

//    memset(CouponToMarks_c4,0x00,sizeof(CouponToMarks_c4));

//    unsigned int id=0;
//    for(unsigned int i=0; i<15; i++) //30 areas
//    {
//        CouponToMarks_c4[id++] = PL_BET_OFFSET;
//        CouponToMarks_c4[id++] = PL_BET_OFFSET+1;
//        CouponToMarks_c4[id++] = PL_BET_OFFSET+2;

//        PL_BET_OFFSET += AREA_MARKS;
//    }

//    //Super Jackpot
//    PL = OFFSET_OF_SJP;
//    for(unsigned int i=0; i<NUM_O_SJP; i++) //6 SS selections
//    {
//        CouponToMarks_c4[id++]= PL;
//        PL ++;
//    }

//    //Stake
//    PL = OFFSET_OF_STAKE;
//    for(unsigned int i=0; i<NUM_O_STAKES; i++) //12 stake values
//    {
//        CouponToMarks_c4[id++]= PL;
//        PL ++;
//    }

//    //Stake
//    PL = OFFSET_OF_MULT;
//    for(unsigned int i=0; i<NUM_O_MULTS; i++) //4 multipliers
//    {
//        CouponToMarks_c4[id++]= PL;
//        PL ++;
//    }

////    qDebug("Total marks: %d",id);
////    for(unsigned int i=0; i<PLAYLSIP_01AD_LENGTH; i++)
////    {
////        qDebug("id: %d, OFFSET = %d",i,CouponToMarks_c4[i]);
////    }
////    qDebug("id: %d, OFFSET = %d",id,CouponToMarks_c4[id-1]);
////    qDebug("OFFSET_OF_MULT+3 = %d",OFFSET_OF_MULT+3);
//}

//void FlexBet::PopulatePlayslipMapping0373()
//{
//    unsigned int PL = 0;
//    unsigned int PL_BET_OFFSET = OFFSET_OF_BET;

//    memset(CouponToMarks_c5,0x00,sizeof(CouponToMarks_c5));

//    unsigned int id=0;
//    for(unsigned int i=0; i<3; i++) //Thousands
//    {
//        CouponToMarks_c5[id] = A1+i;
//        id++;
//    }

//    unsigned int uiOffset = 4;
//    for(unsigned int i=0; i<3; i++) //Event Panels
//    {
//        for(unsigned int j=0; j<10; j++) //Panel Ids
//        {
//            CouponToMarks_c5[id] = A1+uiOffset+j;
//            id++;
//        }
//        uiOffset+=10;
//    }

//    //1,X,2
//    CouponToMarks_c5[id] = A1_BET_OFFSET;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+1;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+2;
//    id++;

//    //1st - 2nd Half
//    CouponToMarks_c5[id] = A1_BET_OFFSET+8;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+11;
//    id++;

//    //handicap
//    CouponToMarks_c5[id] = A1_BET_OFFSET+33;
//    id++;

//    //double chance  - switch
//    CouponToMarks_c5[id] = A1_BET_OFFSET+SWITCH;
//    id++;

//    //H, N, V
//    CouponToMarks_c5[id] = A1_BET_OFFSET+12;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+13;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+14;
//    id++;

//    //half final marks consist of two mark boxes in the normal betslip. A trick will be made in decoding
//    for(unsigned int i=0; i<9; i++)
//    {
//        CouponToMarks_c5[id] = MULTIPLE_MARK_HALF_FINAL+i;
//        id++;
//    }

//    //0.5
//    CouponToMarks_c5[id] = A1_BET_OFFSET+5;
//    id++;

//    //1-5 score panel 1
//    CouponToMarks_c5[id] = A1_BET_OFFSET+22;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+25;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+28;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+31;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+34;
//    id++;

//    //u o
//    CouponToMarks_c5[id] = A1_BET_OFFSET+3;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+4;
//    id++;


//    //1st Half
//    CouponToMarks_c5[id] = A1_BET_OFFSET+8;
//    id++;

////    //H, V
////    CouponToMarks_c5[id] = A1_BET_OFFSET+12;
////    id++;
////    CouponToMarks_c5[id] = A1_BET_OFFSET+14;
////    id++;

//    //1,2
//    CouponToMarks_c5[id] = A1_BET_OFFSET;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+2;
//    id++;

//    //1-3
//    CouponToMarks_c5[id] = A1_BET_OFFSET+22;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+25;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+28;
//    id++;


//    //1-5
//    CouponToMarks_c5[id] = A1_BET_OFFSET+18;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+21;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+24;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+27;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+30;
//    id++;


//    //0-5 score panel 1
//    CouponToMarks_c5[id] = A1_BET_OFFSET+19;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+22;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+25;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+28;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+31;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+34;
//    id++;

//    //0-5 score panel 2
//    CouponToMarks_c5[id] = A1_BET_OFFSET+20;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+23;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+26;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+29;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+32;
//    id++;
//    CouponToMarks_c5[id] = A1_BET_OFFSET+35;
//    id++;

//    //stake
//    for(unsigned int i=0; i<12; i++)
//    {
//        CouponToMarks_c5[id] = OFFSET_OF_STAKE+i;
//        id++;
//    }

//    //multiplier
//    for(unsigned int i=0; i<4; i++)
//    {
//        CouponToMarks_c5[id] = OFFSET_OF_MULT+i;
//        id++;
//    }

////    qDebug("Total marks: %d",id);
////    for(unsigned int i=0; i<PLAYLSIP_01AD_LENGTH; i++)
////    {
////        qDebug("id: %d, OFFSET = %d",i,CouponToMarks_c5[i]);
////    }
////    qDebug("id: %d, OFFSET = %d",id,CouponToMarks_c5[id-1]);
////    qDebug("OFFSET_OF_MULT+3 = %d",OFFSET_OF_MULT+3);
//}

void FlexBet::MapMultipleMarks()
{//enum { half1 = A1_BET_OFFSET+12, halfX=A1_BET_OFFSET+13, half2=A1_BET_OFFSET+14, final1=A1_BET_OFFSET, finalX=A1_BET_OFFSET+1, final2=A1_BET_OFFSET+2; }

	m_MultipleMarks.clear();
	TMarks tMarks;
	unsigned int id=0;
	unsigned int mappedVals[ ] = {
		//1/1
		half1,
		final1,
		//1/X
		half1,
		finalX,
		//1/2
		half1,
		final2,
		//X/1
		halfX,
		final1,
		//X/X
		halfX,
		finalX,
		//X/2
		halfX,
		final2,
		//2/1
		half2,
		final1,
		//2/X
		half2,
		finalX,
		//2/2
		half2,
		final2
	};

	for(unsigned int i=0; i<9; i++)
	{
		tMarks.clear();
		tMarks.append( mappedVals[id] );
		id++;
		tMarks.append( mappedVals[id] );
		id++;
		m_MultipleMarks [ MULTIPLE_MARK_HALF_FINAL+i ] = tMarks;
	}
}

unsigned int FlexBet::getTriples()
{
	if( !sjp_nr )
		return 1;

	unsigned int id=0;
	unsigned int PL_BET_OFFSET = OFFSET_OF_BET;

	unsigned int uiTmp=0;
	unsigned int uiTriples=1;

	for(unsigned int i=0; i<15; i++) //30 areas
	{
		uiTmp=0;

		if( CouponRec->Marks [ CouponToMarks_c4[id++] ] )
			uiTmp++;

		if( CouponRec->Marks [ CouponToMarks_c4[id++] ] )
			uiTmp++;

		if( CouponRec->Marks [ CouponToMarks_c4[id++] ] )
			uiTmp++;

		if( uiTmp==3 )
			uiTriples*=3;

		PL_BET_OFFSET += AREA_MARKS;
	}
	//qDebug("uiTriples=%d",uiTriples);
	return uiTriples;
}


bool FlexBet::isWindowActive ()
{
	return m_bIsWindowActive;
}

bool FlexBet::isDialogOnScreen ()
{
	return m_bIsDialogActive;
}


/**
 * @sa wakeUpService
 */
void FlexBet::wakeUpService ( const QString serviceNameThatsWakesMeUp)
{
	LOG ( QString("%1 wakes up by %2").arg (qAppName ()).arg (serviceNameThatsWakesMeUp));
}

/**
 * @sa exitService
 */
void FlexBet::exitService ( const QString serviceNameThatKillsMe )
{
	LOG (QString("%1 was killed by %2").arg (qAppName ()).arg (serviceNameThatKillsMe));
	QCoreApplication::quit ();
}

