/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : Sat Nov 24 12:27:05 EET 2001
    copyright            : (C) 2001 by
    email                :
 ***************************************************************************/



#include <qapplication.h>
#include <qfont.h>
#include <qstring.h>
#include <qtextcodec.h>
#include <qtranslator.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "ProjectApp.h"
#include "LocalEventLogger.h"


extern ProjectApp *m_pApp;
int main(int argc, char *argv[])
{
	ProjectApp a(argc, argv);

    // aste: Shameless copy from GetConfigValue.h in the Dev project
    QSettings settings( QLatin1String("Intralot"), QLatin1String("ImtsGlobalConfig") );
    settings.sync ();
    QString qsLocale = settings.value (QLatin1String("Global/Locale"),QVariant(QLatin1String("en-us"))).toString (); // default to en-us if none is found
    QLocale::setDefault (QLocale(qsLocale));
    // aste: Shameless copy from GetConfigValue.h in the Dev project

    QScopedPointer<LocalEventLogger> logger (new LocalEventLogger );
    a.installEventFilter(logger.data ());

    m_pApp = &a;  
    //__________________ enable translator _________________
    QTranslator     translator;
    if(translator.load("FlexBet.qm","/IMTSResources/LinkToYourProject/Translations/")){
        m_pApp->installTranslator(&translator);
    }else{
        qDebug() << "Error Loading Translator";
    }
    //__________________ enable translator _________________

    m_pApp->Start();

    if( !QFile::exists("/home/cursor") )
        a.setOverrideCursor ( QCursor( Qt::BlankCursor ) );

    m_pApp->exec ();
}
