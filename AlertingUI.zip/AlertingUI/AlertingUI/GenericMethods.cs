﻿/*
 * Created by Ranorex
 * User: conde
 * Date: 7/1/2016
 * Time: 11:46 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

using System.Data.OracleClient;

namespace AlertingUI
{
    /// <summary>
    /// Description of GenericMethods.
    /// </summary>
    [TestModule("517E8B15-A6E8-47DF-863F-44ECF656E9E2", ModuleType.UserCode, 1)]
    public class GenericMethods : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public GenericMethods()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
        }
        
        public void test() {
        	//System.Diagnostics.Debug.WriteLine(m);
        	
//        	String app = "auth-ui";
//            String role = "admin";
//			String sql = "SELECT * FROM LOTOSAUTH.OAUTH_ROLES WHERE ROLE_APP_ID='"+app+"' AND ROLE_NAME='"+role+"'";
			//String sql = "SELECT * FROM ALT_TYPE_CATEGORY";
			String sql = @"SELECT NAME, DESCR FROM ALT_TYPE_CATEGORY WHERE NAME = 'Automation Test' AND DESCR = 'Automation purposes'";
			Validate_DatabaseTableWithQuery(sql, @"C:\ranorexprojects\export.csv", ",", "", "");
        }
        
        public void Validate_DatabaseTableWithQuery(String SQLQuery, String referenceCSVTable, String csvSeparator, String customLogMessageOverall, String customLogMessageDetail)
		{
        	String ConnectionString = "Data Source=(DESCRIPTION="
			+ "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.142.246)(PORT=1521)))"
			+ "(CONNECT_DATA=(SID=L10FAT)));"
			+ "User Id=LOTOSDB;Password=LOTOSDB;";
        	

			// check if reference file exists
			if (!System.IO.File.Exists(referenceCSVTable))
			{
				throw new Ranorex.RanorexException(string.Format("File does not exist: {0}", referenceCSVTable));
			}
		
			// check if SQL statement is empty
			if (SQLQuery.Trim().Equals(string.Empty))
			{
				throw new Ranorex.RanorexException("SQLQuery is empty");
			}
		
			// prepare separator for csv file (if not passed in)
			char separator;
			if (string.IsNullOrEmpty(csvSeparator))
			{
				separator = ',';
			}
			else
			{
				separator = csvSeparator[0];
			}
		
			// establish database connection
			using (OracleConnection connection = new OracleConnection(@ConnectionString))
			{
				
		
				OracleCommand command = null;
				OracleDataReader SQLReader = null; 
				System.IO.StreamReader CSVReader = null;
		
				try
				{
					// set SQL statement and execute search 
					command = new OracleCommand(@SQLQuery, connection); //connection.CreateCommand();
					connection.Open();
					
            		String test = command.CommandText;
            		
					SQLReader = command.ExecuteReader();
						
					// open csv file (reference file)
					CSVReader = new System.IO.StreamReader(System.IO.File.OpenRead(@referenceCSVTable));
		
					// run through every line in file
					int iRow = 0;
					while ((SQLReader.Read()) && (!CSVReader.EndOfStream))
					{
		
						// read line from csv file
						var line = CSVReader.ReadLine();
		
						// split line into array of values
						var values = line.Split(separator);
		
						// check if number of values equals (in current row of csv file and in SQL result)
						if (values.Length != SQLReader.FieldCount)
						{
							throw new Ranorex.RanorexException(string.Format("Number of fields in SQL query and reference-file does not match ({0} vs. {1})", values.Length + 1, SQLReader.FieldCount));
						}
		
		
						// run through every field in SQL result
						for (int iFields = 0; iFields <= SQLReader.FieldCount - 1; iFields++)
						{
		
							var expectedValue = values[iFields];
							var actualValue = SQLReader[iFields].ToString();
		
							// prepare log message
							string validationMessage = string.Empty;
							if (string.IsNullOrEmpty(customLogMessageDetail))
							{
								validationMessage = String.Format("Comparing content of cell ({2}/{3}) (found:'{0}', expected: '{1}')", actualValue, expectedValue, iRow, iFields);
							}
							else
							{
								validationMessage = customLogMessageDetail;
							}
							// validate if actual value and expected value are equal
							Ranorex.Validate.AreEqual(actualValue, expectedValue, validationMessage);
		
						}
						iRow++;
					}
					if (string.IsNullOrEmpty(customLogMessageOverall))
					{
						customLogMessageOverall = "Successfully validated SQL Table with given SQL-Statement against content of given CSV file";
					}
					// Log success
					Ranorex.Report.Log(Ranorex.ReportLevel.Success, customLogMessageOverall);
		
				}
				finally
				{
					command.Dispose();
					SQLReader.Dispose();
					CSVReader.Dispose();
				}
			}
		}
    
    
    }
}
