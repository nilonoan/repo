﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace AlertingUI
{
    /// <summary>
    /// Description of UiTableValidations.
    /// </summary>
    [TestModule("B15F2507-339E-4975-8E37-7B58E03C030E", ModuleType.UserCode, 1)]
    public class UiTableValidations : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public UiTableValidations()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
        }
        
        public void ProcessPagination(string strPage, string nextButton, string buttonContainer, string strTable, string selectControl, int column)
        {
        	WebDocument page = strPage; //"/dom[@domain='bundle-service.lotos10.fat']";
        	SelectTag select0 = selectControl; //"/dom[@domain='bundle-service.lotos10.fat']//div[#'page-wrapper']/div[2]/div[1]//select[@name='0']";
        	string searchTerm = getSelectedOptionText(select0);
        	
        	Ranorex.ATag button = nextButton; //"/dom[@domain='bundle-service.lotos10.fat']//li[#'DataTables_Table_0_next']/a[@innertext='Next']";
    		LiTag li = buttonContainer; //"/dom[@domain='bundle-service.lotos10.fat']//li[#'DataTables_Table_0_next']";
    		string liClass = li.Class;
        	
        	do {
    				li = buttonContainer; //"/dom[@domain='bundle-service.lotos10.fat']//li[#'DataTables_Table_0_next']";
    				liClass = li.Class;
			         
    				// the below two lines are optional 
 	        		//DivTag pagenum = "/dom[@domain='bundle-service.lotos10.fat']//div[#'DataTables_Table_0_info']";
	        		//Report.Info("Current page displays: " + pagenum.InnerText);
		        	
	        		TableTag Table0 = strTable; //"/dom[@domain='bundle-service.lotos10.fat']//table[#'DataTables_Table_0']";
		        	ProcessPage(searchTerm, Table0, column);

		        	if (!liClass.EndsWith("disabled", System.StringComparison.CurrentCultureIgnoreCase))
		        	{
		        		button.PerformClick();
		        		Report.Info("'Next' button clicked.");
		        		page.WaitForDocumentLoaded();
		        		button = nextButton; //"/dom[@domain='bundle-service.lotos10.fat']//li[#'DataTables_Table_0_next']/a[@innertext='Next']";
		        	}
	        	
        		} while (!liClass.EndsWith("disabled", System.StringComparison.CurrentCultureIgnoreCase ));
             
        }
        
        public void ProcessPage(string searchTerm, TableTag table0, int column)
        {
         	IList<TrTag> rows = table0.FindDescendants<TrTag>();
       
        	for(int i = 0; i < rows.Count; i++) 
        	{
        		if(i == 0 ) { continue; } //first row is empty
        		
	        	Ranorex.TdTag cell = getTableCell(table0, i, column);
	        	string cellText =  cell.InnerText;
	        	string validationMessage = String.Format("Comparing content of cell ({2}/{3}) (found:'{0}', expected: '{1}')", searchTerm, cellText, i, 0);
	        	Ranorex.Validate.AreEqual(searchTerm, cellText, validationMessage);
	        	
        	}
        }
        
        public string getSelectedOptionText(Ranorex.SelectTag select)
        {
        	string optionText = "";
        	foreach ( Ranorex.OptionTag optTag in select.Find(".//option") )
        	{
        		if( optTag.Selected ) {
		        	optionText = optTag.InnerText;
		           
        		}
        	}
        	return optionText;
        }
        	
        public Ranorex.TdTag getTableCell(Ranorex.TableTag table, int rowNum, int colNum)
        {
        	try {
        		IList<Ranorex.TrTag> rows = table.FindDescendants<Ranorex.TrTag>();
        		if(rows.Count < rowNum)
        		{
        			Report.Failure("The table contains less rows than " + rowNum + ", row count: " + rows.Count);
        			
        		}
        		else
        		{
        			Ranorex.TrTag row = rows[rowNum];
        			IList<Ranorex.TdTag> cells = row.FindDescendants<Ranorex.TdTag>();
        			
        			if(cells.Count < colNum || cells.Count == 0)
        			{
        				Report.Failure("The table contains less columns than " + colNum+1 + ", column count: " + cells.Count) ;
        			}
        			else
        			{
        				Ranorex.TdTag cell = cells[colNum];
        				return cell;
        			}
        		}
        	}
        	catch (ElementNotFoundException ex)
        	{
        		Report.Failure(ex.Message);
        	}
        	return null;
        }
    }
}
