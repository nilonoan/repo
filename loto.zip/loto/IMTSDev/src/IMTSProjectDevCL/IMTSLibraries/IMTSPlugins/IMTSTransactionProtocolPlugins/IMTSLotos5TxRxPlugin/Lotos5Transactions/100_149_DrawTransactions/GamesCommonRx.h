/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once

#ifndef GAMESCOMMONRX_H
#define GAMESCOMMONRX_H

/**
 * @file GamesCommonRx.h
 * @brief This file contains the code that initially processes all play receive replies for all family games.
 * @class GamesCommonRx
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief This is an abstract class in which \ref prepareReceipt should be overriden.
 * It also provides generic functions that return reply_100_1 values in a pre-determined
 * format. The subclass could overide them and form the receipt that fits customers' needs.
 */

#include "Transactions/100_149_DrawTransactions/GameTxData.h"
#include "ErrorHandling.h"
#include "Lotos5Headers.h"
#include "ImtsLotos5Enumerations.h"
#include "ImtsEnumerations.h"
#include "handlePromotionOutcomes.h"

class GamesCommonRx;

class GamesCommonRx : public HandlePromotionOutcomes
{
    Q_GADGET

    Q_FLAGS ( PlayPrintReceiptFlag )

public:
    GamesCommonRx ();
    virtual ~GamesCommonRx ();

    enum PlayPrintReceiptFlag { InvalidTicket = 0,
                                NormalTicket  = 1,
                                Exchange      = 1 << 1,
								TicketRepeat  = 1 << 2,
								Promotion     = 1 << 3,
								Pilot         = 1 << 4,
								Training      = 1 << 5,
								EanFollows    = 1 << 6,
								Email         = 1 << 7
                              };

    Q_DECLARE_FLAGS ( PlayPrintReceiptFlags, PlayPrintReceiptFlag )

protected:

    inline  GamesCommonRx* getGamesCommRxInstance () { return this; }

    /**
      * @sa initializeGameRxData
      * @param byte array with gui data
      * @param pointer to received data
      * @return eeRxStatus
      * @brief Performs basic initializations to help us build the receipt
      */
    virtual ImtsRxErrors::eeRxStatus initializeGameRxData(const QByteArray& qbaGuiData, const char* pReceivedData, const bool& bIsTraining );

    /**
      * @sa addPlayTransactionToCustomerSession
      * @brief Populates the map addTransaction method expects and calls it to adds play transaction
      * to customer session.
      */
    virtual void addPlayTransactionToCustomerSession ();

    /**
     * @sa makeReply_100_1_From_Reply_50_1
     * @param qbaGameData
     * @param pReceivedData buffer containing Reply50_1 data
     * @brief initializes Reply100_1 from Reply50_1 data
     */
    virtual void makeReply_100_1_From_Reply_50_1 (const char* pReceivedData );

    /**
     * @brief postExchangeOperation
     * @param pGameTxData
     * @param pReceivedData
     * @return
     */
    virtual ImtsRxErrors::eeRxStatus postExchangeOperations (GameTxData *pGameTxData, const char* pReceivedData );

    /**
     * @sa initFlagsFor2000Exchange
     * @param mArea
     * @param pTrns_gm_2000
     * @return mArea modified
     * @brief initializes the flags for exchange ticket. Very much project dependent. Default does TW.
     */
    virtual void initFlagsFor2000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 );

    /**
     * @sa initTypeFor2000Exchange
     * @param mArea
     * @param pTrns_gm_2000
     * @return mArea modified
     * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
     */
    virtual void initTypeFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode );

    /**
     * @sa initValueFor2000Exchange
     * @param mArea
     * @param pTrns_gm_2000
     * @return mArea modified
     * @brief initializes the value for exchange ticket. Very much project dependent. Default does TW.
     */
    virtual void initValueFor2000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000, const int& iGameCode );

    /**
     * @sa initCustomExchangeDataFor2000
     * @param mArea
     * @param pTrns_gm_2000
     * @return mArea modified
     * @brief do any other initialization you want for exchange
     */
    virtual void initCustomExchangeDataFor2000  ( QVariantMap& mAreaValues, const TRNS_GM_2000* pTrns_gm_2000 );

    /**
     * @sa generateExchangeTicketFor2000
     * @param qbaGameData
     * @param pReceivedData
     * @return status RX_SUCCESS if all OK else RX_EXCHANGE_TICKET_ERROR if something goes wrong in the process
     * @brief This method populates a 100 1 reply with the data found in pReceivedData. pReceivedData
     * was sent to us upon request for an exchange ticket. Basically we populate reply 100 1 from
     * reply 50 1.
     *
     * In addition, we initialise the GameTxData json object that contains all data as if gui
     * placed the request. Remember that from gui, we initialize GameTxData object so that we
     * can successfully initialize the Lotos5 transmit data in order to place a play request.
     */
	virtual ImtsRxErrors::eeRxStatus generateExchangeTicketFor2000 ( const QByteArray &qbaGameData, const char* pReceivedData );

    /**
     * @sa initCouponHeaderDataExchange
     * @param pReply_50_1
     */
    virtual void initCouponHeaderDataExchange ( const REPLY_50_1* pReply_50_1 );

    /**
     * @sa initCouponHdrFlagsExchange
     * @param pReply_50_1
     */
    virtual void initCouponHdrFlagsExchange ( const REPLY_50_1* pReply_50_1 );

    /**
     * @sa initTypeFor5000Exchange
     * @param mArea
     * @param pTrns_gm_5000
     * @return mArea modified
     * @brief initializes the type for exchange ticket. Very much project dependent. Default does TW.
     */
    virtual void initTypeFor5000Exchange  ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode );

    /**
     * @sa initSysFor5000Exchange
     * @param mArea
     * @param pTrns_gm_5000
     * @return mArea modified
     * @brief  Watch out because sys[1] is initialized based on the game code. In some goes the multiplier and in some the
     * the number of marks for panelB for example. So we'll make it pure virtual so that you will have to implemented yourself.
     * The cost is that in case you don't have exchange or ticket replay as a requirement at your project you will have to implement
     * it as an empty method to allow you inherit this class.
     */
    virtual void initSysFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode ) = 0;

    /**
     * @sa initGameFlagsFor5000Exchange
     * @param mArea
     * @param pTrns_gm_5000
     * @return mArea modified
     * @brief initializes the flags for exchange ticket.
     */
    virtual void initGameFlagsFor5000Exchange ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000, const int& iGameCode );

    /**
     * @sa initCustomExchangeDataFor5000
     * @param mArea
     * @param pTrns_gm_5000
     * @return mArea modified
     * @brief do any other initialization you want for exchange
     */
    virtual void initCustomExchangeDataFor5000  ( QVariantMap& mAreaValues, const TRNS_GM_5000* pTrns_gm_5000 );

    /**
     * @brief generateExchangeTicketFor5000
     * @param qbaGameData
     * @param pReceivedData
     * @return status RX_SUCCESS if all OK else RX_EXCHANGE_TICKET_ERROR if something goes wrong in the process
     * @brief This method populates a 100 1 reply with the data found in pReceivedData. pReceivedData
     * was sent to us upon request for an exchange ticket. Basically we populate reply 100 1 from
     * reply 50 1.
     *
     * In addition, we initialise the GameTxData json object that contains all data as if gui
     * placed the request. Remember that from gui, we initialize GameTxData object so that we
     * can successfully initialize the Lotos5 transmit data in order to place a play request.
     */
	virtual ImtsRxErrors::eeRxStatus generateExchangeTicketFor5000 ( const QByteArray &qbaGameData, const char* pReceivedData );

    /**
      * @sa getPlayAction
      * @return play action as indicated in css_it_1.flags
      * @brief returns the play action indicated in css_it_1.flags
      */
    quint32 getPlayAction () ;

    /**
      * @sa getHeaderCrc
      * @brief return header crc in string format
      */
    virtual QString getHeaderCrc ();

    /**
      * @sa getTrnsNumber
      * @brief return the transaction number as a string
      */
    virtual QString getTrnsNumber ();

    /**
      * @sa getSalesDate
      * @return salesDate in a predetermined format
      * @brief
      */
    virtual QString getSalesDate ( QString qsDateFormat = QStringLiteral("dddd dd MMMM yyyy") );

    /**
      * @sa getCouponNumber
      * @return couponNumber
      * @brief
      */
    virtual QString getCouponNumber ();

    /**
      * @sa getFirstDraw
      * @param with to fill with zeros
      * @return firstDraw
      * @brief
      */
    virtual QString getFirstDraw ( int width = 6 );

    /**
      * @sa getLastDraw
      * @param with to fill with zeros
      * @return lastDraw
      * @brief
      */
    virtual QString getLastDraw ( int width = 6 );


    /**
     * @sa getNumberOfValidDraws
     * @return per name
     */
    virtual qint32 getNumberOfValidDraws ();

    /**
      * @sa getFirstDrawDate
      * @return firstDrawDate
      * @brief returns the first draw in a pre-determined format
      */
    virtual QString getFirstDrawDate ( QString qsDateFormat = QStringLiteral("dddd dd MMMM yyyy"), bool bWithTime = false );

    /**
      * @sa getLastDrawDate
      * @return lastDrawDate
      * @brief returns the last draw in a pre-determined format
      */
    virtual QString getLastDrawDate (QString qsDateFormat = QStringLiteral("dddd dd MMMM yyyy") , bool bWithTime = false );

    /**
     * @sa getReply100_1_Datax
     * @return reply_100_1 data[x]
     * @brief returns reply_100_1 data[x]
     */
    long getReply100_1_DataX( const uint& uiIndex );

    /**
      * @sa getBarcode
      * @return barcode ready for printing
      * @brief the barcode in stringformat ready for printing
      */
    virtual QString getBarcode ();

    /**
      * @sa getPlainBarcode
      * @return barcode in a QList
      * @brief returns the barcode in a QList<ulong>
      */
    virtual QList<ulong> getPlainBarcode ();

    /**
      * @sa getFormatedCouponCost
      * @return amount
      * @brief returns the amount. It is already formated.
      */
    virtual QString getFormatedCouponCost ();

    /**
      * @sa getPlainCouponCost
      * @return amount as double
      * @brief returns the amount as double
      */
    virtual double getPlainCouponCost ();

    /**
      * @sa getColumns
      * @return columns
      * @brief returns number of columns in string format
      */
    virtual QString getColumns ();

    /**
      * @sa getGameCode
      * @return gameCode
      * @brief
      */
    virtual int getGameCode () const;

     /**
      * @sa getWorkingGamecode
      * @return workingGameCode
      * @brief
      */
    virtual unsigned int getWorkingGamecode() const;



    /**
     * @sa isTraining
     * @return true/false for training mode
     */
    bool isTraining () const;

    /**
     * @sa setTraining
     * @param bIsTraining
     */
    void setTraining (const bool& );

    /**
     * @sa setBarcode
     * @brief needed for training mode
     */
    void setBarcode ();

    ////////// Game configuration related methods ///////////////////////


    /**
      * @sa getNumberOfAreas
      * @return numberOfAreas
      * @brief
      */
    int getNumberOfAreas ();

    /**
      * @sa getNumberOfPanels
      * @return numberOfPanels
      * @brief
      */
    int getNumberOfPanels ();

    /**
      * @sa getHtmlTemplateFile
      * @return htmlTemplateFile
      * @brief
      */
    QString getHtmlTemplateFile ();

    /**
      * @sa getHtmlPreviewTemplateFile
      * @brief game's html preview file location
      */
    QString getHtmlPreviewTemplateFile();

    /**
     * @sa getLogo
     * @return game's logo for printing
     */
    QString getLogo ();

    /**
      * @sa getPanel
      * @return the panel with the numbers
      * @brief A list that contains the lotto numbers
      */
    QVariantList getPanel ( const int& iArea, const int& iPanel );

    /**
      * @sa getArea
      * @return area
      * @brief The area Map. Check json object
      */
    QVariantMap getArea ( const int& iArea );

    /**
      * @sa getAreaCost
      * @param
      * @brief
      */
    double getAreaCost ( const int& iArea );

    /**
      * @sa getAreaMultiplier
      * @param
      * @brief
      */
    int getAreaMultiplier ( const int& iArea );

    /**
      * @sa getAreaFlags
      * @param
      * @brief
      */
    quint8 getAreaFlags ( const int& iArea );

    /**
      * @sa getAreaDefaultMarks
      * @param
      * @brief
      */
    quint8 getAreaDefaultMarks ( const int& iArea );

    /**
     * @sa getPickPlayType
     * @param iArea
     * @return the playtype as set in gui for pick game.
     */
    quint32 getPickPlayType ( const int& iArea );


    /**
     * @sa getIsecurePrintable
     * @return the Isecure number in printing format
     */
    virtual QString getIsecurePrintable ();

    /**
     * @sa getGameName
     * @return the game's name
     */
    virtual QString getGameName ();

    /**
     * @sa getRiskManagementError
     * @param iCsReply
     * @return The string containing the groups blocked in case risk management is in place.
     */
    virtual QString getRiskManagementError (const int& iCsReply, const uint& iNumberOfGroups );

    /**
     * @sa getEan13Barcode
     * @param number of longs the s/w should expect. The default is 2. Just pass
     * the number your project is expecting and the method will calculate the correct one for you.
     * So, you don't really have to override the method if number of longs is not 2.
     * Ean number follows - Games 5000:After REPLY_100_1 - Games 2000:After TRNS_GM_2000 * groups - Game 7000:After RTRNS_GM_7000
     * @param bIsRaffle. usually these games belong to 2000 family games but have no groups. In that case we need to distinguish it
     * so that we cust the ean pointer to the right memory address.
     * @return the ean barcode as string
     *
     */
    virtual QString getEan13Barcode ( quint8 iNumberOfLongs = 2, bool bIsRaffle = false );

    /**
      * @sa setBit
      * @param buffer
      * @param bitpos to set.
      * @brief set the bit in a buffer indicated by input param bitpos
      */
    inline void setBit ( char* buf, const int& bitpos )
    {
        int pos=bitpos/8;
        int sbit=bitpos%8;

        buf[pos]|=((0x80>>sbit));
    }

    /**
      * @sa isSet
      * @param buffer
      * @param bitpos to set.
      * @return true if set false otherwise
      * @brief check if bit is set in a buffer indicated by input param bitpos
      */
    inline bool isSet ( char* buf, const int& bitpos )
    {
        int pos=bitpos/8;
        int sbit=bitpos%8;

        if (buf[pos]&(0x80>>sbit))
            return true;
        return false;
    }

    /**
      * @sa getTrnsHdrPtr
      * @return pointer to TRNS_HDR
      * @brief returns a pointer to TRNS_HDR
      */
    TRNS_HDR* getTrnsHdrPtr() const;

    /**
      * @sa getCssIt1Ptr
      * @return pointer to CSS_IT_1
      * @brief returns a pointer to CSS_IT_1
      */
    CSS_IT_1* getCssIt1Ptr() const;

    /**
      * @sa getReply100_1Ptr
      * @return pointer to REPLY_100_1
      * @brief returns a pointer to REPLY_100_1
      */
    REPLY_100_1* getReply100_1Ptr() const;

    /**
     * @brief getGameTxData
     * @return
     */
    GameTxData* getGameTxData () const;

    /** @sa getEmail
     * @return the email we ought to send receipt to, if one exists
     * @brief returns email
     */
    QString getEmail () const;

    /** @sa getEmailPassword
     * @return the email password we ought to encrypt data with
     * @brief returns email password
     */
    QString getEmailPassword () const;

    /**
     * @sa getOnTicketMessages
     * @return the list of messages to be printed on the ticket.
     */
    QVariantList getOnTicketMessages () const;

    /**
     * @sa getGameRuleMessageList
     * @return the list of messages to be printed on the ticket.
     */
    QVariantList getGameRuleMessageList () const;

    /**
     * @sa getGamePromotionData
     * @return the QByteArray that contains a promotionData object with all the promotion information
     * for the specific game (e.g. promoiton messages).
     */
    QByteArray getGamePromotionData () const;


	/**
     * @sa setSaveReceiptFileName
     */
    void setSaveReceiptFileName ( const QString& qsFileName );

	/**
	  * @sa HandlePromotion
	  * @param the reply buffer
	  * @return true if the handling of the promotions is ok. Otherwise false.
	  * @brief Handling the promotions of the ticket's reply buffer.
	*/
    bool HandlePromotions(const char *ReceivedData);

	/**
	  * @sa HandleTicketPromotions
      * @param the reply buffer
	  * @param the QVariantList that contains each promotion data
	  * @param if we have pending promotions or not
	  * @return true if the handling of the promotions is ok. Otherwise false.
	  * @brief Handling the promotions of the ticket's reply buffer.
	*/
    bool HandleTicketPromotions(const char *pReceivedData,QVariantList &promotionsActionsDataList,bool &pendingPromotions);

	/**
	  * @sa HandlePendingPromotions
	  * @param the reply buffer
	  * @param if we have pending promotions or not
	  * @param The initial barcode of the trigger ticket
	  * @return true if the handling of the promotions is ok. Otherwise false.
	  * @brief Handling the pending promotions.
	*/
	bool HandlePendingPromotions(const char *pReceivedData,const unsigned long *barcode,QVariantList &promotionsActionsDataList,bool &pendingPromotions);

    /**
     * @sa getDiscountAmount
     * @brief Find if the coupon has discount amount from promotion data
     * @return the discount amount
     */
    QString getPromotionDiscountAmount();

    /**
     * @sa ExecutePromotionsActions
     * @brief For all the promotions, besides the actions that have to be done at the promotion trigger ticket,
     * @brief execute the associated to each promotion actions (e.g. print receipt, play game, play sound etc)
     */
    void ExecutePromotionsActions();

	GameTxData* m_pcGameTxData;
	QString m_qsSaveReceiptFileName;

private:
    void setPlayAction( const uint& flags );

    quint32 m_PlayActionFlag;
    bool m_bIsTraining;
    QList<ulong> m_lTrainingBarcode; // needed for training

protected:
    QVariantList m_promotionsActionsDataList;

    TRNS_HDR* m_pTrns_Hdr;
    CSS_IT_1* m_pCss_It_1;
    REPLY_100_1* m_pReply_100_1;
    QByteArray m_qbaFakedData;

};
Q_DECLARE_OPERATORS_FOR_FLAGS(GamesCommonRx::PlayPrintReceiptFlags)

#endif // GAMESCOMMONRX_H
