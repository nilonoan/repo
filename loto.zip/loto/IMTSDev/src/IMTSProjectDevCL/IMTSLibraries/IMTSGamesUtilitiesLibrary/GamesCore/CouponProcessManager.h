/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#ifndef COUPONPROCESSMANAGER_H
#define COUPONPROCESSMANAGER_H

#include <QObject>
#include <QHash>
#include <QThread>
#include <QSemaphore>
#include <QStringList>
#include "GamesData/Coupon.h"
#include "Configuration/Games/GamesConfig.h"
#include "Plays/ExternalPlay.h"
#include "ImtsGamesEnums.h"
#include "../IMTSGamesUtilitiesLibrary_global.h"

#if defined(IMTS_LINUX) || defined(IMTS_ARM)
#include "PDIPlayslipProject.h"

typedef struct
{
	int     iPrimaRiga;
	int     iNoOfMarks;
	char    pcMarks[200*200];

} __attribute__((packed)) SPhotonCouponDatMarks;
#endif

/**
 * @file CouponProcessManager.h
 * @class CouponProcessManager
 * @brief This object is run into a thread and it is responsible to process incoming
 * coupon data requests from external devices, scanner, camera, aux terminals, etc.
 * Upon receiving a coupon is queued into a list and they are then processed one by
 * one. It does convert the incoming data to CouponData and emits a signal to
 * so that CouponCollectorManager adds in its db. If errors are found, then emits
 * a signal and GamesUi makes a decision where to display the error with the help
 * of WindowManager we have. Check GamesUi class.
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 */
class CouponProcessManagerPrivate;
class IMTSGAMESUTILITIESLIBRARYSHARED_EXPORT CouponProcessManager : public QObject
{
	Q_OBJECT
	Q_PROPERTY ( bool    scanningDeviceEnable     READ scanningDeviceEnabled    WRITE setScanningDeviceEnabled NOTIFY scanningDeviceEnabledChanged )
	Q_PROPERTY ( quint32 dropSameDataInterval     READ dropSameDataInterval     WRITE setDropSameDataInterval )
	Q_PROPERTY ( quint32 questionSameDataInterval READ questionSameDataInterval WRITE setQuestionSameDataInterval )
	Q_PROPERTY ( bool    alwaysPromptOnSameCoupon READ alwaysPromptOnSameCoupon WRITE setAlwaysPromptOnSameCoupon )
	Q_PROPERTY ( qint32  popUpTimeout             READ popUpTimeout             WRITE setPopUpTimeout )
	Q_PROPERTY ( bool    isTraining               READ isTraining               WRITE setIsTraining )

public:
	explicit CouponProcessManager ( QObject* parent = 0 );
	virtual ~CouponProcessManager ();

	bool scanningDeviceEnabled () const;
	void setScanningDeviceEnabled ( const bool& );

	quint32 dropSameDataInterval () const;
	void setDropSameDataInterval ( const quint32& );

	quint32 questionSameDataInterval () const;
	void setQuestionSameDataInterval ( const quint32& );

	bool alwaysPromptOnSameCoupon () const;
	void setAlwaysPromptOnSameCoupon ( const bool& );

	qint32 popUpTimeout () const;
	void setPopUpTimeout ( const qint32& );

	bool isTraining () const;
	void setIsTraining ( const bool& );

	Coupon getCouponData ();

signals:

	void scanningDeviceEnabledChanged ();

	/**
	 * @sa procceedOnDuplicateData
	 * @param eCouponSource
	 * @param qbaCouponData
	 */
	void procceedOnDuplicateData ( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData );

	/**
	 * @sa resumeCouponProcess
	 * @brief triggered to resume processing coupons
	 */
	void resumeCouponProcess ();

	/**
	 * @sa processPendingCoupons
	 */
	void processPendingCoupons ();

	/**
	 * @sa processCouponsBatch
	 */
	void processCouponsBatch ( GamesConfig*, QList<Coupon>, const ImtsGamesEnums::CouponSource& );

	/**
	 * @sa requestCouponDataEdit
	 */
	void requestCouponDataEdit ( const Coupon&,
								 const ImtsGamesEnums::EditModesFlags& );	// Signal game center to edit data.

public slots:
	/**
	 * @sa resumeCouponProcessSlot
	 */
	void resumeCouponProcessSlot ();

	/**
	 * @sa addCouponForProcessingSlot
	 * @param eCouponSource
	 * @param qbaCouponData
	 */
	void addCouponForProcessingSlot ( const ImtsGamesEnums::CouponSource& eCouponSource,
									  const QByteArray& qbaCouponData );

	/**
	 * @sa processPendingCouponsSlot
	 */
	void processPendingCouponsSlot ();

	/**
	 * @sa suspendCouponProcessSlot
	 */
	void suspendCouponProcessSlot ();

protected slots:
	/**
	 * @sa procceedOnDuplicateDataSlot
	 * @brief msg box that prompts user to continue or discard a duplicate read
	 */
	virtual void procceedOnDuplicateDataSlot (const ImtsGamesEnums::CouponSource &eCouponSource, const QByteArray &qbaCouponData);

protected:

	/**
	 * @sa initializeCouponData
	 */
	void initializeCouponData ();

	/**
	 * @sa promptForGeneralError
	 * @param qsDisplayText
	 */
	virtual void promptForGeneralError (const QString& qsDisplayText , const QString& qsBtn1Text , const QString& qsMsgBoxTitle , int iTimeOut = 10000 );

	/**
	 * @sa processPendingCouponsLogic
	 * @param eSource
	 * @param qbaCouponData data received from external source for parsing/processing
	 * @brief internal logic on coupons' processing. Normally for IMTS complient projects
	 * you won't have to override this method. However, for other projects that are not
	 * complient with IMTS like, introducing flexbet in IMTS you might have to override it.
	 */
	virtual void processPendingCouponsLogic (  const ImtsGamesEnums::CouponSource& eSource, const QByteArray& qbaCouponData );

	/**
	 * @sa preCouponProcessOperations
	 * @param coupon source
	 * @param qbaCouponData
	 * @return true/false
	 * @brief There are cases where the last given coupon data is provided twice. In that
	 * case we need to ask the retailer whether he/she wants to proceed or not. The default
	 * implementation does the following:
	 * If same data within a 2seconds window it will drop it.
	 * If same data within a 10seconds window will prompt the retailer for action. (continue/drop)
	 */
	virtual void preCouponProcessOperations( const ImtsGamesEnums::CouponSource& eCouponSource, const QByteArray& qbaCouponData );

	/**
	 * @sa updateCouponCost
	 * @param cGamesConfig
	 * @param cCouponData
	 */
	virtual void updateCouponCost ( GamesConfig&, const Coupon& );

	/**
	 * @sa processQpPlay
	 * @param qbaCouponData
	 */
	virtual void processQpPlay ( const QByteArray& qbaCouponData );

	/**
	 * @sa processFastGamePlay
	 * @param qbaCouponData
	 */
	virtual void processFastGamePlay ( const QByteArray& qbaCouponData );

	/**
	 * @sa overrideQpPlayData
	 * @param list of coupons
	 * @param qbaCouponData
	 * @return list of coupons for transmission
	 */
	virtual bool overrideQpPlayData ( QList<Coupon>&, const QByteArray& );

	/**
	 * @sa selectBetType
	 * @param cGamesConfig
	 * @param cCouponData
	 * @return selects bettype for such games
	 */
	virtual int selectBetType( const int& iNumberOfBetTypes );

	/**
	 * @sa finalizeQpPlay
	 * @param cGamesConfig
	 * @param cCouponData
	 * @return finalize qp play. Project depended
	 */
	virtual void finalizeQpPlay ( GamesConfig&, Coupon&, ExternalPlay& );

	/**
	 * @sa processCameraCoupon
	 * @param qbaCouponData
	 */
	virtual void processCameraCoupon (const QByteArray&);

	/**
	 * @sa processScannerCoupon
	 * @param qbaCouponData
	 */
	virtual void processScannerCoupon (const QByteArray&);

	/**
	 * @sa processQrData
	 * @param qbaCouponData
	 */
	virtual void processQrData (const QByteArray&);

	/**
	 * @sa processAdditionalGame
	 * @param qbaCouponData
	 */
	virtual void processAdditionalGame (const QByteArray&);

	/**
	 * @sa createCouponDataFromGameTxData
	 * @param GameTxData
	 * @param CouponData
	 * @param GamesConfig
	 * @brief calls the createCouponDataFromGameTxData
	 */
	virtual void createCouponDataFromGameTxData ( const QByteArray& qbaGameTxData, Coupon& couponData, GamesConfig *const pcGamesConfig );

	/**
	 * @sa processRegenerationCoupon
	 * @param GameTxData
	 * @brief processes ready GameTxData. Data come from ticket regeneration process
	 */
	virtual void processRegenerationCoupon ( const QByteArray& );

	/**
	* @sa processMiscellaneousGame
	* @param miscellaneous games' data
	* @brief processes miscellaneous games
	*/
	virtual void processMiscellaneousGame ( const QByteArray& );

	/**
	 * @sa processGuiFlexBetData
	 * @param qbaCouponData
	 */
	virtual void processGuiFlexBetData ( const QByteArray& );

	/**
	 * @sa processGuiRacesData
	 * @param qbaCouponData
	 */
	virtual void processGuiRacesData ( const QByteArray& );

	/**
	 * @sa processGuiGBIRacesData
	 * @param qbaCouponData
	 */
	virtual void processGuiGBIRacesData ( const QByteArray& );

	/**
	 * @sa addCouponToList
	 * @param eCouponSource
	 * @param lCouponList
	 * @brief just before adding coupons to list do a final check on whether data should be added
	 * or not.
	 */
	virtual bool addCouponToList(Coupon &, GamesConfig& cGamesConfig, const ImtsGamesEnums::CouponSource &eCouponSource, QList<Coupon>& lCouponList,const bool bCheckForDirectConnection = true);

	/**
	 * @sa preprocessCouponsBatch
	 */
	virtual void preProcessCouponsBatch ( GamesConfig&, QList<Coupon>&, const ImtsGamesEnums::CouponSource& );

	/**
	 * @sa acceptIncomingCouponData
	 */
	void acceptIncomingCouponData ( const ImtsGamesEnums::CouponSource&, const QByteArray& );

private:

	QScopedPointer<CouponProcessManagerPrivate> const d_ptr;
	Q_DISABLE_COPY (CouponProcessManager)
	Q_DECLARE_PRIVATE (CouponProcessManager)

};
Q_DECLARE_METATYPE(QList<Coupon>)
#endif // COUPONPROCESSMANAGER_H
