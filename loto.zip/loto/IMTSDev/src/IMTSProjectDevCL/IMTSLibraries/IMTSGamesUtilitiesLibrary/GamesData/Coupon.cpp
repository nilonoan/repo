/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#include <QtCore/QtAlgorithms>
#include "Area.h"
#include "Coupon.h"
#include <QtCore/QtDebug>

/**
  * @file Coupon.cpp
  * @class CouponData
  * @brief We have designed CouponData class to be implicitly shared meaning that you can
  *	pass this class by value. For this reason QShareData class is used as the base class for
  *	our CouponData shared object. Accesses to the members of this class will take
  *	place via QShareDataPointer pointer. Any non-const access will cause the data of this
  *	class to be copied. And for the record, QSharedDataPointer is a strong smart pointer
  *	class, sharing data. All it means is that QShareDataPointer owns the object it is
  *	pointing with the guarantee to stay alive as long as at least one strong pointer still
  *	points to it.
  * @author Nondas Masalis masalis@intralot.com
  * @version 1.0.0
  */

int Coupon::m_iCountMaxAreasCreated = 0;

class Coupon::CouponData : public QSharedData
{

public:
	CouponData() //!< Default constructor
	{
		m_qvmAdditionalGame.clear ();

		m_origin = ImtsGamesEnums::Verbal;
		m_iCouponId = 0;
		m_bVoidCoupon = false;
		m_dCouponCost = 0.;
		m_iCouponColumns = 0;
		m_lMultiDraw.append(1);
		m_lFutureDraw.clear();
		m_lBetType.clear();
		m_iSystemBet = 0;
		m_lAreaList.clear();

		m_iGameCode = 0;
		m_iSubGameCode = 0;
		m_qsGameName.clear ();
		m_iInputMethod = 0;
		m_iNumberOfPanels = 0;
		m_cArea.clearArea ();
		m_iNumberOfTickets = 1;
		m_qsEmail.clear ();
		m_qsEmailPassword.clear ();
		m_iLastSelectedArea = 0;
		m_bDirectTransmission = false;

		m_advPlay = ImtsGamesEnums::InvalidAdvancePlay;
		m_drawType = ImtsGamesEnums::InvalidDraw;

		m_qvmMiscellaneousData.clear ();
		m_qbaPromotionData.clear ();


	}

	CouponData(const CouponData& other) : QSharedData(other)  //!<  Copy constructor
	{
		m_qvmAdditionalGame = other.m_qvmAdditionalGame;
		m_origin = other.m_origin;
		m_iCouponId = other.m_iCouponId;
		m_bVoidCoupon = other.m_bVoidCoupon;
		m_dCouponCost = other.m_dCouponCost;
		m_iCouponColumns = other.m_iCouponColumns;
		m_lMultiDraw = other.m_lMultiDraw;
		m_lFutureDraw = other.m_lFutureDraw;
		m_lBetType = other.m_lBetType;
		m_iSystemBet = other.m_iSystemBet;
		m_lAreaList = other.m_lAreaList;
		m_cArea = other.m_cArea;

		m_iGameCode = other.m_iGameCode;
		m_iSubGameCode = other.m_iSubGameCode;
		m_qsGameName = other.m_qsGameName;
		m_iInputMethod = other.m_iInputMethod;
		m_iNumberOfPanels = other.m_iNumberOfPanels;
		m_iNumberOfTickets = other.m_iNumberOfTickets;
		m_qsEmail = other.m_qsEmail;
		m_qsEmailPassword = other.m_qsEmailPassword;
		m_iLastSelectedArea = other.m_iLastSelectedArea;
		m_bDirectTransmission = other.m_bDirectTransmission;

		m_advPlay.operator = (other.m_advPlay);
		m_drawType.operator = ( other.m_drawType);

		m_qvmMiscellaneousData = other.m_qvmMiscellaneousData;
		m_qbaPromotionData = other.m_qbaPromotionData;


	}

	~CouponData(){}

	QList<Area> m_lAreaList;
	Area m_cArea;
	QList<int> m_lMultiDraw;
	QList<int> m_lFutureDraw;
	QList<int> m_lBetType;
	int m_iSystemBet;
	QVariantMap m_qvmAdditionalGame; // PowerPlay, Sizzler, Megaplier, NONDAS:Proto?(Opap)->don't know yet
	ImtsGamesEnums::CouponSource m_origin;
	int m_iCouponId;
	bool m_bVoidCoupon : 1;
	double m_dCouponCost;
	int m_iCouponColumns;
	int m_iLastSelectedArea;

	/**
	 * @param m_bDirectTransmission
	 * @brief There are cases where direct transmission is off, but some play methods (e.g., fast qp plays) should
	 * do not accumulate in shopping list but have to be transmitted directly to C/S. In that case, we need to tag
	 * the data with the transmission method to help us out on edit requests. Normally, you shouldn't need to set
	 * this value but in IE we had to. If a customer asks camera data to be played directly and gui data to be added
	 * in the shopping list then you should set this param as true.
	 * @note You SHOULD not set value to true or false in any other case except the above exception. CCM handles
	 * transmission methods, direct/nonDirect very well.
	 */
	bool m_bDirectTransmission;

	// The following params are needed when consructing the tx object. They are not used to drive the view.
	int m_iGameCode;
	int m_iSubGameCode;
	QString m_qsGameName;
	int m_iInputMethod;
	int m_iNumberOfPanels;
	int m_iNumberOfTickets;
	QString m_qsEmail;
	QString m_qsEmailPassword;

	ImtsGamesEnums::AdvancePlayFlags m_advPlay;
	ImtsGamesEnums::DrawTypeFlags m_drawType;

	QVariantMap m_qvmMiscellaneousData; // You can store in here any data you wish.
	QByteArray m_qbaPromotionData;

};

Coupon::Coupon()
	: d (new CouponData)
{
}

Coupon::Coupon(const Coupon& other)
	: d(other.d)
{
}

Coupon::~Coupon()
{
}

Coupon& Coupon::operator=( const Coupon& other ) //!< Assignment operator
{
	if ( this != &other ) {
		d = other.d; // do the assignment
	}
	return *this;
}

/******************************************************************************
 ****************** coupon I N I T I A L I Z A T I O N ************************
 ******************************************************************************/

void Coupon::populateCouponsAreaList()
{
	d->m_lAreaList << d->m_cArea; // create a list of implicitly shared objects. Memory efficient.

	if ( m_iCountMaxAreasCreated < d->m_lAreaList.size() ) {

		++m_iCountMaxAreasCreated;
	}
}

/**
 * @sa cloneArea
 * @param iArea area index to clone
 * @param iTimes how many times
 * @param iPos starting at iPos. Default is 1
 * @param clones a given area as many times starting at iPos
 */
void Coupon::cloneArea (const quint8& iArea, const quint8& iTimes, quint8 iPos )
{
	d->m_cArea = *getArea (iArea);

	if ( iTimes > getAreaListSize () ) {

		addAreas (iTimes-getAreaListSize () );
	}

	for ( ; iPos < iTimes; ++iPos ) {
		d->m_lAreaList[iPos] = d->m_cArea;
	}
}

/******************************************************************************
 ************************** coupon G E T T E R S ******************************
 ******************************************************************************/
ImtsGamesEnums::CouponSource Coupon::getCouponOrigin () const
{
	return d->m_origin;
}

int Coupon::getCouponId () const
{
	return d->m_iCouponId;
}

QList<Area> Coupon::getAreaList () const
{
	return d->m_lAreaList;
}

Area* Coupon::getArea( const int& iArea ) const
{
	// NONDAS I need to check the implications it will have when iArea is
	// indeed out of bounds and the caller does not know about it and try
	// to use it as a valid index. To avoid crashes we populate the area
	// object list with a newly created one and return a valid object to the caller.

	int iGetArea = iArea;
	if ( iGetArea > d->m_lAreaList.size()-1 ) {
		const_cast<Coupon*>(this)->populateCouponsAreaList (); // return the default object if index is out of bounds. What implications would have this to the code need to see. NONDAS
		iGetArea = d->m_lAreaList.size ()-1;
		qDebug ("Add area");
	}

	/**
	   // NOTE: Για κανε το πενηνταράκια ρε συ:
	   Calling a non-const function from a const function the compiler will generate an error.
	   That is, getArea function must be const because it is called from all over the place
	   from within const functions. So instead of changing now all the relative routines to non-const
	   we remove constness as follows:
	   Coupon* dummyThis = const_cast<Coupon*>(this); // remove constness
	   Area* area = &(dummyThis->d->m_lArea[iAreaIndex]); // get the address of area.
	   return area;

	   hence:

	*/

	return &const_cast<Coupon*>(this)->d->m_lAreaList[iGetArea]; // remove constness
}

void Coupon::removeLastAreaFromList()
{
	d->m_lAreaList.removeLast();
}

bool Coupon::isCouponEmpty () const
{

	bool bIsEmpty = false;
	if ( d->m_bVoidCoupon ) {

		bIsEmpty = true;

	} else if ( d->m_qvmAdditionalGame.isEmpty () &&
				d->m_qvmMiscellaneousData.isEmpty () &&
				d->m_qbaPromotionData.isEmpty () &&
				d->m_lMultiDraw.count() == 1 &&
				d->m_lMultiDraw.contains(1) &&
				d->m_lFutureDraw.isEmpty() &&
				d->m_lBetType.isEmpty () &&
				d->m_iSystemBet == 0 &&
				d->m_advPlay == ImtsGamesEnums::InvalidAdvancePlay &&
                d->m_drawType == ImtsGamesEnums::InvalidDraw// &&
                //d->m_iSubGameCode == 0
			 )
	{
#pragma message "The above does not allow to the condition to become true."
		// we are not done yet. We got to check each area as well before we draw a conclusion.

		bIsEmpty = true;
		Q_FOREACH ( const Area& area, d->m_lAreaList ) {

			if ( !area.isAreaEmpty () ) {
				bIsEmpty = false;
				break;
			}
		}

	}

	return bIsEmpty;
}

double Coupon::getCouponCost () const
{
	return d->m_dCouponCost;
}

int Coupon::getCouponColumns () const
{
	return d->m_iCouponColumns;
}

bool Coupon::isCouponVoid () const
{
	return d->m_bVoidCoupon;
}

int Coupon::getNumberOfSelectedAreas () const
{
	int iNumberOfSelectedAreas = 0;
	int iAreaSize = d->m_lAreaList.size();

	for ( int iArea = 0; iArea < iAreaSize; ++iArea ) {

		if ( !getArea(iArea)->isAreaEmpty () ) {
			++iNumberOfSelectedAreas;
		}
	}

	return iNumberOfSelectedAreas;
}

QList<int> Coupon::getFutureDrawList () const
{
	return d->m_lFutureDraw;
}

int Coupon::getFutureDrawValue() const
{
	int iValue {0};

	for ( int iFutureDraw: d->m_lFutureDraw ) {
		iValue += iFutureDraw;
	}
	return iValue;
}

QList<int> Coupon::getBetTypeList () const
{
	return d->m_lBetType;
}


int Coupon::getBetTypeValue () const
{
	int iValue = 0;

	if ( d->m_lBetType.size () ) { // no matter list's size always return the first selection
		iValue = d->m_lBetType.at (0);
	}

	return iValue;

}

int Coupon::getSystemBet () const
{
	return d->m_iSystemBet;
}

QList<int> Coupon::getMultiDrawList () const
{
	return d->m_lMultiDraw;
}

int Coupon::getMultiDrawValue() const
{
	int iValue {0};

	if ( d->m_lMultiDraw.size () == 1 ) { // single selection always return the value at 0

		iValue = d->m_lMultiDraw.at (0);

	} else { // multiselection list return the sum of the values. Subtract 1 because it is the default value of the list when it is initialized.

		for ( int iMultiDraw: d->m_lMultiDraw ) {
			iValue += iMultiDraw;
		}

		iValue = iValue>1?iValue-1:1;
	}

	return iValue;

}

QVariantMap Coupon::getAdditionalGameMap () const
{
	return d->m_qvmAdditionalGame;
}

int Coupon::getAreaListSize() const
{
	return d->m_lAreaList.size ();
}

int Coupon::getGameCode () const
{
	return d->m_iGameCode;
}

int Coupon::getSubGameCode () const
{
	return d->m_iSubGameCode;
}

QString Coupon::getGameName () const
{
	return d->m_qsGameName;
}

int Coupon::getInputMethod () const
{
	return d->m_iInputMethod;
}

int Coupon::getNumberOfPanels () const
{
	return d->m_iNumberOfPanels;
}

int Coupon::getNumberOfTickets () const
{
	return d->m_iNumberOfTickets;
}

QString Coupon::getEmail () const
{
	return d->m_qsEmail;
}

QString Coupon::getEmailPassword () const
{
	return d->m_qsEmailPassword;
}

int Coupon::getLastSelectedArea () const
{
	return d->m_iLastSelectedArea;
}

bool Coupon::isDirectTransmission () const
{
	return d->m_bDirectTransmission;
}

ImtsGamesEnums::AdvancePlayFlags Coupon::getAdvancePlay () const
{
	return d->m_advPlay;
}

ImtsGamesEnums::DrawTypeFlags Coupon::getDrawType () const
{
	return d->m_drawType;
}

QVariantMap Coupon::getMiscellaneousData () const
{
	return d->m_qvmMiscellaneousData;
}

QByteArray Coupon::getPromotionData () const
{
	return d->m_qbaPromotionData;
}

/******************************************************************************
 ************************** coupon S E T T E R S ******************************
 ******************************************************************************/
void Coupon::setCouponOrigin (const ImtsGamesEnums::CouponSource& eSource )
{
	if ( eSource == d->m_origin ) return;

	d->m_origin = eSource;
}

void Coupon::setCouponId (const int& iCouponId )
{
	if ( iCouponId == d->m_iCouponId ) return;
	d->m_iCouponId = iCouponId;
}

void Coupon::setCouponVoid( const bool& bVoid )
{
	if ( bVoid == d->m_bVoidCoupon ) return;

	d->m_bVoidCoupon = bVoid;
}

void Coupon::setCouponCost ( const double& dCouponCost )
{
	if ( dCouponCost == d->m_dCouponCost ) return;

	d->m_dCouponCost = dCouponCost;
}

void Coupon::setCouponColumns ( const int& iCouponColumns )
{
	if ( iCouponColumns == d->m_iCouponColumns ) return;

	d->m_iCouponColumns = iCouponColumns;
}

void Coupon::setMultiDrawSingle( const int& iMultiDraw )
{

	if ( d->m_lMultiDraw.contains(iMultiDraw) ) {

		clearMultiDraw ();

	} else {

		d->m_lMultiDraw.clear();
		d->m_lMultiDraw.append(iMultiDraw);
	}
}

void Coupon::setMultiDrawMulti( const int& iMultiDraw )
{
	if ( d->m_lMultiDraw.contains(iMultiDraw) ) {

		d->m_lMultiDraw.removeOne(iMultiDraw);

	} else {

		d->m_lMultiDraw.append(iMultiDraw);
	}
}

void Coupon::clearMultiDraw()
{
	d->m_lMultiDraw.clear();
	d->m_lMultiDraw.append(1);
}

void Coupon::setFutureDrawSingle( const int& iFutureDraw )
{

	if ( d->m_lFutureDraw.contains (iFutureDraw) ) {
		d->m_lFutureDraw.clear();
	} else {
		d->m_lFutureDraw.clear();
		d->m_lFutureDraw.append(iFutureDraw);
	}
}

void Coupon::setFutureDrawMulti( const int& iFutureDraw )
{
	if ( d->m_lFutureDraw.contains(iFutureDraw) ) {

		d->m_lFutureDraw.removeOne(iFutureDraw);

	} else {

		d->m_lFutureDraw.append(iFutureDraw);
	}
}

void Coupon::clearFutureDraw()
{
	d->m_lFutureDraw.clear();
}

void Coupon::setBetTypeSingle ( const int& iBetType )
{
	if( d->m_lBetType.contains(iBetType) ) {

		d->m_lBetType.clear();

	} else {

		d->m_lBetType.clear();
		d->m_lBetType.append(iBetType);
	}

}

void Coupon::setBetTypeMulti ( const int& iBetType )
{
	if( d->m_lBetType.contains(iBetType) ) {

		d->m_lBetType.removeOne(iBetType);

	} else {

		d->m_lBetType.append(iBetType);
	}
}

void Coupon::setSystemBet (const int& iSystemBet )
{
	d->m_iSystemBet = iSystemBet==d->m_iSystemBet?0:iSystemBet; // if same clear else set.
}

void Coupon::setAdditionalGameMap ( const QVariantMap& qvmAdditionalGame )
{
	d->m_qvmAdditionalGame.clear ();
	d->m_qvmAdditionalGame = qvmAdditionalGame;

}

/**
 * @brief populate as many areas as we need. If you request 5 and we have aleady 2, 3 will be created.
 */
void Coupon::addAreas (const int& iNumberOfAreas )
{
	int iAreaListSize = d->m_lAreaList.size ();

	if ( iNumberOfAreas > iAreaListSize ) {
		for (int i = 0; i < (iNumberOfAreas-iAreaListSize); ++i ) { // create as many as we need.
			const_cast<Coupon*>(this)->populateCouponsAreaList ();
		}
	}

}

void Coupon::setGameCode ( const int& iGameCode )
{
	if ( iGameCode == d->m_iGameCode ) return;

	d->m_iGameCode = iGameCode;
}

void Coupon::setSubGameCode ( const int& iGameCode )
{
	if ( iGameCode == d->m_iSubGameCode ) return;

	d->m_iSubGameCode = iGameCode;
}

void Coupon::setGameName ( const QString& qsGameName )
{
	if ( qsGameName == d->m_qsGameName ) return;

	d->m_qsGameName = qsGameName;
}

void Coupon::setInputMethod ( const int& iInputMethod )
{
	if ( iInputMethod == d->m_iInputMethod ) return;

	d->m_iInputMethod = iInputMethod;
}

void Coupon::setNumberOfPanels ( const int& iNumberOfPanels )
{
	if ( iNumberOfPanels == d->m_iNumberOfPanels ) return;

	d->m_iNumberOfPanels = iNumberOfPanels;
}

void Coupon::setNumberOfTickets ( const int& iNumberOfTickets )
{
	if ( iNumberOfTickets == d->m_iNumberOfTickets ) return;

	d->m_iNumberOfTickets = iNumberOfTickets;
}

void Coupon::setEmail (const QString& qsEmail )
{
	if ( qsEmail == d->m_qsEmail ) return;
	d->m_qsEmail = qsEmail;
}

void Coupon::setEmailPassword ( const QString& qsEmailPassword )
{
	if ( qsEmailPassword == d->m_qsEmailPassword ) return;
	d->m_qsEmailPassword = qsEmailPassword;
}

void Coupon::setLastSelectedArea ( const int& iArea )
{
	if ( iArea == d->m_iLastSelectedArea ) return;
	d->m_iLastSelectedArea = iArea;
}

void Coupon::setIsDirectTransmission ( const bool& bDirectTransmission )
{
	if ( bDirectTransmission == d->m_bDirectTransmission ) return;
	d->m_bDirectTransmission = bDirectTransmission;
}

void Coupon::setAdvancePlay (const ImtsGamesEnums::AdvancePlayFlags& advPlay)
{
	d->m_advPlay.operator = (advPlay);
}

void Coupon::setDrawType (const ImtsGamesEnums::DrawTypeFlags& drawType)
{
	d->m_drawType.operator = (drawType);
}

void Coupon::setMiscellaneousData ( const QVariantMap& qvmMiscellaneousData )
{
	d->m_qvmMiscellaneousData.clear ();
	d->m_qvmMiscellaneousData = qvmMiscellaneousData;
}

void Coupon::setPromotionData (const QByteArray& qbaPromotionData )
{
	d->m_qbaPromotionData.clear ();
	d->m_qbaPromotionData = qbaPromotionData;
}

void Coupon::clearCouponData ()
{
	// ClearEverything. I don't think we need to call setters. Just access parameters directly.
	d->m_qvmAdditionalGame.clear ();
	d->m_origin = ImtsGamesEnums::Verbal;
	// d->m_iCouponId = 0; // DO NOT UNCOMMENT
	d->m_bVoidCoupon = false;
	d->m_dCouponCost = 0.;
	d->m_iCouponColumns = 0;
	d->m_lMultiDraw.clear();
	d->m_lMultiDraw.append(1);
	d->m_lFutureDraw.clear();
	d->m_lBetType.clear ();
	d->m_iSystemBet = 0;
	d->m_iNumberOfTickets = 1;
	d->m_qsEmail.clear ();
	d->m_qsEmailPassword.clear ();
	d->m_iLastSelectedArea = 0;
	d->m_bDirectTransmission = false;
	d->m_advPlay.operator = (ImtsGamesEnums::InvalidAdvancePlay);
	d->m_drawType.operator = (ImtsGamesEnums::InvalidDraw);
	d->m_qvmMiscellaneousData.clear ();
	d->m_qbaPromotionData.clear ();

	// clear areas data model

	int iAreaSize = d->m_lAreaList.size();
	for ( int iArea = 0; iArea < iAreaSize; ++iArea ) {
		getArea(iArea)->clearArea ();
	}

	// Clear members that hold game specific constants
	d->m_iGameCode = 0;
	d->m_iSubGameCode = 0;
	d->m_qsGameName.clear ();
	d->m_iInputMethod = 0;
	d->m_iNumberOfPanels = 0;
}

bool Coupon::isSameCoupon(const Coupon& rhs) const
{

	bool bSame = false;

	bSame =
			d->m_qvmAdditionalGame == rhs.d.constData ()->m_qvmAdditionalGame &&
			d->m_origin            == rhs.d.constData ()->m_origin &&
			d->m_iCouponId         == rhs.d.constData ()->m_iCouponId &&
			d->m_bVoidCoupon       == rhs.d.constData ()->m_bVoidCoupon &&
			d->m_dCouponCost       == rhs.d.constData ()->m_dCouponCost &&
			d->m_iCouponColumns    == rhs.d.constData ()->m_iCouponColumns &&
			d->m_lMultiDraw        == rhs.d.constData ()->m_lMultiDraw &&
			d->m_lFutureDraw       == rhs.d.constData ()->m_lFutureDraw &&
			d->m_lBetType          == rhs.d.constData ()->m_lBetType &&
			d->m_iSystemBet        == rhs.d.constData ()->m_iSystemBet &&
			d->m_iNumberOfTickets  == rhs.d.constData ()->m_iNumberOfTickets &&
			d->m_qsEmail           == rhs.d.constData ()->m_qsEmail &&
			d->m_qsEmailPassword   == rhs.d.constData ()->m_qsEmailPassword &&
			d->m_advPlay           == rhs.d.constData ()->m_advPlay &&
			d->m_drawType          == rhs.d.constData ()->m_drawType  &&
			d->m_iGameCode         == rhs.d.constData ()->m_iGameCode &&
			d->m_iGameCode         == rhs.d.constData ()->m_iSubGameCode &&
			d->m_qsGameName        == rhs.d.constData ()->m_qsGameName &&
			d->m_iInputMethod      == rhs.d.constData ()->m_iInputMethod &&
			d->m_iNumberOfPanels      == rhs.d.constData ()->m_iNumberOfPanels &&
			d->m_qvmMiscellaneousData == rhs.d.constData ()->m_qvmMiscellaneousData;
			d->m_qbaPromotionData     == rhs.d.constData ()->m_qbaPromotionData;

	bSame = d->m_lAreaList.size () == rhs.d.constData ()->m_lAreaList.size ();

	if ( bSame ) {

		int iArea = 0;
		Q_FOREACH(const Area& area, d->m_lAreaList )
		{
			bSame = area.isSameArea ( rhs.d.constData ()->m_lAreaList.at (++iArea));
			if ( !bSame ) break;
		}
	}

	return bSame;

}


/**
* @sa getCouponDataSize
* @return the size of the shared data.

* @brief This routine returns the size of the shared data.
*/
int Coupon::getCouponDataSize () const
{
	return sizeof(CouponData);
}


/**
* @sa getCouponDataPointer()
* @return a const pointer to the shared data.

* @brief This routine returns a pointer to the data we share. Remember
we can have access to them, ONLY via the sharedpointer.

d.constData(), inside the routine, does not call detach. So be careful when you
call this function. We make this call to fill a bytearray with the data, giving
it the pointer to them and data's size. When we consturct the bytearray, it will
make a deep copy of the data so we are fine. And this is a reason I don't call
just d.data() which will make a deep copy of the data before the routine returns.
In other words I don't want to make un-necessary duplicate data copies and this is
the reason for d.constData() call
*/
const char* Coupon::getCouponDataPointer () const
{
	return (const char*)d.constData();
}

void Coupon::detachCouponData ()
{
//	for ( int iArea = 0; iArea < d->m_lAreaList.size (); ++iArea ) {
//		d->m_lAreaList[iArea].detachAreaData ();
//	}
	d.detach ();

}
