/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/
#pragma once
#ifndef EXTERNALPLAY_H
#define EXTERNALPLAY_H

#include "../IMTSJsonDataLibrary_global.h"
#include <QtCore/QObject>
#include <QtCore/QVariantMap>
#include <QtCore/QVariantList>
/**
 * @file InstallationInfo.h
 * @class InstallationInfo
 * @brief Handles InstallationInfo.json
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief Responsible for barcode configuration data
 */
class ExternalPlayPrivate;
class IMTSJSONDATALIBRARYSHARED_EXPORT ExternalPlay : public QObject
{
	Q_OBJECT

	Q_PROPERTY(quint32 gameCode              READ readGameCode              WRITE setGameCode              NOTIFY gameCodeChanged FINAL )
	Q_PROPERTY(quint32 subGameCode           READ readSubGameCode           WRITE setSubGameCode           NOTIFY subGameCodeChanged FINAL )
	Q_PROPERTY(quint32 numberOfTickets       READ readNumberOfTickets       WRITE setNumberOfTickets       NOTIFY numberOfTicketsChanged FINAL )
	Q_PROPERTY(quint32 numberOfAreas         READ readNumberOfAreas         WRITE setNumberOfAreas         NOTIFY numberOfAreasChanged FINAL )
	Q_PROPERTY(quint32 numberOfDraws         READ readNumberOfDraws         WRITE setNumberOfDraws         NOTIFY numberOfDrawsChanged FINAL )
	Q_PROPERTY(quint32 futureDraws           READ readFutureDraws           WRITE setFutureDraws           NOTIFY futureDrawsChanged FINAL )
	Q_PROPERTY(quint32 multiplier            READ readMultiplier            WRITE setMultiplier            NOTIFY multiplierChanged FINAL )
	Q_PROPERTY(quint32 betType               READ readBetType               WRITE setBetType               NOTIFY betTypeChanged FINAL )
	Q_PROPERTY(quint32 drawType              READ readDrawType              WRITE setDrawType              NOTIFY drawTypeChanged FINAL )
	Q_PROPERTY(quint32 system                READ readSystem                WRITE setSystem                NOTIFY systemChanged FINAL )
	Q_PROPERTY(quint32 additionalGame        READ readAdditionalGame        WRITE setAdditionalGame        NOTIFY additionalGameChanged FINAL )
    Q_PROPERTY(QVariantList additionalGamePerArea READ readAdditionalGamePerArea WRITE setAdditionalGamePerArea NOTIFY additionalGamePerAreaChanged FINAL )
	Q_PROPERTY(bool   directTransmission     READ readDirectTransmission    WRITE setDirectTransmission    NOTIFY directTransmissionChanged FINAL )
	Q_PROPERTY(QVariantMap customData        READ readCustomData            WRITE setCustomData            NOTIFY customDataChanged FINAL )
	Q_PROPERTY(quint32 couponSource          READ readCouponSource          WRITE setCouponSource          NOTIFY couponSourceChanged FINAL ) // Introduced when integrated code for Promotions.
	Q_PROPERTY(QByteArray promotionData      READ readPromotionData         WRITE setPromotionData         NOTIFY promotionDataChanged FINAL )

public:
	explicit ExternalPlay ( QObject* parent = 0 );
	ExternalPlay( const ExternalPlay & other ); // override copy constructor

	~ExternalPlay();

	Q_INVOKABLE void clearData ();

	quint32 readGameCode              () const;
	quint32 readSubGameCode           () const;
	quint32 readNumberOfTickets       () const;
	quint32 readNumberOfAreas         () const;
	quint32 readNumberOfDraws         () const;
	quint32 readFutureDraws           () const;
	quint32 readMultiplier            () const;
	quint32 readBetType               () const;
	quint32 readDrawType              () const;
	quint32 readSystem                () const;
	quint32 readAdditionalGame        () const;
    QVariantList readAdditionalGamePerArea () const;
	bool    readDirectTransmission    () const;
	QVariantMap readCustomData        () const;
	quint32 readCouponSource          () const;
	QByteArray readPromotionData      () const;

	void setGameCode              ( const quint32 &);
	void setSubGameCode           ( const quint32 &);
	void setNumberOfTickets       ( const quint32 &);
	void setNumberOfAreas         ( const quint32 &);
	void setNumberOfDraws         ( const quint32 &);
	void setFutureDraws           ( const quint32 &);
	void setMultiplier            ( const quint32 &);
	void setBetType               ( const quint32 &);
	void setDrawType              ( const quint32 &);
	void setSystem                ( const quint32 &);
	void setAdditionalGame        ( const quint32 &);
    void setAdditionalGamePerArea ( const QVariantList &);
	void setDirectTransmission    ( const bool& );
	void setCustomData            ( const QVariantMap &);
	void setCouponSource		  ( const quint32& );
	void setPromotionData         ( const QByteArray& );

Q_SIGNALS:
	void gameCodeChanged ();
	void subGameCodeChanged ();
	void numberOfTicketsChanged ();
	void numberOfAreasChanged ();
	void numberOfDrawsChanged ();
	void futureDrawsChanged ();
	void multiplierChanged ();
	void betTypeChanged ();
	void drawTypeChanged ();
	void systemChanged ();
	void additionalGameChanged ();
	void additionalGamePerAreaChanged ();
	void directTransmissionChanged ();
	void customDataChanged ();
	void miscCountChanged ();
	void couponSourceChanged ();
	void promotionDataChanged ();

private:
	ExternalPlayPrivate* d_ptr;
	Q_DECLARE_PRIVATE (ExternalPlay)
};
Q_DECLARE_METATYPE(ExternalPlay)

#endif // EXTERNALPLAY_H
