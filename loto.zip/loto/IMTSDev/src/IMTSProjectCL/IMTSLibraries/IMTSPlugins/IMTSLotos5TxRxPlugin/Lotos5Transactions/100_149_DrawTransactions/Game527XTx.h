/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once

#ifndef GAME527XTX_H
#define GAME527XTX_H

#include "Game5000Play.h"

/**
 * @file Game527XTx.h
 * @class Game527XTx
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief It is the product that defines the transmit product to be created by the corresponding
 * plugin factory.
 */

class Game527XTx: public Game5000Play//, public GamesFamily5000Tx
{
public:
    explicit Game527XTx();
    ~Game527XTx(){}

protected:

    ItCssMessagePayloadInterface *createItCss() const Q_DECL_OVERRIDE;

    void setTrnsGm5000Type ( const int& iArea ) Q_DECL_OVERRIDE;

    static const Game527XTx* const m_Game527XTx;

};

#endif // GAME527XTX_H
