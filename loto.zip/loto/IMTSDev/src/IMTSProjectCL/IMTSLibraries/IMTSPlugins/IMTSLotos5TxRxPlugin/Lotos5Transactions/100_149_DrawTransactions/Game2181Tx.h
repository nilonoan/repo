/******************************************************************************
 Copyright (C) 2010

 Intralot,
 64, Kifissias Ave. & 3, Premetis Str.
 15125 Athens, Greece
 www.intralot.com

 All rights reserved

******************************************************************************/

#pragma once

#ifndef GAME2181TX_H
#define GAME2181TX_H

#include "Game2000Play.h"

/**
 * @file Game2181Tx.h
 * @class Game2181Tx
 * @author Nondas Masalis masalis@intralot.com
 * @version 1.0.0
 * @brief It is the product that defines the transmit product to be created by the corresponding
 * plugin factory.
 */

class Game2181Tx: public Game2000Play
{
public:
    Game2181Tx();
    ~Game2181Tx(){}

protected:

    ItCssMessagePayloadInterface *createItCss() const Q_DECL_OVERRIDE;

    void setTrnsGm2000Type ( const int& iArea ) Q_DECL_OVERRIDE;
    void setTrnsGm2000Value( const int& iArea ) Q_DECL_OVERRIDE;

    static const Game2181Tx* const m_Game2181Tx;

};

#endif // GAME2181TX_H
