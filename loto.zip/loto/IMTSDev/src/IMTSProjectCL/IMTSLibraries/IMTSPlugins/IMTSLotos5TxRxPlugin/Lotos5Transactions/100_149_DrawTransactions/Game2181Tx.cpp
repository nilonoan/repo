/******************************************************************************
Copyright (C) 2010

Intralot,
64, Kifissias Ave. & 3, Premetis Str.
15125 Athens, Greece
www.intralot.com

All rights reserved

******************************************************************************/
/**
 * @file Game2181Tx.cpp
 * @author: Nondas Masalis masalis@intralot.com
 */

#include "Game2181Tx.h"
#include "Lotos5TxRxFactoryPlugin.h"
#include "ImtsGamesEnums.h"

/** Forces registration */
const Game2181Tx* const Game2181Tx::m_Game2181Tx = new Game2181Tx;


Game2181Tx::Game2181Tx()
{
    static bool bIsProductRegistered = false;

    if ( !bIsProductRegistered ) {
        Lotos5TxRxFactoryPlugin::registerItCssObject(QStringLiteral("Game2181Tx"), this);
        bIsProductRegistered = !bIsProductRegistered;
    }
}

/**
 * @sa createItCss
 * @brief creates and return a product to plugin factory.
 */
ItCssMessagePayloadInterface * Game2181Tx::createItCss() const
{
    return new Game2181Tx;
}

/**
 * @sa setTrnsGm2000Type
 * @brief Initialiazes TRNS_GM_2000 type with data
 * @note we got pick game's play type and translate it to what c/s will understand
 */
void Game2181Tx::setTrnsGm2000Type ( const int& iArea )
{
    int playType=0;

    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Straight") )
            playType+=1;
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Combo") )
            playType+=2;
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Box") )
            playType+=4;
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Pairs") )
            playType+=8;
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("LastDigit") )
            playType+=16;

    m_pTrns_gm_2000->type = playType;

}

/**
 * @sa setTrnsGm2000Value
 * @param the area we are interested in getting the values.
 * @brief Initialiazes TRNS_GM_2000 value with data
 */
void Game2181Tx::setTrnsGm2000Value ( const int& iArea )
{
    int multiplier = 0;
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Straight") ) {
        multiplier =  m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().value(QStringLiteral("Straight")).toInt() ;
        m_pTrns_gm_2000->mult[0] = multiplier / 100;
    } else {
        m_pTrns_gm_2000->mult[0] = 0;
    }
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Combo") ) {
            multiplier =  m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().value(QStringLiteral("Combo")).toInt() ;
            m_pTrns_gm_2000->mult[1] = multiplier / 100;
    } else {
        m_pTrns_gm_2000->mult[1] = 0;
    }
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Box") ) {
            multiplier =  m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().value(QStringLiteral("Box")).toInt() ;
            m_pTrns_gm_2000->mult[2] = multiplier / 100;
    } else {
        m_pTrns_gm_2000->mult[2] = 0;
    }
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("Pairs") ) {
            multiplier =  m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().value(QStringLiteral("Pairs")).toInt() ;
            m_pTrns_gm_2000->mult[3] = multiplier / 100;
    } else {
        m_pTrns_gm_2000->mult[3] = 0;
    }
    if ( m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().contains("LastDigit") ) {
            multiplier =  m_lAreaValues.at(iArea).toMap().value(QStringLiteral("CustomData")).toMap().value(QStringLiteral("LastDigit")).toInt() ;
            m_pTrns_gm_2000->mult[4] = multiplier / 100;
    } else {
        m_pTrns_gm_2000->mult[4] = 0;
    }
}

