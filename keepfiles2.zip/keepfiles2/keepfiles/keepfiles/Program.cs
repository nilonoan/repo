﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;

namespace keepfiles
{
    class Program
    {
        static string g_sDirReadFrom = "";
        static string g_sDirCopyTo = "";

        static void Main(string[] args)
        {
            g_sDirReadFrom = args[0];
            g_sDirCopyTo = args[1];

            DirSearch(g_sDirReadFrom);
        }

        static void DirSearch(string sDirectory)
        {
            string sFileCopyFrom = "";
            string sFileCopyTo = "";
            string sLine = "";
            string[] aFileSelected = new string[] { "loto.tmp", "racha.tmp", "polla.tmp", "xperto.tmp" };
            
            try
            {
                for (int nIndex = 0; nIndex < aFileSelected.Length; nIndex++)
                {
                    string f = sDirectory + @"\" + aFileSelected[nIndex];
                    StreamReader sr = new StreamReader(f);

                    while ((sLine = sr.ReadLine()) != null)
                    {
                        sFileCopyFrom = g_sDirReadFrom + @"\" + sLine.Replace("/", @"\");
                        sFileCopyTo = g_sDirCopyTo + @"\" + aFileSelected[nIndex].Replace(".tmp", "") + @"\" + sLine.Replace("/", @"\");
                        DirCreate(sFileCopyTo.Substring(0, sFileCopyTo.LastIndexOf(@"\")));

                        File.Copy(sFileCopyFrom, sFileCopyTo);
                    }
                }            
            }
            catch (System.Exception eException)
            {
                Console.WriteLine(eException.Message);
            }
        }

        static void DirCreate(string sDirectory)
        {
            try
            {
                char c = '\\';
                string[] sParts = sDirectory.Split(c);
                string sPath = "";

                foreach (string sPart in sParts) {
                    sPath += sPart + @"\";
                    if (!Directory.Exists(sPath)) Directory.CreateDirectory(sPath);
                }
            }
            catch (System.Exception eException)
            {
                Console.WriteLine(eException.Message);
            }
        }
    }
}
